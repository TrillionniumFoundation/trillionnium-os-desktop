#define _GNU_SOURCE
/* New explicit restatement of the required 53 AV predicates and three
 * unnamed transitions. The old Cloud case-source was not recovered.
 * libsepol service functions load only a private userspace database.
 */
#include <sepol/policydb/services.h>
#include <sepol/policydb/policydb.h>
#include <sepol/policydb/hashtab.h>
#include <sepol/policydb/ebitmap.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <unistd.h>
static void need(int ok,const char *why) {
 if(!ok){fprintf(stderr,"fresh policy reconstruction: %s errno=%d\n",why,errno);exit(2);}
}
static int same(const struct stat *a,const struct stat *b) {
 return a->st_dev==b->st_dev && a->st_ino==b->st_ino && a->st_mode==b->st_mode &&
 a->st_uid==b->st_uid && a->st_gid==b->st_gid && a->st_nlink==b->st_nlink && a->st_size==b->st_size &&
 a->st_mtim.tv_sec==b->st_mtim.tv_sec && a->st_mtim.tv_nsec==b->st_mtim.tv_nsec &&
 a->st_ctim.tv_sec==b->st_ctim.tv_sec && a->st_ctim.tv_nsec==b->st_ctim.tv_nsec;
}
static void *complete(const char *path,size_t *size) {
 int fd=open(path,O_RDONLY|O_NOFOLLOW|O_CLOEXEC);need(fd>=0,"open input");
 struct stat a,b,c;
 need(fstat(fd,&a)==0 && S_ISREG(a.st_mode) && a.st_nlink==1 && a.st_uid==getuid() &&
      a.st_size>0 && a.st_size<=16777216,"bounded owned single-link complete input");
 *size=(size_t)a.st_size;char *raw=malloc(*size+1);need(raw!=NULL,"input memory");size_t off=0;
 while(off<*size) {
  ssize_t n=read(fd,raw+off,*size-off);if(n<0 && errno==EINTR)continue;
  need(n>0,"full input read");off+=(size_t)n;
 }
 char extra;need(read(fd,&extra,1)==0 && fstat(fd,&b)==0 && lstat(path,&c)==0 &&
                 same(&a,&b) && same(&a,&c),"input F9 and pathname unchanged");
 need(close(fd)==0,"close input");raw[*size]=0;return raw;
}

struct av_case {const char *id,*source,*target,*class_name,*permissions;int allow;};
static const struct av_case cases[]={
 {"broker_cap_sys_admin","u:r:droidloom_broker:s0","u:r:droidloom_broker:s0","capability","sys_admin",1},
 {"broker_cap_sys_chroot","u:r:droidloom_broker:s0","u:r:droidloom_broker:s0","capability","sys_chroot",1},
 {"broker_cap_mknod","u:r:droidloom_broker:s0","u:r:droidloom_broker:s0","capability","mknod",1},
 {"tmpfs_filesystem_mount","u:r:droidloom_broker:s0","u:object_r:tmpfs:s0","filesystem","mount",1},
 {"tmpfs_filesystem_getattr","u:r:droidloom_broker:s0","u:object_r:tmpfs:s0","filesystem","getattr",1},
 {"droidloom_apex_device_dir_associate","u:object_r:droidloom_apex_device_dir:s0","u:object_r:tmpfs:s0","filesystem","associate",1},
 {"droidloom_apex_loop_control_device_associate","u:object_r:droidloom_apex_loop_control_device:s0","u:object_r:tmpfs:s0","filesystem","associate",1},
 {"droidloom_apex_loop_device_associate","u:object_r:droidloom_apex_loop_device:s0","u:object_r:tmpfs:s0","filesystem","associate",1},
 {"tmpfs_dir_getattr","u:r:droidloom_broker:s0","u:object_r:tmpfs:s0","dir","getattr",1},
 {"tmpfs_dir_search","u:r:droidloom_broker:s0","u:object_r:tmpfs:s0","dir","search",1},
 {"tmpfs_dir_read","u:r:droidloom_broker:s0","u:object_r:tmpfs:s0","dir","read",1},
 {"tmpfs_dir_open","u:r:droidloom_broker:s0","u:object_r:tmpfs:s0","dir","open",1},
 {"tmpfs_dir_write","u:r:droidloom_broker:s0","u:object_r:tmpfs:s0","dir","write",1},
 {"tmpfs_dir_add_name","u:r:droidloom_broker:s0","u:object_r:tmpfs:s0","dir","add_name",1},
 {"tmpfs_dir_remove_name","u:r:droidloom_broker:s0","u:object_r:tmpfs:s0","dir","remove_name",1},
 {"private_dir_create","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_device_dir:s0","dir","create",1},
 {"private_dir_getattr","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_device_dir:s0","dir","getattr",1},
 {"private_dir_search","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_device_dir:s0","dir","search",1},
 {"private_dir_read","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_device_dir:s0","dir","read",1},
 {"private_dir_open","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_device_dir:s0","dir","open",1},
 {"private_dir_write","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_device_dir:s0","dir","write",1},
 {"private_dir_add_name","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_device_dir:s0","dir","add_name",1},
 {"private_dir_remove_name","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_device_dir:s0","dir","remove_name",1},
 {"private_dir_rmdir","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_device_dir:s0","dir","rmdir",1},
 {"control_create","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_control_device:s0","chr_file","create",1},
 {"control_getattr","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_control_device:s0","chr_file","getattr",1},
 {"control_read","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_control_device:s0","chr_file","read",1},
 {"control_write","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_control_device:s0","chr_file","write",1},
 {"control_open","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_control_device:s0","chr_file","open",1},
 {"control_ioctl","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_control_device:s0","chr_file","ioctl",1},
 {"control_unlink","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_control_device:s0","chr_file","unlink",1},
 {"block_create","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_device:s0","blk_file","create",1},
 {"block_getattr","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_device:s0","blk_file","getattr",1},
 {"block_read","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_device:s0","blk_file","read",1},
 {"block_write","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_device:s0","blk_file","write",1},
 {"block_open","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_device:s0","blk_file","open",1},
 {"block_ioctl","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_device:s0","blk_file","ioctl",1},
 {"block_unlink","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_loop_device:s0","blk_file","unlink",1},
 {"apex_mountpoint","u:r:droidloom_broker:s0","u:object_r:apex_mnt_dir:s0","dir","getattr,search,read,open,mounton",1},
 {"system_directory","u:r:droidloom_broker:s0","u:object_r:system_file:s0","dir","getattr,search,read,open",1},
 {"sysfs_loop_directory","u:r:droidloom_broker:s0","u:object_r:sysfs_loop:s0","dir","getattr,search,read,open",1},
 {"sysfs_loop_file","u:r:droidloom_broker:s0","u:object_r:sysfs_loop:s0","file","getattr,read,open",1},
 {"sysfs_symlink","u:r:droidloom_broker:s0","u:object_r:sysfs:s0","lnk_file","getattr,read",1},
 {"broker_socketpair","u:r:droidloom_broker:s0","u:r:droidloom_broker:s0","unix_stream_socket","create,read,write,getattr,getopt,setopt",1},
 {"broker_fork","u:r:droidloom_broker:s0","u:r:droidloom_broker:s0","process","fork",1},
 {"broker_sigkill","u:r:droidloom_broker:s0","u:r:droidloom_broker:s0","process","sigkill",1},
 {"old_control_denied","u:r:droidloom_broker:s0","u:object_r:loop_control_device:s0","chr_file","open,ioctl",0},
 {"old_block_denied","u:r:droidloom_broker:s0","u:object_r:loop_device:s0","blk_file","open,ioctl",0},
 {"dm_char_denied","u:r:droidloom_broker:s0","u:object_r:dm_device:s0","chr_file","open,ioctl",0},
 {"dm_block_denied","u:r:droidloom_broker:s0","u:object_r:dm_device:s0","blk_file","open,ioctl",0},
 {"load_policy_denied","u:r:droidloom_broker:s0","u:r:kernel:s0","security","load_policy",0},
 {"foreign_init_block_denied","u:r:init:s0","u:object_r:droidloom_apex_loop_device:s0","blk_file","getattr,read,write,open,ioctl",0},
 {"broker_fscreate_denied","u:r:droidloom_broker:s0","u:r:droidloom_broker:s0","process","setfscreate",0},
 {"host_proc_mount","u:r:droidloom_broker:s0","u:object_r:proc:s0","filesystem","mount",1},
 {"host_proc_getattr","u:r:droidloom_broker:s0","u:object_r:proc:s0","filesystem","getattr",1},
 {"guest_userns_sys_admin","u:r:droidloom_broker:s0","u:r:droidloom_broker:s0","cap_userns","sys_admin",1},
 {"guest_userns_sys_ptrace","u:r:droidloom_broker:s0","u:r:droidloom_broker:s0","cap_userns","sys_ptrace",1},
 {"initial_userns_sys_ptrace_denied","u:r:droidloom_broker:s0","u:r:droidloom_broker:s0","capability","sys_ptrace",0},
 {"original_init_attach_ptrace","u:r:droidloom_broker:s0","u:r:init:s0","process","ptrace",1},
 {"private_context_control_create","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_device:s0","chr_file","create",1},
 {"private_context_control_getattr","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_device:s0","chr_file","getattr",1},
 {"private_context_control_open","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_device:s0","chr_file","open",1},
 {"private_context_control_read","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_device:s0","chr_file","read",1},
 {"private_context_control_ioctl","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_device:s0","chr_file","ioctl",1},
 {"private_context_directory_create","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_dir:s0","dir","create",1},
 {"private_context_directory_getattr","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_dir:s0","dir","getattr",1},
 {"private_context_directory_open","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_dir:s0","dir","open",1},
 {"private_context_directory_read","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_dir:s0","dir","read",1},
 {"private_context_directory_search","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_dir:s0","dir","search",1},
 {"private_context_directory_write","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_dir:s0","dir","write",1},
 {"private_context_directory_add_name","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_dir:s0","dir","add_name",1},
 {"private_context_control_associate","u:object_r:droidloom_lsm_context_device:s0","u:object_r:tmpfs:s0","filesystem","associate",1},
 {"private_context_directory_associate","u:object_r:droidloom_lsm_context_dir:s0","u:object_r:tmpfs:s0","filesystem","associate",1},
 {"private_context_control_mutations_denied","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_device:s0","chr_file","write,setattr,unlink,relabelfrom,relabelto",0},
 {"private_context_directory_retire_mutations_denied","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_dir:s0","dir","setattr,remove_name,rmdir,relabelfrom,relabelto",0},
 {"foreign_init_control_denied","u:r:init:s0","u:object_r:droidloom_lsm_context_device:s0","chr_file","create,getattr,read,open,ioctl",0},
 {"foreign_init_directory_denied","u:r:init:s0","u:object_r:droidloom_lsm_context_dir:s0","dir","create,read,open,search,write,add_name",0},
 {"wrong_control_file_kind_denied","u:r:droidloom_broker:s0","u:object_r:droidloom_lsm_context_device:s0","file","create,getattr,read,open",0}
};
struct transition_case {const char *id,*source,*target,*class_name,*expected;};
static const struct transition_case transitions[]={
 {"unnamed_tmpfs_dir","u:r:droidloom_broker:s0","u:object_r:tmpfs:s0","dir","u:object_r:tmpfs:s0"},
 {"unnamed_private_char","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_device_dir:s0","chr_file","u:object_r:droidloom_apex_device_dir:s0"},
 {"unnamed_private_block","u:r:droidloom_broker:s0","u:object_r:droidloom_apex_device_dir:s0","blk_file","u:object_r:droidloom_apex_loop_device:s0"}
};
static sepol_security_id_t sid(const char *context) {
 sepol_security_id_t value=0;
 need(sepol_context_to_sid(context,strlen(context)+1,&value)==0 && value!=0,"real fixed context");
 return value;
}
static sepol_security_class_t class_id(const char *name) {
 sepol_security_class_t value=0;
 need(sepol_string_to_security_class(name,&value)==0 && value!=0,"actual policy class");
 return value;
}

static uint32_t type_value(policydb_t *p,const char *name) {
 type_datum_t *v=hashtab_search(p->p_types.table,name);
 need(v && v->flavor==TYPE_TYPE && v->s.value>0 && v->s.value<=p->p_types.nprim,"actual concrete type ID");
 return v->s.value;
}
static uint32_t class_value(policydb_t *p,const char *name) {
 class_datum_t *v=hashtab_search(p->p_classes.table,name);
 need(v && v->s.value>0,"actual parsed class ID");return v->s.value;
}
static void named_transition(policydb_t *p,const char *parent,const char *class_name,const char *name,const char *output) {
 uint32_t source=type_value(p,"droidloom_broker"),foreign=type_value(p,"init");
 filename_trans_key_t k={.ttype=type_value(p,parent),.tclass=class_value(p,class_name),.name=(char *)name};
 filename_trans_datum_t *d=hashtab_search(p->filename_trans,(hashtab_key_t)&k);
 need(d && d->next==NULL && d->otype==type_value(p,output) &&
      ebitmap_cardinality(&d->stypes)==1 && ebitmap_get_bit(&d->stypes,source-1) &&
      !ebitmap_get_bit(&d->stypes,foreign-1),"exact named automatic transition with sole original broker source");
 k.name="p4-not-the-fixed-control-name";
 need(hashtab_search(p->filename_trans,(hashtab_key_t)&k)==NULL,"unpublished name cannot use private transition");
}
static int member(policydb_t *p,uint32_t concrete,uint32_t key) {
 need(concrete>0 && key>0 && concrete<=p->p_types.nprim && key<=p->p_types.nprim && p->type_attr_map,
      "complete actual type/attribute expansion");
 return key==concrete || ebitmap_get_bit(&p->type_attr_map[concrete-1],key-1);
}
static void full_private_xperms(policydb_t *p,const char *output) {
 unsigned char bits[65536]={0};
 uint32_t source=type_value(p,"droidloom_broker"),target=type_value(p,"droidloom_lsm_context_device");
 uint32_t cls=class_value(p,"chr_file");unsigned matched=0,allowed=0;
 for(uint32_t bucket=0;bucket<p->te_avtab.nslot;bucket++) {
  for(avtab_ptr_t n=p->te_avtab.htable[bucket];n;n=n->next) {
   if(!(n->key.specified&AVTAB_XPERMS_ALLOWED) || n->key.target_class!=cls ||
      !member(p,source,n->key.source_type) || !member(p,target,n->key.target_type)) continue;
   need(n->key.specified==AVTAB_XPERMS_ALLOWED && n->datum.xperms,
        "unconditional exact allowed extended permission entry");matched++;
   avtab_extended_perms_t *x=n->datum.xperms;
   need(x->specified==AVTAB_XPERMS_IOCTLFUNCTION || x->specified==AVTAB_XPERMS_IOCTLDRIVER,
        "only actual ioctl function/driver formats");
   for(unsigned bit=0;bit<256;bit++) if(x->perms[bit/32]&(UINT32_C(1)<<(bit%32))) {
    if(x->specified==AVTAB_XPERMS_IOCTLFUNCTION)bits[((unsigned)x->driver<<8)|bit]=1;
    else for(unsigned lo=0;lo<256;lo++)bits[(bit<<8)|lo]=1;
   }
  }
 }
 need(matched>0,"actual explicit ioctl extended permission records");
 for(unsigned code=0;code<65536;code++) {
  unsigned expected=code==0xb701 || code==0xb702;
  need(bits[code]==expected,"complete ioctl matrix differs from the two fixed commands");
  allowed+=bits[code];
 }
 int fd=open(output,O_WRONLY|O_CREAT|O_EXCL|O_CLOEXEC|O_NOFOLLOW,0600);
 need(fd>=0,"exclusive full decoded matrix output");
 size_t off=0;while(off<sizeof(bits)) {
  ssize_t n=write(fd,bits+off,sizeof(bits)-off);if(n<0 && errno==EINTR)continue;
  need(n>0,"complete matrix write");off+=(size_t)n;
 }
 need(fsync(fd)==0 && close(fd)==0,"complete durable matrix output");
 printf("\"xperm_matrix\":{\"entries_matched\":%u,\"commands_examined\":65536,\"allowed_count\":%u,\"allowed\":[46849,46850],\"decoded_bytes\":65536,\"exact\":true}",matched,allowed);
}

int main(int argc,char **argv) {
 struct rlimit memory={536870912,536870912},cpu={60,60};
 need(setrlimit(RLIMIT_AS,&memory)==0 && setrlimit(RLIMIT_CPU,&cpu)==0,"bounded private query");
 need(argc==3,"exact complete policy and new decoded matrix output arguments");size_t bytes=0;void *raw=complete(argv[1],&bytes);
 policydb_t checked;need(policydb_init(&checked)==0,"private complete binary parser");
 policy_file_t input;policy_file_init(&input);input.type=PF_USE_MEMORY;input.data=raw;input.len=bytes;
 need(policydb_read(&checked,&input,0)==0 && input.len==0,"complete binary without trailing data");
 need(checked.policyvers==30 && checked.mls==1 && checked.handle_unknown==DENY_UNKNOWN &&
      checked.policy_type==POLICY_KERN && checked.target_platform==SEPOL_TARGET_SELINUX &&
      checked.p_bools.nprim==0 && checked.cond_list==NULL,"fixed nonconditional binary policy");
 need(sepol_load_policy(raw,bytes)==0,"private userspace policy load");free(raw);
 _Static_assert(sizeof(cases)/sizeof(cases[0])==78,"fixed original plus new AV cases");
 _Static_assert(sizeof(transitions)/sizeof(transitions[0])==3,"3 transition cases");
 unsigned passed=0;uint32_t seq=0;
 puts("{\"schema\":\"p4-new-private-control-host-provider-offline-decisions-v1\",\"original_case_source_recovered\":false,\"kernel_policy_operations\":0,\"cases\":[");
 for(size_t i=0;i<sizeof(cases)/sizeof(cases[0]);i++) {
  const struct av_case *c=&cases[i];sepol_security_class_t cl=class_id(c->class_name);
  char *list=strdup(c->permissions),*save=NULL;need(list!=NULL,"bounded permission list");
  sepol_access_vector_t requested=0;
  for(char *p=strtok_r(list,",",&save);p;p=strtok_r(NULL,",",&save)) {
   sepol_access_vector_t bit=0;need(sepol_string_to_av_perm(cl,p,&bit)==0 && bit!=0 &&
                                   (bit&(bit-1))==0 && !(requested&bit),"actual distinct fixed permission");
   requested|=bit;
  }
  free(list);need(requested!=0,"nonempty decision");
  struct sepol_av_decision observed={0};
  need(sepol_compute_av(sid(c->source),sid(c->target),cl,requested,&observed)==0,"actual private AV decision");
  if(i==0)seq=observed.seqno;
  need(observed.seqno==seq && (observed.decided&requested)==requested,"same complete private decision epoch");
  int pass=c->allow?(observed.allowed&requested)==requested:(observed.allowed&requested)==0;passed+=(unsigned)pass;
  printf("{\"id\":\"%s\",\"source\":\"%s\",\"target\":\"%s\",\"class\":\"%s\",\"permissions\":\"%s\",\"expected_allowed\":%s,\"requested\":%u,\"allowed\":%u,\"decided\":%u,\"sequence\":%u,\"pass\":%s},\n",
    c->id,c->source,c->target,c->class_name,c->permissions,c->allow?"true":"false",requested,observed.allowed,observed.decided,observed.seqno,pass?"true":"false");
 }
 for(size_t i=0;i<sizeof(transitions)/sizeof(transitions[0]);i++) {
  const struct transition_case *c=&transitions[i];sepol_security_id_t value=0;char *context=NULL;size_t len=0;
  need(sepol_transition_sid(sid(c->source),sid(c->target),class_id(c->class_name),&value)==0 &&
       sepol_sid_to_context(value,&context,&len)==0 && context && len>0 &&
       strlen(context)+1==len,"complete unnamed automatic transition");
  int pass=!strcmp(context,c->expected);passed+=(unsigned)pass;
  printf("{\"id\":\"%s\",\"source\":\"%s\",\"target\":\"%s\",\"class\":\"%s\",\"expected\":\"%s\",\"actual\":\"%s\",\"pass\":%s}%s\n",
   c->id,c->source,c->target,c->class_name,c->expected,context,pass?"true":"false",i==2?"":",");
  free(context);
 }
 unsigned total=(unsigned)(sizeof(cases)/sizeof(cases[0])+sizeof(transitions)/sizeof(transitions[0]));
 printf("],\"passed\":%u,\"total\":%u,",passed,total);
 named_transition(&checked,"tmpfs","dir","droidloom-context","droidloom_lsm_context_dir");
 named_transition(&checked,"droidloom_lsm_context_dir","chr_file","p4_lsm_context","droidloom_lsm_context_device");
 printf("\"named_transitions\":{\"exact\":2,\"sole_creator_broker\":true,\"wrong_name_denied\":true,\"foreign_init_excluded\":true},");
 full_private_xperms(&checked,argv[2]);
 puts(",\"runtime_qualified\":false,\"production_ready\":false}");
 policydb_destroy(&checked);
 return passed==total?0:2;
}
