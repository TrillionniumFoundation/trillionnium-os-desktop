import os,sys,stat,json,hashlib,subprocess,time,datetime,resource,traceback
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));os.sched_setaffinity(0,{18})
B=Path('/home/qq/work/p4-broker-mac-provider-20261118-162b-r1')
D=B/'private-control-policy-r1';D.mkdir(mode=0o700)
START=time.monotonic();ENV={'PATH':'/usr/bin:/bin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'}
def f9(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def pin(p):
 p=Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  a=os.fstat(fd);assert stat.S_ISREG(a.st_mode) and a.st_nlink==1 and 0<=a.st_size<=16777216
  h=hashlib.sha256();count=0
  while count<a.st_size:
   part=os.read(fd,min(1048576,a.st_size-count));assert part;h.update(part);count+=len(part)
  assert os.read(fd,1)==b'' and f9(a)==f9(os.fstat(fd))==f9(os.lstat(p))
  return {'path':str(p),'bytes':count,'sha256':h.hexdigest(),'f9':f9(a)}
 finally:os.close(fd)
def write(p,b):
 if isinstance(b,str):b=b.encode()
 fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_WRONLY|os.O_CLOEXEC,0o600)
 try:
  with os.fdopen(fd,'wb',closefd=False) as f:f.write(b);f.flush();os.fsync(f.fileno())
 finally:os.close(fd)
 return pin(p)
def js(p,obj):return write(p,json.dumps(obj,sort_keys=True,indent=2)+'\n')
report={'schema':'p4-private-control-host-policy-execution-v1','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'base_policy_sha256':'f0f9448e374771bdacd8fe4ecdc861b8e2a3d8f01970b976f4fed412e3c52d09',
 'original_authored_R9_source_recovered':False,'kernel_policy_operations':0,
 'final_vendor_composed':False,'live_mac_verified':False,'apparmor_profile_source_verified':False,
 'runtime_qualified':False,'production_ready':False,'steps':[]}
def run(name,args,timeout=100):
 assert time.monotonic()-START<540,'fixed total execution budget'
 cp=subprocess.run([str(x) for x in args],env=ENV,capture_output=True,timeout=min(timeout,max(1,int(540-(time.monotonic()-START)))))
 row={'name':name,'argv':[str(x) for x in args],'exit':cp.returncode,
      'stdout':write(D/(name+'.stdout'),cp.stdout),'stderr':write(D/(name+'.stderr'),cp.stderr)}
 report['steps'].append(row);return cp
try:
 cg=Path('/proc/self/cgroup').read_text().strip().split('::',1)[1];C=Path('/sys/fs/cgroup'+cg)
 limits={n:(C/n).read_text().strip() for n in ['memory.max','cpu.max']}
 assert limits=={'memory.max':'536870912','cpu.max':'100000 100000'}
 available=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 report['admission']={'mem_available':available,'required':23622320128,'limits':limits,'affinity':sorted(os.sched_getaffinity(0))}
 js(D/'admission.json',report['admission']);assert available>=23622320128
 expected={
  B/'recorded-effective-policy.cil':'840049b5d0fb6b6a95123f9258ef96dd6efcb60bd4459bfae85a20f1eb1597cc',
  B/'strict-source-reconstruction-r1/official-and-private-assertions.cil':'f03326dd8d23dae0368a0569d17961a1fb13db969f07c1430c07caf1836dfc4c',
  B/'strict-source-reconstruction-r1/strict-rebuilt.policy':'f0f9448e374771bdacd8fe4ecdc861b8e2a3d8f01970b976f4fed412e3c52d09',
  B/'private-control-host-delta-r1.cil':'92fccaebf3a1a8ab2980a6aabcfdeefab60f9997cac41097946d2c9a28256929',
  B/'query_private_control_policy_r1.c':'602d6d76f27fa1f88856763cac081d718f5f90e631fbd00c2e5d41a5067c5c2e',
  B/'policy_roundtrip_tool':'f6f7521fc2d476112d6c98c8d3b9175054a20ce0f8b514a11a637fb991baee25',
  B/'policy_roundtrip_tool.c':'ed010cdd7e04ae907b46e0d94ec5975707a58db87d76366229a595e0b21050f6',
  B/'source/libsepol/src/libsepol.a':'e46408d19036f30310e31d51cc723b201aec9c529bc2183fcb261ab2761d40e1',
  Path('/usr/bin/x86_64-linux-gnu-gcc-15'):'b5f1b773a7c733738352000c92a077dc5852a1a2fc6d836b1e411be1e9ec5f88',
 }
 report['inputs']=[pin(p) for p in expected]
 for row in report['inputs']:assert row['sha256']==expected[Path(row['path'])],row
 headers=sorted((B/'source/libsepol/include').rglob('*.h'))
 assert 30<=len(headers)<=500
 report['exact_public_headers']=[pin(p) for p in headers]
 base=[B/'recorded-effective-policy.cil',B/'strict-source-reconstruction-r1/official-and-private-assertions.cil',B/'private-control-host-delta-r1.cil']
 compiler=B/'policy_roundtrip_tool';policy=D/'strict-host-private-control.policy'
 cp=run('strict-positive',[compiler,'compile',policy,*base],120);assert cp.returncode==0,'new strict composition failed'
 report['policy']=pin(policy)
 cc=Path('/usr/bin/x86_64-linux-gnu-gcc-15')
 cp=run('query-compile',[cc,'-std=c11','-O2','-Wall','-Wextra','-Werror','-I'+str(B/'source/libsepol/include'),
             B/'query_private_control_policy_r1.c',B/'source/libsepol/src/libsepol.a','-o',D/'query'],120)
 assert cp.returncode==0,'new exact-header query compile failed';report['query_binary']=pin(D/'query')
 cp=run('query-positive',[D/'query',policy,D/'private-control-ioctl-matrix.bin'],60)
 assert cp.returncode==0,'new complete policy decisions failed'
 i=cp.stdout.find(b'{');assert 0<=i<=2048
 q=json.loads(cp.stdout[i:]);assert q['passed']==q['total']==81 and q['named_transitions']['exact']==2 and q['xperm_matrix']['exact']
 report['query']=q;report['decoded_ioctl_matrix']=pin(D/'private-control-ioctl-matrix.bin')
 decoded=(D/'private-control-ioctl-matrix.bin').read_bytes()
 assert len(decoded)==65536 and [i for i,x in enumerate(decoded) if x]==[0xb701,0xb702] and set(decoded)<={0,1}
 negatives={
  'initial-sys-ptrace':'(allow droidloom_broker self (capability (sys_ptrace)))\n',
  'wrong-control-ioctl':'(allowx droidloom_broker droidloom_lsm_context_device (ioctl chr_file (0xb703)))\n',
  'foreign-control-open':'(allow init droidloom_lsm_context_device (chr_file (open)))\n',
  'control-write':'(allow droidloom_broker droidloom_lsm_context_device (chr_file (write)))\n',
  'control-relabel':'(allow droidloom_broker droidloom_lsm_context_device (chr_file (relabelto)))\n',
  'foreign-directory-search':'(allow init droidloom_lsm_context_dir (dir (search)))\n',
  'wrong-file-kind':'(allow droidloom_broker droidloom_lsm_context_device (file (open)))\n',
  'directory-rmdir':'(allow droidloom_broker droidloom_lsm_context_dir (dir (rmdir)))\n',
 }
 report['strict_negative_controls']=[]
 for name,text in negatives.items():
  src=D/('negative-'+name+'.cil');srcpin=write(src,text);out=D/('negative-'+name+'.policy')
  cp=run('negative-'+name,[compiler,'compile',out,*base,src],100)
  assert cp.returncode!=0 and not out.exists(),'negative unexpectedly generated usable policy'
  assert b'neverallow' in cp.stderr.lower(),'negative did not actually exercise neverallow'
  report['strict_negative_controls'].append({'name':name,'input':srcpin,'exit':cp.returncode,'neverallow_failure':True,'output_absent':True})
 report['inputs_after']=[pin(p) for p in expected];assert report['inputs_after']==report['inputs']
 report['headers_after']=[pin(p) for p in headers];assert report['headers_after']==report['exact_public_headers']
 report['input_bookends_equal']=True;report['status']='pass'
except BaseException as e:
 report['status']='failed';report['failure']=str(e);write(D/'failure.txt',traceback.format_exc())
finally:
 report['elapsed_seconds']=time.monotonic()-START
 result=js(D/'RESULT.json',report)
 print(json.dumps({'result':result,'status':report['status'],'policy':report.get('policy'),'cases':report.get('query',{}).get('passed'),'negative_count':len(report.get('strict_negative_controls',[]))},sort_keys=True),flush=True)
sys.exit(0 if report['status']=='pass' else 1)
