#define _GNU_SOURCE
/* Fresh reconstruction tool. Exact new public libsepol headers/library only.
 * Export preserves the binary's effective policy; it cannot recover original
 * neverallow source. Official source assertions are supplied separately.
 */
#include <sepol/kernel_to_cil.h>
#include <sepol/policydb.h>
#include <sepol/policydb/policydb.h>
#include <cil/cil.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <unistd.h>

static void need(int ok,const char *why) {
 if(!ok){fprintf(stderr,"fresh policy reconstruction: %s errno=%d\n",why,errno);exit(2);}
}
static int same(const struct stat *a,const struct stat *b) {
 return a->st_dev==b->st_dev && a->st_ino==b->st_ino && a->st_mode==b->st_mode &&
 a->st_uid==b->st_uid && a->st_gid==b->st_gid && a->st_nlink==b->st_nlink && a->st_size==b->st_size &&
 a->st_mtim.tv_sec==b->st_mtim.tv_sec && a->st_mtim.tv_nsec==b->st_mtim.tv_nsec &&
 a->st_ctim.tv_sec==b->st_ctim.tv_sec && a->st_ctim.tv_nsec==b->st_ctim.tv_nsec;
}
static void *complete(const char *path,size_t *size) {
 int fd=open(path,O_RDONLY|O_NOFOLLOW|O_CLOEXEC);need(fd>=0,"open input");
 struct stat a,b,c;
 need(fstat(fd,&a)==0 && S_ISREG(a.st_mode) && a.st_nlink==1 && a.st_uid==getuid() &&
      a.st_size>0 && a.st_size<=16777216,"bounded owned single-link complete input");
 *size=(size_t)a.st_size;char *raw=malloc(*size+1);need(raw!=NULL,"input memory");size_t off=0;
 while(off<*size) {
  ssize_t n=read(fd,raw+off,*size-off);if(n<0 && errno==EINTR)continue;
  need(n>0,"full input read");off+=(size_t)n;
 }
 char extra;need(read(fd,&extra,1)==0 && fstat(fd,&b)==0 && lstat(path,&c)==0 &&
                 same(&a,&b) && same(&a,&c),"input F9 and pathname unchanged");
 need(close(fd)==0,"close input");raw[*size]=0;return raw;
}
static FILE *new_output(const char *path) {
 int fd=open(path,O_CREAT|O_EXCL|O_NOFOLLOW|O_WRONLY|O_CLOEXEC,0600);need(fd>=0,"exclusive output");
 FILE *f=fdopen(fd,"wb");need(f!=NULL,"output stream");return f;
}
static void finish(FILE *f) {
 need(fflush(f)==0 && fsync(fileno(f))==0 && fclose(f)==0,"complete output publication");
}
int main(int argc,char **argv) {
 struct rlimit memory={536870912,536870912},cpu={300,300},files={67108864,67108864};
 need(setrlimit(RLIMIT_AS,&memory)==0 && setrlimit(RLIMIT_CPU,&cpu)==0 &&
      setrlimit(RLIMIT_FSIZE,&files)==0,"fixed small reconstruction budget");
 need(argc>=4,"export input output or compile output complete_inputs");
 if(!strcmp(argv[1],"export")) {
  need(argc==4,"exact export arguments");size_t size;void *raw=complete(argv[2],&size);
  policydb_t p;need(policydb_init(&p)==0,"private policydb");
  policy_file_t input;policy_file_init(&input);input.type=PF_USE_MEMORY;input.data=raw;input.len=size;
  need(policydb_read(&p,&input,0)==0 && input.len==0,"complete supported binary policy");
  free(raw);
  need(p.policy_type==POLICY_KERN && p.target_platform==SEPOL_TARGET_SELINUX &&
       p.policyvers==30 && p.mls==1 && p.handle_unknown==DENY_UNKNOWN,"fixed binary policy properties");
  FILE *out=new_output(argv[3]);
  need(sepol_kernel_policydb_to_cil(out,&p)==0,"actual official binary-to-CIL exporter");
  finish(out);policydb_destroy(&p);
  printf("{\"mode\":\"export\",\"input_bytes\":%zu,\"original_assertions_recovered\":false,\"kernel_policy_operations\":0}\n",size);
  return 0;
 }
 need(!strcmp(argv[1],"compile") && argc<=32,"bounded strict compile arguments");
 cil_db_t *db=NULL;cil_db_init(&db);need(db!=NULL,"private CIL database");
 cil_set_multiple_decls(db,1);cil_set_disable_neverallow(db,0);cil_set_mls(db,1);
 cil_set_attrs_expand_generated(db,1);cil_set_target_platform(db,SEPOL_TARGET_SELINUX);
 cil_set_policy_version(db,30);need(cil_set_handle_unknown(db,SEPOL_DENY_UNKNOWN)==0,"unknown permissions denied");
 size_t total=0;
 for(int i=3;i<argc;i++) {
  size_t size;void *raw=complete(argv[i],&size);total+=size;
  need(total<=33554432,"bounded total complete CIL bytes");
  need(cil_add_file(db,argv[i],raw,size)==0,"add complete source CIL");
  free(raw);
 }
 need(cil_compile(db)==0,"strict CIL compile with neverallow enabled");
 sepol_policydb_t *policy=NULL;
 need(cil_build_policydb(db,&policy)==0 && policy!=NULL,"strict binary build with neverallow enabled");
 void *raw=NULL;size_t size=0;
 need(sepol_policydb_to_image(NULL,policy,&raw,&size)==0 && size>0 && size<=67108864,"complete binary serialization");
 FILE *out=new_output(argv[2]);need(fwrite(raw,1,size,out)==size,"full binary output");finish(out);
 free(raw);sepol_policydb_free(policy);cil_db_destroy(&db);
 printf("{\"mode\":\"compile\",\"source_count\":%d,\"input_bytes\":%zu,\"output_bytes\":%zu,\"neverallow_enabled\":true,\"kernel_policy_operations\":0}\n",argc-3,total,size);
 return 0;
}
