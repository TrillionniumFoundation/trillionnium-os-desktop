import os,sys,stat,json,hashlib,subprocess,time,datetime,resource,traceback
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));os.sched_setaffinity(0,{18})
B=Path('/home/qq/work/p4-broker-mac-provider-20261118-162b-r1')
D=B/'private-control-query-negatives-r1';D.mkdir(mode=0o700)
START=time.monotonic();ENV={'PATH':'/usr/bin:/bin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'}
def f9(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def pin(p):
 p=Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  a=os.fstat(fd);assert stat.S_ISREG(a.st_mode) and a.st_nlink==1 and 0<=a.st_size<=16777216
  h=hashlib.sha256();count=0
  while count<a.st_size:
   part=os.read(fd,min(1048576,a.st_size-count));assert part;h.update(part);count+=len(part)
  assert os.read(fd,1)==b'' and f9(a)==f9(os.fstat(fd))==f9(os.lstat(p))
  return {'path':str(p),'bytes':count,'sha256':h.hexdigest(),'f9':f9(a)}
 finally:os.close(fd)
def write(p,b):
 if isinstance(b,str):b=b.encode()
 fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_WRONLY|os.O_CLOEXEC,0o600)
 try:
  with os.fdopen(fd,'wb',closefd=False) as f:f.write(b);f.flush();os.fsync(f.fileno())
 finally:os.close(fd)
 return pin(p)
def js(p,obj):return write(p,json.dumps(obj,sort_keys=True,indent=2)+'\n')
report={'schema':'p4-private-control-query-real-policy-negative-controls-v1',
 'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kernel_policy_operations':0,
 'final_vendor_composed':False,'live_mac_verified':False,'runtime_qualified':False,'production_ready':False,'steps':[]}
def run(name,args):
 cp=subprocess.run([str(x) for x in args],env=ENV,capture_output=True,timeout=90)
 row={'name':name,'argv':[str(x) for x in args],'exit':cp.returncode,
      'stdout':write(D/(name+'.stdout'),cp.stdout),'stderr':write(D/(name+'.stderr'),cp.stderr)}
 report['steps'].append(row);return cp
try:
 cg=Path('/proc/self/cgroup').read_text().strip().split('::',1)[1];C=Path('/sys/fs/cgroup'+cg)
 limits={n:(C/n).read_text().strip() for n in ['memory.max','cpu.max']}
 assert limits=={'memory.max':'536870912','cpu.max':'100000 100000'}
 available=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 report['admission']={'mem_available':available,'required':23622320128,'limits':limits,'affinity':sorted(os.sched_getaffinity(0))}
 js(D/'admission.json',report['admission']);assert available>=23622320128
 priorpath=B/'private-control-policy-r1/RESULT.json'
 priorpin=pin(priorpath);assert priorpin['sha256']=='47aa9910f2cade0f7fa3b62fb36541b22e433a487494a6be6a64b14945d078fe'
 prior=json.loads(priorpath.read_bytes());assert prior['status']=='pass'
 expected={Path(x['path']):x['sha256'] for x in prior['inputs']}
 expected[priorpath]=priorpin['sha256'];expected[Path(prior['query_binary']['path'])]=prior['query_binary']['sha256']
 report['inputs']=[pin(p) for p in expected]
 for row in report['inputs']:assert row['sha256']==expected[Path(row['path'])]
 raw=(B/'private-control-host-delta-r1.cil').read_text()
 def replace_one(a,b):
  assert raw.count(a)==1;return raw.replace(a,b)
 variants={
 'missing-get-ioctl':replace_one('(allowx droidloom_broker droidloom_lsm_context_device (ioctl chr_file (0xb701 0xb702)))',
                                '(allowx droidloom_broker droidloom_lsm_context_device (ioctl chr_file (0xb701)))'),
 'wrong-directory-name':replace_one('(typetransition droidloom_broker tmpfs dir "droidloom-context" droidloom_lsm_context_dir)',
                                   '(typetransition droidloom_broker tmpfs dir "droidloom-context-unselected" droidloom_lsm_context_dir)'),
 'missing-guest-ptrace':replace_one('(allow droidloom_broker self (cap_userns (sys_admin sys_ptrace)))',
                                  '(allow droidloom_broker self (cap_userns (sys_admin)))'),
 }
 compiler=B/'policy_roundtrip_tool';query=Path(prior['query_binary']['path'])
 base=[B/'recorded-effective-policy.cil',B/'strict-source-reconstruction-r1/official-and-private-assertions.cil']
 report['negative_controls']=[]
 for name,body in variants.items():
  src=D/(name+'.cil');srcpin=write(src,body);policy=D/(name+'.policy')
  cp=run(name+'-strict-compile',[compiler,'compile',policy,*base,src])
  assert cp.returncode==0,'incomplete-but-valid policy must actually compile with neverallow'
  policypin=pin(policy);matrix=D/(name+'-matrix.bin')
  cp=run(name+'-query',[query,policy,matrix]);assert cp.returncode==2,'query must reject the actual incomplete policy'
  if name=='missing-get-ioctl':
   assert b'complete ioctl matrix differs from the two fixed commands' in cp.stderr and not matrix.exists()
  elif name=='wrong-directory-name':
   assert b'exact named automatic transition with sole original broker source' in cp.stderr and not matrix.exists()
  else:
   i=cp.stdout.find(b'{');assert 0<=i<=2048;q=json.loads(cp.stdout[i:])
   assert q['passed']==80 and q['total']==81 and [x['id'] for x in q['cases'] if not x['pass']]==['guest_userns_sys_ptrace']
   assert q['named_transitions']['exact']==2 and q['xperm_matrix']['exact']
   decoded=matrix.read_bytes();assert len(decoded)==65536 and [i for i,x in enumerate(decoded) if x]==[0xb701,0xb702]
  report['negative_controls'].append({'name':name,'input':srcpin,'policy':policypin,'strict_compile_exit':0,'query_exit':2,
                                      'actual_failure_checked':True})
 report['inputs_after']=[pin(p) for p in expected];assert report['inputs_after']==report['inputs']
 report['input_bookends_equal']=True;report['status']='pass'
except BaseException as e:
 report['status']='failed';report['failure']=str(e);write(D/'failure.txt',traceback.format_exc())
finally:
 report['elapsed_seconds']=time.monotonic()-START
 result=js(D/'RESULT.json',report)
 print(json.dumps({'result':result,'status':report['status'],'negative_count':len(report.get('negative_controls',[]))},sort_keys=True),flush=True)
sys.exit(0 if report['status']=='pass' else 1)
