import os,sys,json,stat,hashlib,zipfile,time,datetime,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));os.sched_setaffinity(0,{18})
A=Path('/home/qq/work/p4-remaining-app-inputs-20261118-162b-r1')
BASE=A/'apk-content-identity-current-r1';D=A/'publisher-delivery-verifier-r1';D.mkdir(mode=0o700)
G=D/'gate';G.mkdir(mode=0o700)
expected=[{"name":"README.md","bytes":8406,"sha256":"fa9cc5b57732bddc41a8f39677ccec83b4256d5dcbd86ec24cccabecc2524028"},{"name":"SOURCE_MANIFEST.json","bytes":3286,"sha256":"6f2a754eec8e42bd4eabcd066dbc183b525300de0b0b6394cbd93be458e29a69"},{"name":"VALIDATION.json","bytes":3419,"sha256":"72993db86f847e1ae574aa03c2ace50ef26dabc9815f514494271b20f5ee569a"},{"name":"axml_metadata.py","bytes":13457,"sha256":"3759ae23233d6909060d591795281e565b447de2ab74e245d244be17a30a8813"},{"name":"controls.py","bytes":3275,"sha256":"2f2e9f9a9aa3e6e6dc7353192505c1a7a96cbf9ef59f7349cb12cf1b846331bf"},{"name":"dual_dynamic_elf.py","bytes":13443,"sha256":"48f7a94d814f5caaa3481db5209bd09e9359c2df5ce461df2043f5fcb1670400"},{"name":"native_publisher_payloads.py","bytes":23457,"sha256":"d5898f62d9d6c70b4cf28f81bacfb359e82a84590ab14b6865d3d19471e370a0"},{"name":"native_resource_payloads.py","bytes":10274,"sha256":"8cb7930d347f2523d5cbac66733c69e173cb6ca3b27e26e64581ac5d5958583d"},{"name":"seven_zip04_payload.py","bytes":9855,"sha256":"f46cf544f0e16a3e973057b37f7ea249f382f4cd6b5911a3d8ed372511706359"},{"name":"test_apk_set.py","bytes":16326,"sha256":"6314ef96cd16a539e9aeaa16ab5030f1a69a2e1d33308f4668fd201d49087fd6"},{"name":"test_candidate.py","bytes":55497,"sha256":"4d4c3e53dbbcfaee7d9fea6a936e57ffdc9607ed193e899037fa3cc07d5e5c32"},{"name":"test_dual_dynamic_elf.py","bytes":11275,"sha256":"b9c28f019e2032f4e92b4d966670b30cd4e35eca3c44691e6ce95c23496cf634"},{"name":"test_mixed_publisher_payloads.py","bytes":7439,"sha256":"e303636376cf03ea659c5c635669100547bd4d18e365101ab8413aa2571b2ec6"},{"name":"test_native_publisher_payloads.py","bytes":14143,"sha256":"fd1a67ecd5f5a40c86a0c16381b72b6f85f16de62a4c783447b422ce5129d0d6"},{"name":"test_native_resource_payloads.py","bytes":17729,"sha256":"35f8c5c4c59deb5df2b6300d3323814be67eb522c38882c4e755ff839e16278d"},{"name":"test_seven_zip04_payload.py","bytes":10899,"sha256":"928c1c063461b8060bc23da1a9e7eced9554c331dbf6c1513744824ee376df2a"},{"name":"test_verify_publisher_apk.py","bytes":21267,"sha256":"db658cf84ca88a0215089b6e2cf3c4ca28caff02b062059ad2d4f7a751bd52f9"},{"name":"verify_apk.py","bytes":43119,"sha256":"cd83cd9beb2479ab01c27f5a1422d2ceb2b4703f3e2632b036f3f0fc4633ce20"},{"name":"verify_apk_set.py","bytes":22828,"sha256":"2f7f862a368fcf1e53f6618b2de21f082afd18a8b42aa09282b85a7026c7738f"},{"name":"verify_publisher_apk.py","bytes":25460,"sha256":"e111691e2da1c51677c8dc50c84e5649e312c986c070bb6ddeb31999bb9e5aad"}]
def f9(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def pinread(p,limit=1048576):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  a=os.fstat(fd);assert stat.S_ISREG(a.st_mode) and a.st_nlink==1 and 0<=a.st_size<=limit
  raw=b''
  while len(raw)<a.st_size:
   b=os.read(fd,min(65536,a.st_size-len(raw)));assert b;raw+=b
  assert os.read(fd,1)==b'' and f9(a)==f9(os.fstat(fd))==f9(p.lstat())
  return raw,{'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'f9':f9(a)}
 finally:os.close(fd)
def write(p,body):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
 try:
  with os.fdopen(fd,'wb',closefd=False) as f:f.write(body);f.flush();os.fsync(f.fileno())
 finally:os.close(fd)
 return pinread(p,max(len(body),1048576))[1]
before=[]
for row in expected:
 raw,pin=pinread(BASE/row['name'])
 assert pin['sha256']==row['sha256'] and pin['bytes']==row['bytes'];before.append(pin)
 write(G/row['name'],raw)
sys.path.insert(0,str(G));import verify_apk_set as sets
live=A/'aurora-wrapper-r1/live-r1'
raw,transport_pin=pinread(live/'TRANSPORT-RESULT.json')
assert transport_pin['sha256']=='3e1fda8f840a38dd3c21a79e076b063352d5d5a194f1ab19d1c5c848828e2b7c'
transport=sets._json(raw);assert transport['transport']['stopped'] is None
packages=[]
for result in transport['results']:
 if result.get('status')!='transport_complete_requires_apk_gate':continue
 pkg=result['package'];mraw,mpin=pinread(live/(pkg+'.metadata.json'));meta=sets._json(mraw)
 traw,tpin=pinread(live/(pkg+'.transport.json'));assert sets._json(traw)==result
 out={'package':pkg,'metadata':meta,'metadata_pin':mpin,'transport_pin':tpin,
      'google_version_name':result['version_name'],'google_version_code':result['version_code'],
      'external_certificates':result['official_signer_certificate_sha256'],'apks':[]}
 for row in result['files']:
  path=Path(row['path']);assert path.parent==live and path.name.startswith('part-') and path.suffix=='.apk'
  with sets._held(path,sets.APK_LIMIT,row) as (file,pin):
   sha1=hashlib.sha1()
   for chunk in iter(lambda:file.read(1048576),b''):sha1.update(chunk)
   assert sha1.hexdigest()==row['sha1']==row['delivery_sha1'] and pin['sha256']==row['delivery_sha256']
   file.seek(0)
   with zipfile.ZipFile(file) as apk:
    entries=sets.safe_members(apk);assert 'AndroidManifest.xml' in entries
    manifest=apk.read(entries['AndroidManifest.xml']);observed=sets.manifest_observation(manifest)
    assert observed['package']==pkg and (observed['version_code_major']<<32)|observed['version_code']==result['version_code']
    if row['role']=='BASE':assert observed['split_name'] is None and observed['version_name']==result['version_name']
    else:assert row['role']=='SPLIT' and observed['split_name'] is not None
    natives=[]
    for name,item in entries.items():
     if name.startswith('lib/'):
      with apk.open(item) as body:header=body.read(20)
      natives.append({'path':name,'bytes':item.file_size,'prefix20':header.hex(),'elf':header.startswith(b'\x7fELF')})
    out['apks'].append({'delivery':row,'input_pin':pin,'manifest':observed,
      'manifest_binary_sha256':hashlib.sha256(manifest).hexdigest(),
      'zip_file_count':len(entries),'zip_declared_expansion_bytes':sum(x.file_size for x in entries.values()),'native_files':natives})
 if len(out['apks'])>1:out['closure']=sets.validate_closure([x['manifest'] for x in out['apks']])
 packages.append(out)
after=[pinread(BASE/row['name'])[1] for row in expected];assert before==after
report={'schema':'p4-publisher-delivery-source-preparation-v1','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'original_gate_sources':before,'original_gate_bookends_equal':True,'original_gate_files':len(before),
 'transport':transport_pin,'packages':packages,'current_metadata_not_copied_from_apk':True,'sdk_verified':False,
 'runtime_qualified':False,'production_ready':False}
made=write(D/'SOURCE-PREPARATION.json',(json.dumps(report,sort_keys=True,indent=2)+'\n').encode())
print(json.dumps({'report':made,'packages':[{'package':x['package'],'version':x['google_version_name'],
  'apk_count':len(x['apks']),'native_files':sum(len(a['native_files']) for a in x['apks']),
  'nonelf':[n for a in x['apks'] for n in a['native_files'] if not n['elf']]} for x in packages]},sort_keys=True))
