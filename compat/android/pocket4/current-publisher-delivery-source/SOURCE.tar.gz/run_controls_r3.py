import os,sys,json,stat,hashlib,subprocess,time,datetime,re
from pathlib import Path
os.sched_setaffinity(0,{18})
D=Path('/home/qq/work/p4-remaining-app-inputs-20261118-162b-r1/publisher-delivery-verifier-r1')
G=D/'gate'; O=D/'controls-r3';O.mkdir(mode=0o700)
def f9(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def pin(p):
 fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:
  a=os.fstat(f.fileno());assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
  h=hashlib.sha256()
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
  assert f9(os.fstat(f.fileno()))==f9(a)==f9(p.lstat())
 return dict(path=str(p),bytes=a.st_size,sha256=h.hexdigest(),f9=f9(a))
def snapshot():return [pin(p) for p in sorted(G.iterdir()) if p.is_file()]
import base64
fixture_dir=D/'current-app-acceptance';fixture_dir.mkdir(mode=0o700)
fixtures=json.loads("[{\"name\":\"firefox-candidate.json\",\"git_blob_sha1\":\"ad8ade876c3c2c6694ae556b742772d2178edb33\",\"source_url\":\"https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/088196e9c761d51da7a4ee5fe0b372aef490bb40/compat/android/pocket4/current-app-acceptance/firefox-candidate.json\",\"body_base64\":\"ewogICJzY2hlbWEiOiAicG9ja2V0NC1vZmZpY2lhbC1hcGstY2FuZGlkYXRlLXYxIiwKICAicGFja2FnZSI6ICJvcmcubW96aWxsYS5maXJlZm94IiwKICAidmVyc2lvbl9uYW1lIjogIjE2MC4wLjEiLAogICJ2ZXJzaW9uX2NvZGUiOiAyMDE2MTk2Njc4LAogICJ2ZXJzaW9uX2NvZGVfbWFqb3IiOiAwLAogICJtaW5fc2RrX3ZlcnNpb24iOiAyNiwKICAidGFyZ2V0X3Nka192ZXJzaW9uIjogMzcsCiAgImFwayI6IHsKICAgICJuYW1lIjogImJhc2UuYXBrIiwKICAgICJieXRlcyI6IDE0MDY4OTkxNSwKICAgICJzaGEyNTYiOiAiMjgzYjE5ZjgzMTNlOGNlNmU4YTkxM2JiMTc4Y2U0YTc5YzVjZWNkODJjNDlmODIxZGU3ZmFmYjA2OGM3M2ZjZCIKICB9LAogICJuYXRpdmVfYWJpcyI6IFsKICAgICJ4ODZfNjQiCiAgXSwKICAic2lnbmVyX2NlcnRpZmljYXRlX3NoYTI1NiI6IFsKICAgICJhNzhiNjJhNTE2NWI0NDk0YjJmZWFkOWU3NmEyODBkMjJkOTM3ZmVlNjI1MWFlY2U1OTk0NDZiMmVhMzE5YjA0IgogIF0sCiAgInNvdXJjZSI6IHsKICAgICJhcGtfdXJsIjogImh0dHBzOi8vZnRwLm1vemlsbGEub3JnL3B1Yi9mZW5peC9yZWxlYXNlcy8xNjAuMC4xL2FuZHJvaWQvZmVuaXgtMTYwLjAuMS1hbmRyb2lkLXg4Nl82NC9mZW5peC0xNjAuMC4xLm11bHRpLmFuZHJvaWQteDg2XzY0LmFwayIsCiAgICAidmVyc2lvbl9tZXRhZGF0YV91cmwiOiAiaHR0cHM6Ly9wcm9kdWN0LWRldGFpbHMubW96aWxsYS5vcmcvMS4wL21vYmlsZV92ZXJzaW9ucy5qc29uIiwKICAgICJwdWJsaXNoZXJfY2VydGlmaWNhdGVfdXJsIjogImh0dHBzOi8vYWNjb3VudHMuZmlyZWZveC5jb20vLndlbGwta25vd24vYXNzZXRsaW5rcy5qc29uIiwKICAgICJvYnNlcnZlZF91dGMiOiAiMjAyNi0xMS0xOFQwODo1MDoxNC43MzI0MTkrMDA6MDAiLAogICAgIm9ic2VydmVkX3N0YWJsZV92ZXJzaW9uIjogIjE2MC4wLjEiLAogICAgInNoYTI1Nl9raW5kIjogIm9ic2VydmVkX3dob2xlX2ZpbGVfZGlnZXN0X25vdF9wdWJsaXNoZXJfcHVibGlzaGVkX2NoZWNrc3VtIgogIH0KfQo=\"},{\"name\":\"szzc-candidate.json\",\"git_blob_sha1\":\"bed565614fffb825493253a15101684a63dffc03\",\"source_url\":\"https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/088196e9c761d51da7a4ee5fe0b372aef490bb40/compat/android/pocket4/current-app-acceptance/szzc-candidate.json\",\"body_base64\":\"ewogICJzY2hlbWEiOiAicG9ja2V0NC1vZmZpY2lhbC1hcGstY2FuZGlkYXRlLXYyIiwKICAicGFja2FnZSI6ICJjb20uc3p6YyIsCiAgInZlcnNpb25fbmFtZSI6ICI5LjYuMyIsCiAgInZlcnNpb25fY29kZSI6IDMyOSwKICAidmVyc2lvbl9jb2RlX21ham9yIjogMCwKICAibWluX3Nka192ZXJzaW9uIjogMjMsCiAgInRhcmdldF9zZGtfdmVyc2lvbiI6IDMzLAogICJhcGsiOiB7CiAgICAibmFtZSI6ICJiYXNlLmFwayIsCiAgICAiYnl0ZXMiOiAyMjA1MjI5OTQsCiAgICAic2hhMjU2IjogIjdhZjQzODgwODkwNGRiZDQ0NTdmOGQ1ZWE3ZTI2N2U1Nzc5ZThhZDZhYjRkNmE5YzE1NmMxZThlYTAyODVkOTYiCiAgfSwKICAibmF0aXZlX2FiaXMiOiBbCiAgICAiYXJtNjQtdjhhIiwKICAgICJhcm1lYWJpLXY3YSIKICBdLAogICJzaWduZXJfY2VydGlmaWNhdGVfc2hhMjU2IjogWwogICAgImQ4NWJlZDRkMmE3YzA4ZTFiNmI1ZjAwOTdkNmM2NmE3OWE1YjEyYjU4ZDk3ZTc5NGQzYjVjNWJmZjJhZWFmNDQiCiAgXSwKICAiY3Jvc3NfYXJjaF9zaGFyZWRfbGlicmFyaWVzIjogWwogICAgewogICAgICAicGF0aCI6ICJsaWIvYXJtNjQtdjhhL2xpYmV4ZWNfeDg2LnNvIiwKICAgICAgImtpbmQiOiAiY3Jvc3NfYXJjaF9zaGFyZWRfbGlicmFyeSIsCiAgICAgICJieXRlcyI6IDY2NzE0NCwKICAgICAgInNoYTI1NiI6ICI3YWQ2MzZhZjgzOGI2MmRhYTdmYjAyYmI0NDA1MDRjNDZiNThkMDMwNDBhZWU0YmRiMTM3YjI2ODZkNWU3Zjg5IiwKICAgICAgImVsZl9jbGFzcyI6IDIsCiAgICAgICJlbGZfbWFjaGluZSI6IDYyLAogICAgICAiZWxmX3R5cGUiOiAzLAogICAgICAic29uYW1lIjogImxpYmV4ZWMuc28iLAogICAgICAiZW50cnlfcG9pbnQiOiAyMjkzMjgsCiAgICAgICJoYXNfaW50ZXJwcmV0ZXIiOiBmYWxzZQogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAibGliL2FybTY0LXY4YS9saWJleGVjbWFpbl94ODYuc28iLAogICAgICAia2luZCI6ICJjcm9zc19hcmNoX3NoYXJlZF9saWJyYXJ5IiwKICAgICAgImJ5dGVzIjogMjExNjE2LAogICAgICAic2hhMjU2IjogIjNmMjBiODIyNTljNmE1M2M1YzI0ZjFhMmNkMTQyZTBkMmRjYzAyODE5NDEyZDMwYWJiZjNkMzJlNmFhOWQ5NzUiLAogICAgICAiZWxmX2NsYXNzIjogMiwKICAgICAgImVsZl9tYWNoaW5lIjogNjIsCiAgICAgICJlbGZfdHlwZSI6IDMsCiAgICAgICJzb25hbWUiOiAibGliZXhlY21haW4uc28iLAogICAgICAiZW50cnlfcG9pbnQiOiAwLAogICAgICAiaGFzX2ludGVycHJldGVyIjogZmFsc2UKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogImxpYi9hcm1lYWJpLXY3YS9saWJleGVjX3g4Ni5zbyIsCiAgICAgICJraW5kIjogImNyb3NzX2FyY2hfc2hhcmVkX2xpYnJhcnkiLAogICAgICAiYnl0ZXMiOiA1NTY4MjQsCiAgICAgICJzaGEyNTYiOiAiZGI0MDE0NWY2N2IwMjE3MDFlZGUzMTIwNTM1N2ZjODFlNjlhNjc4MjVmMDYxYmM5ZDAxZTliZDczOWQ3OWJkNCIsCiAgICAgICJlbGZfY2xhc3MiOiAxLAogICAgICAiZWxmX21hY2hpbmUiOiAzLAogICAgICAiZWxmX3R5cGUiOiAzLAogICAgICAic29uYW1lIjogImxpYmV4ZWMuc28iLAogICAgICAiZW50cnlfcG9pbnQiOiAxODExNjgsCiAgICAgICJoYXNfaW50ZXJwcmV0ZXIiOiBmYWxzZQogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAibGliL2FybWVhYmktdjdhL2xpYmV4ZWNtYWluX3g4Ni5zbyIsCiAgICAgICJraW5kIjogImNyb3NzX2FyY2hfc2hhcmVkX2xpYnJhcnkiLAogICAgICAiYnl0ZXMiOiAxMzI1MjAsCiAgICAgICJzaGEyNTYiOiAiZjhhMzU1MTRkNzNiNDFmYTA3ODE5NDhkMTY0YjdlNWIxZDBiMzhhM2Q0ZWU3YTlmNDMyODhiODkxMzQ0ZDE0YyIsCiAgICAgICJlbGZfY2xhc3MiOiAxLAogICAgICAiZWxmX21hY2hpbmUiOiAzLAogICAgICAiZWxmX3R5cGUiOiAzLAogICAgICAic29uYW1lIjogImxpYmV4ZWNtYWluLnNvIiwKICAgICAgImVudHJ5X3BvaW50IjogMCwKICAgICAgImhhc19pbnRlcnByZXRlciI6IGZhbHNlCiAgICB9CiAgXSwKICAic291cmNlIjogewogICAgImFwa191cmwiOiAiaHR0cHM6Ly9zdGF0aWMuenVjaGVjZG4uY29tL2Rvd25sb2FkL1NaWkMuYXBrIiwKICAgICJ2ZXJzaW9uX21ldGFkYXRhX3VybCI6ICJodHRwczovL3N0YXRpYy56dWNoZWNkbi5jb20vZG93bmxvYWQvU1paQy5hcGsiLAogICAgInZlcnNpb25fbWV0YWRhdGFfa2luZCI6ICJzaWduZWRfYXBrX2FuZHJvaWRfbWFuaWZlc3QiLAogICAgInNpZ25lcl9yZWZlcmVuY2VfdXJsIjogImh0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbS9UcmlsbGlvbm5pdW1Gb3VuZGF0aW9uL3RyaWxsaW9ubml1bS1vcy1kZXNrdG9wLzZmZDdlZmRjZmEyN2RhMjAxNWI3ZWI1YjEwM2RjMzk5NDkxYWExOGYvY29tcGF0L2FuZHJvaWQvcG9ja2V0NC9jb250aW51YXRpb24tMjAyNjExMDktZTNkZi9hcHBsaWNhdGlvbi1jYW5kaWRhdGVzL0NBTkRJREFURTQyLmpzb24iLAogICAgInNpZ25lcl9yZWZlcmVuY2Vfa2luZCI6ICJwdWJsaWNfaGlzdG9yaWNhbF9jYW5kaWRhdGUiLAogICAgIm9ic2VydmVkX3V0YyI6ICIyMDI2LTExLTE4VDA5OjE1OjE0LjM1NTQ2OCswMDowMCIsCiAgICAib2JzZXJ2ZWRfc3RhYmxlX3ZlcnNpb24iOiAiOS42LjMiLAogICAgInNoYTI1Nl9raW5kIjogIm9ic2VydmVkX3dob2xlX2ZpbGVfZGlnZXN0IgogIH0KfQo=\"}]")
fixture_pins=[]
for f in fixtures:
 body=base64.b64decode(f['body_base64'],validate=True)
 assert hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==f['git_blob_sha1']
 path=fixture_dir/f['name']
 with path.open('xb') as output:output.write(body)
 fixture_pins.append({'source_url':f['source_url'],'git_blob_sha1':f['git_blob_sha1'],**pin(path)})
(D/'fixture-source-receipt-r1.json').write_text(json.dumps(fixture_pins,sort_keys=True,indent=2)+'\n')
start=snapshot()
prepared=json.loads((D/'SOURCE-PREPARATION.json').read_bytes())
old=[]
for expected in prepared['original_gate_sources']:
 p=Path(expected['path']);got=pin(p);assert got==expected
 copied=pin(G/p.name);assert (got['bytes'],got['sha256'])==(copied['bytes'],copied['sha256'])
 old.append(got)
cg=Path('/sys/fs/cgroup')/Path(Path('/proc/self/cgroup').read_text().split('0::',1)[1].strip()).relative_to('/')
resource={n:(cg/n).read_text().strip() for n in ('memory.max','memory.swap.max','cpu.max')}
resource['actual_cpu_affinity']=sorted(os.sched_getaffinity(0))
assert resource['memory.max']=='1073741824' and resource['memory.swap.max']=='0'
assert resource['cpu.max'].split()==['100000','100000'] and set(os.sched_getaffinity(0))=={18}
counts={'test_candidate.py':41,'test_dual_dynamic_elf.py':9,'test_native_resource_payloads.py':20,'test_apk_set.py':14,'test_native_publisher_payloads.py':22,'test_verify_publisher_apk.py':20,'test_seven_zip04_payload.py':13,'test_mixed_publisher_payloads.py':7,'test_publisher_delivery.py':39}
results=[]
for name,count in counts.items():
 begun=time.monotonic();r=subprocess.run(['/usr/bin/python3','-I','-B',str(G/name)],cwd=G,env={'PATH':'/usr/bin:/bin','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 (O/(name+'.stdout')).write_bytes(r.stdout);(O/(name+'.stderr')).write_bytes(r.stderr)
 text=r.stderr.decode('utf-8','replace');m=re.findall(r'Ran (\d+) tests?',text);observed=int(m[-1]) if m else None
 item=dict(name=name,expected_tests=count,observed_tests=observed,exit_code=r.returncode,elapsed_seconds=time.monotonic()-begun,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest(),passed=r.returncode==0 and observed==count and text.rstrip().endswith('OK'))
 results.append(item);print(json.dumps(item),flush=True)
last=snapshot();same=last==start
old_after=[pin(Path(p['path'])) for p in old]
receipt={'schema':'pocket4-publisher-delivery-controls-v1','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'resource':resource,'source_before':start,'source_after':last,'source_bookends_equal':same,'original_20_files_unchanged':old==old_after,'tests':results,'expected_old_controls':146,'all_passed':same and old==old_after and all(x['passed'] for x in results),'signed_input_qualified':False,'runtime_qualified':False,'production_ready':False}
body=(json.dumps(receipt,sort_keys=True,indent=2)+'\n').encode();(O/'RESULT.json').write_bytes(body)
print(json.dumps({'receipt':pin(O/'RESULT.json'),'all_passed':receipt['all_passed']}),flush=True)
sys.exit(0 if receipt['all_passed'] else 1)
