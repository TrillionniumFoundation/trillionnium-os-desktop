import os,sys,json,stat,hashlib,subprocess,time,datetime,traceback,zipfile
from pathlib import Path
os.sched_setaffinity(0,{18})
A=Path('/home/qq/work/p4-remaining-app-inputs-20261118-162b-r1')
D=A/'publisher-delivery-verifier-r1';G=D/'gate';O=D/'actual-r1'
O.mkdir(mode=0o700)
for name in ('candidates','sets','receipts','results','logs'):(O/name).mkdir(mode=0o700)
J=Path('/home/qq/work/pocket4-native-source597-ai395-20261108-8b88-r1/work/aosp-source/prebuilts/jdk/jdk21/linux-x86/bin/java')
os.environ.clear();os.environ.update(PATH=str(J.parent)+':/usr/bin:/bin',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',LD_LIBRARY_PATH=str(A/'sdk37/lib64'),JAVA_TOOL_OPTIONS='-XX:ReservedCodeCacheSize=32m -XX:CompressedClassSpaceSize=32m -XX:MaxMetaspaceSize=96m -XX:+UseSerialGC -Xss256k')
sys.path.insert(0,str(G))
import verify_publisher_delivery as gate
def f9(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def pin(p):
 fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:
  a=os.fstat(f.fileno());assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
  h=hashlib.sha256()
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
  assert f9(os.fstat(f.fileno()))==f9(a)==f9(p.lstat())
 return dict(path=str(p),bytes=a.st_size,sha256=h.hexdigest(),f9=f9(a))
def exact_json(p,expected):
 with gate.sets._held(p,1048576,expected) as (stream,got):return gate.sets._json(stream.read()),got
def small(p):return {k:p[k] for k in ('path','bytes','sha256')}
def write_json(p,o):
 body=(json.dumps(o,sort_keys=True,indent=2)+'\n').encode()
 with p.open('xb') as f:f.write(body);f.flush();os.fsync(f.fileno())
 return pin(p)
begun=time.monotonic()
control,control_pin=exact_json(D/'controls-r3/RESULT.json',{'bytes':24734,'sha256':'52290f1d6335f4efd05ca0f27ee728471b099809c1ec3407967a101a36ca0faf'})
assert control['all_passed'] and sum(t['observed_tests'] for t in control['tests'])==185
sources=control['source_after'];assert all(pin(Path(p['path']))==p for p in sources)
prepared,prep_pin=exact_json(D/'SOURCE-PREPARATION.json',{'bytes':97355,'sha256':'85813dff5f12cc71489801a8beac3156693e7c7256db46d5f172108db0fc7796'})
sdk,sdk_pin=exact_json(A/'metadata/sdk37-preparation-receipt.json',{'bytes':7636,'sha256':'c9b2003dfeec0d0dc72263ff63723f9b4fe5f77ca4ad0b6ac77224ca80a78bb5'})
assert sdk['ready'] and sdk['archive']['official_sha1_matched']
tools=[]
for expected in sdk['extracted']+[sdk['java'],sdk['jdk_release']]:
 got=pin(Path(expected['path']));assert got['bytes']==expected['bytes'] and got['sha256']==expected['sha256']
 tools.append(got)
tx,tx_pin=exact_json(Path(prepared['transport']['path']),prepared['transport'])
assert tx_pin['sha256']=='3e1fda8f840a38dd3c21a79e076b063352d5d5a194f1ab19d1c5c848828e2b7c'
cg=Path('/sys/fs/cgroup')/Path(Path('/proc/self/cgroup').read_text().split('0::',1)[1].strip()).relative_to('/')
limits={n:(cg/n).read_text().strip() for n in ('memory.max','memory.swap.max','cpu.max')}
limits['actual_cpu_affinity']=sorted(os.sched_getaffinity(0))
assert limits['memory.max']=='1073741824' and limits['memory.swap.max']=='0'
assert limits['cpu.max'].split()==['100000','100000'] and limits['actual_cpu_affinity']==[18]
print(json.dumps({'action':'real_sdk37_verification_started','controls':185,'limits':limits,'packages':7,'original_apks':23}),flush=True)
results=[]
for observed in prepared['packages']:
 package=observed['package'];started=time.monotonic()
 print(json.dumps({'package':package,'stage':'prepare_original_delivery_candidate'}),flush=True)
 try:
  meta,meta_pin=exact_json(Path(observed['metadata_pin']['path']),observed['metadata_pin'])
  delivery,delivery_pin=exact_json(Path(observed['transport_pin']['path']),observed['transport_pin'])
  members=[];base=None
  for item in delivery['files']:
   with gate.sets._held(item['path'],gate.sets.APK_LIMIT,item) as (stream,original_pin):
    assert gate.stream_hash1(stream)==item['delivery_sha1']==item['sha1']
    with zipfile.ZipFile(stream) as archive:
     files=gate.sets.safe_members(archive)
     assert 0<files['AndroidManifest.xml'].file_size<=1048576
     raw=gate.sets.manifest_observation(archive.read(files['AndroidManifest.xml']))
     abis=sorted({name.split('/')[1] for name in files if name.startswith('lib/')})
   if raw['split_name'] is None:assert base is None;base=raw
   members.append({'member':gate.sets.normalized_name(raw['split_name']),'split_name':raw['split_name'],'bytes':item['bytes'],'sha256':item['delivery_sha256'],'sha1':item['delivery_sha1'],'native_abis':abis,'delivery_path':item['path']})
  members.sort(key=lambda p:p['split_name'] or '')
  assert base is not None
  is_set=len(members)>1
  certs=sorted(gate.certificate_digest(c['sha256_base64url'],32) for c in meta['certificate_sets'])
  candidate={'schema':gate.SET_SCHEMA if is_set else gate.SINGLE_SCHEMA,'package':meta['package'],'version_name':meta['version_name'],'version_code':meta['version_code']&0xffffffff,'version_code_major':meta['version_code']>>32,'min_sdk_version':int(base['min_sdk_version'],0),'target_sdk_version':int(base['target_sdk_version'],0),'signer_certificate_sha256':certs,'selected_abi':'arm64-v8a','container':None,'apks':members,'source':{'distribution':'google_play_publisher_delivery','signer_reference_kind':'current_get_items_certificate_set','container_origin':gate.ORIGIN_SET if is_set else gate.ORIGIN_SINGLE,'publisher_archive_obtained':False,'observed_utc':tx['finished_utc'],'metadata':small(meta_pin),'delivery':small(delivery_pin),'transaction':small(tx_pin)}}
  if is_set:
   input_path=O/'sets'/(package+'.apks')
   candidate['container']=gate.assemble_local_set(members,input_path)
  else:input_path=Path(members[0]['delivery_path'])
  gate.validate_candidate(candidate);gate.validate_source(candidate,meta,delivery,tx)
  candidate_path=O/'candidates'/(package+'.json');candidate_pin=write_json(candidate_path,candidate)
  receipt_path=O/'receipts'/(package+'.json')
  print(json.dumps({'package':package,'stage':'real_sdk37','apk_count':len(members),'candidate_sha256':candidate_pin['sha256']}),flush=True)
  output=gate.verify_delivery(input_path,A/'sdk37',candidate_path,candidate_pin['sha256'],receipt_path)
  output_pin=write_json(O/'results'/(package+'.json'),output)
  receipt=json.loads(receipt_path.read_bytes())
  assert all(x['signature_verified'] and not any(x['tool_exits'].values()) and x['verification_SDK_range']==[37,37] and not x['executed'] for x in receipt['identities'])
  result={'package':package,'version_name':candidate['version_name'],'version_code':meta['version_code'],'status':'publisher_delivery_source_verified','apk_count':len(members),'native_file_count':sum(len(x['native_members']) for x in receipt['complete_zip_integrity']),'selected_arm64_library_count':len(receipt['selected_abi_native_members']),'original_delivery_bytes':sum(p['bytes'] for p in members),'candidate':candidate_pin,'input':pin(input_path),'receipt':pin(receipt_path),'result':output_pin,'elapsed_seconds':time.monotonic()-started,'installed':False,'runtime_qualified':False,'production_ready':False}
 except Exception as error:
  failure=traceback.format_exc();log=O/'logs'/(package+'.failure.txt');log.write_text(failure)
  result={'package':package,'status':'failed','error_type':type(error).__name__,'error':str(error),'failure_log':pin(log),'elapsed_seconds':time.monotonic()-started,'installed':False,'runtime_qualified':False,'production_ready':False}
 results.append(result)
 print(json.dumps(result,sort_keys=True),flush=True)
 assert time.monotonic()-begun<1700
source_after=[pin(Path(p['path'])) for p in sources]
tools_after=[pin(Path(p['path'])) for p in tools]
original_gate_after=[pin(Path(p['path'])) for p in prepared['original_gate_sources']]
source_equal=sources==source_after;tools_equal=tools==tools_after;old_equal=prepared['original_gate_sources']==original_gate_after
all_passed=source_equal and tools_equal and old_equal and all(x['status']=='publisher_delivery_source_verified' for x in results)
receipt={'schema':'pocket4-seven-publisher-delivery-sdk37-run-v1','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-begun,'limits':limits,'controls':control_pin,'preparation':prep_pin,'sdk_preparation':sdk_pin,'sdk_tools_before':tools,'sdk_tools_after':tools_after,'source_before':sources,'source_after':source_after,'source_bookends_equal':source_equal,'sdk_tool_bookends_equal':tools_equal,'original_20_gate_files_unchanged':old_equal,'packages':results,'all_seven_source_verified':all_passed,'external_google_metadata_used':True,'locally_assembled_containers_are_publisher_archives':False,'installed':False,'runtime_qualified':False,'production_ready':False}
final_pin=write_json(O/'RESULT.json',receipt)
print(json.dumps({'all_seven_source_verified':all_passed,'receipt':final_pin}),flush=True)
sys.exit(0 if all_passed else 1)
