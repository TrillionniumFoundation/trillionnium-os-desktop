import os,sys,json,stat,hashlib,subprocess,time,datetime,re
from pathlib import Path
os.sched_setaffinity(0,{18})
D=Path('/home/qq/work/p4-remaining-app-inputs-20261118-162b-r1/publisher-delivery-verifier-r1')
G=D/'gate'; O=D/'controls-r2';O.mkdir(mode=0o700)
def f9(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def pin(p):
 fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:
  a=os.fstat(f.fileno());assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
  h=hashlib.sha256()
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
  assert f9(os.fstat(f.fileno()))==f9(a)==f9(p.lstat())
 return dict(path=str(p),bytes=a.st_size,sha256=h.hexdigest(),f9=f9(a))
def snapshot():return [pin(p) for p in sorted(G.iterdir()) if p.is_file()]
start=snapshot()
prepared=json.loads((D/'SOURCE-PREPARATION.json').read_bytes())
old=[]
for expected in prepared['original_gate_sources']:
 p=Path(expected['path']);got=pin(p);assert got==expected
 copied=pin(G/p.name);assert (got['bytes'],got['sha256'])==(copied['bytes'],copied['sha256'])
 old.append(got)
cg=Path('/sys/fs/cgroup')/Path(Path('/proc/self/cgroup').read_text().split('0::',1)[1].strip()).relative_to('/')
resource={n:(cg/n).read_text().strip() for n in ('memory.max','memory.swap.max','cpu.max')}
resource['actual_cpu_affinity']=sorted(os.sched_getaffinity(0))
assert resource['memory.max']=='1073741824' and resource['memory.swap.max']=='0'
assert resource['cpu.max'].split()==['100000','100000'] and set(os.sched_getaffinity(0))=={18}
counts={'test_candidate.py':41,'test_dual_dynamic_elf.py':9,'test_native_resource_payloads.py':20,'test_apk_set.py':14,'test_native_publisher_payloads.py':22,'test_verify_publisher_apk.py':20,'test_seven_zip04_payload.py':13,'test_mixed_publisher_payloads.py':7,'test_publisher_delivery.py':38}
results=[]
for name,count in counts.items():
 begun=time.monotonic();r=subprocess.run(['/usr/bin/python3','-I','-B',str(G/name)],cwd=G,env={'PATH':'/usr/bin:/bin','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 (O/(name+'.stdout')).write_bytes(r.stdout);(O/(name+'.stderr')).write_bytes(r.stderr)
 text=r.stderr.decode('utf-8','replace');m=re.findall(r'Ran (\d+) tests?',text);observed=int(m[-1]) if m else None
 item=dict(name=name,expected_tests=count,observed_tests=observed,exit_code=r.returncode,elapsed_seconds=time.monotonic()-begun,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest(),passed=r.returncode==0 and observed==count and text.rstrip().endswith('OK'))
 results.append(item);print(json.dumps(item),flush=True)
last=snapshot();same=last==start
old_after=[pin(Path(p['path'])) for p in old]
receipt={'schema':'pocket4-publisher-delivery-controls-v1','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'resource':resource,'source_before':start,'source_after':last,'source_bookends_equal':same,'original_20_files_unchanged':old==old_after,'tests':results,'expected_old_controls':146,'all_passed':same and old==old_after and all(x['passed'] for x in results),'signed_input_qualified':False,'runtime_qualified':False,'production_ready':False}
body=(json.dumps(receipt,sort_keys=True,indent=2)+'\n').encode();(O/'RESULT.json').write_bytes(body)
print(json.dumps({'receipt':pin(O/'RESULT.json'),'all_passed':receipt['all_passed']}),flush=True)
sys.exit(0 if receipt['all_passed'] else 1)
