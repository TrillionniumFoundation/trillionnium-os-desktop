import os,sys,json,stat,hashlib,tarfile,gzip,io,time,datetime,subprocess
from pathlib import Path
os.sched_setaffinity(0,{18})
A=Path('/home/qq/work/p4-remaining-app-inputs-20261118-162b-r1')
D=A/'publisher-delivery-verifier-r1';F=D/'freeze-r1';F.mkdir(mode=0o700)
L=A/'aurora-wrapper-r1/live-r1'
def f9(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def read_pin(p,limit=4*1024*1024):
 fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:
  a=os.fstat(f.fileno());assert stat.S_ISREG(a.st_mode) and a.st_nlink==1 and 0<=a.st_size<=limit
  body=f.read(limit+1);assert len(body)==a.st_size
  assert f9(os.fstat(f.fileno()))==f9(a)==f9(p.lstat())
 return body,dict(path=str(p),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),f9=f9(a))
def pin(p,limit=4*1024*1024):return read_pin(p,limit)[1]
def write(p,body):
 p.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
 with p.open('xb') as f:f.write(body);f.flush();os.fsync(f.fileno())
 os.chmod(p,0o444)
 return pin(p)
def encoded(o):return (json.dumps(o,sort_keys=True,indent=2)+'\n').encode()
actual_raw,actual_pin=read_pin(D/'actual-r1/RESULT.json')
assert actual_pin['sha256']=='08ac50de400ed6ac56337597d9b52a0dbfec47a08ac190dd4c7e1ed468996497'
actual=json.loads(actual_raw);assert actual['all_seven_source_verified']
controls_raw,controls_pin=read_pin(D/'controls-r3/RESULT.json')
assert controls_pin['sha256']=='52290f1d6335f4efd05ca0f27ee728471b099809c1ec3407967a101a36ca0faf'
controls=json.loads(controls_raw);assert controls['all_passed'] and sum(x['observed_tests'] for x in controls['tests'])==185
for p in actual['source_after']:assert pin(Path(p['path']))==p
prepared=json.loads((D/'SOURCE-PREPARATION.json').read_bytes())
for p in prepared['original_gate_sources']:assert pin(Path(p['path']))==p
source_pairs=[]
def add(source,name):source_pairs.append((Path(source),name))
for p in sorted((D/'gate').iterdir()):
 assert p.is_file() and not p.is_symlink()
 add(p,'gate/'+p.name)
for p in sorted((D/'current-app-acceptance').iterdir()):add(p,'current-app-acceptance/'+p.name)
for name in ('controls-r2','controls-r3'):
 for p in sorted((D/name).iterdir()):add(p,'controls/'+name+'/'+p.name)
for name in ('candidates','receipts','results'):
 for p in sorted((D/'actual-r1'/name).iterdir()):add(p,'actual/'+name+'/'+p.name)
add(D/'actual-r1/RESULT.json','actual/RESULT.json')
for name in ('PUBLISHER-DELIVERY.md','SOURCE-PREPARATION.json','fixture-source-receipt-r1.json','run_controls_r1.py','run_controls_r2.py','run_controls_r3.py','run_actual_r1.py','controls-r1-terminal.raw.json','controls-r2-terminal.raw.json','controls-r3-terminal.raw.json','actual-r1-terminal.raw.json'):
 add(D/name,name)
add(A/'prepare_publisher_delivery_gate_r1.py','prepare_publisher_delivery_gate_r1.py')
add(A/'metadata/sdk37-preparation-receipt.json','sdk37-preparation-receipt.json')
add(Path(__file__),'freeze_publisher_delivery_r1.py')
for row in actual['packages']:
 package=row['package']
 add(L/(package+'.metadata.json'),'source-evidence/'+package+'.metadata.json')
 add(L/(package+'.transport.json'),'source-evidence/'+package+'.transport.json')
add(L/'TRANSPORT-RESULT.json','source-evidence/TRANSPORT-RESULT.json')
add(L/'WORKER-RESULT.json','source-evidence/WORKER-RESULT.json')
consumer=Path('/home/qq/work/p4-runtime-continuation-20261118-162b-r1/increment-16/apk-source-consumer-observation-r1.json')
consumer_pin=pin(consumer)
assert consumer_pin['bytes']==12916 and consumer_pin['sha256']=='741f31c2b91f37c634256970b066c550e58709509088976bd7442d1a719a2070'
add(consumer,'consumer/apk-source-consumer-observation-r1.json')
entries=[];source_before=[]
for original,name in source_pairs:
 assert not name.startswith('/') and '..' not in name.split('/')
 body,p=read_pin(original);source_before.append(p);out=write(F/name,body)
 entries.append({'member':name,'bytes':out['bytes'],'sha256':out['sha256'],'mode':0o444,'original':p})
names=[x['member'] for x in entries];assert len(set(names))==len(names)
data_inputs=[];applications=[];summary_rows=[]
for row in actual['packages']:
 package=row['package'];receipt=json.loads((D/'actual-r1/receipts'/(package+'.json')).read_bytes())
 fragment=json.loads((D/'actual-r1/results'/(package+'.json')).read_bytes())
 candidate=json.loads((D/'actual-r1/candidates'/(package+'.json')).read_bytes())
 applications.append(fragment['application'])
 data_inputs.append({'package':package,'original_delivery_apks':receipt['original_delivery_apks'],'verified_input':row['input'],'local_container_is_publisher_archive':False,'keep_until_root_archive_and_actual_installation_custody':True})
 summary_rows.append({'package':package,'version_name':row['version_name'],'version_code':row['version_code'],'apks':row['apk_count'],'original_delivery_bytes':row['original_delivery_bytes'],'signers':candidate['signer_certificate_sha256'],'native_members':row['native_file_count'],'selected_arm64_members':row['selected_arm64_library_count'],'candidate':row['candidate'],'receipt':row['receipt'],'all_delivery_source_verified':True,'installed':False,'runtime_qualified':False,'production_ready':False})
summary={'schema':'pocket4-seven-current-source-input-summary-v1','packages':summary_rows,'original_delivery_apks':sum(x['apks'] for x in summary_rows),'original_delivery_bytes':sum(x['original_delivery_bytes'] for x in summary_rows),'native_members':sum(x['native_members'] for x in summary_rows),'arm64_native_members':sum(x['selected_arm64_members'] for x in summary_rows),'all_source_verified':True,'installed':False,'runtime_qualified':False,'production_ready':False}
assert summary['original_delivery_apks']==23 and summary['original_delivery_bytes']==942526044
for name,value in [('DATA-INPUTS.json',data_inputs),('EXPECTED-INPUTS.json',applications),('SOURCE-INPUT-SUMMARY.json',summary)]:
 p=write(F/name,encoded(value));entries.append({'member':name,'bytes':p['bytes'],'sha256':p['sha256'],'mode':0o444,'original':None})
unit=subprocess.run(['/usr/bin/systemctl','--user','show','p4-seven-delivery-sdk37-162b-r1.scope','--property=LoadState,ActiveState,SubState,ControlGroup','--no-pager'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15,env={'PATH':'/usr/bin:/bin','LC_ALL':'C.UTF-8','XDG_RUNTIME_DIR':'/run/user/1000','DBUS_SESSION_BUS_ADDRESS':'unix:path=/run/user/1000/bus'})
unit_record={'argv':['systemctl','--user','show','p4-seven-delivery-sdk37-162b-r1.scope','--property=LoadState,ActiveState,SubState,ControlGroup','--no-pager'],'exit_code':unit.returncode,'stdout':unit.stdout.decode('utf-8','strict'),'stderr':unit.stderr.decode('utf-8','strict'),'observation_only':True}
name='actual/scope-terminal-observation.json';p=write(F/name,encoded(unit_record));entries.append({'member':name,'bytes':p['bytes'],'sha256':p['sha256'],'mode':0o444,'original':None})
source_after=[pin(Path(p['path'])) for p in source_before];assert source_before==source_after
freeze={'schema':'pocket4-publisher-delivery-source-evidence-freeze-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':sorted(entries,key=lambda x:x['member']),'payload_member_count':len(entries),'payload_bytes':sum(p['bytes'] for p in entries),'original_sources_bookends_equal':True,'old_gate_source_files_unchanged':20,'old_controls_passed':146,'new_controls_passed':39,'all_real_seven_source_verified':True,'original_apks_included':False,'local_containers_included':False,'new_receipt_schema':'pocket4-verified-publisher-delivery-source-receipt-v1','installed':False,'runtime_qualified':False,'production_ready':False}
freeze_pin=write(F/'SOURCE_FREEZE.json',encoded(freeze))
archive_path=D/'publisher-delivery-source-evidence-r1.tar.gz'
all_entries=freeze['entries']+[{'member':'SOURCE_FREEZE.json','bytes':freeze_pin['bytes'],'sha256':freeze_pin['sha256'],'mode':0o444}]
with archive_path.open('xb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=6,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.USTAR_FORMAT) as archive:
   for record in sorted(all_entries,key=lambda x:x['member']):
    body,got=read_pin(F/record['member'])
    assert got['sha256']==record['sha256'] and got['bytes']==record['bytes']
    info=tarfile.TarInfo(record['member']);info.size=len(body);info.mode=record['mode'];info.uid=0;info.gid=0;info.uname='';info.gname='';info.mtime=0
    archive.addfile(info,io.BytesIO(body))
 raw.flush();os.fsync(raw.fileno())
os.chmod(archive_path,0o444)
expected={x['member']:x for x in all_entries};seen=[]
with tarfile.open(archive_path,'r:gz') as archive:
 for member in archive:
  assert member.isreg() and member.name not in seen and member.name in expected
  record=expected[member.name];assert member.size==record['bytes'] and member.mode==record['mode']
  body=archive.extractfile(member).read(record['bytes']+1)
  assert len(body)==record['bytes'] and hashlib.sha256(body).hexdigest()==record['sha256']
  seen.append(member.name)
assert set(seen)==set(expected)
receipt={'schema':'pocket4-publisher-delivery-package-receipt-v1','archive':pin(archive_path),'freeze':freeze_pin,'complete_regular_member_count':len(all_entries),'uncompressed_member_bytes':sum(x['bytes'] for x in all_entries),'all_archive_members_reread_and_hashed':True,'original_sources_bookends_equal':True,'original_20_gate_files_unchanged':True,'controls':{'old':146,'new':39,'all_passed':True},'actual_seven_package_sdk37_passed':True,'actual_apk_count':23,'original_delivery_bytes':942526044,'scope_observation':unit_record,'installed':False,'runtime_qualified':False,'production_ready':False}
receipt_pin=write(D/'PACKAGE-RECEIPT-r1.json',encoded(receipt))
print(json.dumps({'receipt':receipt_pin,'archive':receipt['archive'],'freeze':freeze_pin,'complete_regular_member_count':len(all_entries),'uncompressed_member_bytes':receipt['uncompressed_member_bytes'],'scope_observation':unit_record},sort_keys=True),flush=True)
