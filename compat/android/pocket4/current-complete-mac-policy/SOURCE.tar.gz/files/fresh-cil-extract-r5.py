import os,resource,pathlib,subprocess,hashlib,json,shutil,time,datetime,stat
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));os.sched_setaffinity(0,{18})
base=pathlib.Path('/home/qq/work/p4-broker-mac-provider-20261118-162b-r1')
mem={x.split(':',1)[0]:int(x.split(':',1)[1].split()[0])*1024 for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if ':' in x and x.split(':',1)[1].split()[0].isdigit()}
assert mem['MemAvailable']>=23622320128,('fresh MemAvailable below approved 22GiB',mem['MemAvailable'])
cg=pathlib.Path('/sys/fs/cgroup'+next(x.split('::',1)[1] for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::')))
limits={name:(cg/name).read_text().strip() for name in ['memory.max','cpu.max']}
assert limits['memory.max']=='536870912' and sorted(os.sched_getaffinity(0))==[18]
quota,period=map(int,limits['cpu.max'].split());assert quota==period
debugfs=shutil.which('debugfs',path='/usr/bin:/usr/sbin:/bin:/sbin');assert debugfs,'normal installed debugfs absent'
image=pathlib.Path('/home/qq/work/p4-official-vendor-cp3a-20261118-162b-r1/official-gsi/images/system.img')
dest=base/'cp3a-original-rebuild-r5';dest.mkdir(mode=0o700)
env={'PATH':'/usr/bin:/usr/sbin:/bin:/sbin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'}
def identity(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def digest_file(f):
 f.seek(0);h=hashlib.sha256();n=0
 while True:
  raw=f.read(1048576)
  if not raw:break
  h.update(raw);n+=len(raw)
 return n,h.hexdigest()
pins=[
 ('/system/etc/selinux/plat_sepolicy.cil','plat_sepolicy.cil',3363281,'f6422dd5853e815d340f2e9c4dcba2bb1016b55ffc2a073fc916ac23dfe66fc2'),
 ('/system/etc/selinux/mapping/202604.cil','plat_mapping_202604.cil',234191,None),
 ('/system/etc/selinux/plat_sepolicy_genfs_202604.cil','plat_sepolicy_genfs_202604.cil',303,'3bdfcfba699936cb12d007fee7bca2feb1a88c75cc947f98b14c55fe4932b0d3'),
 ('/system/product/etc/selinux/product_sepolicy.cil','product_sepolicy.cil',275433,'bcdaa16015d01771f85972ef7a2eb885708294898030d6ab78fbfa30f8090014'),
 ('/system/system_ext/etc/selinux/system_ext_sepolicy.cil','system_ext_sepolicy.cil',275433,'bcdaa16015d01771f85972ef7a2eb885708294898030d6ab78fbfa30f8090014'),
 ('/system/product/etc/selinux/mapping/202604.cil','product_mapping_202604.cil',1,'01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b'),
 ('/system/system_ext/etc/selinux/mapping/202604.cil','system_ext_mapping_202604.cil',1,'01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();print(json.dumps({'started':start,'MemAvailable':mem['MemAvailable'],'debugfs':debugfs,'action':'read-only official image extraction'}),flush=True)
fd=os.open(image,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
with os.fdopen(fd,'rb') as held:
 initial=os.fstat(held.fileno());assert stat.S_ISREG(initial.st_mode) and initial.st_nlink==1
 expected=(2294853632,'dc781249bb4724b7a0777e5077321b84576db46f61abb4b9086b81077bfd0ab4');assert initial.st_size==expected[0]
 assert identity(os.fstat(held.fileno()))==identity(initial)==identity(image.lstat())
 result=[]
 for internal,name,size,prior in pins:
  out=dest/name
  r=subprocess.run([debugfs,'-R','dump '+internal+' '+str(out),str(image)],env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=30)
  (dest/(name+'.debugfs.stdout')).write_bytes(r.stdout);(dest/(name+'.debugfs.stderr')).write_bytes(r.stderr)
  assert r.returncode==0,(name,r.returncode,r.stderr)
  s=out.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size==size
  raw=out.read_bytes();h=hashlib.sha256(raw).hexdigest();assert prior is None or h==prior,(name,h,prior)
  result.append({'image_path':internal,'file':name,'bytes':len(raw),'sha256':h,'matches_prior_complete_pin':None if prior is None else True})
  assert identity(os.fstat(held.fileno()))==identity(initial)==identity(image.lstat())
 final=digest_file(held);assert final==expected and identity(os.fstat(held.fileno()))==identity(initial)==identity(image.lstat())
record={'schema':'p4-cp3a-fresh-readonly-policy-extraction-v1','observed_start':start,'observed_end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'image':{'path':str(image),'bytes':final[0],'sha256':final[1],'full_hash_before_and_after':False,'complete_hash_after_extraction':True,'full_F9_held_before_through_after_all_extractions_and_hash':True,'identity':identity(initial)},'debugfs':{'path':debugfs,'sha256':hashlib.sha256(pathlib.Path(debugfs).read_bytes()).hexdigest()},'files':result,'writes_to_original_image':0,'mount_operations':0,'policy_load_operations':0,'lost_cloud_offline1_restored':False,'prior_mapping_pin_unavailable':True,'cgroup':str(cg),'actual_limits':limits,'tasks':{n:(cg/n).read_text().strip() for n in ['pids.max','pids.peak','pids.events']},'resource_window':{'minimum_MemAvailable':23622320128,'observed_MemAvailable':mem['MemAvailable'],'memory_limit':536870912,'cpu_affinity':[18],'cpu_quota_percent':100,'outer_timeout_seconds':600}}
with (dest/'EXTRACTION.json').open('x') as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(record),flush=True)
