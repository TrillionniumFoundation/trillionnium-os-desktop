import os,resource,subprocess,pathlib,json,hashlib,zlib,time
resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648));os.sched_setaffinity(0,{18,19})
b=pathlib.Path('/home/qq/work/p4-broker-mac-provider-20261118-162b-r1')
env={'PATH':'/usr/bin:/bin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'}
raw=zlib.decompress((b/'cp3a-r1.policy.zlib').read_bytes())
assert len(raw)==760303 and hashlib.sha256(raw).hexdigest()=='4ffcd33846438bf2ced8ad1331c8e60233529ab033a683c2e1188e714471c730'
with (b/'cp3a-r1.policy').open('xb') as f:f.write(raw)
assert hashlib.sha256((b/'query_private_loop_binary.c').read_bytes()).hexdigest()=='ec31e6b07ad27b5ad504a707abd9c9cf831b4c9a722fb21db80473b6cc0c0b76'
lib=b/'source/libsepol/src/libsepol.a'
assert hashlib.sha256(lib.read_bytes()).hexdigest()=='e46408d19036f30310e31d51cc723b201aec9c529bc2183fcb261ab2761d40e1'
cmd=['/usr/bin/cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-I'+str(b/'source/libsepol/include'),str(b/'query_private_loop_binary.c'),str(lib),'-o',str(b/'query_private_loop_binary')]
r=subprocess.run(cmd,env=env,capture_output=True,timeout=30)
(b/'query-build.stdout').write_bytes(r.stdout);(b/'query-build.stderr').write_bytes(r.stderr)
print(json.dumps({'compile_exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}),flush=True)
if r.returncode:raise SystemExit(r.returncode)
s=subprocess.run([str(b/'query_private_loop_binary'),str(b/'cp3a-r1.policy')],env=env,capture_output=True,timeout=35)
(b/'query-result.stdout').write_bytes(s.stdout);(b/'query-result.stderr').write_bytes(s.stderr)
record={'source_sha256':hashlib.sha256((b/'query_private_loop_binary.c').read_bytes()).hexdigest(),'library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((b/'query_private_loop_binary').read_bytes()).hexdigest(),'policy_sha256':hashlib.sha256(raw).hexdigest(),'exit_code':s.returncode,'stdout':s.stdout.decode(),'stderr':s.stderr.decode(),'kernel_policy_operations':0}
(b/'query-result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
raise SystemExit(s.returncode)
