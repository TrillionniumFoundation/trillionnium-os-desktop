/* Negative-control fixture producer only; never installed or loaded. */
#define main original_decoder_main
#include "query_private_loop_binary.c"
#undef main

int main(int argc, char **argv) {
    need(argc == 4, "fixed input, new output and mutation mode");
    FILE *f = fopen(argv[1], "rb"); need(f != NULL, "control input");
    policydb_t p; need(policydb_init(&p) == 0, "control policydb");
    policy_file_t input; policy_file_init(&input); input.type = PF_USE_STDIO; input.fp = f;
    need(policydb_read(&p, &input, 0) == 0 && fclose(f) == 0, "full real policy decode");
    uint16_t broker = type_id(&p, "droidloom_broker");
    uint16_t target = type_id(&p, "droidloom_apex_loop_device");
    uint16_t cls = (uint16_t)class_value(&p, "blk_file")->s.value;
    unsigned changed = 0;
    if (!strcmp(argv[3], "permissive")) {
        need(ebitmap_set_bit(&p.permissive_map, broker, 1) == 0, "control permissive bit");
        changed++;
    } else if (!strcmp(argv[3], "wrong-named-transition")) {
        filename_trans_key_t key = {.ttype=type_id(&p,"tmpfs"), .tclass=class_value(&p,"dir")->s.value,
                                    .name="droidloom-apex-devices"};
        for (filename_trans_datum_t *d = hashtab_search(p.filename_trans, (hashtab_key_t)&key); d; d=d->next)
            if (ebitmap_get_bit(&d->stypes, broker - 1)) { d->otype = type_id(&p,"tmpfs"); changed++; }
    } else {
        for (uint32_t slot=0; slot<p.te_avtab.nslot; slot++)
            for (struct avtab_node *n=p.te_avtab.htable[slot]; n; n=n->next)
                if (n->key.source_type==broker && n->key.target_type==target &&
                    n->key.target_class==cls && n->key.specified==AVTAB_XPERMS_ALLOWED) {
                    avtab_extended_perms_t *x=n->datum.xperms;
                    need(x && x->specified==AVTAB_XPERMS_IOCTLFUNCTION && x->driver==0x4c,
                         "real exact fixture xperm entry");
                    if (!strcmp(argv[3],"widen")) x->perms[0] |= 1U;
                    else if (!strcmp(argv[3],"remove-configure")) x->perms[0] &= ~(1U << 10);
                    else if (!strcmp(argv[3],"foreign-subject")) n->key.source_type=type_id(&p,"init");
                    else need(0,"known fixed mutation only");
                    changed++;
                }
    }
    need(changed==1,"one actual binary policy mutation");
    int fd=open(argv[2],O_CREAT|O_EXCL|O_WRONLY|O_NOFOLLOW|O_CLOEXEC,0600);
    need(fd>=0,"exclusive new control output");
    f=fdopen(fd,"wb");need(f!=NULL,"control stream");
    policy_file_t out;policy_file_init(&out);out.type=PF_USE_STDIO;out.fp=f;
    need(policydb_write(&p,&out)==0 && fflush(f)==0 && fsync(fd)==0 && fclose(f)==0,
         "complete mutated binary serialize");
    policydb_destroy(&p);return 0;
}
