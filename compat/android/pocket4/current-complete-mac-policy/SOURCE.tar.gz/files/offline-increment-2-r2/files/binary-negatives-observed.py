import os,resource,subprocess,pathlib,json,hashlib
resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648));os.sched_setaffinity(0,{18,19})
b=pathlib.Path('/home/qq/work/p4-broker-mac-provider-20261118-162b-r1');env={'PATH':'/usr/bin:/bin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'}
cmd=['/usr/bin/cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-I'+str(b/'source/libsepol/include'),str(b/'mutate_private_loop_binary_control.c'),str(b/'source/libsepol/src/libsepol.a'),'-o',str(b/'mutate_private_loop_binary_control')]
r=subprocess.run(cmd,env=env,capture_output=True,timeout=30);(b/'mutator-build.stdout').write_bytes(r.stdout);(b/'mutator-build.stderr').write_bytes(r.stderr)
print(json.dumps({'compile_exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}),flush=True)
if r.returncode:raise SystemExit(r.returncode)
expected={'widen':'ioctl mismatch at 0x4c00 actual=1 required=0','remove-configure':'ioctl mismatch at 0x4c0a actual=0 required=1','foreign-subject':'private object accessible by a non-broker type','permissive':'fixed type is permissive','wrong-named-transition':'named automatic transition has wrong result','truncated':'complete supported binary policy, no trailing bytes','trailing':'complete supported binary policy, no trailing bytes'}
results=[]
for mode,why in expected.items():
 out=b/('negative-'+mode+'.policy')
 if mode in ('truncated','trailing'):
  original=(b/'cp3a-r1.policy').read_bytes();data=original[:-1] if mode=='truncated' else original+b'!'
  with out.open('xb') as f:f.write(data)
 else:
  m=subprocess.run([str(b/'mutate_private_loop_binary_control'),str(b/'cp3a-r1.policy'),str(out),mode],env=env,capture_output=True,timeout=15)
  assert m.returncode==0,(mode,m.stdout,m.stderr)
 q=subprocess.run([str(b/'query_private_loop_binary'),str(out)],env=env,capture_output=True,timeout=35)
 assert q.returncode==2 and why.encode() in q.stderr,(mode,q.returncode,q.stdout,q.stderr)
 results.append({'mutation':mode,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'exit_code':q.returncode,'expected_rejection':why,'stderr':q.stderr.decode(),'passed':True})
record={'schema':'p4-private-loop-binary-negative-controls-v1','policy_sha256':hashlib.sha256((b/'cp3a-r1.policy').read_bytes()).hexdigest(),'library_sha256':hashlib.sha256((b/'source/libsepol/src/libsepol.a').read_bytes()).hexdigest(),'mutator_sha256':hashlib.sha256((b/'mutate_private_loop_binary_control.c').read_bytes()).hexdigest(),'controls':results,'kernel_policy_operations':0,'runtime_qualified':False,'production_ready':False}
(b/'binary-negative-controls.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
