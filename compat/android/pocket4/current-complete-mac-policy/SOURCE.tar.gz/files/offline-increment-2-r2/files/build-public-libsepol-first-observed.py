import os,resource,subprocess,pathlib,hashlib,json,tarfile,io,stat,time
resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648));os.sched_setaffinity(0,{18,19})
base=pathlib.Path('/home/qq/work/p4-broker-mac-provider-20261118-162b-r1');base.mkdir(mode=0o700,exist_ok=False)
repo=pathlib.Path('/home/qq/work/pocket4-native-source597-ai395-20261108-8b88-r1/work/aosp-source/external/selinux');commit='a8c5e74f85f869bf236a01ba24181b78f5e39a52';env={'PATH':'/usr/bin:/bin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'}
def run(args,timeout):
 c=subprocess.run(args,env=env,capture_output=True,timeout=timeout);assert c.returncode==0,(args,c.returncode,c.stderr.decode('utf-8','replace'));return c.stdout
assert run(['git','-C',str(repo),'rev-parse','HEAD'],15).decode().strip()==commit
archive=run(['git','-C',str(repo),'archive','--format=tar',commit,'libsepol'],30);assert 0<len(archive)<32*1024*1024
(base/'libsepol-official-commit.tar').write_bytes(archive);dest=base/'source';dest.mkdir();members=[];total=0
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:') as tf:
 for item in tf.getmembers():
  pp=pathlib.PurePosixPath(item.name);assert not pp.is_absolute() and '..' not in pp.parts and pp.parts[0]=='libsepol';assert item.isdir() or item.isfile();total+=item.size;assert total<=64*1024*1024 and len(members)<4096
  out=dest.joinpath(*pp.parts)
  if item.isdir():out.mkdir(parents=True,exist_ok=True)
  else:
   out.parent.mkdir(parents=True,exist_ok=True);data=tf.extractfile(item).read();assert len(data)==item.size;out.write_bytes(data);out.chmod(0o600);members.append({'path':item.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':'p4-new-official-libsepol-source-v1','repository':'https://android.googlesource.com/platform/external/selinux','source_repo':str(repo),'git_commit':commit,'source_archive_bytes':len(archive),'source_archive_sha256':hashlib.sha256(archive).hexdigest(),'files':members,'original_source_modified':False,'kernel_policy_operations':0};(base/'source-manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
t=time.monotonic();c=subprocess.run(['/usr/bin/make','-C',str(dest/'libsepol/src'),'-j2','libsepol.a'],env=env,capture_output=True,timeout=100);(base/'build.stdout').write_bytes(c.stdout);(base/'build.stderr').write_bytes(c.stderr)
result={'schema':'p4-private-libsepol-build-observation-v1','exit_code':c.returncode,'elapsed_seconds':time.monotonic()-t,'commit':commit,'source_archive_sha256':manifest['source_archive_sha256'],'source_manifest_sha256':hashlib.sha256((base/'source-manifest.json').read_bytes()).hexdigest(),'source_files':len(members),'stderr_tail':c.stderr.decode('utf-8','replace')[-6000:],'library':None,'global_install':False,'original_source_modified':False,'kernel_policy_operations':0}
lib=dest/'libsepol/src/libsepol.a'
if lib.is_file():result['library']={'path':str(lib),'bytes':lib.stat().st_size,'sha256':hashlib.sha256(lib.read_bytes()).hexdigest()}
(base/'build-result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,sort_keys=True));assert c.returncode==0
