#define _GNU_SOURCE
/* Build against the exact same private a8c5e74f libsepol sources/headers.
 * This is a complete binary-policy decoder, never a CIL-text assumption.
 * No kernel policy API, no SELinux filesystem writes, no device operations.
 */
#include <sepol/policydb/policydb.h>
#include <sepol/policydb/services.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <unistd.h>

static void need(int ok, const char *why) {
    if (!ok) { fprintf(stderr, "private-loop binary query: %s errno=%d\n", why, errno); exit(2); }
}
static int same(const struct stat *a, const struct stat *b) {
    return a->st_dev == b->st_dev && a->st_ino == b->st_ino &&
        a->st_mode == b->st_mode && a->st_nlink == b->st_nlink &&
        a->st_uid == b->st_uid && a->st_gid == b->st_gid && a->st_size == b->st_size &&
        a->st_mtim.tv_sec == b->st_mtim.tv_sec && a->st_mtim.tv_nsec == b->st_mtim.tv_nsec &&
        a->st_ctim.tv_sec == b->st_ctim.tv_sec && a->st_ctim.tv_nsec == b->st_ctim.tv_nsec;
}
static uint16_t type_id(const policydb_t *p, const char *name) {
    type_datum_t *t = hashtab_search(p->p_types.table, name);
    need(t && t->flavor == TYPE_TYPE && t->s.value > 0 && t->s.value <= p->p_types.nprim &&
         t->s.value <= UINT16_MAX && t->bounds == 0, "fixed concrete unbounded type absent");
    need(!ebitmap_get_bit(&p->permissive_map, t->s.value), "fixed type is permissive");
    return (uint16_t)t->s.value;
}
static class_datum_t *class_value(const policydb_t *p, const char *name) {
    class_datum_t *c = hashtab_search(p->p_classes.table, name);
    need(c && c->s.value > 0 && c->s.value <= UINT16_MAX, "fixed class absent");
    return c;
}
static uint32_t permissions(class_datum_t *c, const char *names) {
    uint32_t mask = 0;
    char *copy = strdup(names), *save = NULL; need(copy != NULL, "permission buffer");
    for (char *n = strtok_r(copy, " ", &save); n; n = strtok_r(NULL, " ", &save)) {
        perm_datum_t *v = hashtab_search(c->permissions.table, n);
        if (!v && c->comdatum) v = hashtab_search(c->comdatum->permissions.table, n);
        need(v && v->s.value >= 1 && v->s.value <= 32, "fixed permission absent");
        uint32_t bit = UINT32_C(1) << (v->s.value - 1);
        need(!(mask & bit), "duplicate fixed permission"); mask |= bit;
    }
    free(copy); return mask;
}
static int matches(const policydb_t *p, uint16_t concrete, uint16_t key) {
    need(concrete && concrete <= p->p_types.nprim && key && key <= p->p_types.nprim,
         "bounded actual binary type ID");
    return concrete == key || ebitmap_get_bit(&p->type_attr_map[concrete - 1], key - 1);
}
static unsigned bit(const uint32_t bits[8], unsigned n) {
    return (bits[n >> 5] >> (n & 31)) & 1U;
}
static void decode(const avtab_extended_perms_t *x, unsigned char allowed[65536]) {
    need(x != NULL, "actual extended permission datum");
    if (x->specified == AVTAB_XPERMS_IOCTLFUNCTION) {
        for (unsigned n = 0; n < 256; n++) if (bit(x->perms, n))
            allowed[(unsigned)x->driver * 256 + n] = 1;
    } else if (x->specified == AVTAB_XPERMS_IOCTLDRIVER) {
        for (unsigned d = 0; d < 256; d++) if (bit(x->perms, d))
            memset(allowed + d * 256, 1, 256);
    } else need(0, "non-ioctl extended permission on a private device class");
}
static void object(const policydb_t *p, uint16_t broker, const char *target_name,
                   const char *class_name, const unsigned *expected, size_t count) {
    uint16_t target = type_id(p, target_name);
    class_datum_t *c = class_value(p, class_name);
    unsigned char allowed[65536] = {0};
    uint32_t generic = 0; unsigned extended_entries = 0, generic_entries = 0, seen = 0;
    need(p->te_avtab.nslot <= MAX_AVTAB_HASH_BUCKETS && p->te_avtab.nel <= MAX_AVTAB_SIZE,
         "bounded actual avtab");
    for (uint32_t slot = 0; slot < p->te_avtab.nslot; slot++)
        for (const struct avtab_node *n = p->te_avtab.htable[slot]; n; n = n->next) {
            need(++seen <= p->te_avtab.nel, "bounded noncyclic avtab");
            if (n->key.target_class != c->s.value || !matches(p, target, n->key.target_type)) continue;
            if (!(n->key.specified & (AVTAB_ALLOWED | AVTAB_XPERMS_ALLOWED))) continue;
            need(!(n->key.specified & AVTAB_ENABLED), "conditional marker in unconditional table");
            /* Include every actual attribute expansion. A direct-key-only
             * search could miss a grant to another subject or opcode. */
            for (uint32_t t = 1; t <= p->p_types.nprim; t++) {
                type_datum_t *d = p->type_val_to_struct[t - 1];
                need(d != NULL, "complete actual type index");
                if (d->flavor == TYPE_TYPE && matches(p, (uint16_t)t, n->key.source_type))
                    need(t == broker, "private object accessible by a non-broker type");
            }
            need(matches(p, broker, n->key.source_type), "unresolved grant subject");
            if (n->key.specified & AVTAB_ALLOWED) { generic |= n->datum.data; generic_entries++; }
            if (n->key.specified & AVTAB_XPERMS_ALLOWED) { decode(n->datum.xperms, allowed); extended_entries++; }
        }
    need(seen == p->te_avtab.nel, "complete actual avtab traversal");
    uint32_t required = permissions(c, "create getattr read write open ioctl unlink");
    need(generic == required && generic_entries > 0 && extended_entries > 0,
         "exact generic private-device permissions and explicit xperms required");
    unsigned actual_count = 0;
    for (unsigned v = 0; v < 65536; v++) {
        unsigned want = 0;
        for (size_t j = 0; j < count; j++) want |= expected[j] == v;
        if (allowed[v] != want) {
            fprintf(stderr, "private-loop binary query: ioctl mismatch at 0x%04x actual=%u required=%u\n", v, allowed[v], want);
            exit(2);
        }
        actual_count += allowed[v];
    }
    printf("{\"target\":\"%s\",\"class\":\"%s\",\"type_id\":%u,\"class_id\":%u,"
           "\"generic_mask\":%u,\"generic_entries\":%u,\"extended_entries\":%u,"
           "\"all_65536_opcode_bits_checked\":true,\"allowed_count\":%u,\"allowed\":[",
           target_name, class_name, target, c->s.value, generic, generic_entries, extended_entries, actual_count);
    for (size_t j = 0; j < count; j++) printf("%s%u", j ? "," : "", expected[j]);
    printf("]}");
}
static void named(const policydb_t *p, uint16_t broker, const char *parent_name,
                  const char *class_name, const char *name, const char *result_name) {
    uint16_t parent = type_id(p, parent_name), result = type_id(p, result_name);
    class_datum_t *c = class_value(p, class_name);
    filename_trans_key_t key = { .ttype = parent, .tclass = c->s.value, .name = (char *)name };
    filename_trans_datum_t *d = hashtab_search(p->filename_trans, (hashtab_key_t)&key);
    unsigned found = 0, chain = 0;
    for (; d; d = d->next) {
        need(++chain <= p->p_types.nprim, "bounded named-transition chain");
        if (ebitmap_get_bit(&d->stypes, broker - 1)) {
            need(d->otype == result, "named automatic transition has wrong result"); found++;
        }
    }
    need(found == 1, "exact named automatic transition required");
    printf("{\"parent\":\"%s\",\"class\":\"%s\",\"name\":\"%s\",\"result\":\"%s\",\"matching_rules\":%u}",
           parent_name, class_name, name, result_name, found);
}
int main(int argc, char **argv) {
    need(argc == 2, "one complete explicit policy input");
    struct rlimit mem = {2147483648ULL, 2147483648ULL}, cpu = {30, 30};
    need(setrlimit(RLIMIT_AS, &mem) == 0 && setrlimit(RLIMIT_CPU, &cpu) == 0, "bounded resources");
    int fd = open(argv[1], O_RDONLY | O_NOFOLLOW | O_CLOEXEC); need(fd >= 0, "open complete policy");
    struct stat before, after, named_file;
    need(fstat(fd, &before) == 0 && S_ISREG(before.st_mode) && before.st_nlink == 1 &&
         before.st_uid == getuid() && before.st_size > 0 && before.st_size <= 67108864,
         "owned bounded regular binary policy");
    size_t size = (size_t)before.st_size, done = 0;
    void *bytes = malloc(size); need(bytes != NULL, "policy buffer");
    while (done < size) {
        ssize_t n = read(fd, (char *)bytes + done, size - done);
        if (n < 0 && errno == EINTR) continue;
        need(n > 0, "full policy bytes"); done += (size_t)n;
    }
    char extra;
    need(read(fd, &extra, 1) == 0 && fstat(fd, &after) == 0 && lstat(argv[1], &named_file) == 0 &&
         same(&before, &after) && same(&before, &named_file), "exact input identity remained stable");
    need(close(fd) == 0, "close policy input");
    policydb_t p; need(policydb_init(&p) == 0, "fresh private policydb");
    policy_file_t input; policy_file_init(&input);
    input.type = PF_USE_MEMORY; input.data = bytes; input.len = size;
    need(policydb_read(&p, &input, 0) == 0 && input.len == 0, "complete supported binary policy, no trailing bytes");
    free(bytes);
    need(p.policy_type == POLICY_KERN && p.target_platform == SEPOL_TARGET_SELINUX && p.mls == 1 &&
         p.handle_unknown == DENY_UNKNOWN && p.policyvers == 30 && p.p_types.nprim <= UINT16_MAX,
         "fixed enforcing MLS SELinux policy format");
    need(p.te_cond_avtab.nel == 0 && p.cond_list == NULL && p.p_bools.nprim == 0,
         "fixed production component permits no conditional policy grants");
    uint16_t broker = type_id(&p, "droidloom_broker");
    const unsigned control[] = {0x4c82}, block[] = {0x4c01, 0x4c05, 0x4c0a};
    printf("{\"schema\":\"p4-private-loop-complete-binary-policy-query-v1\",\"policy_bytes\":%zu,"
           "\"policy_version\":%u,\"types\":%u,\"avtab_entries\":%u,\"broker_type_id\":%u,\"ioctl\":[",
           size, p.policyvers, p.p_types.nprim, p.te_avtab.nel, broker);
    object(&p, broker, "droidloom_apex_loop_control_device", "chr_file", control, 1); printf(",");
    object(&p, broker, "droidloom_apex_loop_device", "blk_file", block, 3);
    printf("],\"named_transitions\":[");
    named(&p, broker, "tmpfs", "dir", "droidloom-apex-devices", "droidloom_apex_device_dir"); printf(",");
    named(&p, broker, "droidloom_apex_device_dir", "chr_file", "loop-control", "droidloom_apex_loop_control_device");
    printf("],\"conditional_grants\":0,\"actual_binary_xperm_bitmaps_verified\":true,"
           "\"kernel_policy_operations\":0,\"live_kernel_decisions\":0,\"runtime_qualified\":false,\"production_ready\":false}\n");
    policydb_destroy(&p); return 0;
}
