import os,resource,pathlib,subprocess,hashlib,json,time,datetime
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));os.sched_setaffinity(0,{18})
b=pathlib.Path('/home/qq/work/p4-broker-mac-provider-20261118-162b-r1')
mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert mem>=23622320128
cg=pathlib.Path('/sys/fs/cgroup'+next(x.split('::',1)[1] for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::')))
limits={n:(cg/n).read_text().strip() for n in ['memory.max','cpu.max']}
assert limits=={'memory.max':'536870912','cpu.max':'100000 100000'}
image='/home/qq/work/p4-official-vendor-cp3a-20261118-162b-r1/official-gsi/images/system.img'
out=b/'plat-dump-scope-r2.cil';assert not out.exists()
cmd=['/usr/sbin/debugfs','-R','dump /system/etc/selinux/plat_sepolicy.cil '+out.name,image]
start=time.monotonic();p=subprocess.Popen(cmd,cwd=b,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={'PATH':'/usr/bin:/usr/sbin:/bin:/sbin','LC_ALL':'C'})
record={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cmd':cmd,'cwd':str(b),'memory_available':mem,'actual_limits':limits,'affinity':sorted(os.sched_getaffinity(0)),'child_pid':p.pid}
try:
 stdout,stderr=p.communicate(timeout=5);record['timed_out']=False
except subprocess.TimeoutExpired:
 record['timed_out']=True;record['child_observation']={}
 for name in ['status','wchan','syscall']:
  try:record['child_observation'][name]=(pathlib.Path('/proc')/str(p.pid)/name).read_text()[:16384]
  except OSError as e:record['child_observation'][name]={'error':repr(e)}
 record['cgroup_at_timeout']={}
 for name in ['memory.current','memory.events','cpu.stat','io.stat','pids.current','pids.max','pids.events','pids.peak']:
  try:record['cgroup_at_timeout'][name]=(cg/name).read_text()[:16384]
  except OSError as e:record['cgroup_at_timeout'][name]={'error':repr(e)}
 p.terminate()
 try:stdout,stderr=p.communicate(timeout=2)
 except subprocess.TimeoutExpired:p.kill();stdout,stderr=p.communicate(timeout=2)
record['pids_observation']={n:(cg/n).read_text().strip() for n in ['pids.current','pids.max','pids.events','pids.peak'] if (cg/n).exists()}
record.update(exit_code=p.returncode,elapsed=time.monotonic()-start,stdout=stdout.decode(errors='replace'),stderr=stderr.decode(errors='replace'))
if out.exists():
 raw=out.read_bytes();record['output']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(b/'extraction-scope-diagnostic-r2.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(record),flush=True)
assert p.returncode==0 and record['output']=={'bytes':3363281,'sha256':'f6422dd5853e815d340f2e9c4dcba2bb1016b55ffc2a073fc916ac23dfe66fc2'}
