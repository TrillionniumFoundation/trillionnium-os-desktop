#!/usr/bin/env python3
"""New strict source reconstruction, not recovery of lost R9 authored files.

The complete saved policy is exported by the exact independent public
libsepol build. Official CP3A neverallow assertions and their original
closed type sets are then added. Existing effective grants are not edited.
"""
import hashlib,json,os,pathlib,re,resource,stat,sys,datetime
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
os.sched_setaffinity(0,{18})
BASE=pathlib.Path(__file__).resolve().parent
TOKEN=re.compile(r'\s+|;[^\n]*|[()]|"(?:[^"\\]|\\.)*"|[^()\s";]+',re.S)
def identity(s):
    return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def complete(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    with os.fdopen(fd,'rb') as f:
        a=os.fstat(f.fileno())
        assert stat.S_ISREG(a.st_mode) and a.st_nlink==1 and 0<a.st_size<=16777216
        raw=f.read();assert len(raw)==a.st_size and identity(a)==identity(os.fstat(f.fileno()))==identity(p.lstat())
    return raw
def parse(raw):
    text=raw.decode('utf-8');roots=[];stack=[];position=0;count=0
    for m in TOKEN.finditer(text):
        assert m.start()==position,('unparsed CIL byte',position)
        position=m.end();token=m.group()
        if token.isspace() or token.startswith(';'):continue
        count+=1;assert count<=2000000 and len(token)<=1048576
        if token=='(':
            row=[]
            if stack:stack[-1].append(row)
            else:roots.append(row)
            stack.append(row);assert len(stack)<=256
        elif token==')':
            assert stack
            stack.pop()
        else:
            assert stack,'atom outside CIL expression'
            stack[-1].append(token if token.startswith('"') else sys.intern(token))
    assert position==len(text) and not stack
    return roots
def render(row):
    return '('+' '.join(render(x) if isinstance(x,list) else x for x in row)+')'
def flat(nodes):
    for row in nodes:
        assert row and isinstance(row[0],str)
        # These inputs must be already flattened platform/kernel CIL.
        assert row[0] not in ('block','in','optional','macro','call','booleanif','tunableif'),row[0]
    return nodes
class Types:
    def __init__(self,rows):
        self.types={r[1] for r in rows if r[0]=='type' and len(r)==2}
        self.attrs={r[1] for r in rows if r[0] in ('typeattribute','typeattributealias') and len(r)==2}
        self.aliases={}
        self.sets={}
        self.cache={}
        self.active=set()
        for r in rows:
            if r[0] in ('typealiasactual','typeattributealiasactual'):
                assert len(r)==3 and all(isinstance(x,str) for x in r)
                if r[1] in self.aliases:assert self.aliases[r[1]]==r[2]
                self.aliases[r[1]]=r[2]
            elif r[0]=='typeattributeset':
                assert len(r)==3 and r[1] in self.attrs
                self.sets.setdefault(r[1],[]).append(r[2])
    def named(self,name):
        if name in self.types:return frozenset([name])
        if name in self.cache:return self.cache[name]
        assert name not in self.active,('recursive type expression',name)
        self.active.add(name)
        if name in self.aliases:value=self.named(self.aliases[name])
        elif name in self.attrs:
            value=frozenset().union(*(self.expr(x) for x in self.sets.get(name,[])))
        else:raise AssertionError(('unknown original type name',name))
        self.active.remove(name);self.cache[name]=value
        assert value<=self.types
        return value
    def expr(self,value):
        if isinstance(value,str):return self.named(value)
        assert isinstance(value,list)
        if not value:return frozenset()
        head=value[0]
        if head=='all':
            assert len(value)==1
            return frozenset(self.types)
        if head=='not':
            assert len(value)==2
            return frozenset(self.types)-self.expr(value[1])
        if head in ('and','or','xor'):
            assert len(value)>=3
            parts=[self.expr(x) for x in value[1:]]
            result=parts[0]
            for part in parts[1:]:
                result=result&part if head=='and' else result|part if head=='or' else result^part
            return result
        return frozenset().union(*(self.expr(x) for x in value))
def write_new(p,raw):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(raw)
    assert complete(p)==raw
    return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def main():
    original=BASE/'cp3a-original-rebuild-r5'
    observation=json.loads(complete(original/'EXTRACTION.json'))
    assert observation['image']['sha256']=='dc781249bb4724b7a0777e5077321b84576db46f61abb4b9086b81077bfd0ab4'
    rows=[];sources=[]
    for member in observation['files']:
        p=original/member['file'];raw=complete(p)
        assert len(raw)==member['bytes'] and hashlib.sha256(raw).hexdigest()==member['sha256']
        rows.extend(flat(parse(raw)));sources.append({'path':str(p),'bytes':len(raw),'sha256':member['sha256']})
    effective_path=BASE/'recorded-effective-policy.cil'
    raw=complete(effective_path);effective=flat(parse(raw))
    assert not any(r[0] in ('neverallow','neverallowx') for r in effective)
    origin=Types(rows);current=Types(effective)
    assert origin.types<=current.types,sorted(origin.types-current.types)
    extra=current.types-origin.types
    assert len(extra)==15 and all(x.startswith('droidloom_') for x in extra),sorted(extra)
    for required in ['droidloom_broker','droidloom_apex_device_dir','droidloom_apex_loop_control_device','droidloom_apex_loop_device']:
        assert required in extra
    additions=[];checks=[];empty=[]
    existing_def={(r[0],r[1]) for r in effective if len(r)>1 and isinstance(r[1],str)}
    # Preserve each original attribute's membership in the original type universe.
    for name in sorted(origin.attrs):
        value=origin.named(name)
        if name in current.attrs:
            assert current.named(name)==value,('existing binary attribute differs from original CP3A set',name)
            checks.append(name)
        elif name not in origin.aliases:
            additions.append(['typeattribute',name])
            if value:additions.append(['typeattributeset',name,sorted(value)])
            else:empty.append(name)
    for name,target in sorted(origin.aliases.items()):
        value=origin.named(name)
        if name in current.aliases or name in current.types or name in current.attrs:
            assert current.named(name)==value,('existing alias differs',name)
            continue
        if name in origin.attrs:
            additions.extend([['typeattributealias',name],['typeattributealiasactual',name,target]])
        else:
            additions.extend([['typealias',name],['typealiasactual',name,target]])
    # CIL permission/class macros can be referenced by original assertions.
    aux=[]
    for row in rows:
        if row[0] in ('classpermission','classpermissionset','permissionx'):
            key=(row[0],row[1])
            if key not in existing_def and render(row) not in {render(x) for x in aux}:aux.append(row)
    additions.extend(aux)
    official=[]
    seen=set()
    for row in rows:
        if row[0] not in ('neverallow','neverallowx'):continue
        # The original generated CIL uses named closed type sets. Refuse an
        # unexpected direct complement rather than widen it to the new types.
        assert len(row)==4 and isinstance(row[1],str) and isinstance(row[2],str),row
        origin.named(row[1])
        if row[2] not in ('self','notself','other'):origin.named(row[2])
        key=render(row)
        if key not in seen:official.append(row);seen.add(key)
    assert official,'official CP3A input contains no recoverable neverallow assertions'
    private=parse(b"""
(typeattribute p4_rebuild_non_broker)
(typeattributeset p4_rebuild_non_broker (not droidloom_broker))
(neverallow p4_rebuild_non_broker droidloom_apex_device_dir (dir (all)))
(neverallow p4_rebuild_non_broker droidloom_apex_loop_control_device (chr_file (all)))
(neverallow p4_rebuild_non_broker droidloom_apex_loop_device (blk_file (all)))
(neverallow droidloom_broker droidloom_apex_loop_control_device (chr_file (not (create getattr read write open ioctl unlink))))
(neverallow droidloom_broker droidloom_apex_loop_device (blk_file (not (create getattr read write open ioctl unlink))))
(neverallow droidloom_broker droidloom_apex_device_dir (file (all)))
(neverallow droidloom_broker droidloom_apex_device_dir (lnk_file (all)))
(neverallowx droidloom_broker droidloom_apex_loop_control_device (ioctl chr_file (not (0x4c82))))
(neverallowx droidloom_broker droidloom_apex_loop_device (ioctl blk_file (not (0x4c01 0x4c05 0x4c0a))))
(neverallow droidloom_broker kernel (security (load_policy)))
(neverallow droidloom_broker self (process (setfscreate)))
(neverallow droidloom_broker loop_control_device (chr_file (all)))
(neverallow droidloom_broker loop_device (blk_file (all)))
(neverallow droidloom_broker dm_device (chr_file (all)))
(neverallow droidloom_broker dm_device (blk_file (all)))
(neverallow droidloom_broker unlabeled (chr_file (all)))
(neverallow droidloom_broker unlabeled (blk_file (all)))
""")
    for name in ['kernel','loop_control_device','loop_device','dm_device','unlabeled']:
        assert name in current.types,('required original device type missing',name)
    dest=BASE/'strict-source-reconstruction-r1';dest.mkdir(mode=0o700)
    frozen=write_new(dest/'effective-policy.cil',raw)
    assertion_raw=(';; Newly restored official assertions and fixed private-loop safeguards.\n'+
                   '\n'.join(render(x) for x in additions+official+private)+'\n').encode()
    assertions=write_new(dest/'official-and-private-assertions.cil',assertion_raw)
    record={'schema':'p4-new-effective-policy-source-reconstruction-v1','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'official_sources':sources,
            'effective_export':{'path':str(effective_path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},
            'saved_binary_sha256':'4ffcd33846438bf2ced8ad1331c8e60233529ab033a683c2e1188e714471c730',
            'effective_grants_edited':False,'new_inputs':[frozen,assertions],
            'original_concrete_types':len(origin.types),'additional_concrete_types':sorted(extra),
            'original_attributes_and_aliases':len(origin.attrs|set(origin.aliases)),
            'existing_attribute_memberships_verified':len(checks),'empty_original_attributes':empty,
            'original_unique_neverallow_assertions':len(official),
            'new_private_safeguard_assertions':sum(x[0].startswith('neverallow') for x in private),
            'original_authored_R9_deriver_recovered':False,'original_authored_R9_assertion_text_recovered':False,
            'original_56_case_source_recovered':False,'old_cloud_logs_restored':False,
            'strict_recompile_complete':False,'kernel_policy_operations':0,'runtime_qualified':False,'production_ready':False}
    metadata=(json.dumps(record,sort_keys=True,indent=2)+'\n').encode()
    write_new(dest/'RECONSTRUCTION.json',metadata)
    print(json.dumps({k:v for k,v in record.items() if k not in ('empty_original_attributes','official_sources')},sort_keys=True),flush=True)
if __name__=='__main__':main()
