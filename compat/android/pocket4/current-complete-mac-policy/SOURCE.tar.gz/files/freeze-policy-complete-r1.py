import os,pathlib,resource,hashlib,json,stat,datetime,tarfile,gzip,io
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));os.sched_setaffinity(0,{18})
B=pathlib.Path('/home/qq/work/p4-broker-mac-provider-20261118-162b-r1')
mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert mem>=23622320128
cg=pathlib.Path('/sys/fs/cgroup'+next(x.split('::',1)[1] for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::')))
limits={n:(cg/n).read_text().strip() for n in ['memory.max','cpu.max']};assert limits=={'memory.max':'536870912','cpu.max':'100000 100000'}
def ident(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 with os.fdopen(fd,'rb') as f:
  a=os.fstat(f.fileno());assert stat.S_ISREG(a.st_mode) and a.st_nlink==1 and a.st_uid==os.getuid() and 0<=a.st_size<=16777216
  raw=f.read();assert len(raw)==a.st_size and ident(a)==ident(os.fstat(f.fileno()))==ident(p.lstat())
 return raw,{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'identity':ident(a)}
validation=json.loads(read(B/'reconstruction-verification-r2'/'RESULT.json')[0])
assert validation['pass_all'] is True and validation['negative_passed']==6 and validation['both_policies_56_and_xperm_pass'] is True
compile_result=json.loads(read(B/'reconstruction-validation-r1'/'RESULT.json')[0])
assert compile_result['strict_compile_pass'] is True and compile_result['actual_binary']['sha256']=='f0f9448e374771bdacd8fe4ecdc861b8e2a3d8f01970b976f4fed412e3c52d09'
frozen2=json.loads(read(B/'offline-increment-2-r2'/'SOURCE_FREEZE.json')[0])
assert frozen2['file_count']==23 and frozen2['negative_controls_passed']==7
for member in frozen2['files']:
 raw,pin=read(B/'offline-increment-2-r2'/'files'/member['path'])
 assert (pin['bytes'],pin['sha256'])==(member['bytes'],member['sha256'])
for reference in frozen2['references']:
 raw,pin=read(pathlib.Path(reference['path']))
 assert (pin['bytes'],pin['sha256'])==(reference['bytes'],reference['sha256'])
flat=[
 'cp3a-r1.policy','libsepol-official-commit.tar','source-manifest.json','source/libsepol/src/libsepol.a',
 'source/libsepol/include/sepol/kernel_to_cil.h','source/libsepol/include/sepol/policydb/flask_types.h',
 'source/libsepol/src/kernel_to_cil.c','policy_roundtrip_tool.c','policy_roundtrip_tool',
 'recorded-effective-policy.cil','reconstruct_strict_source.py','query_explicit_56.c','query_private_loop_binary_512.c',
 'query_private_loop_binary','mutate_private_loop_binary_control','binary-negative-controls.json',
 'fresh-cil-extract-r5.py','strict-reconstruction-run-r1.py','strict-reconstruction-verify-r1.py','strict-reconstruction-verify-r2.py',
 'build-export-policy-r2-observed.py','effective-policy-export-r2.json','effective-policy-export.stdout','effective-policy-export.stderr',
 'roundtrip-tool-build.stdout','roundtrip-tool-build.stderr',
 'extraction-scope-diagnostic-r1.py','extraction-scope-diagnostic-r1.json',
 'extraction-scope-diagnostic-r2.py','extraction-scope-diagnostic-r2.json',
 'terminal-extraction-r5.json','terminal-strict-rebuild-r1.json','terminal-strict-verify-r2.json',
 'terminal-strict-verify-r1-parser-failure.json','terminal-debugfs-tasklimit-r1.json','terminal-debugfs-tasklimit-r2.json',
 'freeze-policy-complete-r1.py'
]
negative=json.loads(read(B/'binary-negative-controls.json')[0])
for control in negative['controls']:
 name='negative-'+control['mutation']+'.policy';raw,pin=read(B/name)
 assert pin['sha256']==control['sha256'] and pin['bytes']==control['bytes'] and control['passed'] is True
 flat.append(name)
directories=['offline-increment-2-r2','cp3a-original-rebuild-r5','strict-source-reconstruction-r1','reconstruction-validation-r1','reconstruction-verification-r1','reconstruction-verification-r2']
selected={pathlib.PurePosixPath(x) for x in flat}
for dirname in directories:
 for path in (B/dirname).rglob('*'):
  st=path.lstat()
  assert not stat.S_ISLNK(st.st_mode)
  if stat.S_ISREG(st.st_mode):selected.add(pathlib.PurePosixPath(path.relative_to(B).as_posix()))
  else:assert stat.S_ISDIR(st.st_mode)
assert len(selected)<=256 and all(not p.is_absolute() and '..' not in p.parts and not str(p).endswith('.rs') for p in selected)
dest=B/'offline-policy-complete-r1';dest.mkdir(mode=0o700);files=dest/'files';files.mkdir(mode=0o700)
entries=[];total=0
for rel in sorted(selected):
 raw,pin=read(B/rel);total+=len(raw);assert total<=67108864
 out=files/rel;out.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
 with out.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 out.chmod(0o444)
 assert read(out)[0]==raw
 entries.append({'path':str(rel),'bytes':pin['bytes'],'sha256':pin['sha256'],'source_identity':pin['identity']})
for entry in entries:
 _,pin=read(B/entry['path'])
 assert (pin['bytes'],pin['sha256'],pin['identity'])==(entry['bytes'],entry['sha256'],entry['source_identity'])
manifest={
 'schema':'p4-fresh-complete-offline-policy-source-freeze-v1',
 'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_file_count':len(entries),'complete_tar_regular_members':len(entries)+1,'source_bytes':total,
 'files':entries,'resource_window':{'memory_available':mem,'limits':limits,'affinity':sorted(os.sched_getaffinity(0))},
 'public_selinux_source_commit':'a8c5e74f85f869bf236a01ba24181b78f5e39a52',
 'official_GSI_reference_not_embedded':{'bytes':2294853632,'sha256':'dc781249bb4724b7a0777e5077321b84576db46f61abb4b9086b81077bfd0ab4','fresh_complete_hash_and_F9_observation':'files/cp3a-original-rebuild-r5/EXTRACTION.json'},
 'separate_policy_identities':{
  'original_saved_complete_binary':{'path':'files/cp3a-r1.policy','bytes':760303,'sha256':'4ffcd33846438bf2ced8ad1331c8e60233529ab033a683c2e1188e714471c730'},
  'new_strict_rebuilt_binary':{'path':'files/strict-source-reconstruction-r1/strict-rebuilt.policy','bytes':764720,'sha256':'f0f9448e374771bdacd8fe4ecdc861b8e2a3d8f01970b976f4fed412e3c52d09'},
  'byte_identical':False,'old_binary_effective_CIL_grants_edited':False,
  'reconstruction_method':'Export saved complete policy using official libsepol; retain full exported effective policy; add original closed CP3A attributes and all official assertions plus explicit private-loop safeguards; strict recompile.'},
 'new_results':{'official_CIL_inputs':7,'original_concrete_types':2151,'original_attributes_and_aliases':3013,'original_neverallow_assertions':5784,'additional_private_assertions':17,'strict_neverallow_compile_exit':0,'explicit_AV_and_unnamed_transition_cases_per_binary':56,'both_binary_decision_suites_pass':True,'strict_CIL_negative_controls':6,'strict_negatives_pass':True,'full_65536_ioctl_bits_per_device_on_both_binaries':True},
 'preserved_offline_increment_2':{'path':'files/offline-increment-2-r2/SOURCE_FREEZE.json','sha256':'54be093336eb7ba5b1c88eb15067e7320484a970be99e7710a15f01d3b8cd30a','files':23,'actual_binary_negative_controls':7},
 'known_missing_original_artifacts':{'old_authored_R9_deriver':True,'old_authored_R9_assertion_text':True,'old_56_case_source_text':True,'lost_Cloud_offline1_logs':True},
 'new_56_cases_are_explicit_restated_contract_not_claimed_old_source_recovery':True,
 'historical_observations_preserved_without_changed_timestamps_or_claims':True,
 'implementation_tests_are_not_live_qualification':True,
 'new_final_vendor_composition':False,'kernel_policy_operations':0,'live_kernel_decisions':0,'actual_private_nodes_created':False,'runtime_qualified':False,'production_ready':False,
 'rust_runtime_sources_included':False
}
raw=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
with (dest/'SOURCE_FREEZE.json').open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
(dest/'SOURCE_FREEZE.json').chmod(0o444)
tarpath=B/'offline-policy-complete-r1.tar.gz';members=[('SOURCE_FREEZE.json',dest/'SOURCE_FREEZE.json')]+[('files/'+e['path'],files/e['path']) for e in entries]
with tarpath.open('xb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,compresslevel=6,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
   for name,path in sorted(members):
    data,pin=read(path);info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o444;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    tar.addfile(info,io.BytesIO(data))
 out.flush();os.fsync(out.fileno())
tarpath.chmod(0o444)
expected={name:read(path)[1] for name,path in members}
with tarfile.open(tarpath,'r:gz') as tar:
 actual=tar.getmembers();assert len(actual)==len(expected) and len({m.name for m in actual})==len(actual)
 for member in actual:
  assert member.name in expected and member.isfile() and member.mode==0o444 and member.uid==member.gid==member.mtime==0
  data=tar.extractfile(member).read();pin=expected[member.name]
  assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256']
for directory in sorted((p for p in dest.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True):directory.chmod(0o555)
dest.chmod(0o555)
_,archive=read(tarpath);_,freeze=read(dest/'SOURCE_FREEZE.json')
receipt={'schema':'p4-complete-offline-policy-archive-v1','archive_path':str(tarpath),'archive_bytes':archive['bytes'],'archive_sha256':archive['sha256'],'freeze_path':str(dest/'SOURCE_FREEZE.json'),'freeze_bytes':freeze['bytes'],'freeze_sha256':freeze['sha256'],'regular_members':len(expected),'source_files':len(entries),'uncompressed_source_bytes':total,'all_members_readback_verified':True,'source_F9_and_SHA_unchanged':True,'runtime_qualified':False,'production_ready':False}
with (B/'offline-policy-complete-r1-ARCHIVE.json').open('x') as f:json.dump(receipt,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(receipt),flush=True)
