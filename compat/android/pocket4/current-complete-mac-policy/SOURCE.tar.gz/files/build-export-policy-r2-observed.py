import os,resource,pathlib,subprocess,json,hashlib,datetime,time
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));os.sched_setaffinity(0,{18})
base=pathlib.Path('/home/qq/work/p4-broker-mac-provider-20261118-162b-r1')
mem=int(next(x for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')).split()[1])*1024
assert mem>=23622320128,mem
cg=pathlib.Path('/sys/fs/cgroup'+next(x.split('::',1)[1] for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::')))
limits={name:(cg/name).read_text().strip() for name in ['memory.max','cpu.max']}
assert limits['memory.max']=='536870912' and sorted(os.sched_getaffinity(0))==[18],limits
quota,period=map(int,limits['cpu.max'].split());assert quota==period
lib=base/'source/libsepol/src/libsepol.a';policy=base/'cp3a-r1.policy';tool=base/'policy_roundtrip_tool'
assert hashlib.sha256(lib.read_bytes()).hexdigest()=='e46408d19036f30310e31d51cc723b201aec9c529bc2183fcb261ab2761d40e1'
assert hashlib.sha256(policy.read_bytes()).hexdigest()=='4ffcd33846438bf2ced8ad1331c8e60233529ab033a683c2e1188e714471c730'
assert hashlib.sha256((base/'policy_roundtrip_tool.c').read_bytes()).hexdigest()=='ed010cdd7e04ae907b46e0d94ec5975707a58db87d76366229a595e0b21050f6'
env={'PATH':'/usr/bin:/bin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'}
cmd=['/usr/bin/cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-I'+str(base/'source/libsepol/include'),'-I'+str(base/'source/libsepol/cil/include'),str(base/'policy_roundtrip_tool.c'),str(lib),'-o',str(tool)]
t=time.monotonic();c=subprocess.run(cmd,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=30)
(base/'roundtrip-tool-build.stdout').write_bytes(c.stdout);(base/'roundtrip-tool-build.stderr').write_bytes(c.stderr)
limits['observed_scheduler_affinity']=sorted(os.sched_getaffinity(0))
record={'schema':'p4-new-policy-export-observation-v1','observed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'MemAvailable':mem,'cgroup':str(cg),'limits':limits,'build':{'args':cmd,'exit':c.returncode,'elapsed':time.monotonic()-t,'stdout':c.stdout.decode(),'stderr':c.stderr.decode()},'kernel_policy_operations':0,'original_authored_source_recovered':False}
if c.returncode==0:
 out=base/'recorded-effective-policy.cil';t=time.monotonic()
 e=subprocess.run([str(tool),'export',str(policy),str(out)],env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=60)
 (base/'effective-policy-export.stdout').write_bytes(e.stdout);(base/'effective-policy-export.stderr').write_bytes(e.stderr)
 record['export']={'exit':e.returncode,'elapsed':time.monotonic()-t,'stdout':e.stdout.decode(),'stderr':e.stderr.decode()}
 if e.returncode==0:
  raw=out.read_bytes();record['export']['output']={'path':str(out),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 record['tool_sha256']=hashlib.sha256(tool.read_bytes()).hexdigest()
with (base/'effective-policy-export-r2.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record),flush=True)
assert c.returncode==0 and record['export']['exit']==0

p=subprocess.run(['/usr/bin/python3','-I','-B',str(base/'fresh-cil-extract-r3.py')],env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=300)
(base/'fresh-extraction-r3.stdout').write_bytes(p.stdout);(base/'fresh-extraction-r3.stderr').write_bytes(p.stderr)
print(json.dumps({'extraction_exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}),flush=True)
assert p.returncode==0
