import os,resource,pathlib,subprocess,hashlib,json,time,datetime,stat,re
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));os.sched_setaffinity(0,{18})
b=pathlib.Path('/home/qq/work/p4-broker-mac-provider-20261118-162b-r1')
mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert mem>=23622320128
cg=pathlib.Path('/sys/fs/cgroup'+next(x.split('::',1)[1] for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::')))
limits={n:(cg/n).read_text().strip() for n in ['memory.max','cpu.max']};assert limits=={'memory.max':'536870912','cpu.max':'100000 100000'}
dest=b/'reconstruction-verification-r2';dest.mkdir(mode=0o700)
env={'PATH':'/usr/bin:/bin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'}
def snap(p):
 st=p.lstat();assert stat.S_ISREG(st.st_mode) and st.st_nlink==1
 raw=p.read_bytes();end=p.lstat();fields=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 assert fields(st)==fields(end) and len(raw)==st.st_size
 return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'identity':fields(st)}
src=b/'strict-source-reconstruction-r1'
inputs=[b/'query_explicit_56.c',b/'query_private_loop_binary_512.c',b/'source/libsepol/src/libsepol.a',b/'policy_roundtrip_tool',b/'cp3a-r1.policy',src/'strict-rebuilt.policy',src/'effective-policy.cil',src/'official-and-private-assertions.cil']
before=[snap(p) for p in inputs]
record={'schema':'p4-new-56-and-strict-six-validation-v1','observed_start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs':before,'actual_limits':limits,'affinity':sorted(os.sched_getaffinity(0)),'memory_available':mem,'commands':[],'negative_cases':[],'kernel_policy_operations':0,'runtime_qualified':False,'production_ready':False,'old_cloud_56_case_source_recovered':False}
def save():
 record['observed_end']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (dest/'RESULT.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
def run(name,cmd,timeout=180):
 print(json.dumps({'starting':name}),flush=True);start=time.monotonic()
 p=subprocess.run(cmd,cwd=b,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,env=env)
 (dest/(name+'.stdout')).write_bytes(p.stdout);(dest/(name+'.stderr')).write_bytes(p.stderr)
 row={'name':name,'command':cmd,'exit_code':p.returncode,'elapsed':time.monotonic()-start,'stdout':snap(dest/(name+'.stdout')),'stderr':snap(dest/(name+'.stderr'))}
 record['commands'].append(row);save();print(json.dumps({'completed':name,'exit_code':p.returncode,'elapsed':row['elapsed']}),flush=True);return p
tool_dir=b/'reconstruction-verification-r1'
for name in ['query_explicit_56','query_private_loop_binary_512']:
 inputs.append(tool_dir/name)
before=[snap(p) for p in inputs];record['inputs']=before
def decision_json(raw):
 parts=raw.split(b'\n',3)
 assert len(parts)==4 and re.fullmatch(rb'libsepol\.policydb_index_others: security:  [0-9]+ users, [0-9]+ roles, [0-9]+ types, 0 bools',parts[0]) and re.fullmatch(rb'libsepol\.policydb_index_others: security: [0-9]+ sens, [0-9]+ cats',parts[1]) and re.fullmatch(rb'libsepol\.policydb_index_others: security:  [0-9]+ classes, [0-9]+ rules, 0 cond rules',parts[2])
 return json.loads(parts[3])
for tag,path in [('saved',b/'cp3a-r1.policy'),('strict-rebuilt',src/'strict-rebuilt.policy')]:
 p=run('56-'+tag,[str(tool_dir/'query_explicit_56'),str(path)],30)
 if p.returncode==0:
  q=decision_json(p.stdout);assert q['passed']==56 and q['total']==56 and all(c['pass'] for c in q['cases'])
 assert p.returncode==0,('56 actual decisions',tag,p.stderr.decode())
 p=run('xperm-'+tag,[str(tool_dir/'query_private_loop_binary_512'),str(path)],30)
 assert p.returncode==0,('complete xperm',tag,p.stderr.decode())
 q=json.loads(p.stdout);assert q['actual_binary_xperm_bitmaps_verified'] is True
record['both_policies_56_and_xperm_pass']=True;save()
negatives=[["block-4c00","(allowx droidloom_broker droidloom_apex_loop_device (ioctl blk_file (0x4c00)))\n","neverallowx"],["control-4c80","(allowx droidloom_broker droidloom_apex_loop_control_device (ioctl chr_file (0x4c80)))\n","neverallowx"],["foreign-init","(allow init droidloom_apex_loop_device (blk_file (read)))\n","neverallow"],["old-loop","(allow droidloom_broker loop_device (blk_file (open ioctl)))\n","neverallow"],["policy-loader","(allow droidloom_broker kernel (security (load_policy)))\n","neverallow"],["untrusted-sysadmin","(allow untrusted_app self (capability (sys_admin)))\n","neverallow"]]
for name,statement,diagnostic in negatives:
 injection=dest/(name+'.cil')
 with injection.open('x') as f:f.write(statement)
 pin=snap(injection);output=dest/(name+'.should-not-exist.policy')
 p=run('negative-'+name,[str(b/'policy_roundtrip_tool'),'compile',str(output),str(src/'effective-policy.cil'),str(src/'official-and-private-assertions.cil'),str(injection)])
 text=p.stderr.decode('utf-8','strict')
 rejected=p.returncode==2 and re.search(r'(?m)^'+diagnostic+r' check failed',text) is not None and not output.exists()
 assert snap(injection)==pin
 row={'name':name,'input':pin,'exit_code':p.returncode,'actual_strict_diagnostic':diagnostic+' check failed','no_binary_published':not output.exists(),'pass':rejected}
 record['negative_cases'].append(row);save();assert rejected,(name,text[-4096:])
assert [snap(p) for p in inputs]==before
record.update(input_F9_and_hash_unchanged=True,negative_passed=len(record['negative_cases']),pass_all=True)
save();print(json.dumps({'pass_all':True,'negative_passed':6,'both_56_and_xperm_pass':True,'result':snap(dest/'RESULT.json')}),flush=True)
