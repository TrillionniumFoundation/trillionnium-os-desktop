import os,resource,pathlib,subprocess,hashlib,json,time,datetime,stat
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));os.sched_setaffinity(0,{18})
b=pathlib.Path('/home/qq/work/p4-broker-mac-provider-20261118-162b-r1')
mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert mem>=23622320128
cg=pathlib.Path('/sys/fs/cgroup'+next(x.split('::',1)[1] for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::')))
limits={n:(cg/n).read_text().strip() for n in ['memory.max','cpu.max']};assert limits=={'memory.max':'536870912','cpu.max':'100000 100000'}
dest=b/'reconstruction-validation-r1';dest.mkdir(mode=0o700)
def snap(p):
 st=p.lstat();assert stat.S_ISREG(st.st_mode) and st.st_nlink==1
 raw=p.read_bytes();end=p.lstat();fields=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 assert fields(st)==fields(end) and len(raw)==st.st_size
 return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'identity':fields(st)}
inputs=[b/'reconstruct_strict_source.py',b/'policy_roundtrip_tool.c',b/'policy_roundtrip_tool',b/'recorded-effective-policy.cil',b/'cp3a-r1.policy',b/'cp3a-original-rebuild-r5'/'EXTRACTION.json']
before=[snap(p) for p in inputs]
commands=[['/usr/bin/python3','-I','-B',str(inputs[0])],[str(b/'policy_roundtrip_tool'),'compile',str(b/'strict-source-reconstruction-r1'/'strict-rebuilt.policy'),str(b/'strict-source-reconstruction-r1'/'effective-policy.cil'),str(b/'strict-source-reconstruction-r1'/'official-and-private-assertions.cil')]]
record={'schema':'p4-new-policy-strict-validation-v1','observed_start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs':before,'actual_limits':limits,'affinity':sorted(os.sched_getaffinity(0)),'memory_available':mem,'commands':[],'kernel_policy_operations':0,'runtime_qualified':False,'production_ready':False}
for i,cmd in enumerate(commands):
 print(json.dumps({'starting':i,'cmd':cmd}),flush=True);start=time.monotonic()
 p=subprocess.run(cmd,cwd=b,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'})
 (dest/(str(i)+'.stdout')).write_bytes(p.stdout);(dest/(str(i)+'.stderr')).write_bytes(p.stderr)
 row={'command':cmd,'exit_code':p.returncode,'elapsed':time.monotonic()-start,'stdout':snap(dest/(str(i)+'.stdout')) if p.stdout else {'bytes':0},'stderr':snap(dest/(str(i)+'.stderr')) if p.stderr else {'bytes':0}}
 record['commands'].append(row);print(json.dumps(row),flush=True)
 if p.returncode:break
assert [snap(p) for p in inputs]==before
record['input_F9_and_hash_unchanged']=True;record['observed_end']=datetime.datetime.now(datetime.timezone.utc).isoformat()
output=b/'strict-source-reconstruction-r1'/'strict-rebuilt.policy'
if output.exists():
 record['actual_binary']=snap(output);record['same_binary_as_saved']=record['actual_binary']['sha256']=='4ffcd33846438bf2ced8ad1331c8e60233529ab033a683c2e1188e714471c730'
record['strict_compile_pass']=len(record['commands'])==2 and all(x['exit_code']==0 for x in record['commands'])
(dest/'RESULT.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(record),flush=True)
assert record['strict_compile_pass']
