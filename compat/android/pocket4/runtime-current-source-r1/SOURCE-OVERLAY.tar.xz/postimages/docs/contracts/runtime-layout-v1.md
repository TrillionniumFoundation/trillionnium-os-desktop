# Runtime and namespace layout v1

This is the construction contract for the Rust `droidloomd`. The supervisor
implements the fail-closed transaction, emits the complete typed Linux
construction/reverse-teardown plan, and provides the executable Android
cell path. `droidloomd` retains the exact namespace child handle while
`droidloomctl` supplies idempotent lifecycle operations. Production user-ID
mapping, cgroup limits, seccomp, and complete packaging hardening remain later
work; the executable path does not claim those unfinished isolation layers.

## Read-only development inspection

`droidloom-supervisor development-inspect --spec <path>` checks the cell
specification, readable image magic, selected GApps hashes, override files,
writable-image metadata and endpoint types without root. It creates no files,
mounts, namespaces, network rules or Android processes. Permission-denied and
missing-input errors are failures; successful inspection does not prove boot,
complete filesystem integrity or isolation. `development-validate`,
`development-run`, and the private namespace entry still require root.

## Intended production identity

The mapping below is a design requirement, not an implemented preview guarantee.

One cell exists for one logged-in host UID. Its stable ID is `u<host-uid>`.
Android UID/GID `0..99999` maps one-to-one onto a dedicated contiguous
subordinate host range of at least 100,000 IDs. Android root is therefore an
unprivileged subordinate host ID, never host root or the interactive host UID.
Ranges must not overlap another allocation or cell.

## Namespaces

The cell receives new user, PID, mount, IPC, UTS, network, and cgroup
namespaces. Android `init` becomes PID 1 only inside the PID namespace. The
supervisor keeps a pidfd and host-side cgroup handle; process names and PID
scans are never lifecycle authority.

## Mount tree

| Cell path | Source/ownership | Required flags |
| --- | --- | --- |
| `/system` | activated package artifact | read-only, nodev |
| `/system/bin/init` | optional package-owned compatibility binary over the activated base | read-only, nosuid, nodev, executable |
| immutable partition file override | optional package-owned compatibility file at its original Android path | read-only, nosuid, nodev, executable mappings allowed |
| `/vendor` | activated package artifact | read-only, nodev |
| `/product` | activated package artifact | read-only, nodev |
| `/data` | per-user `data.img` raw ext4 filesystem | read-write, nodev, nosuid |
| `/metadata` | per-user `metadata.img` raw ext4 filesystem | read-write, nodev, nosuid |
| `/data/media/0/<collection>` | explicitly configured host-user directory | read-write idmapped bind, nodev, nosuid, noexec |
| `/proc` | private procfs | nosuid, nodev, noexec, hide host processes |
| `/sys` | minimal read-only projection/synthetic tree | read-only, nosuid, nodev, noexec |
| `/dev` | private tmpfs | nosuid, strict modes |
| `/dev/pts` | private devpts | nosuid, noexec, newinstance |
| `/dev/binderfs` | private binderfs | three named devices only |

An optional `gapps_dir` in the root-owned cell specification selects a derived
`product`/`system_ext` image pair before Android init starts. `system` and `vendor`
retain their normal sources. The add-on manifest binds all three base partitions
and both derived outputs to exact hashes, Android SDK and native architecture.
Its files and ancestors must be root-owned, without symlinks or group/other write
access. Missing or mismatched selected images fail startup. Omission uses the
base images; installing the optional package does not edit the specification.
Read-only Android image mounts detect raw ext4 or EROFS from the filesystem
magic, including the selected add-on images.

The first GApps activation refuses already initialized Android data. A marker
inside the cell-owned data image records selected packages, signers and manifest
identity. Changing signers/selection or disabling the add-on requires fresh data
or a suitable backup; images alone cannot roll back Google updates in `/data`.
Manifest changes invalidate only the selected Google applications' parser cache.
The runtime never deletes accounts or installed app updates as a side effect.

The supervisor builds the selected private tree before exec. The production
CP3A entry uses the explicitly selected subordinate-user-namespace capability
profile described below. Its `CAP_SYS_ADMIN` is confined to namespaces owned by
that subordinate user namespace; Android receives no initial-user-namespace
authority or general view of host mounts.
Android-controlled system state remains confined to loop-backed filesystems.
Only explicit shared-storage collections may be writable host-directory bind
mounts. They map the host UID to MediaProvider's recorded app UID and the host
GID to Android `media_rw`, and are mounted
`nodev,nosuid,noexec`, and placed behind Android's ordinary emulated-storage
service rather than exposed as Android system state.

The host kernel must provide FUSE. The packaged `vold` recursively binds its
MediaProvider lower view so configured collection submounts remain visible;
both volume teardown paths detach the whole lower tree. A non-recursive bind
exposes the underlying empty mountpoint instead of the host collection.
The supervisor reads MediaProvider's UID once from the initialized data image's
`/data/system/packages.list`; it never guesses an app UID. The test collection
uses setgid directory inheritance so Android-created files retain the mapped
host group. MediaProvider's primary GID is also mapped to a reserved subordinate
host GID, satisfying Linux's creator-credential checks before setgid inheritance.
The temporary mapping helper exits before Android init starts;
the mounts retain the kernel's mapping reference. Initial Android provisioning
must have installed MediaProvider before shared collections can be enabled.

## Device allowlist

The initial device set is null, zero, full, random, urandom, tty/ptmx/devpts,
the standard FUSE node used by Android's private emulated-storage mount,
ashmem only if an AOSP compatibility audit still requires it, the three private
Binder devices, and exactly one configured DRM render node. No `card*`, KMS,
physical input, framebuffer, camera, media, USB, Bluetooth, modem, block, raw
memory, or host control node is allowed. The synthetic sysfs exposes the
otherwise-empty fusectl mount point but no host FUSE connections.

## Host paths

- package-owned: `/usr/lib/droidloom`, `/usr/bin/droidloom-*`, and
  `/usr/share/droidloom`;
- ephemeral: `/run/droidloom/cells/u<uid>` and the user's mode-0700 runtime
  directory socket endpoint;
- system state: `/var/lib/droidloom/images` and activation metadata;
- per-user Android data: a platform-owned directory containing `data.img` and
  `metadata.img`, retained on normal package removal and deleted only by
  explicit wipe; the containing host filesystem is never exposed to Android.
- per-user shared storage: an explicit allowlist of host-owned directories,
  each mapped to one top-level collection below `/storage/emulated/0`; an
  omitted list exposes no host directory.
- per-user application integration: managed `.desktop` files below
  `$XDG_DATA_HOME/applications` with `droidloom-` names, rendered icons below the user's
  hicolor icon tree, and reconciliation state below `$XDG_STATE_HOME/droidloom`.
  Only the unprivileged user service writes these paths.
- per-user window policy: user-selected initial geometry at
  `$XDG_CONFIG_HOME/droidloom/window-policy-v1.json` and automatically
  remembered stable sizes at
  `$XDG_STATE_HOME/droidloom/window-sizes-v1.json`. Only the unprivileged
  presenter and CLI read or write these bounded, versioned documents.

No source-checkout path may appear in a runtime mount or unit.
When selected, `android_init` must be a normalized absolute path to a regular,
executable package-owned file. The supervisor bind-mounts it read-only over the
immutable base's `/system/bin/init`; omitting it retains the base init.
Each `android_file_overrides` entry names a normalized absolute package-owned
regular file and a unique normalized target below `/system`, `/system_ext`,
`/product`, or `/vendor`. Existing targets must be regular files. A missing
leaf is allowed only when every parent already exists as a real directory in
the mounted partition; new directory hierarchies and symlink parents are
refused. Before applying overrides, the supervisor projects each affected
parent into a cell-private tmpfs, retaining original files and subdirectories
as read-only binds and preserving symlink text, ownership, and parent
permissions. It creates only the declared leaf targets and seals the parent
read-only. Held directory descriptors and disabled mount-path
canonicalization keep sibling binds attached to the original image objects.
The underlying partition is never written, and the projection disappears
with the cell mount namespace. All override files are bind-mounted read-only
with executable mappings allowed. `/system/bin/init` remains reserved for the
separately validated `android_init` field.
Each `android_runtime_directories` entry names a normalized, package-owned host
directory and a unique, non-overlapping target below the cell-private
`/droidloom` tree. The supervisor creates the target before entering Android
and bind-mounts the directory read-only with device and setuid semantics
disabled. These projections may contain executable compatibility helpers, but
they are not Android-writable storage and cannot target `/system`, `/vendor`,
`/data`, or another Android namespace.

## Network

Each cell owns a network namespace and one veth peer. Host policy assigns its
address, forwarding, DNS broker, anti-spoofing, and NAT/firewall objects under
a stable cell tag. Android `netd` may operate only inside the cell namespace.
Teardown removes every tagged host object even if Android is unresponsive.

## Construction transaction

Construction is fail-closed and rolls back in reverse ownership order:
reserve identity/cgroup, create namespaces, populate UID/GID maps, assemble
mounts and devices, create Binder contexts, create network policy, apply
resource limits, start init, then publish the per-user lifecycle handle. A
handle is published only after every prerequisite succeeds.

Teardown first refuses new launches, terminates the pidfd-owned namespace,
waits with a bound, kills the remaining cgroup if necessary, removes network
policy/veth, unmounts the private tree, removes runtime paths, and finally
releases the cgroup. Repeating teardown must be safe.

## Lifecycle readiness and progress

`running` means the namespace owner is alive. Android readiness additionally
requires `sys.boot_completed=1`, a running `droidloom-input-bridge`, the task
launcher executable, and the task-control socket. Public `droidloomctl start`
and `restart` wait for readiness; `--no-wait` and internal `--cell` orchestration
retain service/cell-only startup. `droidloomctl wait` observes readiness without
starting or restarting the cell. `status` reports the current observed stage.

Legacy lifecycle requests remain bare JSON objects with a single JSON response.
Interactive clients opt into progress with `{"request": <control request>}`.
The daemon sends newline-delimited `{"progress": "..."}` frames followed by the
normal response object. APK file descriptors still accompany the first request
byte and are accepted only for installation. UID authorization is unchanged;
boot observations are emitted only after authorizing the cell owner.

Boot waiting is bounded at 120 seconds, with short timeouts on readiness probes.
Task-launcher retries share a 120-second execution deadline; application catalog
and package-manager commands use 110 seconds. Timed-out subprocess groups receive
a forced kill after a short grace period. Clients enforce a 250-second wall-clock
request deadline, including queue time, even if progress or partial bytes keep
arriving. Socket writes are bounded, and a full accept queue fails promptly.
Client disconnection does not tear down Android. A timed-out client's operation
may still complete, so its error advises checking the result before retrying.

## Linux CPU inventory projection

The minimal synthetic sysfs exposes only the host kernel's `online`, `possible`,
and `present` CPU-list files through read-only, noexec/nosuid/nodev bind mounts.
It does not expose per-core controls, uevents or the complete host sysfs tree.
These lists report Linux topology, not a fabricated mobile model or a fixed CPU
count; cgroup quotas and CPU affinity remain independent and unchanged. Missing
or invalid source lists and failed read-only mounts fail the boot transaction
instead of silently advertising one CPU.

## Explicit system-as-root GSI layout

The cell specification accepts `image_layout: "gsi_system_as_root"` for a
verified GSI with `/system/product` and `/system/system_ext` inside the system
image. Omitting this field retains `split_partitions`: separate system, product
and system_ext images remain mandatory. There is no missing-file fallback.
Both layouts keep `image_dir/images/system.img` and the explicit raw ext4
`vendor_image`; a GSI cannot select the separate GApps image pair.

Metadata inspection, the auditable Linux plan and the actual namespace executor
consume the same explicit layout. Before exposing a GSI root, the executor
requires real internal partition directories and the exact `/product` and
`/system_ext` aliases. It creates equivalent relative aliases only in the
private synthetic root, preventing host-side absolute-symlink resolution before
chroot. File override targets below these aliases are mapped to their real
`/system` paths; duplicate targets through two names are rejected. Other
symlink-parent and read-only leaf-override restrictions remain in force.
Read-only ext4 image mounts include `noload`, keeping journal replay disabled.

This layout support does not qualify a new Android/framework/APEX/native bridge
cohort or a user-data upgrade. The caller must verify the exact image hashes,
platform/shared-UID signing compatibility and all selected overlays, then run
fresh boot, runtime and application acceptance. No image is rewritten by this
layout selection.

## Production user-namespace broker prerequisite

The owned-child primitive now creates its own fixed child with clone3 and an
atomic pidfd, binds its retained proc directory, start time and user-namespace
FD, and uses a nonce-bound ready/go channel. It strips inherited descriptors
and supplementary groups before entering a new user namespace, writes
exact lease-derived UID/GID maps with initial-userns CAP_SETUID/CAP_SETGID,
retains the original setgroups allow state, and checks the complete
readback before permitting its fixed child to adopt mapped credentials.
The child then parks; this primitive has no external PID-adoption or Android
execution interface. Exit is signalled and reaped through the held pidfd.
An unproven exit retains the exclusive lease and descriptor custody until
process death, while the durable reservation is never reclaimed.

The admitted entry now consumes an opaque HostAdmission that holds the actual
identity lease, complete bounded NSS/provider observations and live-namespace
seals. Its fixed owned worker runs with UID/GID 65534 and cannot issue authority.
Local identity grants, JSON diagnostics, plans and synthetic test fixtures
cannot construct HostAdmission. The fixed mapped keeper can create one owned
PID 1 with private PID, mount, IPC, UTS, network and cgroup namespaces.

Two immutable base-mount descriptors have a separate nonce-bound transfer.
The fixed PID 1 constructs an empty tmpfs root, separate fresh /data and
/metadata, validates the GSI layout, pivots away from inherited host mounts and
parks. No original account-data body is read or mounted by this stage.

A following single-FD DEV transfer accepts only the same tree's opaque
PreparedDevices. The fresh ID-mapped tmpfs has a 64 MiB / 16,384-inode bound,
nosuid/noexec, device access enabled, a 0755 root and exactly seven 0666 nodes:
null 1:3, zero 1:5, full 1:7, random 1:8, urandom 1:9, tty 5:0 and fuse 10:229.
The child rechecks the exact node set and guest UID/GID 0, attaches only at its
private /dev and closes all descriptors except its original control socket.
A second transfer, extra rights, a foreign tree or mismatched nonce is rejected.
No host device inode is bound, chowned or chmodded.

Both stages retain their real mount/loop and lease owners after any attempted
transfer. Teardown first proves PID 1's actual PIDFD reap, closes live-only
namespace FDs, then retires DEV and base resources, and finally reaps the keeper.
An unknown lifetime quarantines all remaining resources and the real lease.

These are construction stages, not a running Android lifecycle. Private controls
remain separate from production HostAdmission. Binder, delegated cgroups, complete runtime/APEX inputs, peer IPC credentials,
exec/seccomp and
normal daemon wiring require their own implementation and qualification.
Original-data mount authority remains closed. Existing development execution is
unchanged; a failed production gate never selects a development fallback.

## Private process-filesystem construction

The fixed owned PID 1 creates its proc fs_context in the actual private PID/user
namespace. A nonce- and SCM_CREDENTIALS-bound single-FD phase sends that context
to the initial-userns broker, which performs only a fixed detached fsmount with
RO, NOSUID, NODEV and NOEXEC. Before returning one mount FD, the broker checks
PROC type, all flags, only PID 1, and PID/user namespace identity against its held
objects. The child attaches it to its private root and repeats full verification.
It never retains or binds host proc. A separate fresh devpts instance uses the
mapped tty GID and only a relative private ptmx link.

The context and returned mount stay in the same TreeChild custody until actual
PIDFD reap; unknown exit quarantines the lease and all remaining descriptors.
The kernel does not automatically lock these flags on an SCM_RIGHTS transfer.
Android proc write/remount policy, runtime/APEX, Binder and exec/seccomp remain
separate gates. This preparation cannot report a Running cell.

## Original init security metadata

The runtime broker checks the held original init inode's `security.selinux`
value against the exact CP3A bytes `u:object_r:init_exec:s0` followed by one NUL.
Its `security.capability` attribute must be absent. The checks use bounded
descriptor reads and preserve the complete sealed file identity, including
ctime, before and after both reads. They run before mount preparation and again
when checking the live namespace or transferring the detached init mount.
Missing, truncated, oversized, different or unreadable labels are rejected;
an empty capability attribute is still present and is rejected. An unsupported
attribute operation does not prove absence.

These checks require preserved input metadata; they neither set a label nor
establish the active SELinux/AppArmor policy or the post-exec process domain.
The execution gate still requires independently implemented live MAC,
init/APEX activation, guest cgroup and final capability/seccomp contracts.
Ordinary xattr storage tests cannot construct that execution capability.

## Concurrent production property observation

The original owned init's boot property is read through the held private
property-area file. Bionic publishes new trie nodes after reserving their
storage and publishes mutable values with each property's dirty bit and
serial. Its global update serial belongs to another area; the boot context's
header serial alone cannot prove a consistent copy.

The reader checks the allocation header around the copy and retains a value
parse error until the actual leaf serial and file identity have been rechecked.
A changed snapshot receives at most three immediate reads, then remains
`Updating` under the existing boot deadline. Dirty values never become Ready.
Identical malformed trie snapshots and stable invalid values still fail;
owner, mode, inode, size, ABI and traversal bounds remain mandatory. These
read retries neither start Android nor issue execution admission.

## Fixed application query inputs

A prepared runtime may select the command layout (`cmd` and `toybox`) or the
Contacts layout, which adds both `app_process64` and `content.jar`. Selection
comes from the verified manifest and stays typed through descriptor transfer,
parent projection checks and the child mount consumer. The Contacts transfer
has a distinct fixed protocol phase and requires the same three descriptors as
the command layout; neither a pathname nor a caller-provided role list is sent.
The legacy readonly runtime retains its two-descriptor transfer. The explicit
production activation layout below adds its two fixed writable roots.

The private query root is an owned read-only, nosuid, nodev tmpfs. Both consumers
require the complete selected leaf set, mapped root ownership and bounded
regular files. Executables use mode 0555. The Contacts JAR uses mode 0444 and
its dedicated `droidloom_provider_jar` label; the app process uses the separate
`droidloom_provider_exec` label. Ordinary command labels do not gain Contacts
execution permissions. The child checks exact labels and absent capabilities,
while the parent retains each original inode and verifies the same mount and
complete identities after projection. Partial Contacts inputs, extra leaves,
symlinks, hard-link aliases and an executable JAR are rejected.

These construction checks preserve source-image bytes and resource custody.
They do not qualify Android startup, provider authorization, Contacts results
or upgrades of retained user data; those need acceptance in the final runtime.

## Original activation owner and scoped final capabilities

The production constructor prepares the listener on the original fresh DEV,
before idmapping and descriptor transfer, with the same live MAC and namespace
owner. Its `MountActivationDev`/`ActivationDevReady` protocol is distinct from
the private seven-device probe. Fresh DEV contains exactly the seven devices
and `socket/droidloom-linkerconfig`; the directory is 0755 and the single
listener inode is 0600. The same directory, socket inode, kernel `SO_COOKIE`,
mapped credentials, MAC observation and retained server FD remain required.

The executed stage requires an actual `ExecutedInitWitness`, with the original
PIDFD, nonce, held proc identity and executable. It uses a separate complete
DEV observation: a bounded descriptor-relative traversal records every inode,
mount ID, file type, mapped owner, symlink target and metadata generation.
Device bodies are not opened and symlink targets are not followed. Two complete
observations must agree. Every later listener revalidation compares the full
inventory, and any new or replaced entry invalidates that observation. Only
the original DEV, devpts and Binder filesystem mounts may be traversed. The
complete prepared runtime mount inventory and existing namespace checks remain
in force; this does not accept an init-created mount namespace or a new mount.

The owner coordinator now consumes the original listener and selected runtime
trampoline/original-linkerconfig inputs. It authenticates the actual peer and
runs the existing bounded broker protocol, retaining the real command exit
and retirement evidence on the same tree owner. The command receives at most
30 seconds and cannot extend the original 120-second preparation deadline.
An error retires that same tree; unproven retirement retains its resources in
the existing quarantine. Neither a socket connection nor a zero process exit
alone constructs Android execution admission.

The production activation layout transfers four fixed descriptors: readonly
runtime image, original init, fresh APEX container and fresh linkerconfig
container. A selected query layout adds its fifth descriptor.
`MountRuntimeActivation` and `MountRuntimeActivationContacts` are distinct
protocol phases; the readonly two/three-descriptor phases cannot select these
writable mounts. Each receiver rejects a phase/arity mismatch and verifies
the original transferred inodes before reporting `RuntimeReady`.

The initial-root broker creates two separate detached tmpfs superblocks and
labels only their fresh root inodes. It requires the original CP3A directory
labels `u:object_r:apex_mnt_dir:s0` and `u:object_r:linkerconfig_file:s0`, with
the original terminating NUL, and absent file-capability attributes. Both roots
are 0755 and receive the exact same admitted user-namespace idmap. `/apex` is
bounded to 64 MiB and 16,384 inodes; `/linkerconfig` is bounded to 16 MiB and
4,096 inodes. These are implementation resource limits, not claims that a boot
has completed within them. Both mounts are writable, nosuid, nodev and noexec;
actual executable APEX payloads need separately verified readonly submounts.
The original runtime-image containers must be empty and remain readonly.

The child checks empty membership, fixed labels, ownership, distinct tmpfs
instances and exact capacities before and after attachment. The parent verifies
the entire mount transition, including every unchanged preexisting mount, and
retains the actual new root inode/mount custody until original-tree retirement.
Later directory contents may change inside these writable roots; their root
identity, owner, mode, labels, flags and capacity may not. A new bind mount or
init-created mount namespace still needs its own transition provider. This
removes the previous readonly-container obstacle to original init's
`mkdir /linkerconfig/bootstrap`, `mkdir /linkerconfig/default` and initial
`ld.config.txt` writes, without treating those writes as successful activation.

The runtime manifest may explicitly select
`execution.scope = "android_cp3a_scoped_capabilities_v1"`. Production requires
this selection, the actual activation inputs and the native-v2 runtime input
contract. The selection is accepted only for these exact original bytes:

| Input | Bytes | SHA-256 |
| --- | ---: | --- |
| Official CP3A system image | 2,294,853,632 | `dc781249bb4724b7a0777e5077321b84576db46f61abb4b9086b81077bfd0ab4` |
| Original `/system/bin/init` | 2,934,488 | `9f69cc83a88db5f8533014cfea5ad9ea8e0454120335329aec27f8d65b2a9537` |

The fixed profile in `production_execution_profile.rs` contains the 23 explicit
capabilities requested by the original system and APEX init scripts plus
`SETPCAP` for init's child-service capability transitions. It selects
`CHOWN`, `DAC_OVERRIDE`, `DAC_READ_SEARCH`, `FOWNER`, `FSETID`, `KILL`, `SETGID`,
`SETUID`, `SETPCAP`, `NET_BIND_SERVICE`, `NET_ADMIN`, `NET_RAW`, `IPC_LOCK`,
`SYS_CHROOT`, `SYS_PTRACE`, `SYS_ADMIN`, `SYS_NICE`, `SYS_RESOURCE`, `MKNOD`,
`AUDIT_CONTROL`, `SYSLOG`, `WAKE_ALARM`, `BLOCK_SUSPEND` and `PERFMON`.
No caller-supplied capability mask is accepted. An altered system or init
requires a separately implemented profile; changing a version string cannot
select this one.

Before changing capabilities the raw child requires PID 1, parent PID 0,
root UID/GID inside the selected namespace, no supplementary groups, NNP=1,
securebits=0 and the original SIGKILL parent-death signal. Complete actual
procfs UID/GID maps must each contain one subordinate extent and must not map
namespace root to initial-namespace root. Kernel `NS_GET_USERNS` observations
must show that the mount, PID, network, IPC, UTS and cgroup namespaces are all
owned by this same subordinate user namespace. Existing parent lease and
original held-namespace checks still apply.

The child rejects unavailable selected bounding bits and an unknown capability
ABI, clears ambient capabilities, removes every unselected bounding bit and
sets permitted/effective/bounding to `0000005c49ac75ff`, with inheritable and
ambient both zero. It reads all five sets back and rechecks NNP, securebits,
parent-death signal and namespace ownership before arming the existing MAC
stack and seccomp filter. Securebits remain zero so original init's ordinary
setuid and ambient-capability child-service transitions are possible. The
post-exec observer must also retain the opaque exact-image runtime profile and
observe the same five masks, NNP=1 and filtering mode 2 on the original held
proc descriptor.

These checks do not grant initial-user-namespace operations. A capability
whose requested operation is checked in the initial user namespace still
cannot authorize that operation here, and the independent MAC/seccomp layers
remain mandatory. Root services without explicit capability declarations are
bounded by this profile as well. Successful boot and their required behavior
must be established by actual runtime acceptance.

Remaining execution contracts include the actual original-init APEX payload
and linkerconfig bind-mount transitions, the original trampoline projection,
default-mount-namespace transition, and guest cgroup/task-profile acceptance.
The complete `VerifiedExecutionContracts` type remains uninhabited until those
providers exist. Input declarations never construct execution admission.

## Fixed original-linkerconfig input production

The runtime-inputs adapter can select
`activation.scope = "cp3a_original_linkerconfig_inputs_v1"` with complete held
`FileRef` records for `original`, `trampoline` and `build_provenance`. The
explicit CP3A execution selection is also required. The producer emits the
consumer's `activation` declaration only after checking the exact original
runtime APEX payload and reading `/bin/linkerconfig` from that filesystem with
the fixed verified debugfs tool. That whole body must equal the separately
held original ELF. Original label bytes are extracted and its entire xattr
inventory must show the exact linkerconfig label and no file capabilities.

The original linkerconfig input is 512,120 bytes, SHA-256
`40105456e35de393c382d5ec9794a2cd30370291a0502e58bb24d6ae2b417ede`, with actual
interpreter `/system/bin/linker64`. Its source is the 11,452,416-byte runtime
APEX payload, SHA-256
`f97a0b03fb4b5dc91ddc71b02fc1f9831749d4a2e3f7cd6db47e3378f31a6345`.

The fixed freestanding trampoline is 24,384 bytes, SHA-256
`71ea5a2f70f4674ff2028dcdfe2ca6ee0d5ab1968ec21c5a3b0ee7be4d555e70`.
It was built in two distinct directories with identical output, Rust 1.93.0
and that toolchain's own `rust-lld`. The Rust channel manifest SHA-256 is
`beb6ba4e41c84e9c11c80e6804a007497d0c8ba0810cd403fabc8f4a9c45b1f8`.
The exact sources are `linkerconfig_trampoline.rs`, SHA-256
`d9368ae085d216091e2228a01206309b4e58022087115001a3744fb2f0a51e15`, and
`production_activation_protocol.rs`, SHA-256
`75a6c01c9e7f482df64931f23c0219251312fa2afe15fd2e055a72ac196f9db3`.
An ordinary test hashes those actual current source files, so a source change
requires an explicit new build and pin. The pinned ELF has no interpreter,
dynamic segment or writable/executable load segment; actual invocation with
invalid arguments exits 126. This refusal is not a successful activation test.

The reproducible compiler settings are edition 2024, target
`x86_64-unknown-linux-gnu`, crate name `droidloom_linkerconfig_trampoline`,
panic=abort, opt-level=2, codegen-units=1, debuginfo=0, strip=symbols and
relocation-model=static. Select the pinned toolchain's `rust-lld` with
linker-flavor=ld.lld and link arguments `--build-id=none`, `-static`, `-nostdlib`
and `-znoexecstack`; remap the source directory to
`/droidloom/trampoline-source`. The actual build record retains both commands
and complete output hashes. A build record alone cannot replace the separately
verified ELF pin or provide runtime credit.

The producer creates `linkerconfig-original` and `linkerconfig-trampoline` with
mode 0555 and records explicit installation requirements for initial-root
ownership, the complete `linkerconfig_exec` label and absent capability xattrs.
It does not relabel source image inodes, install the output, load a host policy,
or run the original linkerconfig. Production rechecks those exact code pins
alongside the actual sealed files and same-owner executable mounts. The input
production record continues to report installation, activation and runtime
qualification as pending.

## Original fixed application query input production

An adapter with the explicit CP3A execution selection can also select
`query.scope = "cp3a_fixed_application_query_inputs_v1"`. This closed object
accepts no executable paths or replacement files. The producer reads the four
fixed members directly from the same held, fully verified system image with
the pinned filesystem tool. It verifies each whole body, ELF interpreter or
JAR format, original inode mode and ownership, complete SELinux label bytes,
and absence of other xattrs. The output selects the existing fixed command
and Contacts query roles; it adds no query command or application authority.

| Original member | Bytes | Original owner/mode | SHA-256 |
| --- | ---: | --- | --- |
| `/system/bin/cmd` | 52,160 | 0:2000 / 0755 | `237410b6f4bfb9586a9a1135feaa4e75c189288483575890447aa5d492c56984` |
| `/system/bin/toybox` | 611,248 | 0:2000 / 0755 | `5c2b46686560564967fb5c1cb4ec633c42f658c347831c1d8c788ecf66e1774b` |
| `/system/bin/app_process64` | 51,616 | 0:2000 / 0755 | `bcc150b9c7e2abcc9aef312ea04f5bbcba631dbb2e23cb1b240b7219df1229a2` |
| `/system/framework/content.jar` | 20,158 | 0:0 / 0644 | `c0ee6290243eda4a6dd95292c28274dd199b82b57466e00a83e1bb1a50eae8b3` |

All three ELF interpreters are `/system/bin/linker64`. The original labels
are respectively `system_file`, `toolbox_exec`, `zygote_exec` and
`system_file`, each with the actual complete Android context and trailing
NUL. Production checks the same exact source pins. The original-image
verifier preserves the three executables' mapped Android shell group 2000;
it does not confuse those inodes with the root-owned sealed input copies.
The content JAR remains a distinct nonexecutable role with its original
root group and exact mode. No source inode is relabelled or chowned.

The producer creates the three sealed input candidates with mode 0555 and
the JAR with mode 0444. `QUERY-INSTALL-REQUIREMENTS.json` records the actual
source metadata and explicit root ownership/label requirements for later
installation. The consumer still requires the original labels before
constructing separately labelled read-only private query projections.
Extraction, copies and metadata checks provide no successful query,
Contacts response, application admission or runtime qualification.
