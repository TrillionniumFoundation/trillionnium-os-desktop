//! Detached, read-only host procfs with an explicit SELinux context provider.
//! Creation stays in the original initial user/PID namespaces. Foreign reads
//! accept only the original executed init or its owned activation peer; no
//! supplied PID, path, prior receipt or caller-chosen role can issue a read.
use super::*;

const NSFS_MAGIC: u64 = 0x6e73_6673;
const PIDFS_MAGIC: u64 = 0x5049_4446;
const NS_GET_NSTYPE: libc::c_ulong = 0xb703;
const NS_GET_ID: libc::c_ulong = 0x8008_b70d;
const PIDFD_GET_INFO: libc::c_ulong = 0xc048_ff0b;
const PIDFD_THREAD: u32 = 0x80;
const MOUNTINFO_MAX: usize = 16 * 1024 * 1024;

#[repr(C)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct PidfdInfo {
    mask: u64,
    cgroup: u64,
    pid: u32,
    tgid: u32,
    ppid: u32,
    ruid: u32,
    rgid: u32,
    euid: u32,
    egid: u32,
    suid: u32,
    sgid: u32,
    fsuid: u32,
    fsgid: u32,
    exit_code: i32,
    coredump: u32,
    spare: u32,
}
const _: () =
    assert!(std::mem::size_of::<PidfdInfo>() == 72 && std::mem::align_of::<PidfdInfo>() == 8);

fn file(rc: libc::c_long) -> Result<File> {
    if rc < 0 {
        return Err(io::Error::last_os_error().into());
    }
    let fd = i32::try_from(rc).map_err(|_| MacError::Rejected("host proc descriptor overflow"))?;
    Ok(unsafe { File::from_raw_fd(fd) })
}
fn success(rc: libc::c_long) -> Result<()> {
    if rc == 0 {
        Ok(())
    } else {
        Err(io::Error::last_os_error().into())
    }
}
fn alive(fd: BorrowedFd<'_>) -> Result<()> {
    let mut p = libc::pollfd {
        fd: fd.as_raw_fd(),
        events: libc::POLLIN,
        revents: 0,
    };
    let rc = unsafe { libc::poll(&mut p, 1, 0) };
    if rc < 0 {
        return Err(io::Error::last_os_error().into());
    }
    require(rc == 0 && p.revents == 0, "original PIDFD must remain live")
}
fn pidfd_info(fd: BorrowedFd<'_>) -> Result<PidfdInfo> {
    alive(fd)?;
    let before = descriptor_identity(fd)?;
    let mut fs: libc::statfs = unsafe { std::mem::zeroed() };
    success(unsafe { libc::fstatfs(fd.as_raw_fd(), &mut fs) } as libc::c_long)?;
    require(
        fs.f_type as u64 == PIDFS_MAGIC,
        "original kernel pidfs descriptor required",
    )?;
    let mut value: PidfdInfo = unsafe { std::mem::zeroed() };
    value.mask = 3;
    success(unsafe { libc::ioctl(fd.as_raw_fd(), PIDFD_GET_INFO, &mut value) } as libc::c_long)?;
    require(
        value.mask & 3 == 3
            && value.mask & !7 == 0
            && value.pid > 0
            && value.tgid > 0
            && value.exit_code == 0
            && value.coredump == 0
            && value.spare == 0,
        "complete live PIDFD info with no terminal state",
    )?;
    require(
        descriptor_identity(fd)? == before,
        "original PIDFD inode changed",
    )?;
    alive(fd)?;
    Ok(value)
}
fn canonical(bytes: &[u8], zero: bool) -> Result<u64> {
    require(
        !bytes.is_empty()
            && bytes.len() <= 20
            && bytes.iter().all(u8::is_ascii_digit)
            && (bytes.len() == 1 || bytes[0] != b'0'),
        "canonical bounded proc integer",
    )?;
    let value = std::str::from_utf8(bytes)
        .map_err(|_| MacError::Rejected("proc integer encoding"))?
        .parse::<u64>()
        .map_err(|_| MacError::Rejected("proc integer overflow"))?;
    require(zero || value > 0, "positive proc identity integer")?;
    Ok(value)
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct Process {
    pid: u32,
    tgid: u32,
    parent: u32,
    start: u64,
}
fn stat_identity(raw: &[u8]) -> Result<(u32, u32, u64)> {
    require(
        !raw.is_empty()
            && raw.len() <= 65536
            && raw.ends_with(b"\n")
            && !raw[..raw.len() - 1].contains(&b'\n'),
        "complete bounded proc stat record",
    )?;
    let start = raw
        .windows(2)
        .position(|w| w == b" (")
        .ok_or(MacError::Rejected("proc stat command start"))?;
    let end = raw
        .iter()
        .rposition(|b| *b == b')')
        .ok_or(MacError::Rejected("proc stat command end"))?;
    require(
        end > start + 1 && raw.get(end + 1) == Some(&b' '),
        "complete proc stat command",
    )?;
    let pid = u32::try_from(canonical(&raw[..start], false)?)
        .map_err(|_| MacError::Rejected("proc PID overflow"))?;
    let tail = &raw[end + 2..raw.len() - 1];
    let parts: Vec<_> = tail
        .split(|b| b.is_ascii_whitespace())
        .filter(|p| !p.is_empty())
        .collect();
    require(
        (50..=64).contains(&parts.len())
            && parts[0].len() == 1
            && b"RSDTtWIP".contains(&parts[0][0]),
        "complete live proc stat fields",
    )?;
    let parent = u32::try_from(canonical(parts[1], true)?)
        .map_err(|_| MacError::Rejected("proc parent overflow"))?;
    Ok((pid, parent, canonical(parts[19], false)?))
}
fn status_number(raw: &[u8], key: &[u8]) -> Result<u32> {
    require(
        !raw.is_empty() && raw.len() <= 65536 && raw.ends_with(b"\n"),
        "complete bounded proc status",
    )?;
    let mut values = raw
        .split(|b| *b == b'\n')
        .filter_map(|line| line.strip_prefix(key));
    let value = values
        .next()
        .ok_or(MacError::Rejected("required proc status field absent"))?;
    require(
        values.next().is_none(),
        "duplicate proc status identity field",
    )?;
    let parts: Vec<_> = value
        .split(|b| b.is_ascii_whitespace())
        .filter(|p| !p.is_empty())
        .collect();
    require(parts.len() == 1, "one exact proc status identity integer")?;
    u32::try_from(canonical(parts[0], true)?)
        .map_err(|_| MacError::Rejected("proc status identity overflow"))
}
fn proc_read(directory: &File, name: &CStr) -> Result<Vec<u8>> {
    require(
        kind(directory)? == PROC_MAGIC,
        "actual held process procfs required",
    )?;
    let opened = open_at(directory.as_raw_fd(), name, libc::O_RDONLY)?;
    require(
        kind(&opened)? == PROC_MAGIC && Node::of(&opened)?.mode & libc::S_IFMT == libc::S_IFREG,
        "fixed actual proc regular file",
    )?;
    bounded(&opened, 65536)
}
fn process(directory: &File) -> Result<Process> {
    let before = Node::of(directory)?;
    require(
        before.mode & libc::S_IFMT == libc::S_IFDIR && kind(directory)? == PROC_MAGIC,
        "actual original proc directory",
    )?;
    let first = stat_identity(&proc_read(directory, c"stat")?)?;
    let status = proc_read(directory, c"status")?;
    let result = Process {
        pid: status_number(&status, b"Pid:")?,
        tgid: status_number(&status, b"Tgid:")?,
        parent: status_number(&status, b"PPid:")?,
        start: first.2,
    };
    require(
        (result.pid, result.parent, result.start) == first
            && stat_identity(&proc_read(directory, c"stat")?)? == first
            && Node::of(directory)? == before,
        "stable actual PID, parent, start time and original proc inode",
    )?;
    Ok(result)
}
fn namespace(directory: &File, name: &CStr, expected_kind: i32) -> Result<(File, Node, u64)> {
    let ns = open_at(
        directory.as_raw_fd(),
        c"ns",
        libc::O_PATH | libc::O_DIRECTORY,
    )?;
    require(
        kind(&ns)? == PROC_MAGIC,
        "actual fixed proc namespace directory",
    )?;
    // Only these two fixed kernel namespace magic links are intentionally followed.
    let f = file(unsafe {
        libc::openat(
            ns.as_raw_fd(),
            name.as_ptr(),
            libc::O_RDONLY | libc::O_CLOEXEC,
        )
    } as libc::c_long)?;
    require(
        kind(&f)? == NSFS_MAGIC,
        "actual kernel namespace descriptor",
    )?;
    let node = Node::of(&f)?;
    let nstype = unsafe { libc::ioctl(f.as_raw_fd(), NS_GET_NSTYPE, 0 as libc::c_ulong) };
    if nstype < 0 {
        return Err(io::Error::last_os_error().into());
    }
    let mut id = 0_u64;
    success(unsafe { libc::ioctl(f.as_raw_fd(), NS_GET_ID, &mut id) } as libc::c_long)?;
    require(
        nstype == expected_kind && id != 0 && Node::of(&f)? == node,
        "fixed actual namespace type and identity",
    )?;
    Ok((f, node, id))
}
fn same_namespaces(original: &File, view: &File) -> Result<()> {
    for (name, kind) in [(c"user", libc::CLONE_NEWUSER), (c"pid", libc::CLONE_NEWPID)] {
        let (a, an, aid) = namespace(original, name, kind)?;
        let (b, bn, bid) = namespace(view, name, kind)?;
        require(
            an == bn && aid == bid && Node::of(&a)? == an && Node::of(&b)? == bn,
            "new proc view must name the same original user/PID namespaces",
        )?;
    }
    Ok(())
}
fn mount_id(f: &File) -> Result<u64> {
    let mut value: libc::statx = unsafe { std::mem::zeroed() };
    success(unsafe {
        libc::syscall(
            libc::SYS_statx,
            f.as_raw_fd(),
            c"".as_ptr(),
            libc::AT_EMPTY_PATH,
            0x1000_u32,
            &mut value,
        )
    })?;
    require(
        value.stx_mask & 0x1000 != 0 && value.stx_mnt_id != 0,
        "actual held proc mount ID",
    )?;
    Ok(value.stx_mnt_id)
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct Volume {
    dev: u64,
    ino: u64,
    mode: u32,
    uid: u32,
    gid: u32,
    mount: u64,
    fsid: [u8; 8],
}
fn volume(root: &File) -> Result<Volume> {
    let n = Node::of(root)?;
    let mut fs: libc::statfs = unsafe { std::mem::zeroed() };
    success(unsafe { libc::fstatfs(root.as_raw_fd(), &mut fs) } as libc::c_long)?;
    let mut v: libc::statvfs = unsafe { std::mem::zeroed() };
    success(unsafe { libc::fstatvfs(root.as_raw_fd(), &mut v) } as libc::c_long)?;
    require(
        fs.f_type as u64 == PROC_MAGIC
            && n.mode == libc::S_IFDIR | 0o555
            && n.uid == 0
            && n.gid == 0
            && v.f_flag & 15 == 15,
        "actual readonly nosuid nodev noexec root proc view",
    )?;
    const _: () = assert!(std::mem::size_of::<libc::fsid_t>() == 8);
    let fsid = unsafe { std::mem::transmute::<libc::fsid_t, [u8; 8]>(fs.f_fsid) };
    Ok(Volume {
        dev: n.dev,
        ino: n.ino,
        mode: n.mode,
        uid: n.uid,
        gid: n.gid,
        mount: mount_id(root)?,
        fsid,
    })
}
fn absent_mount(bytes: &[u8], mount: u64) -> Result<()> {
    require(
        !bytes.is_empty() && bytes.len() <= MOUNTINFO_MAX && bytes.ends_with(b"\n"),
        "complete bounded original host mount inventory",
    )?;
    let text = std::str::from_utf8(bytes)
        .map_err(|_| MacError::Rejected("host mount inventory encoding"))?;
    let mut seen = BTreeSet::new();
    for line in text.lines() {
        let fields: Vec<_> = line.split_ascii_whitespace().collect();
        require(
            fields.len() >= 10 && fields.iter().filter(|x| **x == "-").count() == 1,
            "complete host mount inventory row",
        )?;
        let id = canonical(fields[0].as_bytes(), false)?;
        require(
            id != mount && seen.insert(id),
            "host selected proc must stay detached; mount IDs must be unique",
        )?;
    }
    Ok(())
}
fn detached(loaded: &LoadedPolicyWitness, id: u64) -> Result<()> {
    let file = open_at(loaded.own_proc.as_raw_fd(), c"mountinfo", libc::O_RDONLY)?;
    require(
        kind(&file)? == PROC_MAGIC,
        "original caller mount inventory from procfs",
    )?;
    absent_mount(&bounded(&file, MOUNTINFO_MAX)?, id)
}
fn broker(loaded: &LoadedPolicyWitness, selection: &ProductionSelection) -> Result<()> {
    loaded.revalidate(selection)?;
    require(
        context_matches(&self_attr::selinux_current()?, BROKER),
        "actual typed initial broker SELinux identity",
    )?;
    require(
        proc_attr(&loaded.own_proc, true)? == AA_BROKER,
        "actual original broker AppArmor identity",
    )?;
    self_attr::require_no_fscreate()?;
    loaded.stable_epoch()
}
/// A privately created representation view. Its descriptors are never exported
/// to a guest or caller and it is never grafted onto a host/guest path.
pub(super) struct HostProcView {
    mount: File,
    root: File,
    own: File,
    own_pidfd: File,
    own_node: Node,
    own_process: Process,
    own_info: PidfdInfo,
    volume: Volume,
    provider: ProviderBinding,
    _same_thread: PhantomData<Rc<()>>,
}
impl HostProcView {
    pub(super) fn create(
        loaded: &LoadedPolicyWitness,
        selection: &ProductionSelection,
    ) -> Result<Self> {
        broker(loaded, selection)?;
        let own_pidfd =
            file(unsafe { libc::syscall(libc::SYS_pidfd_open, loaded.tid, PIDFD_THREAD) })?;
        let own_info = pidfd_info(own_pidfd.as_fd())?;
        require(
            own_info.pid == loaded.tid as u32,
            "PIDFD is the original actual broker thread",
        )?;
        let original = process(&loaded.own_proc)?;
        require(
            (original.pid, original.tgid, original.parent)
                == (own_info.pid, own_info.tgid, own_info.ppid),
            "original broker proc and PIDFD agree",
        )?;
        let mut sequence = Some(loaded.av_sequence);
        access(
            &loaded.root,
            BROKER,
            "u:object_r:proc:s0",
            "filesystem",
            &["mount", "getattr"],
            true,
            &mut sequence,
        )?;
        let context = file(unsafe { libc::syscall(libc::SYS_fsopen, c"proc".as_ptr(), 1_u32) })?;
        for (key, value) in [
            (c"hidepid", c"2"),
            (c"gid", c"0"),
            (c"subset", c"pid"),
            (c"lsm_context", c"selinux"),
        ] {
            success(unsafe {
                libc::syscall(
                    libc::SYS_fsconfig,
                    context.as_raw_fd(),
                    1_u32,
                    key.as_ptr(),
                    value.as_ptr(),
                    0,
                )
            })?;
        }
        broker(loaded, selection)?;
        success(unsafe {
            libc::syscall(
                libc::SYS_fsconfig,
                context.as_raw_fd(),
                6_u32,
                std::ptr::null::<libc::c_char>(),
                std::ptr::null::<libc::c_char>(),
                0,
            )
        })?;
        let mount =
            file(unsafe { libc::syscall(libc::SYS_fsmount, context.as_raw_fd(), 1_u32, 15_u32) })?;
        let root = open_at(mount.as_raw_fd(), c".", libc::O_RDONLY | libc::O_DIRECTORY)?;
        let snapshot = volume(&root)?;
        require(
            volume(&mount)? == snapshot,
            "original created mount/root custody",
        )?;
        detached(loaded, snapshot.mount)?;
        let name = CString::new(own_info.pid.to_string())
            .map_err(|_| MacError::Rejected("actual thread proc name"))?;
        let own = open_at(root.as_raw_fd(), &name, libc::O_RDONLY | libc::O_DIRECTORY)?;
        require(
            mount_id(&own)? == snapshot.mount && process(&own)? == original,
            "host view resolves the same actual broker thread",
        )?;
        same_namespaces(&loaded.own_proc, &own)?;
        let value = Self {
            mount,
            root,
            own_node: Node::of(&own)?,
            own,
            own_pidfd,
            own_process: original,
            own_info,
            volume: snapshot,
            provider: loaded.binding(),
            _same_thread: PhantomData,
        };
        value.revalidate(loaded, selection)?;
        Ok(value)
    }
    pub(super) fn revalidate(
        &self,
        loaded: &LoadedPolicyWitness,
        selection: &ProductionSelection,
    ) -> Result<()> {
        require(
            self.provider == loaded.binding(),
            "host proc belongs to another original provider or epoch",
        )?;
        broker(loaded, selection)?;
        require(
            volume(&self.mount)? == self.volume
                && volume(&self.root)? == self.volume
                && mount_id(&self.own)? == self.volume.mount
                && Node::of(&self.own)? == self.own_node,
            "original private readonly proc mount and broker inode",
        )?;
        detached(loaded, self.volume.mount)?;
        require(
            pidfd_info(self.own_pidfd.as_fd())? == self.own_info
                && process(&loaded.own_proc)? == self.own_process
                && process(&self.own)? == self.own_process,
            "original broker PIDFD and both held proc identities",
        )?;
        same_namespaces(&loaded.own_proc, &self.own)?;
        require(
            context_matches(&proc_attr(&self.own, false)?, BROKER)
                && context_matches(&self_attr::selinux_current()?, BROKER),
            "explicit proc SELinux provider must agree with actual typed CURRENT",
        )?;
        require(
            proc_attr(&self.own, true)? == AA_BROKER,
            "selected proc keeps explicit enforcing AppArmor observation",
        )?;
        require(
            pidfd_info(self.own_pidfd.as_fd())? == self.own_info,
            "broker PIDFD changed during view revalidation",
        )?;
        loaded.stable_epoch()
    }
    fn observe(
        &self,
        loaded: &LoadedPolicyWitness,
        selection: &ProductionSelection,
        original: &File,
        pidfd: BorrowedFd<'_>,
        expected: &str,
    ) -> Result<Vec<u8>> {
        self.revalidate(loaded, selection)?;
        let held = descriptor_identity(pidfd)?;
        let before = pidfd_info(pidfd)?;
        let original_node = Node::of(original)?;
        let original_process = process(original)?;
        require(
            (
                original_process.pid,
                original_process.tgid,
                original_process.parent,
            ) == (before.pid, before.tgid, before.ppid)
                && before.pid == before.tgid,
            "original live process PIDFD/proc identities",
        )?;
        let name = CString::new(before.pid.to_string())
            .map_err(|_| MacError::Rejected("actual PIDFD-derived proc name"))?;
        let viewed = open_at(
            self.root.as_raw_fd(),
            &name,
            libc::O_RDONLY | libc::O_DIRECTORY,
        )?;
        let node = Node::of(&viewed)?;
        require(
            mount_id(&viewed)? == self.volume.mount && process(&viewed)? == original_process,
            "selected view resolves only the same original process and start time",
        )?;
        same_namespaces(original, &viewed)?;
        let context = proc_attr(&viewed, false)?;
        require(
            context_matches(&context, expected),
            "actual original foreign SELinux role differs",
        )?;
        require(
            proc_attr(&viewed, true)? == AA_ANDROID,
            "actual original foreign AppArmor role differs",
        )?;
        require(
            Node::of(&viewed)? == node
                && process(&viewed)? == original_process
                && Node::of(original)? == original_node
                && process(original)? == original_process
                && descriptor_identity(pidfd)? == held
                && pidfd_info(pidfd)? == before,
            "original foreign process changed across selected context read",
        )?;
        same_namespaces(original, &viewed)?;
        self.revalidate(loaded, selection)?;
        Ok(context)
    }
    pub(super) fn for_init(
        &self,
        loaded: &LoadedPolicyWitness,
        init: &ExecutedInitWitness<'_>,
    ) -> Result<Vec<u8>> {
        original_owner(init.revalidate())?;
        let generation = original_owner(init.generation())?;
        require(
            pidfd_info(init.pidfd())?.pid == init.host_pid(),
            "selected init is the original host PIDFD",
        )?;
        let observed = self.observe(
            loaded,
            init.selection(),
            init.proc_directory(),
            init.pidfd(),
            INIT,
        )?;
        original_owner(init.revalidate())?;
        require(
            original_owner(init.generation())? == generation,
            "original init generation changed across host view read",
        )?;
        Ok(observed)
    }
    pub(super) fn for_helper(
        &self,
        loaded: &LoadedPolicyWitness,
        init: &ExecutedInitWitness<'_>,
        peer: &OwnedActivationPeer<'_>,
    ) -> Result<Vec<u8>> {
        original_owner(init.revalidate())?;
        original_owner(peer.revalidate())?;
        let generation = original_owner(init.generation())?;
        require(
            peer.generation() == generation && pidfd_info(peer.pidfd())?.ppid == init.host_pid(),
            "fixed helper is this original init's descendant",
        )?;
        let observed = self.observe(
            loaded,
            init.selection(),
            peer.proc_directory(),
            peer.pidfd(),
            LINKERCONFIG,
        )?;
        original_owner(peer.revalidate())?;
        original_owner(init.revalidate())?;
        require(
            peer.generation() == generation && original_owner(init.generation())? == generation,
            "original helper/init generation changed across host view read",
        )?;
        Ok(observed)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn original_process_pidfd_and_proc_agree_without_issuing_a_mac_view() {
        let proc = File::open("/proc/self").unwrap();
        let observed = process(&proc).unwrap();
        let fd =
            file(unsafe { libc::syscall(libc::SYS_pidfd_open, libc::getpid(), 0_u32) }).unwrap();
        let pid = pidfd_info(fd.as_fd()).unwrap();
        assert_eq!(
            (observed.pid, observed.tgid, observed.parent),
            (pid.pid, pid.tgid, pid.ppid)
        );
        assert!(observed.start > 0);
    }
    #[test]
    fn ordinary_files_cannot_supply_pidfd_or_proc_mount_authority() {
        let regular = tempfile::tempfile().unwrap();
        assert!(pidfd_info(regular.as_fd()).is_err());
        assert!(process(&regular).is_err());
        assert!(volume(&regular).is_err());
    }
    #[test]
    fn stat_parser_rejects_incomplete_dead_and_ambiguous_identity_records() {
        let proc = File::open("/proc/self").unwrap();
        let raw = proc_read(&proc, c"stat").unwrap();
        assert!(stat_identity(&raw).is_ok());
        assert!(stat_identity(&raw[..raw.len() - 1]).is_err());
        let end = raw.iter().rposition(|b| *b == b')').unwrap();
        let mut dead = raw.clone();
        dead[end + 2] = b'Z';
        assert!(stat_identity(&dead).is_err());
        let mut extra = raw.clone();
        extra.extend_from_slice(b"\n");
        assert!(stat_identity(&extra).is_err());
        assert!(status_number(b"Pid:\t1\nPid:\t1\n", b"Pid:").is_err());
        assert!(status_number(b"Pid:\t01\n", b"Pid:").is_err());
    }
    #[test]
    fn detached_view_inventory_rejects_attached_reused_and_truncated_mount_ids() {
        let row = b"41 1 0:42 / / ro - proc proc ro\n";
        assert!(absent_mount(row, 42).is_ok());
        assert!(absent_mount(row, 41).is_err());
        assert!(absent_mount(&row[..row.len() - 1], 42).is_err());
        assert!(absent_mount(&[row.as_slice(), row.as_slice()].concat(), 42).is_err());
    }
}
