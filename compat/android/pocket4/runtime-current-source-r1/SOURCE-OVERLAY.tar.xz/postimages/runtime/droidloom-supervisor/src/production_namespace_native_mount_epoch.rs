//! Exact mount-graph epochs around the original init's native NEWNS round trip.
//! No path list, serialized mount IDs, bool or standalone parser result can
//! construct an accepted epoch. The entry baseline comes from the completed
//! original six-call storage owner; both native results remain ptrace-stopped.
use super::super::runtime::NativeStorageSnapshot;
use super::super::writable_proc::{MountInventory, MountRecord};
use super::*;
use std::collections::{BTreeMap, BTreeSet};

#[derive(Clone, Debug, Eq, PartialEq)]
struct Records {
    base: MountInventory,
    shared: BTreeMap<u64, u64>,
    masters: BTreeMap<u64, u64>,
}

fn parse(raw: &[u8]) -> Result<Records> {
    let text = std::str::from_utf8(raw)
        .map_err(|_| NamespaceError::Rejected("native mount inventory encoding"))?;
    if raw.is_empty() || raw.len() > 65536 || !text.ends_with('\n') || text.lines().count() > 256 {
        return Err(NamespaceError::Rejected(
            "bounded complete native mount inventory",
        ));
    }
    let mut ordinary = String::new();
    let mut shared = BTreeMap::new();
    let mut masters = BTreeMap::new();
    for line in text.lines() {
        let (left, right) = line
            .split_once(" - ")
            .ok_or(NamespaceError::Rejected("native mount separator"))?;
        let fields: Vec<_> = left.split_ascii_whitespace().collect();
        if !(6..=8).contains(&fields.len()) {
            return Err(NamespaceError::Rejected(
                "native mount optional fields differ",
            ));
        }
        let id = fields[0]
            .parse::<u64>()
            .map_err(|_| NamespaceError::Rejected("native mount ID encoding"))?;
        if id == 0 || id.to_string() != fields[0] {
            return Err(NamespaceError::Rejected("noncanonical native mount ID"));
        }
        let mut have_shared = false;
        let mut have_master = false;
        for field in &fields[6..] {
            let (kind, value) = field
                .split_once(':')
                .ok_or(NamespaceError::Rejected("native propagation field"))?;
            let group = value
                .parse::<u64>()
                .map_err(|_| NamespaceError::Rejected("native propagation group encoding"))?;
            if group == 0 || group.to_string() != value {
                return Err(NamespaceError::Rejected(
                    "noncanonical native propagation group",
                ));
            }
            match kind {
                "shared" if !have_shared && !have_master => {
                    if shared.insert(id, group).is_some() {
                        return Err(NamespaceError::Rejected("duplicate native shared group"));
                    }
                    have_shared = true;
                }
                "master" if !have_master => {
                    if masters.insert(id, group).is_some() {
                        return Err(NamespaceError::Rejected("duplicate native master group"));
                    }
                    have_master = true;
                }
                _ => return Err(NamespaceError::Rejected("foreign native propagation field")),
            }
        }
        if shared
            .get(&id)
            .is_some_and(|group| masters.get(&id) == Some(group))
        {
            return Err(NamespaceError::Rejected("native peer is its own master"));
        }
        ordinary.push_str(&fields[..6].join(" "));
        ordinary.push_str(" - ");
        ordinary.push_str(right);
        ordinary.push('\n');
    }
    let records = super::super::writable_proc::mount_records(ordinary.as_bytes())?;
    Ok(Records {
        base: MountInventory {
            records,
            visible: BTreeMap::new(),
        },
        shared,
        masters,
    })
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct VisibleNode {
    node: Node,
    mode: u32,
    uid: u32,
    gid: u32,
}
impl VisibleNode {
    fn of(file: &File) -> Result<Self> {
        let m = file.metadata()?;
        Ok(Self {
            node: Node::of(file)?,
            mode: m.mode(),
            uid: m.uid(),
            gid: m.gid(),
        })
    }
}

struct View {
    records: Records,
    visible_nodes: BTreeMap<String, VisibleNode>,
    held: Vec<(String, File, u64, VisibleNode)>,
    root: File,
    root_node: VisibleNode,
}
impl View {
    fn observe(proc: &File, root: &File) -> Result<Self> {
        let raw = read_proc(proc, "mountinfo")?;
        let mut records = parse(&raw)?;
        let root_node = VisibleNode::of(root)?;
        let targets: BTreeSet<_> = records
            .base
            .records
            .values()
            .map(|record| record.target.clone())
            .collect();
        let mut actual = BTreeMap::new();
        let mut visible_nodes = BTreeMap::new();
        let mut held = Vec::new();
        for target in targets {
            let file = super::super::writable_proc::target_from_root(root, &target)?;
            let mount = super::super::writable_proc::held_mount_id(&file)?;
            let node = VisibleNode::of(&file)?;
            actual.insert(target.clone(), (mount, node.node.device));
            visible_nodes.insert(target.clone(), node);
            held.push((target, file, mount, node));
        }
        records.base.visible =
            super::super::writable_proc::checked_visible(&records.base.records, &actual)?;
        let value = Self {
            records,
            visible_nodes,
            held,
            root: root.try_clone()?,
            root_node,
        };
        value.revalidate_held()?;
        if read_proc(proc, "mountinfo")? != raw {
            return Err(NamespaceError::Rejected(
                "native mount view changed while stopped",
            ));
        }
        Ok(value)
    }

    fn revalidate_held(&self) -> Result<()> {
        if VisibleNode::of(&self.root)? != self.root_node {
            return Err(NamespaceError::Rejected("held native root changed"));
        }
        for (target, file, mount, node) in &self.held {
            let named = super::super::writable_proc::target_from_root(&self.root, target)?;
            if VisibleNode::of(file)? != *node
                || VisibleNode::of(&named)? != *node
                || super::super::writable_proc::held_mount_id(file)? != *mount
                || super::super::writable_proc::held_mount_id(&named)? != *mount
            {
                return Err(NamespaceError::Rejected(
                    "native visible mount identity changed",
                ));
            }
        }
        Ok(())
    }

    fn equals_actual(&self, now: &Self) -> Result<()> {
        self.revalidate_held()?;
        now.revalidate_held()?;
        if self.records != now.records
            || self.visible_nodes != now.visible_nodes
            || self.root_node != now.root_node
        {
            return Err(NamespaceError::Rejected("actual namespace epoch changed"));
        }
        Ok(())
    }
}

fn same_row(before: &MountRecord, after: &MountRecord) -> bool {
    before.device == after.device
        && before.root == after.root
        && before.target == after.target
        && before.flags == after.flags
        && before.filesystem == after.filesystem
        && before.source == after.source
        && before.options == after.options
}

/// Matching is by the complete graph and observed visible layers, not row
/// ordering, increasing IDs or a guessed ID offset. Ambiguous copies fail.
fn copied_graph(before: &Records, after: &Records) -> Result<BTreeMap<u64, u64>> {
    if before.base.records.is_empty()
        || before.base.records.len() != after.base.records.len()
        || before
            .base
            .records
            .keys()
            .any(|id| after.base.records.contains_key(id))
        || before.base.visible.keys().collect::<Vec<_>>()
            != after.base.visible.keys().collect::<Vec<_>>()
    {
        return Err(NamespaceError::Rejected(
            "native copy must have a distinct complete mount-ID set",
        ));
    }
    let mut map = BTreeMap::new();
    let mut used = BTreeSet::new();
    let mut external_parents = BTreeMap::new();
    while map.len() != before.base.records.len() {
        let mut progress = false;
        for old in before.base.records.values() {
            if map.contains_key(&old.id) {
                continue;
            }
            let internal = before.base.records.contains_key(&old.parent);
            if internal && !map.contains_key(&old.parent) {
                continue;
            }
            let matches: Vec<_> = after
                .base
                .records
                .values()
                .filter(|new| {
                    !used.contains(&new.id)
                        && same_row(old, new)
                        && before.shared.get(&old.id) == after.shared.get(&new.id)
                        && before.masters.get(&old.id) == after.masters.get(&new.id)
                        && (before.base.visible.get(&old.target) == Some(&old.id))
                            == (after.base.visible.get(&new.target) == Some(&new.id))
                        && if internal {
                            map.get(&old.parent) == Some(&new.parent)
                        } else {
                            !after.base.records.contains_key(&new.parent)
                                && external_parents
                                    .get(&old.parent)
                                    .is_none_or(|id| *id == new.parent)
                                && !external_parents
                                    .iter()
                                    .any(|(id, mapped)| *id != old.parent && *mapped == new.parent)
                        }
                })
                .collect();
            if matches.len() != 1 {
                continue;
            }
            let new = matches[0];
            if !internal {
                external_parents.insert(old.parent, new.parent);
            }
            map.insert(old.id, new.id);
            used.insert(new.id);
            progress = true;
        }
        if !progress {
            return Err(NamespaceError::Rejected(
                "native mount copy has a missing, foreign or ambiguous edge",
            ));
        }
    }
    for (target, id) in &before.base.visible {
        if map.get(id) != after.base.visible.get(target) {
            return Err(NamespaceError::Rejected(
                "native copy changed a visible layer",
            ));
        }
    }
    if used.len() != after.base.records.len() {
        return Err(NamespaceError::Rejected(
            "native copy added a foreign mount",
        ));
    }
    Ok(map)
}

pub(super) struct NativeMountEpoch {
    before: View,
    default: Option<View>,
    copied_ids: BTreeMap<u64, u64>,
    restored: bool,
}
impl NativeMountEpoch {
    pub(super) fn begin(snapshot: NativeStorageSnapshot, resources: &Resources) -> Result<Self> {
        snapshot.matches_original(
            resources.binding.identity,
            resources.binding.nonce,
            resources.binding.pidfd,
            resources.binding.proc,
        )?;
        let root = namespace_root(&resources.proc)?;
        if Node::of(&root)? != Node::of(&resources.bootstrap_root)? {
            return Err(NamespaceError::Rejected("native baseline root differs"));
        }
        let before = View::observe(&resources.proc, &root)?;
        snapshot.matches_actual_parts(
            &before.records.base,
            &before.records.shared,
            &before.records.masters,
        )?;
        Ok(Self {
            before,
            default: None,
            copied_ids: BTreeMap::new(),
            restored: false,
        })
    }

    pub(super) fn admit_clone(&mut self, proc: &File, root: &File) -> Result<()> {
        if self.default.is_some() || !self.copied_ids.is_empty() || self.restored {
            return Err(NamespaceError::Rejected("native mount-copy epoch replay"));
        }
        self.before.revalidate_held()?;
        let after = View::observe(proc, root)?;
        let ids = copied_graph(&self.before.records, &after.records)?;
        if self.before.visible_nodes != after.visible_nodes
            || self.before.root_node != after.root_node
        {
            return Err(NamespaceError::Rejected(
                "native copy changed an inode, owner or idmap view",
            ));
        }
        self.before.revalidate_held()?;
        self.default = Some(after);
        self.copied_ids = ids;
        Ok(())
    }

    pub(super) fn verify_default(&self, proc: &File, root: &File) -> Result<()> {
        if self.restored || self.copied_ids.len() != self.before.records.base.records.len() {
            return Err(NamespaceError::Rejected(
                "actual default epoch is incomplete",
            ));
        }
        self.before.revalidate_held()?;
        let expected = self
            .default
            .as_ref()
            .ok_or(NamespaceError::Rejected("native default epoch absent"))?;
        let now = View::observe(proc, root)?;
        expected.equals_actual(&now)
    }

    pub(super) fn admit_restoration(&mut self, proc: &File, root: &File) -> Result<()> {
        if self.restored || self.default.is_none() {
            return Err(NamespaceError::Rejected(
                "original namespace restoration phase",
            ));
        }
        let now = View::observe(proc, root)?;
        self.before.equals_actual(&now)?;
        self.default.as_ref().unwrap().revalidate_held()?;
        self.restored = true;
        Ok(())
    }

    pub(super) fn verify_completed(&self) -> Result<()> {
        if !self.restored || self.copied_ids.len() != self.before.records.base.records.len() {
            return Err(NamespaceError::Rejected(
                "native namespace round trip lacks complete actual epochs",
            ));
        }
        self.before.revalidate_held()?;
        self.default
            .as_ref()
            .ok_or(NamespaceError::RetirementUnproven)?
            .revalidate_held()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn original() -> Records {
        let mut records = parse(b"7 900 8:1 / / ro shared:71 - ext4 /dev/system ro\n\
            11 7 0:2 / /apex rw,nosuid,nodev,noexec shared:72 - tmpfs none rw\n\
            19 11 0:3 / /apex rw,nosuid,nodev,noexec - tmpfs tmpfs rw\n\
            23 7 0:4 / /mnt rw,nosuid,nodev,noexec shared:73 - tmpfs tmpfs rw\n\
            29 23 0:4 /user /mnt/installer rw,nosuid,nodev,noexec shared:74 master:73 - tmpfs tmpfs rw\n").unwrap();
        records.base.visible = BTreeMap::from([
            ("/".into(), 7),
            ("/apex".into(), 19),
            ("/mnt".into(), 23),
            ("/mnt/installer".into(), 29),
        ]);
        records
    }

    fn actual_copy(before: &Records) -> Records {
        let mapping = BTreeMap::from([(7, 103), (11, 207), (19, 61), (23, 405), (29, 151)]);
        let mut after = before.clone();
        after.base.records = before
            .base
            .records
            .values()
            .map(|old| {
                let mut new = old.clone();
                new.id = mapping[&old.id];
                new.parent = mapping.get(&old.parent).copied().unwrap_or(990);
                (new.id, new)
            })
            .collect();
        after.base.visible = before
            .base
            .visible
            .iter()
            .map(|(path, id)| (path.clone(), mapping[id]))
            .collect();
        after.shared = before
            .shared
            .iter()
            .map(|(id, group)| (mapping[id], *group))
            .collect();
        after.masters = before
            .masters
            .iter()
            .map(|(id, group)| (mapping[id], *group))
            .collect();
        after
    }

    #[test]
    fn native_namespace_copy_keeps_covered_layers_and_shared_slave_groups_without_id_order_assumptions()
     {
        let before = original();
        let after = actual_copy(&before);
        let ids = copied_graph(&before, &after).unwrap();
        assert_eq!(ids[&11], 207);
        assert_eq!(ids[&19], 61);
        assert_eq!(after.base.visible["/apex"], 61);
        assert_eq!(after.shared[&151], 74);
        assert_eq!(after.masters[&151], 73);
    }

    #[test]
    fn native_namespace_copy_rejects_reused_ids_foreign_edges_flags_and_missing_layers() {
        let before = original();
        for case in [
            "reuse", "edge", "flags", "source", "missing", "master", "visible",
        ] {
            let mut after = actual_copy(&before);
            match case {
                "reuse" => {
                    let mut row = after.base.records.remove(&103).unwrap();
                    row.id = 7;
                    after.base.records.insert(7, row);
                }
                "edge" => after.base.records.get_mut(&61).unwrap().parent = 103,
                "flags" => {
                    after
                        .base
                        .records
                        .get_mut(&61)
                        .unwrap()
                        .flags
                        .remove("nodev");
                }
                "source" => after.base.records.get_mut(&151).unwrap().root = "/other".into(),
                "missing" => {
                    after.base.records.remove(&207);
                }
                "master" => {
                    after.masters.insert(151, 74);
                }
                "visible" => {
                    after.base.visible.insert("/apex".into(), 207);
                }
                _ => unreachable!(),
            }
            assert!(copied_graph(&before, &after).is_err(), "{case}");
        }
    }
}
