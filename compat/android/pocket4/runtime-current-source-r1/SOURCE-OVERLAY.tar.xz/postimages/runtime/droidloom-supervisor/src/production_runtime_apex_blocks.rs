//! Finite original-builtin APEX block ownership in the existing runtime guard.
//!
//! Only actual uncompressed members of the selected readonly system qualify.
//! A CAPEX decompression output on writable /data cannot enter this provider.
//! No loop/control FD is sent to Android. Original apexd execution, AVB
//! signature verification, dm ownership and mount publication remain separate.
use super::*;
use crate::production_execution_profile::apex_inputs;
use crate::production_mac::MacPreflight;
use crate::production_namespace::{ExecutedInitGeneration, ExecutedInitWitness};
use std::time::Instant;

#[path = "production_runtime_apex_mount_helper.rs"]
mod mount_helper;
#[path = "production_runtime_apex_mounts.rs"]
mod mounts;
use mounts::Publication;

const ORIGINAL_LABEL: &[u8] = b"u:object_r:system_file:s0\0";

fn original_metadata(file: &File, uid: u32, gid: u32, bytes: u64) -> Result<FileIdentity> {
    let meta = file.metadata()?;
    let flags = unsafe { libc::fcntl(file.as_raw_fd(), libc::F_GETFL) };
    require(
        meta.mode() == libc::S_IFREG | 0o644
            && meta.uid() == uid
            && meta.gid() == gid
            && meta.nlink() == 1
            && meta.len() == bytes
            && flags >= 0
            && flags & (libc::O_ACCMODE | libc::O_PATH) == libc::O_RDONLY,
        "exact original builtin APEX metadata and readonly body descriptor",
    )?;
    let mut fs: libc::statvfs = unsafe { std::mem::zeroed() };
    zero_rc(unsafe { libc::fstatvfs(file.as_raw_fd(), &mut fs) })?;
    require(
        fs.f_flag as u64 & (READONLY_FLAGS | MOUNT_ATTR_NOEXEC) == READONLY_FLAGS,
        "original builtin APEX remains on the admitted readonly system filesystem",
    )?;
    let mut names = [0_u8; 128];
    let count =
        unsafe { libc::flistxattr(file.as_raw_fd(), names.as_mut_ptr().cast(), names.len()) };
    if count < 0 {
        return Err(io::Error::last_os_error().into());
    }
    require(
        count as usize == b"security.selinux\0".len()
            && &names[..count as usize] == b"security.selinux\0",
        "complete original builtin APEX xattr inventory",
    )?;
    let mut label = [0_u8; 128];
    let count = unsafe {
        libc::fgetxattr(
            file.as_raw_fd(),
            c"security.selinux".as_ptr(),
            label.as_mut_ptr().cast(),
            label.len(),
        )
    };
    if count < 0 {
        return Err(io::Error::last_os_error().into());
    }
    require(
        count as usize == ORIGINAL_LABEL.len() && &label[..count as usize] == ORIGINAL_LABEL,
        "exact original builtin APEX SELinux label including NUL",
    )?;
    Ok(FileIdentity::of(&meta))
}

#[derive(Debug)]
struct ApexLoop {
    index: usize,
    source: File,
    identity: FileIdentity,
    generation: ExecutedInitGeneration,
    binding: Option<LoopBinding>,
    publication: Option<Publication>,
}

#[derive(Debug, Default)]
pub(super) struct ApexLoops {
    rows: Vec<ApexLoop>,
    // Keep actual successful retirements if a later binding is still busy.
    // A subsequent retry must neither lose its receipt nor clear it again.
    retired: Vec<u64>,
}
impl ApexLoops {
    pub(super) fn revalidate(&self) -> Result<()> {
        require(
            self.retired.is_empty(),
            "APEX block owner has already entered retirement",
        )?;
        for row in &self.rows {
            require(
                original_metadata(
                    &row.source,
                    row.identity.uid,
                    row.identity.gid,
                    row.identity.bytes,
                )? == row.identity,
                "held original builtin APEX source changed",
            )?;
            row.binding
                .as_ref()
                .ok_or(MountError::Rejected(
                    "APEX loop preparation did not complete",
                ))?
                .verify()?;
            if let Some(publication) = &row.publication {
                publication.revalidate()?;
            }
        }
        Ok(())
    }
    pub(super) fn cleanup(&mut self) -> Result<()> {
        // All rows stay in the parent guard if any owned kernel binding has
        // uncertain lifetime. Exact status, not a saved loop number, retires it.
        for row in &mut self.rows {
            if let Some(publication) = row.publication.as_mut() {
                publication.retire_helper()?;
            }
        }
        // A held guest mntns or payload root keeps the filesystem and loop
        // alive even after PID1 reap. Drop all such views before LOOP_CLR_FD.
        for row in &mut self.rows {
            drop(row.publication.take());
        }
        for row in &mut self.rows {
            if let Some(binding) = row.binding.as_mut() {
                if binding.file.is_some() {
                    self.retired.push(binding.retire()?);
                }
            }
        }
        self.rows.clear();
        Ok(())
    }
    pub(super) fn retired_devices(&self) -> &[u64] {
        &self.retired
    }
}

impl PreparedRuntime {
    /// Perform the actual LOOP_CONFIGURE operation for one compiled builtin
    /// role. The resource is inserted in the same runtime/lease guard before
    /// the first kernel mutation and has no guest descriptor export.
    pub(crate) fn prepare_original_builtin_apex_loop(
        &self,
        init: &ExecutedInitWitness<'_>,
        mac: &MacPreflight,
        index: usize,
        end: Instant,
    ) -> Result<()> {
        crate::production_devices::require_initial_broker()
            .map_err(|e| MountError::Io(io::Error::other(e.to_string())))?;
        init.revalidate_capability_contract()?;
        mac.revalidate(init.selection())
            .map_err(|e| MountError::Io(io::Error::other(e.to_string())))?;
        require(
            std::ptr::eq(self, init.runtime_owner()?),
            "APEX block owner must be this executed init's original runtime",
        )?;
        let fixed = apex_inputs::original_builtin(index).map_err(MountError::Rejected)?;
        let source = init.original_builtin_apex(index)?;
        let (uid, gid) = init.mapped_root_ids();
        let identity = original_metadata(&source, uid, gid, fixed.input.original_apex_bytes)?;
        let archive = VerifiedArchive::inspect(&source, index, end)?;
        archive.matches(&source)?;
        let resources = self
            .resources
            .as_ref()
            .ok_or(MountError::Rejected("runtime owner retired"))?;
        resources.matches_witness(&init.namespace_witness()?)?;
        let generation = init.generation()?;
        mac.revalidate(init.selection())
            .map_err(|e| MountError::Io(io::Error::other(e.to_string())))?;
        require(
            Instant::now() < end,
            "same APEX input deadline expired before kernel operation",
        )?;
        {
            let mut loops = resources
                .apex_loops
                .try_borrow_mut()
                .map_err(|_| MountError::Rejected("APEX block provider is already active"))?;
            require(
                loops.rows.len() < 10 && !loops.rows.iter().any(|r| r.index == index),
                "each of the ten original builtin roles may bind only once",
            )?;
            require(
                loops.rows.iter().all(|r| r.generation == generation),
                "same original init generation for all APEX blocks",
            )?;
            loops.rows.push(ApexLoop {
                index,
                source,
                identity,
                generation,
                binding: None,
                publication: None,
            });
            let row = loops
                .rows
                .last_mut()
                .ok_or(MountError::Rejected("APEX custody insertion failed"))?;
            row.binding = Some(LoopBinding::attach_apex(&row.source, archive)?);
            row.binding.as_ref().unwrap().verify()?;
            require(
                FileIdentity::of(&row.source.metadata()?) == row.identity,
                "original APEX changed across atomic readonly loop configuration",
            )?;
        }
        init.revalidate()?;
        mac.revalidate(init.selection())
            .map_err(|e| MountError::Io(io::Error::other(e.to_string())))?;
        resources.matches_witness(&init.namespace_witness()?)?;
        require(
            Instant::now() < end,
            "same APEX input deadline expired after kernel operation",
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn original_apex_block_provider_rejects_ordinary_or_writable_host_files() {
        let file = tempfile::tempfile().unwrap();
        assert!(
            original_metadata(
                &file,
                unsafe { libc::geteuid() },
                unsafe { libc::getegid() },
                0
            )
            .is_err()
        );
        let special = File::open("/dev/null").unwrap();
        assert!(original_metadata(&special, 0, 0, 0).is_err());
        let mut empty = ApexLoops::default();
        empty.revalidate().unwrap();
        empty.cleanup().unwrap();
        assert!(empty.retired_devices().is_empty());
    }
}
