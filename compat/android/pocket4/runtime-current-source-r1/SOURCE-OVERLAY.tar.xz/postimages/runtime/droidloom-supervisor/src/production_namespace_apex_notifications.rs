//! Listener custody acquired only from the original PID-1 pre-exec barrier.
use super::*;
use crate::production_apex_seccomp as wire;

#[path = "production_apex_notify_receive.rs"]
mod receiver;

struct Transport {
    file: File,
    node: Node,
    creator: i64,
    receiving: Option<receiver::Receiver>,
    pending: Option<wire::Notification>,
    failed: bool,
}

impl Transport {
    fn new(file: File) -> Result<Self> {
        let flags = unsafe { libc::fcntl(file.as_raw_fd(), libc::F_GETFL) };
        let fd_flags = unsafe { libc::fcntl(file.as_raw_fd(), libc::F_GETFD) };
        if flags < 0 || fd_flags < 0 {
            return Err(io::Error::last_os_error().into());
        }
        if filesystem_kind(&file)? != 0x0904_1934
            || flags & libc::O_ACCMODE != libc::O_RDWR
            || fd_flags & libc::FD_CLOEXEC == 0
        {
            return Err(NamespaceError::Rejected(
                "notification listener kernel descriptor shape",
            ));
        }
        // No notified syscall can run before this authenticated exec barrier.
        // This kernel ioctl probes the actual seccomp file operations, not a
        // caller's filename or an anon-inode-looking regular file.
        let absent = 0_u64;
        let check = unsafe { libc::ioctl(file.as_raw_fd(), wire::ID_VALID, &absent) };
        if check != -1 || io::Error::last_os_error().raw_os_error() != Some(libc::ENOENT) {
            return Err(NamespaceError::Rejected(
                "notification listener kernel operations differ",
            ));
        }
        let node = Node::of(&file)?;
        Ok(Self {
            file,
            node,
            creator: unsafe { libc::syscall(libc::SYS_gettid) },
            receiving: None,
            pending: None,
            failed: false,
        })
    }

    fn revalidate(&self) -> Result<()> {
        if self.creator != unsafe { libc::syscall(libc::SYS_gettid) }
            || Node::of(&self.file)? != self.node
        {
            return Err(NamespaceError::Rejected(
                "notification listener original owner changed",
            ));
        }
        Ok(())
    }

    fn valid(&self, notification: &wire::Notification) -> Result<()> {
        self.revalidate()?;
        if notification.operation().is_none() {
            return Err(NamespaceError::Rejected(
                "notification operation outside fixed filter",
            ));
        }
        if unsafe { libc::ioctl(self.file.as_raw_fd(), wire::ID_VALID, &notification.id) } != 0 {
            return Err(io::Error::last_os_error().into());
        }
        Ok(())
    }

    fn receive(&mut self, end: Instant) -> Result<wire::Notification> {
        self.revalidate()?;
        if self.failed || self.pending.is_some() || self.receiving.is_some() {
            return Err(NamespaceError::Rejected(
                "notification previous request/receiver still owned",
            ));
        }
        // A deadline can expire after the kernel consumed a notification but
        // before its packet reached this owner. Do not retry on a new budget
        // and silently abandon that unknown pending request. Only retirement
        // remains available unless this exact receive completes admission.
        self.failed = true;
        self.receiving = Some(receiver::Receiver::spawn(&self.file, end)?);
        // Store actual child custody before releasing its private READY barrier.
        let result = (|| -> io::Result<wire::Notification> {
            let receiver = self.receiving.as_mut().unwrap();
            receiver.start()?;
            receiver.complete()
        })();
        self.stop_receiver()?;
        let notification = result?;
        self.valid(&notification)?;
        if Instant::now() >= end {
            return Err(NamespaceError::Rejected(
                "notification pending admission exceeded its original deadline",
            ));
        }
        self.pending = Some(notification);
        self.failed = false;
        Ok(notification)
    }

    fn stop_receiver(&mut self) -> Result<()> {
        self.revalidate()?;
        if let Some(receiver) = self.receiving.as_mut() {
            receiver.retire()?;
        }
        self.receiving.take();
        Ok(())
    }

    fn reject(&mut self, errno: i32) -> Result<()> {
        if self.failed {
            return Err(NamespaceError::Rejected(
                "notification transport requires original tree retirement",
            ));
        }
        if !(1..=4095).contains(&errno) {
            return Err(NamespaceError::Rejected(
                "notification error must be a real positive errno",
            ));
        }
        let notification = self
            .pending
            .as_ref()
            .ok_or(NamespaceError::Rejected("no original pending notification"))?;
        self.valid(notification)?;
        let response = wire::Response {
            id: notification.id,
            value: 0,
            error: -errno,
            flags: 0,
        };
        self.failed = true;
        if unsafe { libc::ioctl(self.file.as_raw_fd(), wire::SEND, &response) } != 0 {
            return Err(io::Error::last_os_error().into());
        }
        self.pending.take();
        self.failed = false;
        Ok(())
    }

    fn retire_after_tree(&mut self) -> Result<()> {
        self.stop_receiver()?;
        let end = Instant::now() + Duration::from_secs(2);
        loop {
            self.revalidate()?;
            let left = end.saturating_duration_since(Instant::now());
            if left.is_zero() {
                return Err(NamespaceError::RetirementUnproven);
            }
            let mut p = libc::pollfd {
                fd: self.file.as_raw_fd(),
                events: libc::POLLIN,
                revents: 0,
            };
            let count = unsafe { libc::poll(&mut p, 1, left.as_millis().clamp(1, 50) as i32) };
            if count < 0 {
                let error = io::Error::last_os_error();
                if error.kind() == io::ErrorKind::Interrupted {
                    continue;
                }
                return Err(error.into());
            }
            if p.revents & libc::POLLNVAL != 0 {
                return Err(NamespaceError::RetirementUnproven);
            }
            // HUP means this real filter has no task users left. Closing its
            // fd alone would only turn blocked operations into ENOSYS.
            if p.revents & libc::POLLHUP != 0 {
                self.pending.take();
                return Ok(());
            }
        }
    }
}

pub(super) struct InheritedNotifications {
    transport: Transport,
    identity: ProcessIdentity,
    nonce: [u8; 16],
    pidfd: Node,
    proc: Node,
}

impl InheritedNotifications {
    pub(super) fn receive_from_child(child: &TreeChild) -> Result<Self> {
        child.verify()?;
        wait_readable(&child.control, &child.pidfd)?;
        let (packet, credentials, file) =
            receive_child_descriptor_record(child.control.as_raw_fd(), Phase::ApexNotifyReady)?;
        if !packet.matches(child.nonce, 1)
            || credentials.pid != child.identity.pid as i32
            || credentials.uid != child.uids.start
            || credentials.gid != child.gids.start
        {
            return Err(NamespaceError::Rejected(
                "notification pre-exec original child peer/nonce differs",
            ));
        }
        if packet.phase == Phase::Failed as u32 && packet.errno > 0 {
            return Err(io::Error::from_raw_os_error(packet.errno).into());
        }
        let transport =
            Transport::new(file.ok_or(NamespaceError::Rejected("notification listener absent"))?)?;
        let value = Self {
            transport,
            identity: child.identity,
            nonce: child.nonce,
            pidfd: descriptor_node(child.pidfd.as_fd())?,
            proc: child.proc_node,
        };
        value.revalidate(child)?;
        Ok(value)
    }

    fn revalidate(&self, child: &TreeChild) -> Result<()> {
        child.verify()?;
        if self.identity != child.identity
            || self.nonce != child.nonce
            || self.proc != child.proc_node
            || self.pidfd != descriptor_node(child.pidfd.as_fd())?
        {
            return Err(NamespaceError::Rejected(
                "notification listener belongs to another original tree",
            ));
        }
        self.transport.revalidate()
    }

    pub(super) fn receive(
        &mut self,
        child: &TreeChild,
        end: Instant,
    ) -> Result<wire::Notification> {
        self.revalidate(child)?;
        let notification = self.transport.receive(end)?;
        self.revalidate(child)?;
        Ok(notification)
    }

    pub(super) fn reject(&mut self, child: &TreeChild, errno: i32) -> Result<()> {
        self.revalidate(child)?;
        self.transport.reject(errno)
    }

    pub(super) fn retire_after_tree(&mut self) -> Result<()> {
        self.transport.retire_after_tree()
    }
    pub(super) fn stop_receiver(&mut self) -> Result<()> {
        self.transport.stop_receiver()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    pub(super) fn actual_listener() -> (
        File,
        std::sync::mpsc::SyncSender<bool>,
        std::thread::JoinHandle<(i64, i32)>,
    ) {
        let (send, receive) = std::sync::mpsc::sync_channel(1);
        let (release, wait) = std::sync::mpsc::sync_channel(1);
        let task = std::thread::spawn(move || {
            assert_eq!(
                unsafe { libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) },
                0
            );
            let raw = unsafe { wire::install() }.unwrap();
            let file = unsafe { File::from_raw_fd(raw) };
            send.send(file).unwrap();
            if wait.recv().unwrap() {
                let result = unsafe { libc::syscall(libc::SYS_ioctl, -1, 0x4c82_u64, 0) };
                (result, io::Error::last_os_error().raw_os_error().unwrap())
            } else {
                (0, 0)
            }
        });
        (receive.recv().unwrap(), release, task)
    }

    #[test]
    fn apex_notification_actual_ioctl_is_received_once_and_denial_reaches_original_task() {
        let (file, release, task) = actual_listener();
        let mut transport = Transport::new(file).unwrap();
        release.send(true).unwrap();
        let notification = transport
            .receive(Instant::now() + Duration::from_secs(3))
            .unwrap();
        assert_eq!(notification.operation(), Some(wire::Operation::LoopIoctl));
        assert_eq!(notification.data.args[1], 0x4c82);
        assert!(
            transport
                .receive(Instant::now() + Duration::from_secs(1))
                .is_err()
        );
        assert!(transport.reject(0).is_err());
        transport.valid(&notification).unwrap();
        transport.reject(libc::EACCES).unwrap();
        assert_eq!(task.join().unwrap(), (-1, libc::EACCES));
        assert!(transport.valid(&notification).is_err());
        assert!(transport.reject(libc::EPERM).is_err());
        transport.retire_after_tree().unwrap();
    }

    #[test]
    fn apex_notification_idle_kernel_recv_expires_and_actual_worker_is_reaped() {
        let (file, release, task) = actual_listener();
        let mut transport = Transport::new(file).unwrap();
        let now = Instant::now();
        assert!(transport.receive(now + Duration::from_millis(80)).is_err());
        assert!(now.elapsed() < Duration::from_secs(3));
        assert!(transport.receiving.is_none() && transport.pending.is_none());
        assert!(transport.failed);
        assert!(
            transport
                .receive(Instant::now() + Duration::from_secs(3))
                .is_err()
        );
        release.send(false).unwrap();
        assert_eq!(task.join().unwrap(), (0, 0));
        transport.retire_after_tree().unwrap();
    }

    #[test]
    fn apex_notification_listener_rejects_regular_and_other_anonymous_descriptors() {
        assert!(Transport::new(tempfile::tempfile().unwrap()).is_err());
        let raw = unsafe { libc::eventfd(0, libc::EFD_CLOEXEC | libc::EFD_NONBLOCK) };
        assert!(raw >= 0);
        assert!(Transport::new(unsafe { File::from_raw_fd(raw) }).is_err());
    }
}
