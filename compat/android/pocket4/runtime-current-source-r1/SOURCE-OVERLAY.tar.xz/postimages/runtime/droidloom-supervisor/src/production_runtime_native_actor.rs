//! Original broker mount actors held idle for one native namespace observation.
//! Keeping the exact RefCell borrow prevents a same-thread dispatcher from
//! starting an APEX publication while the original task is at ARM/EXIT.
//! It neither creates a mount nor replaces the guest's seccomp actor boundary.
use super::*;
use std::cell::Ref;

pub(crate) struct NativeMountActorGuard<'a> {
    resources: &'a RuntimeResources,
    loops: Ref<'a, ApexLoops>,
}

impl NativeMountActorGuard<'_> {
    pub(crate) fn revalidate(&self, witness: &OwnedNamespaceWitness<'_>) -> Result<()> {
        self.resources.matches_witness(witness)?;
        self.loops.revalidate()
    }
}

impl PreparedRuntime {
    pub(crate) fn native_mount_actor_guard(
        &self,
        witness: &OwnedNamespaceWitness<'_>,
    ) -> Result<NativeMountActorGuard<'_>> {
        require(
            self.exported,
            "native actor scope requires original transferred runtime",
        )?;
        let resources = self.resources.as_ref().ok_or(MountError::Rejected(
            "original native runtime already retired",
        ))?;
        resources.matches_witness(witness)?;
        let loops = resources
            .apex_loops
            .try_borrow()
            .map_err(|_| MountError::Rejected("original mount actor is active"))?;
        loops.revalidate()?;
        Ok(NativeMountActorGuard { resources, loops })
    }
}
