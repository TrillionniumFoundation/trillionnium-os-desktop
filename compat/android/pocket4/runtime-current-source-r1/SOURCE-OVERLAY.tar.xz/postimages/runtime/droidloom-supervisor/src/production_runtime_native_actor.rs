//! Original broker mount actors held by one native or apexd request.
//! Existing native ARM/EXIT observers retain a shared ledger borrow. An
//! original apexd request acquires its exclusive borrow once at entry and
//! retains it until the request owner retires. Short borrows below refer only
//! to that already held RefMut; they never reacquire RuntimeResources.
use super::*;
use std::cell::{Ref, RefCell, RefMut};

enum NativeActorLedger<'a> {
    Shared(Ref<'a, ApexLoops>),
    Exclusive(RefCell<RefMut<'a, ApexLoops>>),
}

pub(crate) struct NativeMountActorGuard<'a> {
    resources: &'a RuntimeResources,
    loops: NativeActorLedger<'a>,
}

impl NativeMountActorGuard<'_> {
    pub(crate) fn revalidate(&self, witness: &OwnedNamespaceWitness<'_>) -> Result<()> {
        match &self.loops {
            NativeActorLedger::Shared(loops) => {
                // Preserve the complete original native observer path.
                self.resources.matches_witness(witness)?;
                loops.revalidate()
            }
            NativeActorLedger::Exclusive(loops) => {
                self.resources.matches_input_witness(witness)?;
                loops
                    .try_borrow()
                    .map_err(|_| MountError::Rejected("original apexd actor ledger is active"))?
                    .revalidate()
            }
        }
    }

    pub(crate) fn require_exclusive(&self) -> Result<()> {
        require(
            matches!(&self.loops, NativeActorLedger::Exclusive(_)),
            "original apexd request requires its exclusive retained actor ledger",
        )
    }
}

impl PreparedRuntime {
    pub(crate) fn native_mount_actor_guard(
        &self,
        witness: &OwnedNamespaceWitness<'_>,
    ) -> Result<NativeMountActorGuard<'_>> {
        require(
            self.exported,
            "native actor scope requires original transferred runtime",
        )?;
        let resources = self.resources.as_ref().ok_or(MountError::Rejected(
            "original native runtime already retired",
        ))?;
        resources.matches_witness(witness)?;
        let loops = resources
            .apex_loops
            .try_borrow()
            .map_err(|_| MountError::Rejected("original mount actor is active"))?;
        loops.revalidate()?;
        Ok(NativeMountActorGuard {
            resources,
            loops: NativeActorLedger::Shared(loops),
        })
    }

    pub(crate) fn apexd_mount_actor_guard(
        &self,
        witness: &OwnedNamespaceWitness<'_>,
    ) -> Result<NativeMountActorGuard<'_>> {
        require(
            self.exported,
            "apexd actor scope requires original transferred runtime",
        )?;
        let resources = self.resources.as_ref().ok_or(MountError::Rejected(
            "original apexd runtime already retired",
        ))?;
        resources.matches_witness(witness)?;
        // This is the only acquisition of the original runtime ledger. The
        // request must never drop it to obtain a different mutation borrow.
        let loops = resources
            .apex_loops
            .try_borrow_mut()
            .map_err(|_| MountError::Rejected("original mount actor is active"))?;
        loops.revalidate()?;
        let value = NativeMountActorGuard {
            resources,
            loops: NativeActorLedger::Exclusive(RefCell::new(loops)),
        };
        value.require_exclusive()?;
        value.revalidate(witness)?;
        Ok(value)
    }
}
