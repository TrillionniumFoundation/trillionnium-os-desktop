//! Narrow adapter for an actual original apexd LOOP_CONFIGURE request.
//!
//! Namespace code alone issues OriginalApexdIoctlRequest and its single-use
//! bound request. This adapter does not create a task, choose a caller FD,
//! manufacture a guest loop handle, reply to a notification, or grant an APEX
//! mount/AVB/dm-verity result. Caller-owned storage must retain this operation
//! before configure(), then retain the transferred binding before any reply.
use crate::production_execution::RuntimeMacOwner;
use crate::production_mac::MacRequestedCapexWitness;
use crate::production_namespace::{
    BoundApexdCapexRequest, DefaultMountBinding, ObservedApexdLoopConfigure,
    OriginalApexdIoctlRequest,
};
use crate::production_private_loop_owner::{
    PrivateLoopDevice, PrivateLoopOwner, compressed::MatchedDecompressedCapex,
};
use std::io;
use std::rc::Rc;
use std::time::Instant;

type Result<T> = io::Result<T>;
fn need(value: bool, reason: &'static str) -> Result<()> {
    if value {
        Ok(())
    } else {
        Err(io::Error::new(io::ErrorKind::InvalidData, reason))
    }
}
fn observed_error(error: impl std::fmt::Display) -> io::Error {
    // Controller observation failure is never translated into an original
    // apexd syscall errno or a synthetic successful notification response.
    io::Error::other(error.to_string())
}
fn before(end: Instant) -> Result<()> {
    need(
        Instant::now() < end,
        "original apexd request deadline expired",
    )
}
fn u32_at(bytes: &[u8; 304], at: usize) -> u32 {
    u32::from_le_bytes(bytes[at..at + 4].try_into().unwrap())
}
fn u64_at(bytes: &[u8; 304], at: usize) -> u64 {
    u64::from_le_bytes(bytes[at..at + 8].try_into().unwrap())
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct ConfigureShape {
    source_fd: u32,
    offset: u64,
    bytes: u64,
}
impl ConfigureShape {
    fn parse(raw: &[u8; 304]) -> Result<Self> {
        // Exact Linux 6.18 loop_config layout and actual fixed CP3A call site:
        // d3fc4 flags=4, d4016 block_size=4096, d4034 LOOP_CONFIGURE.
        // The invalid-fd support probe is a separate real-kernel operation.
        let source_fd = u32_at(raw, 0);
        need(
            source_fd <= i32::MAX as u32,
            "actual configure requires a nonnegative source FD",
        )?;
        need(u32_at(raw, 4) == 4096, "original CP3A logical block size")?;
        need(
            u32_at(raw, 60) == 4,
            "original CP3A AUTOCLEAR-only requested flags",
        )?;
        need(
            raw[8..32].iter().all(|x| *x == 0)
                && raw[48..60].iter().all(|x| *x == 0)
                && raw[64..304].iter().all(|x| *x == 0),
            "all readonly, encryption, filename, initialization and reserved fields remain zero",
        )?;
        let offset = u64_at(raw, 32);
        let bytes = u64_at(raw, 40);
        need(
            bytes > 0 && offset.checked_add(bytes).is_some(),
            "bounded nonempty original payload extent",
        )?;
        Ok(Self {
            source_fd,
            offset,
            bytes,
        })
    }
    fn require_extent(&self, offset: u64, bytes: u64) -> Result<()> {
        need(
            self.offset == offset && self.bytes == bytes,
            "original requested extent is not the exact fixed-role APEX payload",
        )
    }
    fn require_matched(&self, matched: &MatchedDecompressedCapex) -> Result<()> {
        matched.revalidate()?;
        let archive = matched.sealed_backing()?.archive()?;
        need(
            archive.index() == matched.index(),
            "same original compressed role",
        )?;
        self.require_extent(archive.offset(), archive.payload_bytes())
    }
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Phase {
    Prepared,
    Configuring,
    Configured,
    Transferred,
    Retired,
}

pub(crate) struct PreparedApexdCapexLoop<'request> {
    // Actual devices drop before MAC/source custody. Uncertain Drop below
    // explicitly retains the original owned observations instead of resetting.
    device: Option<PrivateLoopDevice>,
    mac: Option<MacRequestedCapexWitness>,
    matched: Rc<MatchedDecompressedCapex>,
    owner: RuntimeMacOwner,
    bound: BoundApexdCapexRequest<'request>,
    default_binding: DefaultMountBinding,
    shape: ConfigureShape,
    end: Instant,
    phase: Phase,
}
impl<'request> PreparedApexdCapexLoop<'request> {
    pub(crate) fn prepare<'task>(
        request: &'request OriginalApexdIoctlRequest<'task>,
        observed: &ObservedApexdLoopConfigure,
        matched: Rc<MatchedDecompressedCapex>,
        owner: &RuntimeMacOwner,
    ) -> Result<Self> {
        let end = request.deadline();
        before(end)?;
        request.revalidate().map_err(observed_error)?;
        request.require_owner(owner).map_err(observed_error)?;
        observed.revalidate(request).map_err(observed_error)?;
        let default_binding = request.default_binding();
        let shape = ConfigureShape::parse(observed.bytes())?;
        matched.require_requested(observed.source())?;
        shape.require_matched(&matched)?;
        let mac = MacRequestedCapexWitness::observe(owner, Rc::clone(&matched))
            .map_err(observed_error)?;
        before(end)?;
        // The only role-index issuer is the already matched opaque object.
        // The request journals this once and retains its own same-OFD copy.
        let bound = request
            .bind_matched_capex(observed, &matched)
            .map_err(observed_error)?;
        observed.revalidate(request).map_err(observed_error)?;
        request.revalidate().map_err(observed_error)?;
        need(
            request.default_binding() == default_binding && request.deadline() == end,
            "same original default epoch and deadline",
        )?;
        let result = Self {
            device: None,
            mac: Some(mac),
            matched,
            owner: owner.clone(),
            bound,
            default_binding,
            shape,
            end,
            phase: Phase::Prepared,
        };
        result.revalidate_request()?;
        Ok(result)
    }
    fn revalidate_request(&self) -> Result<()> {
        before(self.end)?;
        self.bound.revalidate().map_err(observed_error)?;
        self.shape.require_matched(&self.matched)?;
        self.mac
            .as_ref()
            .ok_or_else(|| observed_error("original CAPEX MAC witness absent"))?
            .require_matched(&self.owner, &self.matched)
            .map_err(observed_error)?;
        self.owner.objects().map_err(observed_error)?;
        self.bound.revalidate().map_err(observed_error)?;
        before(self.end)
    }
    pub(crate) fn configure(&mut self, pool: &mut PrivateLoopOwner) -> Result<()> {
        need(
            self.phase == Phase::Prepared && self.device.is_none(),
            "one configuration attempt for the same original bound request",
        )?;
        self.revalidate_request()?;
        let (mac, selection) = self.owner.objects().map_err(observed_error)?;
        pool.revalidate(mac, selection).map_err(observed_error)?;
        self.phase = Phase::Configuring;
        let device = pool
            .attach_requested(mac, selection, Rc::clone(&self.matched), self.end)
            .map_err(observed_error)?;
        // Store before any later fallible observation. Failure preserves this
        // actual device and the original complete matching owner for retirement.
        self.device = Some(device);
        self.phase = Phase::Configured;
        self.revalidate_request()?;
        let (mac, selection) = self.owner.objects().map_err(observed_error)?;
        self.device
            .as_ref()
            .unwrap()
            .revalidate(mac, selection)
            .map_err(observed_error)?;
        self.revalidate_request()
    }
    /// Move only to the same original RuntimeResources before a notification
    /// response. This is not an ioctl result or a guest FD publication.
    pub(crate) fn transfer_to_runtime(&mut self) -> Result<ApexdCapexLoopBinding> {
        need(
            self.phase == Phase::Configured,
            "only an actually configured request may transfer",
        )?;
        self.revalidate_request()?;
        need(
            self.device.is_some() && self.mac.is_some(),
            "complete original device and MAC custody",
        )?;
        let result = ApexdCapexLoopBinding {
            device: self.device.take(),
            mac: self.mac.take(),
            matched: Rc::clone(&self.matched),
            owner: self.owner.clone(),
            default_binding: self.default_binding,
        };
        self.phase = Phase::Transferred;
        Ok(result)
    }
    pub(crate) fn retire(&mut self) -> Result<()> {
        need(
            matches!(self.phase, Phase::Prepared | Phase::Configured),
            "uncertain configuration or transferred custody cannot be declared retired here",
        )?;
        if let Some(device) = self.device.as_mut() {
            self.mac
                .as_ref()
                .ok_or_else(|| observed_error("original MAC witness absent"))?
                .require_matched(&self.owner, &self.matched)
                .map_err(observed_error)?;
            let (mac, selection) = self.owner.objects().map_err(observed_error)?;
            device.retire(mac, selection).map_err(observed_error)?;
            self.device.take();
        }
        self.phase = Phase::Retired;
        Ok(())
    }
}
impl Drop for PreparedApexdCapexLoop<'_> {
    fn drop(&mut self) {
        if matches!(self.phase, Phase::Configuring | Phase::Configured) {
            // PrivateLoopDevice retains its exact private binding/alias/source.
            // Also retain the inseparable original runtime MAC pair and label
            // observation, even if attach failed after an uncertain mutation.
            if let Some(mac) = self.mac.take() {
                std::mem::forget(mac);
            }
            std::mem::forget(self.owner.clone());
            std::mem::forget(Rc::clone(&self.matched));
        }
    }
}
impl std::fmt::Debug for PreparedApexdCapexLoop<'_> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("PreparedApexdCapexLoop")
            .field("phase", &self.phase)
            .field("role_index", &self.matched.index())
            .finish_non_exhaustive()
    }
}

/// Only block-source custody. Namespace/guest-loop ownership, notification
/// completion, AVB and dm-verity admission remain with their original owners.
pub(crate) struct ApexdCapexLoopBinding {
    device: Option<PrivateLoopDevice>,
    mac: Option<MacRequestedCapexWitness>,
    matched: Rc<MatchedDecompressedCapex>,
    owner: RuntimeMacOwner,
    default_binding: DefaultMountBinding,
}
impl ApexdCapexLoopBinding {
    pub(crate) fn index(&self) -> usize {
        self.matched.index()
    }
    pub(crate) fn default_binding(&self) -> DefaultMountBinding {
        self.default_binding
    }
    pub(crate) fn revalidate(&self, owner: &RuntimeMacOwner) -> Result<()> {
        let (mac, selection) = owner.objects().map_err(observed_error)?;
        self.owner
            .require_pair(mac, selection)
            .map_err(observed_error)?;
        self.mac
            .as_ref()
            .ok_or_else(|| observed_error("retired requested MAC witness"))?
            .require_matched(&self.owner, &self.matched)
            .map_err(observed_error)?;
        self.device
            .as_ref()
            .ok_or_else(|| observed_error("retired requested loop"))?
            .revalidate(mac, selection)
            .map_err(observed_error)?;
        self.matched.revalidate()
    }
    pub(crate) fn device(&self, owner: &RuntimeMacOwner) -> Result<&PrivateLoopDevice> {
        self.revalidate(owner)?;
        Ok(self.device.as_ref().unwrap())
    }
    pub(crate) fn retire(&mut self, owner: &RuntimeMacOwner) -> Result<()> {
        let (mac, selection) = owner.objects().map_err(observed_error)?;
        self.owner
            .require_pair(mac, selection)
            .map_err(observed_error)?;
        self.mac
            .as_ref()
            .ok_or_else(|| observed_error("retired requested MAC witness"))?
            .require_matched(&self.owner, &self.matched)
            .map_err(observed_error)?;
        let device = self
            .device
            .as_mut()
            .ok_or_else(|| observed_error("requested loop already retired"))?;
        device.retire(mac, selection).map_err(observed_error)?;
        self.device.take();
        self.mac.take();
        Ok(())
    }
}
impl Drop for ApexdCapexLoopBinding {
    fn drop(&mut self) {
        if self.device.is_some() {
            if let Some(mac) = self.mac.take() {
                std::mem::forget(mac);
            }
            std::mem::forget(self.owner.clone());
            std::mem::forget(Rc::clone(&self.matched));
        }
    }
}
impl std::fmt::Debug for ApexdCapexLoopBinding {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ApexdCapexLoopBinding")
            .field("role_index", &self.matched.index())
            .field("retired", &self.device.is_none())
            .finish_non_exhaustive()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn configuration() -> [u8; 304] {
        let mut raw = [0; 304];
        raw[0..4].copy_from_slice(&19_u32.to_le_bytes());
        raw[4..8].copy_from_slice(&4096_u32.to_le_bytes());
        raw[32..40].copy_from_slice(&4096_u64.to_le_bytes());
        raw[40..48].copy_from_slice(&8192_u64.to_le_bytes());
        raw[60..64].copy_from_slice(&4_u32.to_le_bytes());
        raw
    }
    #[test]
    fn actual_configuration_rejects_every_nonzero_reserved_or_encryption_byte() {
        let raw = configuration();
        let parsed = ConfigureShape::parse(&raw).unwrap();
        parsed.require_extent(4096, 8192).unwrap();
        for index in (8..32).chain(48..60).chain(64..304) {
            let mut changed = raw;
            changed[index] = 1;
            assert!(ConfigureShape::parse(&changed).is_err(), "offset {index}");
        }
    }
    #[test]
    fn actual_configuration_keeps_probe_flags_geometry_and_role_extent_separate() {
        let raw = configuration();
        for flags in [0_u32, 1, 5, 8, 16, 20, u32::MAX] {
            let mut changed = raw;
            changed[60..64].copy_from_slice(&flags.to_le_bytes());
            assert!(ConfigureShape::parse(&changed).is_err());
        }
        for size in [0_u32, 512, 8192, u32::MAX] {
            let mut changed = raw;
            changed[4..8].copy_from_slice(&size.to_le_bytes());
            assert!(ConfigureShape::parse(&changed).is_err());
        }
        let mut probe = [0; 304];
        probe[0..4].copy_from_slice(&u32::MAX.to_le_bytes());
        assert!(ConfigureShape::parse(&probe).is_err());
        let parsed = ConfigureShape::parse(&raw).unwrap();
        assert!(parsed.require_extent(0, 8192).is_err());
        assert!(parsed.require_extent(4096, 4096).is_err());
        let mut changed = raw;
        changed[32..40].copy_from_slice(&u64::MAX.to_le_bytes());
        assert!(ConfigureShape::parse(&changed).is_err());
        changed = raw;
        changed[40..48].fill(0);
        assert!(ConfigureShape::parse(&changed).is_err());
    }
}
