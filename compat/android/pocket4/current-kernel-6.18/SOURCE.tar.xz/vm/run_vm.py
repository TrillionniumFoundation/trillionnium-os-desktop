"""Run bounded, unprivileged KVM guests from the freshly verified kernel.

No NIC, disk, shared filesystem, host policy load, installation, or private key.
Each QEMU is an original child held by PIDFD and reaped before another starts.
"""
from pathlib import Path
import fcntl,hashlib,json,os,re,secrets,select,shutil,signal,subprocess,sys,time

ROOT=Path('/home/qq/work/p4-kernel-6.18.64-cp3a-20261118-r1')
PREP=ROOT/'vm-fresh-r7'
DEPS=Path('/home/qq/work/p4-kernel61864-vm-deps-20261118-162b-r1/root')
CONTROL=ROOT/'control/vm-run-r5'
CONTROL.mkdir(mode=0o700,exist_ok=False)
EXPECTED=sys.argv[1]
assert re.fullmatch('[0-9a-f]{64}',EXPECTED)
report={'schema':'p4-fresh-61864-kvm-qualification-v1','started_ns':time.time_ns(),
        'preparation_sha256':EXPECTED,'guests':[],'production_android_runtime_qualified':False,
        'host_kernel_installed':False,'host_policy_loaded':False,'private_keys_read':False}
end=time.monotonic()+840
lock=None
cg=None

def ident(p):
 s=Path(p).stat();return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def digest(p):
 p=Path(p);assert p.name!='signing_key.pem';before=ident(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 assert before==ident(p)
 return {'path':str(p),'bytes':before[6],'sha256':h.hexdigest(),'identity':before}
def memory():
 return {k:int(v.split()[0])*1024 for k,v in (x.split(':',1) for x in Path('/proc/meminfo').read_text().splitlines())}
def save():
 tmp=CONTROL/'receipt.tmp';tmp.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');tmp.replace(CONTROL/'vm-receipt.json')
def check_inputs(rows):
 for d in rows:assert digest(d['path'])==d,('input changed',d['path'])

def boot(mode,prep):
 nonce=secrets.token_hex(16);log=CONTROL/(mode+'.serial.log')
 lsm='landlock,lockdown,yama,integrity,apparmor'+(',selinux' if mode=='active' else '')+',bpf'
 cmdline='console=ttyS0,115200 rdinit=/init panic=1 oops=panic loglevel=5 audit=1 module.sig_enforce=1 lockdown=integrity apparmor=1 enforcing=1 selinux='+('1' if mode=='active' else '0')+' lsm='+lsm+' p4_mode='+mode+' p4_nonce='+nonce
 argv=[str(DEPS/'usr/bin/qemu-system-x86_64'),'-no-user-config','-nodefaults',
       '-machine','q35,accel=kvm','-cpu','host','-smp','2','-m','2048',
       '-display','none','-monitor','none','-serial','stdio','-net','none','-no-reboot',
       '-bios',prep['boot_firmware']['path'],'-L',str(DEPS/'usr/share/qemu'),
       '-kernel',prep['kernel']['path'],'-initrd',prep['initramfs']['path'],'-append',cmdline]
 env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','LC_ALL':'C',
      'LD_LIBRARY_PATH':str(DEPS/'usr/lib/x86_64-linux-gnu')}
 row={'mode':mode,'nonce':nonce,'argv':argv,'started_ns':time.time_ns(),'budget_seconds':300,
      'guest_memory_mib':2048,'guest_vcpus':2,'network':False,'shared_filesystems':False}
 report['guests'].append(row);save()
 deadline=min(end,time.monotonic()+300);fd=None;p=None
 with log.open('xb',buffering=0) as output:
  try:
   p=subprocess.Popen(argv,env=env,cwd=CONTROL,stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT,close_fds=True,start_new_session=True)
   fd=os.pidfd_open(p.pid,0);row['original_pid']=p.pid;st=os.fstat(fd);row['original_pidfd_device_inode']=[st.st_dev,st.st_ino]
   poll=select.poll();poll.register(fd,select.POLLIN);last=0;save()
   while True:
    now=time.monotonic();why=None
    if now>=deadline:why='fixed guest deadline'
    elif log.stat().st_size>32*1024**2:why='serial byte bound'
    elif memory()['MemAvailable']<12*1024**3:why='host memory reserve'
    elif shutil.disk_usage(ROOT).free<32*1024**3:why='host disk reserve'
    if why:
     row['termination_reason']=why;signal.pidfd_send_signal(fd,signal.SIGKILL,None,0)
    if poll.poll(200):break
    if why:
     if not poll.poll(5000):raise RuntimeError('Original QEMU PIDFD did not retire')
     break
    if now-last>=15:
     last=now;print(json.dumps({'phase':'fresh_vm_running','mode':mode,'elapsed_seconds':int(300-(deadline-now)),'serial_bytes':log.stat().st_size,'memory_available':memory()['MemAvailable']}),flush=True)
   observed=os.waitid(os.P_PIDFD,fd,os.WEXITED|os.WNOWAIT)
   assert observed.si_pid==p.pid
   row['pidfd_waitid']={'pid':observed.si_pid,'code':observed.si_code,'status':observed.si_status}
   row['qemu_exit']=p.wait(timeout=5)
   row['actual_reaped']=True
  finally:
   if p is not None and p.returncode is None:
    if fd is not None:
     try:signal.pidfd_send_signal(fd,signal.SIGKILL,None,0)
     except ProcessLookupError:pass
    else:p.kill()
    row['qemu_exit_after_error']=p.wait(timeout=5);row['actual_reaped']=True
   if fd is not None:os.close(fd)
 row['serial']=digest(log)
 raw=log.read_bytes();text=raw.decode('utf-8',errors='strict').replace('\r','')
 checks=[];groups=[]
 for line in text.splitlines():
  if line.startswith('P4CHECK '):checks.append(json.loads(line[len('P4CHECK '):]))
  if line.startswith('P4GROUP '):groups.append(json.loads(line[len('P4GROUP '):]))
 required={'kernel.release','module.signature_enforced','kernel.integrity_lockdown','kernel.perf_default_four',
           'kernel.perf_unprivileged_denied','grant.positive.consume','grant.wrong_nonce.consume',
           'grant.expiry.consume','grant.fs_change.consume','grant.cred_change.consume','grant.mount_change.consume',
           'context.initial_net_selection_denied'}
 for name in ['positive','wrong_nonce','expiry','fs_change','cred_change','wrong_namespace','admin_effective','admin_permitted','admin_inheritable','admin_bounding','admin_ambient','mount_change']:
  required.add('grant.'+name+'.worker_exit')
 if mode=='active':required.update(['context.selected_so_peersec','context.selected_scm_security',
  'context.before_selection.selinux_denial','context.before_selection.apparmor_denial',
  'context.after_selection.selinux_denial','context.after_selection.apparmor_denial',
  'context.child_inherits_fixed_provider','context.used_namespace_rejected','context.typed_selfattr_selinux',
  'proc.legacy_selected_selinux_read','proc.legacy_selected_selinux_write','proc.default_and_explicit_apparmor_preserved',
  'proc.selected_provider_immutable','proc.default_provider_immutable','proc.subordinate_selector_rejected',
  'proc.transfer_subordinate_selection_rejected','proc.transfer_original_child_pidns','proc.transfer_pidns_inode',
  'proc.transfer_guest_rendered_host_gid','proc.readproc_member_visible','proc.readproc_nonmember_hidden','proc.readproc_target_retired','proc.transfer_parent_gid_203009','proc.transfer_legacy_selinux_read',
  'proc.transfer_legacy_selinux_write','proc.transfer_held_pidns_exact','proc.transfer_held_userns_exact',
  'proc.transfer_initial_broker_selects','proc.transfer_initial_broker_creates','proc.transfer_broker_namespace_unchanged',
  'proc.transfer_child_exit',
  'binder.saved_open_credential_context','binder.saved_open_cred_mac_denied','binder.denied_not_delivered'])
 else:required.update(['context.inactive_provider_rejected','binder.inactive_typed_mount_rejected','proc.inactive_selector_rejected'])
 row['checks']=checks;row['groups']=groups;row['required_missing']=sorted(required-{x['name'] for x in checks})
 row['panic_or_oops']=bool(re.search(r'Kernel panic - not syncing|BUG:|Oops:',text))
 row['passed']=(row.get('qemu_exit')==0 and not row.get('termination_reason') and
   ('P4VM_BEGIN '+mode+' '+nonce) in text.splitlines() and ('P4VM_END '+mode+' '+nonce+' 0') in text.splitlines() and
   len(checks)>80 and all(x.get('pass') is True for x in checks) and
   {x['name'] for x in groups}=={'basic','grant','context'} and all(x.get('pass') is True for x in groups) and
   not row['required_missing'] and not row['panic_or_oops'])
 row['finished_ns']=time.time_ns();save()
 print(json.dumps({'phase':'fresh_vm_finished','mode':mode,'passed':row['passed'],'qemu_exit':row.get('qemu_exit'),
  'checks':len(checks),'failures':[x for x in checks if not x.get('pass')],
  'missing':row['required_missing'],'serial_sha256':row['serial']['sha256']}),flush=True)
 assert set(map(int,(cg/'cgroup.procs').read_text().split()))=={os.getpid()},'unretired QEMU descendant'

def main():
 global lock,cg
 assert os.getuid()==1000 and os.access('/dev/kvm',os.R_OK|os.W_OK)
 assert memory()['MemAvailable']>=15*1024**3 and shutil.disk_usage(ROOT).free>=32*1024**3
 cgline=Path('/proc/self/cgroup').read_text().strip();assert cgline.startswith('0::/') and '\n' not in cgline
 cg=Path('/sys/fs/cgroup')/cgline[3:].lstrip('/')
 values={x:(cg/x).read_text().strip() for x in ['memory.max','memory.high','memory.swap.max','cpu.max','pids.max']}
 assert values['memory.max']==str(3*1024**3) and values['memory.high']==str(5*1024**3//2) and values['memory.swap.max']=='0'
 assert values['cpu.max']=='200000 100000' and sorted(os.sched_getaffinity(0))==[22,23]
 lock=os.open(ROOT/'control/vm.serial.lock',os.O_RDWR|os.O_CLOEXEC);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 st=os.fstat(lock);report['admission']={'observed_ns':time.time_ns(),'cgroup':str(cg),'limits':values,'cpu_affinity':sorted(os.sched_getaffinity(0)),'memory_available':memory()['MemAvailable'],'lock_device_inode':[st.st_dev,st.st_ino],'host_boot':Path('/proc/sys/kernel/random/boot_id').read_text().strip()};save()
 data=(PREP/'preparation-receipt.json').read_bytes();assert hashlib.sha256(data).hexdigest()==EXPECTED
 prep=json.loads(data);assert prep['prepared'] and not prep.get('error')
 rows=prep['modules']+[prep['kernel'],prep['config'],prep['certificate'],prep['unsigned_module'],prep['initramfs'],prep['initramfs_inventory'],prep['boot_firmware']]+prep['input_files']+prep['tool_files']+prep['qemu_library_inputs']
 check_inputs(rows)
 for mode in ['active','inactive']:boot(mode,prep)
 check_inputs(rows);report['input_bookends_unchanged']=True
 report['cgroup_final']={x:(cg/x).read_text().strip() for x in ['memory.peak','memory.events','memory.swap.current','cpu.stat','pids.peak']}
 events=dict(line.split() for line in report['cgroup_final']['memory.events'].splitlines());assert events['oom']=='0' and events['oom_kill']=='0' and report['cgroup_final']['memory.swap.current']=='0'
 report['kernel_abi_vm_qualified']=all(x['passed'] for x in report['guests'])
 report['finished_ns']=time.time_ns();save();os.close(lock);lock=None
 print(json.dumps({'phase':'fresh_vm_complete','kernel_abi_vm_qualified':report['kernel_abi_vm_qualified'],'receipt':digest(CONTROL/'vm-receipt.json')}),flush=True)
 return 0 if report['kernel_abi_vm_qualified'] else 1

if __name__=='__main__':
 try:sys.exit(main())
 except Exception as e:
  report['error']=repr(e);report['failed_ns']=time.time_ns();save();raise
 finally:
  if lock is not None:os.close(lock)
