profile p4_vm_deny flags=(attach_disconnected) {
  file,
  capability,
  network,
  mount,
  umount,
  pivot_root,
  ptrace,
  signal,
  unix,
  userns,
  deny /tmp/aa-secret r,
}
