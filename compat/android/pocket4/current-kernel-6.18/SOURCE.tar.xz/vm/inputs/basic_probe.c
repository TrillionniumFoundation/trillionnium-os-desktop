#include "probe_common.h"
#include <linux/perf_event.h>
#include <sys/xattr.h>
#include <sys/utsname.h>
#include <grp.h>
#include <dirent.h>
static void features(const char *path,int depth){
 must(depth<12,"features_depth");struct dirent**list;int count=scandir(path,&list,NULL,alphasort);must(count>=0&&count<256,"features_directory");
 for(int i=0;i<count;i++){struct dirent*d=list[i];if(!strcmp(d->d_name,".")||!strcmp(d->d_name,"..")){free(d);continue;}char p[1024];int n=snprintf(p,sizeof(p),"%s/%s",path,d->d_name);must(n>0&&n<(int)sizeof(p),"features_path");struct stat st;must(lstat(p,&st)==0,"features_stat");printf("%s { ",d->d_name);if(S_ISDIR(st.st_mode))features(p,depth+1);else{must(S_ISREG(st.st_mode),"features_regular");char buf[8192];read_path(p,buf,sizeof(buf));printf("%s",buf);}printf(" }\n");free(d);}free(list);
}
static int perf_open(void){struct perf_event_attr a={.type=PERF_TYPE_SOFTWARE,.size=sizeof(a),.config=PERF_COUNT_SW_CPU_CLOCK,.disabled=1,.exclude_kernel=1,.exclude_hv=1};return syscall(SYS_perf_event_open,&a,0,-1,-1,0);}
int main(int argc,char**argv){
 setvbuf(stdout,NULL,_IONBF,0);alarm(30);
 if(argc==2&&!strcmp(argv[1],"features")){puts("P4FEATURES_BEGIN");features("/sys/kernel/security/apparmor/features",0);puts("P4FEATURES_END");return 0;}
 if(argc==4&&!strcmp(argv[1],"load")){int in=open(argv[2],O_RDONLY|O_CLOEXEC);must(in>=0,"policy_input_open");struct stat st;must(fstat(in,&st)==0&&S_ISREG(st.st_mode)&&st.st_size>0&&st.st_size<2*1024*1024,"policy_input_bound");char*bytes=malloc(st.st_size);must(bytes!=NULL,"policy_buffer");size_t n=0;while(n<(size_t)st.st_size){ssize_t r=read(in,bytes+n,st.st_size-n);must(r>0,"policy_input_read");n+=r;}close(in);int out=open(argv[3],O_WRONLY|O_CLOEXEC);must(out>=0,"policy_target_open");ssize_t written=write(out,bytes,n);int e=written<0?-errno:written;result(argv[3],written==(ssize_t)n,e,n);close(out);free(bytes);return failures?1:0;}
 if(argc==4&&!strcmp(argv[1],"module")){int fd=open(argv[2],O_RDONLY|O_CLOEXEC);must(fd>=0,"module_input_open");int expected=atoi(argv[3]);int e=errno_result(syscall(SYS_finit_module,fd,"",0));result(argv[2],e==expected,e,expected);close(fd);return failures?1:0;}
 if(argc==4&&!strcmp(argv[1],"label")){must(setxattr(argv[2],"security.selinux",argv[3],strlen(argv[3])+1,0)==0,"fixture_secret_label");return 0;}
 struct utsname u;must(uname(&u)==0,"uname");result("kernel.release",!strcmp(u.release,"6.18.64-p4ctx6181"),strcmp(u.release,"6.18.64-p4ctx6181"),0);printf("P4OBS uname=%s\n",u.release);
 char buf[512];read_path("/sys/module/module/parameters/sig_enforce",buf,sizeof(buf));result("module.signature_enforced",buf[0]=='Y'||buf[0]=='1',buf[0], 'Y');
 read_path("/sys/kernel/security/lockdown",buf,sizeof(buf));result("kernel.integrity_lockdown",strstr(buf,"[integrity]")!=NULL,strstr(buf,"[integrity]")!=NULL,1);printf("P4OBS lockdown=%s",buf);
 read_path("/proc/sys/kernel/perf_event_paranoid",buf,sizeof(buf));result("kernel.perf_default_four",atoi(buf)==4,atoi(buf),4);
 int f=perf_open();result("kernel.perf_privileged_control",f>=0,f<0?-errno:0,0);if(f>=0)close(f);
 pid_t p=fork();must(p>=0,"perf_child_fork");if(!p){must(setgroups(0,NULL)==0&&setresgid(1000,1000,1000)==0&&setresuid(1000,1000,1000)==0,"perf_unprivileged_uid");int fd=perf_open();int e=fd<0?errno:0;if(fd>=0)close(fd);result("kernel.perf_unprivileged_denied",e==EACCES,e,EACCES);_exit(failures?1:0);}wait_ok(p,"kernel.perf_unprivileged_child_exit");
 printf("P4GROUP {\"name\":\"basic\",\"pass\":%s,\"failures\":%d}\n",failures?"false":"true",failures);return failures?1:0;
}
