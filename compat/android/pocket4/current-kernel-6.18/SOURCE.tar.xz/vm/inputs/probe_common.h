/* Fresh isolated VM qualification helpers, not production authorization. */
#ifndef P4_VM_PROBE_COMMON_H
#define P4_VM_PROBE_COMMON_H
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/capability.h>
#include <poll.h>
#include <sched.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/mount.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
static int failures;
static void result(const char *name,bool pass,long actual,long expected){
 printf("P4CHECK {\"name\":\"%s\",\"pass\":%s,\"actual\":%ld,\"expected\":%ld}\n",name,pass?"true":"false",actual,expected);
 fflush(stdout);if(!pass)failures++;
}
static void fatal(const char *name){int e=errno;result(name,false,e,0);_exit(99);}
static void must(bool ok,const char *name){if(!ok)fatal(name);}
static void write_full(int fd,const void *buf,size_t len){
 size_t n=0;while(n<len){ssize_t r=write(fd,(const char*)buf+n,len-n);if(r<0&&errno==EINTR)continue;must(r>0,"write_full");n+=(size_t)r;}
}
static void write_path(const char *path,const char *text){int fd=open(path,O_WRONLY|O_CLOEXEC);must(fd>=0,"write_path_open");write_full(fd,text,strlen(text));must(close(fd)==0,"write_path_close");}
static size_t read_path(const char *path,char *buf,size_t cap){
 int fd=open(path,O_RDONLY|O_CLOEXEC);must(fd>=0,"read_path_open");size_t n=0;
 while(n+1<cap){ssize_t r=read(fd,buf+n,cap-n-1);if(r<0&&errno==EINTR)continue;must(r>=0,"read_path_read");if(!r)break;n+=(size_t)r;}
 must(n+1<cap,"read_path_bound");buf[n]=0;close(fd);return n;
}
static uint64_t ns_inode(const char *name){char p[80];struct stat st;snprintf(p,sizeof(p),"/proc/self/ns/%s",name);must(stat(p,&st)==0,"ns_inode");return st.st_ino;}
static int errno_result(int rc){return rc<0?-errno:rc;}
static void send_packet(int fd,const void *data,size_t bytes,const int *fds,size_t nfds){
 char control[CMSG_SPACE(8*sizeof(int))]={0};must(nfds<=8,"send_packet_fd_bound");
 struct iovec io={.iov_base=(void*)data,.iov_len=bytes};struct msghdr msg={.msg_iov=&io,.msg_iovlen=1};
 if(nfds){msg.msg_control=control;msg.msg_controllen=CMSG_SPACE(nfds*sizeof(int));struct cmsghdr*c=CMSG_FIRSTHDR(&msg);c->cmsg_level=SOL_SOCKET;c->cmsg_type=SCM_RIGHTS;c->cmsg_len=CMSG_LEN(nfds*sizeof(int));memcpy(CMSG_DATA(c),fds,nfds*sizeof(int));}
 must(sendmsg(fd,&msg,MSG_NOSIGNAL)==(ssize_t)bytes,"send_packet");
}
static size_t recv_packet(int fd,void *data,size_t bytes,int *fds,size_t cap){
 struct pollfd p={.fd=fd,.events=POLLIN};must(poll(&p,1,15000)==1&&(p.revents&POLLIN),"recv_packet_deadline");
 char control[CMSG_SPACE(8*sizeof(int))]={0};struct iovec io={.iov_base=data,.iov_len=bytes};struct msghdr msg={.msg_iov=&io,.msg_iovlen=1,.msg_control=control,.msg_controllen=sizeof(control)};
 must(recvmsg(fd,&msg,MSG_CMSG_CLOEXEC)==(ssize_t)bytes&&!(msg.msg_flags&(MSG_TRUNC|MSG_CTRUNC)),"recv_packet");size_t n=0;
 for(struct cmsghdr*c=CMSG_FIRSTHDR(&msg);c;c=CMSG_NXTHDR(&msg,c)){must(c->cmsg_level==SOL_SOCKET&&c->cmsg_type==SCM_RIGHTS&&c->cmsg_len>=CMSG_LEN(0),"recv_packet_cmsg");size_t nr=(c->cmsg_len-CMSG_LEN(0))/sizeof(int);must(n+nr<=cap,"recv_packet_fd_count");memcpy(fds+n,CMSG_DATA(c),nr*sizeof(int));n+=nr;}return n;
}
static void map_child(pid_t pid){char p[100];snprintf(p,sizeof(p),"/proc/%d/setgroups",pid);write_path(p,"deny\n");snprintf(p,sizeof(p),"/proc/%d/uid_map",pid);write_path(p,"0 0 65536\n");snprintf(p,sizeof(p),"/proc/%d/gid_map",pid);write_path(p,"0 0 65536\n");}
static void wait_ok(pid_t pid,const char *name){int st=0;must(waitpid(pid,&st,0)==pid,"wait_exact_child");result(name,WIFEXITED(st)&&WEXITSTATUS(st)==0,st,0);}
#endif
