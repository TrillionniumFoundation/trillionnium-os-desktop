/* Actual P4 grant integration tests in a fresh VM, using the public ABI. */
#include "probe_common.h"
#include "p4_guest_mntns.h"
enum mode { POSITIVE, WRONG_NONCE, EXPIRY, FS_CHANGE, CRED_CHANGE, WRONG_NAMESPACE,
 ADMIN_EFFECTIVE, ADMIN_PERMITTED, ADMIN_INHERITABLE, ADMIN_BOUNDING, ADMIN_AMBIENT, MOUNT_CHANGE };
static const char *names[]={"positive","wrong_nonce","expiry","fs_change","cred_change","wrong_namespace","admin_effective","admin_permitted","admin_inheritable","admin_bounding","admin_ambient","mount_change"};
struct hello {int mode,pid;uint64_t user,mnt,pidns,caps[5];};
struct reply {int mint_errno;uint64_t nonce[2];};
struct clone_args {int fd,other;enum mode mode;};
static void capture_caps(uint64_t out[5]){
 char status[8192];read_path("/proc/self/status",status,sizeof(status));
 const char *keys[]={"CapEff:\t","CapPrm:\t","CapInh:\t","CapBnd:\t","CapAmb:\t"};
 for(int i=0;i<5;i++){char*p=strstr(status,keys[i]);must(p&&sscanf(p+strlen(keys[i]),"%" SCNx64,&out[i])==1,"parse_cap_sets");}
}
static void set_caps(uint64_t eff,uint64_t prm,uint64_t inh){
 struct __user_cap_header_struct h={.version=_LINUX_CAPABILITY_VERSION_3,.pid=0};struct __user_cap_data_struct d[2]={{0}};
 for(int i=0;i<2;i++){d[i].effective=eff>>(32*i);d[i].permitted=prm>>(32*i);d[i].inheritable=inh>>(32*i);}
 must(syscall(SYS_capset,&h,d)==0,"capset");
}
static void drop_caps(enum mode mode){
 uint64_t admin=1ULL<<CAP_SYS_ADMIN;bool keep_bound=mode==ADMIN_BOUNDING||mode==ADMIN_AMBIENT;
 /* Establish an inheritable bit before removing SETPCAP and its bounding bit. */
 if(mode==ADMIN_INHERITABLE){struct __user_cap_header_struct h={.version=_LINUX_CAPABILITY_VERSION_3};struct __user_cap_data_struct d[2];must(syscall(SYS_capget,&h,d)==0,"capget");d[0].inheritable|=(uint32_t)admin;must(syscall(SYS_capset,&h,d)==0,"capset_inheritable_fixture");}
 for(int c=0;c<64;c++){int v=prctl(PR_CAPBSET_READ,c,0,0,0);if(v<0&&errno==EINVAL)break;must(v>=0,"capbset_read");if(c!=CAP_SYS_ADMIN||!keep_bound)must(prctl(PR_CAPBSET_DROP,c,0,0,0)==0,"capbset_drop");}
 must(prctl(PR_CAP_AMBIENT,PR_CAP_AMBIENT_CLEAR_ALL,0,0,0)==0,"ambient_clear");
 uint64_t eff=0,prm=0,inh=0;
 if(mode==ADMIN_EFFECTIVE)eff=prm=admin;
 if(mode==ADMIN_PERMITTED)prm=admin;
 if(mode==ADMIN_INHERITABLE)inh=admin;
 if(mode==ADMIN_AMBIENT)prm=inh=admin;
 if(mode==CRED_CHANGE)eff=prm=1ULL<<CAP_SETPCAP;
 set_caps(eff,prm,inh);
 if(mode==ADMIN_AMBIENT)must(prctl(PR_CAP_AMBIENT,PR_CAP_AMBIENT_RAISE,CAP_SYS_ADMIN,0,0)==0,"ambient_raise");
}
static int worker(int fd,enum mode mode){
 alarm(20);must(getpid()==2,"worker_pid_two");drop_caps(mode);
 struct hello h={.mode=mode,.pid=getpid(),.user=ns_inode("user"),.mnt=ns_inode("mnt"),.pidns=ns_inode("pid")};capture_caps(h.caps);
 int fds[4]={syscall(SYS_pidfd_open,getpid(),0),open("/proc/self/ns/user",O_RDONLY|O_CLOEXEC),open("/proc/self/ns/mnt",O_RDONLY|O_CLOEXEC),open("/proc/self/ns/pid",O_RDONLY|O_CLOEXEC)};
 for(int i=0;i<4;i++)must(fds[i]>=0,"worker_identity_fd");send_packet(fd,&h,sizeof(h),fds,4);for(int i=0;i<4;i++)close(fds[i]);
 struct reply r={0};int token=-1;size_t n=recv_packet(fd,&r,sizeof(r),&token,1);
 bool reject=mode==WRONG_NAMESPACE||(mode>=ADMIN_EFFECTIVE&&mode<=ADMIN_AMBIENT);char name[120];snprintf(name,sizeof(name),"grant.%s.mint",names[mode]);
 result(name,reject?r.mint_errno==ESTALE&&n==0:r.mint_errno==0&&n==1,r.mint_errno,reject?ESTALE:0);
 if(reject)return failures?1:0;if(r.mint_errno||n!=1)return 1;
 bool absent=true;for(int i=0;i<5;i++)absent&=!(h.caps[i]&(1ULL<<CAP_SYS_ADMIN));result("grant.all_five_admin_sets_absent",absent,absent,1);
 int e=errno_result(unshare(CLONE_NEWNS));result("grant.ordinary_unshare_denied_before",e==-EPERM,e,-EPERM);
 e=errno_result(mount("tmpfs","/mnt/mutate","tmpfs",MS_NOSUID|MS_NODEV,"size=4k"));result("grant.ordinary_mount_denied_before",e==-EPERM,e,-EPERM);
 struct p4_guest_mntns_consume c={.abi=P4_GUEST_MNTNS_ABI,.nonce={r.nonce[0],r.nonce[1]}};
 if(mode==WRONG_NONCE)c.nonce[0]^=1;
 if(mode==EXPIRY){struct timespec t={.tv_sec=6};while(nanosleep(&t,&t)<0)must(errno==EINTR,"expiry_wait");}
 if(mode==FS_CHANGE)umask(0177);if(mode==CRED_CHANGE)set_caps(0,0,0);
 int expected=0;if(mode==WRONG_NONCE)expected=-EINVAL;if(mode==EXPIRY)expected=-ETIME;if(mode==FS_CHANGE||mode==CRED_CHANGE||mode==MOUNT_CHANGE)expected=-ESTALE;
 e=errno_result(ioctl(token,P4_GUEST_MNTNS_CONSUME,&c));snprintf(name,sizeof(name),"grant.%s.consume",names[mode]);result(name,e==expected,e,expected);
 uint64_t user=ns_inode("user"),mnt=ns_inode("mnt"),pid=ns_inode("pid"),caps[5];capture_caps(caps);
 result("grant.only_expected_mount_namespace_change",user==h.user&&pid==h.pidns&&((expected==0)?mnt!=h.mnt:mnt==h.mnt),mnt==h.mnt,expected?1:0);
 if(mode!=CRED_CHANGE)result("grant.cap_sets_unchanged",memcmp(caps,h.caps,sizeof(caps))==0,memcmp(caps,h.caps,sizeof(caps)),0);
 c.nonce[0]=r.nonce[0];e=errno_result(ioctl(token,P4_GUEST_MNTNS_CONSUME,&c));int replay=mode==EXPIRY?-ETIME:-EALREADY;result("grant.descriptor_spent",e==replay,e,replay);
 e=errno_result(unshare(CLONE_NEWNS));result("grant.ordinary_unshare_denied_after",e==-EPERM,e,-EPERM);
 e=errno_result(mount("tmpfs","/mnt/mutate","tmpfs",MS_NOSUID|MS_NODEV,"size=4k"));result("grant.ordinary_mount_denied_after",e==-EPERM,e,-EPERM);
 close(token);return failures?1:0;
}
static int pid_one(void *opaque){
 struct clone_args*a=opaque;close(a->other);char ready;must(read(a->fd,&ready,1)==1&&ready=='G',"maps_ready");must(getpid()==1,"fixture_pid_one");
 must(mount(NULL,"/",NULL,MS_REC|MS_PRIVATE,NULL)==0,"fixture_private_mounts");must(mount("proc","/proc","proc",MS_NOSUID|MS_NOEXEC|MS_NODEV,NULL)==0,"fixture_proc");
 pid_t p=fork();must(p>=0,"fixture_worker_fork");if(!p){char fd[32],mode[32];snprintf(fd,sizeof(fd),"%d",a->fd);snprintf(mode,sizeof(mode),"%d",a->mode);must(fcntl(a->fd,F_SETFD,0)==0,"worker_control_exec");execl("/grant_probe","/grant_probe","--worker",fd,mode,(char*)NULL);fatal("worker_exec");}
 close(a->fd);int st;must(waitpid(p,&st,0)==p,"fixture_wait_worker");return WIFEXITED(st)?WEXITSTATUS(st):98;
}
static void one_case(enum mode mode){
 int pair[2];must(socketpair(AF_UNIX,SOCK_SEQPACKET|SOCK_CLOEXEC,0,pair)==0,"fixture_channel");
 void*stack=mmap(NULL,1024*1024,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_STACK,-1,0);must(stack!=MAP_FAILED,"clone_stack");
 struct clone_args a={.fd=pair[1],.other=pair[0],.mode=mode};pid_t p=clone(pid_one,(char*)stack+1024*1024,CLONE_NEWUSER|CLONE_NEWNS|CLONE_NEWPID|SIGCHLD,&a);must(p>=0,"fixture_clone");close(pair[1]);map_child(p);write_full(pair[0],"G",1);
 struct hello h={0};int fds[4];must(recv_packet(pair[0],&h,sizeof(h),fds,4)==4,"fixture_four_fds");must(h.mode==(int)mode&&h.pid==2,"fixture_identity_packet");
 for(int i=1;i<4;i++){struct stat st;must(fstat(fds[i],&st)==0,"fixture_fstat_namespace");uint64_t inode=i==1?h.user:i==2?h.mnt:h.pidns;must(st.st_ino==inode,"fixture_namespace_inode");}
 int ctl=open("/dev/p4_guest_mntns",O_RDWR|O_CLOEXEC);must(ctl>=0,"grant_control_open");int wrong=-1;if(mode==WRONG_NAMESPACE){wrong=open("/proc/self/ns/mnt",O_RDONLY|O_CLOEXEC);must(wrong>=0,"wrong_ns_open");}
 struct p4_guest_mntns_mint m={.abi=P4_GUEST_MNTNS_ABI,.target_pidfd=fds[0],.userns_fd=fds[1],.mountns_fd=wrong>=0?wrong:fds[2],.pidns_fd=fds[3],.nonce={0x613850346772616eULL,(uint64_t)mode+1}};
 int token=ioctl(ctl,P4_GUEST_MNTNS_MINT,&m);int mint_errno=token<0?errno:0;
 if(token>=0&&mode==MOUNT_CHANGE){pid_t q=fork();must(q>=0,"mount_mutator_fork");if(!q){must(setns(fds[2],CLONE_NEWNS)==0,"mount_mutator_setns");must(mount("tmpfs","/mnt/mutate","tmpfs",MS_NOSUID|MS_NODEV,"size=4k")==0,"mount_mutator_actual_mount");_exit(0);}wait_ok(q,"grant.mount_change.actual_mutator_exit");}
 struct reply r={.mint_errno=mint_errno,.nonce={m.nonce[0],m.nonce[1]}};send_packet(pair[0],&r,sizeof(r),token>=0?&token:NULL,token>=0?1:0);
 if(token>=0)close(token);close(ctl);if(wrong>=0)close(wrong);for(int i=0;i<4;i++)close(fds[i]);char name[100];snprintf(name,sizeof(name),"grant.%s.worker_exit",names[mode]);wait_ok(p,name);close(pair[0]);munmap(stack,1024*1024);
}
int main(int argc,char**argv){
 setvbuf(stdout,NULL,_IONBF,0);if(argc==4&&!strcmp(argv[1],"--worker"))return worker(atoi(argv[2]),atoi(argv[3]));
 alarm(180);must(getuid()==0,"grant_vm_root");for(enum mode m=POSITIVE;m<=MOUNT_CHANGE;m++)one_case(m);
 printf("P4GROUP {\"name\":\"grant\",\"pass\":%s,\"failures\":%d}\n",failures?"false":"true",failures);return failures?1:0;
}
