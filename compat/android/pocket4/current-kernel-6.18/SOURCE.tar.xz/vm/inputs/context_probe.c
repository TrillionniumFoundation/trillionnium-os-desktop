/* Fresh VM tests of immutable typed contexts and saved Binder credentials. */
#include "probe_common.h"
#include "p4_lsm_context.h"
#include <linux/android/binder.h>
#include <linux/android/binderfs.h>
#include <sys/xattr.h>
#ifndef SCM_SECURITY
#define SCM_SECURITY 0x03
#endif
#define SELINUX_ID 101U
#define BASE "user_u:base_r:base_t"
#define SENDER "user_u:base_r:sender_t"
#define RECEIVER "user_u:base_r:receiver_t"
#define DENIED "user_u:base_r:denied_t"
#define DENY_BINDER "user_u:base_r:deny_binder_t"
struct net_hello {uint64_t inode;int used;};
struct net_reply {int error,active;};
struct net_args {int fd,other,used,active;};
/* Original x86-64 6.18 UAPI: lsm_get_self_attr=459, set_self_attr=460. */
struct explicit_lsm_context {uint64_t id,flags,len,ctx_len;char text[256];};
static void setcon(const char*s){struct explicit_lsm_context c={.id=SELINUX_ID};c.ctx_len=strlen(s)+1;must(c.ctx_len<=sizeof(c.text),"lsm_set_context_bound");c.len=32+c.ctx_len;memcpy(c.text,s,c.ctx_len);must(syscall(460,100,&c,(uint32_t)c.len,0)==0,"lsm_set_self_attr");}
static void getcon(char*out,size_t capacity){struct explicit_lsm_context c={.id=SELINUX_ID};uint32_t size=sizeof(c);long n=syscall(459,100,&c,&size,1);must(n==1&&c.id==SELINUX_ID&&c.flags==0&&c.ctx_len>0&&c.ctx_len<=sizeof(c.text)&&c.len>=32+c.ctx_len&&c.len<=size,"lsm_get_self_attr");size_t len=strnlen(c.text,c.ctx_len);must(len<c.ctx_len&&len+1<=capacity,"lsm_get_context_bound");memcpy(out,c.text,len+1);}
static void trim(char*s){size_t n=strlen(s);while(n&&(s[n-1]=='\n'||s[n-1]=='\r'))s[--n]=0;}
/* The fc originates in a mapped guest PID namespace; only its initial-userns
 * broker selects the LSM and creates the superblock. gid is deliberately
 * nonidentity mapped to catch interpretation by the CREATE caller. */
struct transfer_args {int fd,other;};
struct transfer_hello {uint64_t pidns,userns;};
static void transfer_group_access(void){
 int ready[2];must(pipe2(ready,O_CLOEXEC)==0,"proc.readproc_target_pipe");
 pid_t target=fork();must(target>=0,"proc.readproc_target_fork");
 if(!target){close(ready[0]);must(setresgid(1001,1001,1001)==0&&setresuid(1001,1001,1001)==0,"proc.readproc_target_identity");write_full(ready[1],"R",1);close(ready[1]);for(;;)pause();}
 close(ready[1]);struct pollfd pollfd={.fd=ready[0],.events=POLLIN};must(poll(&pollfd,1,5000)==1,"proc.readproc_target_deadline");char c;must(read(ready[0],&c,1)==1&&c=='R',"proc.readproc_target_ready");close(ready[0]);
 for(int member=0;member<=1;member++){
  pid_t reader=fork();must(reader>=0,"proc.readproc_reader_fork");
  if(!reader){failures=0;gid_t gid=member?3009:0;must(setresgid(gid,gid,gid)==0&&setresuid(2000,2000,2000)==0,"proc.readproc_reader_identity");struct __user_cap_header_struct h={.version=_LINUX_CAPABILITY_VERSION_3,.pid=0};struct __user_cap_data_struct d[2]={0};must(syscall(SYS_capget,&h,d)==0,"proc.readproc_capget");must(!(d[0].effective|d[1].effective|d[0].permitted|d[1].permitted),"proc.readproc_reader_unprivileged");
   char path[96];snprintf(path,sizeof(path),"/proc-transfer/%d/status",target);int fd=open(path,O_RDONLY|O_CLOEXEC);int e=fd<0?errno:0;char data[256];ssize_t n=fd>=0?read(fd,data,sizeof(data)):-1;if(fd>=0)close(fd);
   result(member?"proc.readproc_member_visible":"proc.readproc_nonmember_hidden",member?(e==0&&n>0):(e==ENOENT),e,member?0:ENOENT);_exit(failures?1:0);
  }wait_ok(reader,member?"proc.readproc_member_child_exit":"proc.readproc_nonmember_child_exit");
 }
 must(kill(target,SIGKILL)==0,"proc.readproc_target_kill");int st;must(waitpid(target,&st,0)==target,"proc.readproc_target_wait");result("proc.readproc_target_retired",WIFSIGNALED(st)&&WTERMSIG(st)==SIGKILL,st,SIGKILL);
}
static int transfer_proc_child(void*opaque){
 struct transfer_args*a=opaque;failures=0;close(a->other);char c;must(read(a->fd,&c,1)==1,"proc.transfer_maps_ready");
 must(setresgid(0,0,0)==0&&setresuid(0,0,0)==0,"proc.transfer_guest_ids");
 must(mount(NULL,"/",NULL,MS_REC|MS_PRIVATE,NULL)==0,"proc.transfer_private_tree");
 int fc=syscall(SYS_fsopen,"proc",1);must(fc>=0,"proc.transfer_fsopen");
 must(syscall(SYS_fsconfig,fc,1,"hidepid","2",0)==0&&syscall(SYS_fsconfig,fc,1,"gid","3009",0)==0,"proc.transfer_child_parameters");
 int e=errno_result(syscall(SYS_fsconfig,fc,1,"lsm_context","selinux",0));result("proc.transfer_subordinate_selection_rejected",e==-EPERM,e,-EPERM);
 int ns[3]={fc,open("/proc/self/ns/pid",O_RDONLY|O_CLOEXEC),open("/proc/self/ns/user",O_RDONLY|O_CLOEXEC)};must(ns[1]>=0&&ns[2]>=0,"proc.transfer_namespace_fds");
 struct transfer_hello h={.pidns=ns_inode("pid"),.userns=ns_inode("user")};send_packet(a->fd,&h,sizeof(h),ns,3);for(int i=0;i<3;i++)close(ns[i]);
 int mnt;must(recv_packet(a->fd,&c,1,&mnt,1)==1&&c=='M',"proc.transfer_returned_mount");
 must(syscall(SYS_move_mount,mnt,"",AT_FDCWD,"/proc-transfer",4)==0,"proc.transfer_attach");close(mnt);
 send_packet(a->fd,"R",1,NULL,0);must(recv_packet(a->fd,&c,1,NULL,0)==0&&c=='O',"proc.transfer_parent_observed");
 char self[32]={0},ctx[256],typed[256],mounts[32768];ssize_t n=readlink("/proc-transfer/self",self,sizeof(self)-1);
 result("proc.transfer_original_child_pidns",getpid()==1&&n==1&&self[0]=='1',getpid(),1);
 struct stat st;must(stat("/proc-transfer/1/ns/pid",&st)==0,"proc.transfer_pidns_stat");result("proc.transfer_pidns_inode",st.st_ino==h.pidns,st.st_ino,h.pidns);
 read_path("/proc-transfer/self/mountinfo",mounts,sizeof(mounts));char*row=strstr(mounts," /proc-transfer ");bool mapped=false;
 if(row){char*end=strchr(row,'\n');if(end)*end=0;mapped=strstr(row,"gid=203009")&&strstr(row,"hidepid=invisible")&&strstr(row,"lsm_context=selinux");}
 if(row)printf("P4OBS guest_proc_mount=%s\n",row);result("proc.transfer_guest_rendered_host_gid",mapped,mapped,1);
 read_path("/proc-transfer/thread-self/attr/current",ctx,sizeof(ctx));trim(ctx);result("proc.transfer_legacy_selinux_read",!strcmp(ctx,BASE),strcmp(ctx,BASE),0);
 write_path("/proc-transfer/thread-self/attr/current",SENDER);getcon(typed,sizeof(typed));result("proc.transfer_legacy_selinux_write",!strcmp(typed,SENDER),strcmp(typed,SENDER),0);write_path("/proc-transfer/thread-self/attr/current",BASE);
 transfer_group_access();
 must(umount("/proc-transfer")==0,"proc.transfer_unmount");close(a->fd);return failures?1:0;
}
static void proc_transfer_test(void){
 must(mkdir("/proc-transfer",0777)==0&&chmod("/proc-transfer",0777)==0,"proc.transfer_directory");
 uint64_t parent_pidns=ns_inode("pid"),parent_userns=ns_inode("user");
 int pair[2];must(socketpair(AF_UNIX,SOCK_SEQPACKET|SOCK_CLOEXEC,0,pair)==0,"proc.transfer_channel");void*stack=mmap(NULL,1024*1024,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_STACK,-1,0);must(stack!=MAP_FAILED,"proc.transfer_stack");
 struct transfer_args a={.fd=pair[1],.other=pair[0]};pid_t p=clone(transfer_proc_child,(char*)stack+1024*1024,CLONE_NEWUSER|CLONE_NEWNS|CLONE_NEWPID|SIGCHLD,&a);must(p>=0,"proc.transfer_clone");close(pair[1]);
 char path[100];snprintf(path,sizeof(path),"/proc/%d/setgroups",p);write_path(path,"deny\n");snprintf(path,sizeof(path),"/proc/%d/uid_map",p);write_path(path,"0 100000 65536\n");snprintf(path,sizeof(path),"/proc/%d/gid_map",p);write_path(path,"0 200000 65536\n");write_full(pair[0],"G",1);
 struct transfer_hello h;int fds[3];must(recv_packet(pair[0],&h,sizeof(h),fds,3)==3,"proc.transfer_context_receive");
 struct stat st,live;must(fstat(fds[1],&st)==0,"proc.transfer_pidns_fstat");snprintf(path,sizeof(path),"/proc/%d/ns/pid",p);must(stat(path,&live)==0,"proc.transfer_live_pidns");result("proc.transfer_held_pidns_exact",st.st_ino==h.pidns&&live.st_ino==h.pidns&&h.pidns!=parent_pidns,st.st_ino,h.pidns);
 must(fstat(fds[2],&st)==0,"proc.transfer_userns_fstat");snprintf(path,sizeof(path),"/proc/%d/ns/user",p);must(stat(path,&live)==0,"proc.transfer_live_userns");result("proc.transfer_held_userns_exact",st.st_ino==h.userns&&live.st_ino==h.userns&&h.userns!=parent_userns,st.st_ino,h.userns);
 must(syscall(SYS_fsconfig,fds[0],1,"gid","203009",0)==0,"proc.transfer_host_mapped_gid");
 int e=errno_result(syscall(SYS_fsconfig,fds[0],1,"lsm_context","selinux",0));result("proc.transfer_initial_broker_selects",e==0,e,0);must(e==0,"proc.transfer_select_required");
 e=errno_result(syscall(SYS_fsconfig,fds[0],6,NULL,NULL,0));result("proc.transfer_initial_broker_creates",e==0,e,0);must(e==0,"proc.transfer_create_required");
 int mnt=syscall(SYS_fsmount,fds[0],1,MS_NOSUID|MS_NOEXEC|MS_NODEV);must(mnt>=0,"proc.transfer_fsmount");send_packet(pair[0],"M",1,&mnt,1);close(mnt);for(int i=0;i<3;i++)close(fds[i]);
 char c;must(recv_packet(pair[0],&c,1,NULL,0)==0&&c=='R',"proc.transfer_child_attached");
 char mounts[32768];snprintf(path,sizeof(path),"/proc/%d/mountinfo",p);read_path(path,mounts,sizeof(mounts));char*row=strstr(mounts," /proc-transfer ");bool mapped=false;
 if(row){char*end=strchr(row,'\n');if(end)*end=0;mapped=strstr(row,"gid=203009")&&strstr(row,"lsm_context=selinux");}
 if(row)printf("P4OBS broker_proc_mount=%s\n",row);result("proc.transfer_parent_gid_203009",mapped,mapped,1);result("proc.transfer_broker_namespace_unchanged",ns_inode("pid")==parent_pidns&&ns_inode("user")==parent_userns,ns_inode("pid"),parent_pidns);
 send_packet(pair[0],"O",1,NULL,0);wait_ok(p,"proc.transfer_child_exit");close(pair[0]);munmap(stack,1024*1024);must(rmdir("/proc-transfer")==0,"proc.transfer_directory_retired");
}
struct proc_args {int fd,other;};
static int subordinate_proc(void*opaque){struct proc_args*a=opaque;close(a->other);char c;must(read(a->fd,&c,1)==1,"subordinate_proc_maps");int e=errno_result(mount("proc","/proc-denied","proc",MS_NOSUID|MS_NOEXEC|MS_NODEV,"lsm_context=selinux"));result("proc.subordinate_selector_rejected",e==-EPERM,e,-EPERM);return e==-EPERM?0:1;}
static void proc_tests(int active){
 must(mkdir("/proc-selinux",0700)==0&&mkdir("/proc-denied",0700)==0,"proc_test_directories");
 int e=errno_result(mount("proc","/proc-selinux","proc",MS_NOSUID|MS_NOEXEC|MS_NODEV,"lsm_context=selinux"));result(active?"proc.mount_selected":"proc.inactive_selector_rejected",e==(active?0:-EOPNOTSUPP),e,active?0:-EOPNOTSUPP);
 if(!active||e)return;
 char selected[256],defaulted[256],explicit_aa[256],typed[256];read_path("/proc-selinux/thread-self/attr/current",selected,sizeof(selected));read_path("/proc/thread-self/attr/current",defaulted,sizeof(defaulted));read_path("/proc-selinux/thread-self/attr/apparmor/current",explicit_aa,sizeof(explicit_aa));trim(selected);trim(defaulted);trim(explicit_aa);
 result("proc.legacy_selected_selinux_read",!strcmp(selected,BASE),strcmp(selected,BASE),0);result("proc.default_and_explicit_apparmor_preserved",strstr(defaulted,"unconfined")&&!strcmp(defaulted,explicit_aa),strcmp(defaulted,explicit_aa),0);
 write_path("/proc-selinux/thread-self/attr/current",SENDER);getcon(typed,sizeof(typed));result("proc.legacy_selected_selinux_write",!strcmp(typed,SENDER),strcmp(typed,SENDER),0);write_path("/proc-selinux/thread-self/attr/current",BASE);
 e=errno_result(mount(NULL,"/proc-selinux",NULL,MS_REMOUNT|MS_NOSUID|MS_NOEXEC|MS_NODEV,"lsm_context=default"));result("proc.selected_provider_immutable",e==-EBUSY,e,-EBUSY);
 e=errno_result(mount(NULL,"/proc",NULL,MS_REMOUNT|MS_NOSUID|MS_NOEXEC|MS_NODEV,"lsm_context=selinux"));result("proc.default_provider_immutable",e==-EBUSY,e,-EBUSY);
 int pair[2];must(socketpair(AF_UNIX,SOCK_SEQPACKET|SOCK_CLOEXEC,0,pair)==0,"proc_test_channel");void*stack=mmap(NULL,1024*1024,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_STACK,-1,0);must(stack!=MAP_FAILED,"proc_test_stack");struct proc_args a={.fd=pair[1],.other=pair[0]};pid_t p=clone(subordinate_proc,(char*)stack+1024*1024,CLONE_NEWUSER|CLONE_NEWNS|SIGCHLD,&a);must(p>=0,"subordinate_proc_clone");close(pair[1]);map_child(p);write_full(pair[0],"G",1);wait_ok(p,"proc.subordinate_selector_child_exit");close(pair[0]);munmap(stack,1024*1024);
 must(umount("/proc-selinux")==0,"selected_proc_unmount");
}
static void mac_tests(const char*phase){
 char name[120];pid_t p=fork();must(p>=0,"selinux_deny_fork");
 if(!p){failures=0;setcon(DENIED);int fd=open("/tmp/secret",O_RDONLY|O_CLOEXEC);int e=fd<0?errno:0;if(fd>=0)close(fd);snprintf(name,sizeof(name),"context.%s.selinux_denial",phase);result(name,e==EACCES,e,EACCES);_exit(failures?1:0);}
 snprintf(name,sizeof(name),"context.%s.selinux_deny_child",phase);wait_ok(p,name);
 p=fork();must(p>=0,"apparmor_deny_fork");
 if(!p){failures=0;write_path("/proc/self/attr/apparmor/current","changeprofile p4_vm_deny");int fd=open("/tmp/aa-secret",O_RDONLY|O_CLOEXEC);int e=fd<0?errno:0;if(fd>=0)close(fd);snprintf(name,sizeof(name),"context.%s.apparmor_denial",phase);result(name,e==EACCES,e,EACCES);_exit(failures?1:0);}
 snprintf(name,sizeof(name),"context.%s.apparmor_deny_child",phase);wait_ok(p,name);
}
static void typed_sockets(void){
 setcon(SENDER);int pair[2];must(socketpair(AF_UNIX,SOCK_STREAM|SOCK_CLOEXEC,0,pair)==0,"typed_socketpair");
 char ctx[256]={0};socklen_t len=sizeof(ctx);int e=errno_result(getsockopt(pair[0],SOL_SOCKET,SO_PEERSEC,ctx,&len));
 result("context.selected_so_peersec",e==0&&len>0&&len<sizeof(ctx)&&!strcmp(ctx,SENDER),e,0);printf("P4OBS selected_so_peersec=%.*s\n",(int)len,ctx);
 close(pair[0]);close(pair[1]);must(socketpair(AF_UNIX,SOCK_DGRAM|SOCK_CLOEXEC,0,pair)==0,"typed_datagram_pair");
 int yes=1;must(setsockopt(pair[1],SOL_SOCKET,SO_PASSSEC,&yes,sizeof(yes))==0,"typed_passsec_enable");setcon(RECEIVER);must(send(pair[0],"T",1,0)==1,"typed_send");
 char byte,control[1024]={0};struct iovec io={.iov_base=&byte,.iov_len=1};struct msghdr msg={.msg_iov=&io,.msg_iovlen=1,.msg_control=control,.msg_controllen=sizeof(control)};
 must(recvmsg(pair[1],&msg,0)==1&&byte=='T'&&!(msg.msg_flags&(MSG_CTRUNC|MSG_TRUNC)),"typed_recv");bool found=false;
 for(struct cmsghdr*c=CMSG_FIRSTHDR(&msg);c;c=CMSG_NXTHDR(&msg,c))if(c->cmsg_level==SOL_SOCKET&&c->cmsg_type==SCM_SECURITY){size_t n=c->cmsg_len-CMSG_LEN(0);memset(ctx,0,sizeof(ctx));must(n>0&&n<sizeof(ctx),"typed_security_bound");memcpy(ctx,CMSG_DATA(c),n);found=!strcmp(ctx,SENDER);printf("P4OBS selected_scm_security=%.*s\n",(int)n,ctx);}
 result("context.selected_scm_security",found,found,1);close(pair[0]);close(pair[1]);mac_tests("after_selection");
}
static int net_child(void*opaque){
 struct net_args*a=opaque;failures=0;close(a->other);char start;must(read(a->fd,&start,1)==1&&start=='G',"net_maps_ready");
 if(a->used){int s=socket(AF_UNIX,SOCK_DGRAM|SOCK_CLOEXEC,0);must(s>=0,"used_net_actual_socket");close(s);}
 int ns=open("/proc/self/ns/net",O_RDONLY|O_CLOEXEC);must(ns>=0,"child_net_fd");struct net_hello h={.inode=ns_inode("net"),.used=a->used};send_packet(a->fd,&h,sizeof(h),&ns,1);close(ns);
 struct net_reply r;must(recv_packet(a->fd,&r,sizeof(r),NULL,0)==0,"net_reply");int expected=a->used?EBUSY:a->active?0:EOPNOTSUPP;
 result(a->used?"context.used_namespace_rejected":a->active?"context.fresh_namespace_selected":"context.inactive_provider_rejected",r.error==expected,r.error,expected);
 if(a->active&&!a->used&&r.error==0){
  int ctl=open("/dev/p4_lsm_context",O_RDWR|O_CLOEXEC);must(ctl>=0,"subordinate_context_control_open");int n=open("/proc/self/ns/net",O_RDONLY|O_CLOEXEC);must(n>=0,"subordinate_net_open");
  struct p4_lsm_netns req={.size=sizeof(req),.version=P4_LSM_CONTEXT_ABI,.netns_fd=n,.lsm_id=SELINUX_ID,.expected_ns_inum=ns_inode("net")};int e=errno_result(ioctl(ctl,P4_LSM_NETNS_SET,&req));result("context.subordinate_issuer_rejected",e==-EPERM,e,-EPERM);close(n);close(ctl);
  typed_sockets();must(unshare(CLONE_NEWNET)==0,"selected_derive_net");ns=open("/proc/self/ns/net",O_RDONLY|O_CLOEXEC);must(ns>=0,"derived_net_fd");h.inode=ns_inode("net");send_packet(a->fd,&h,sizeof(h),&ns,1);close(ns);must(recv_packet(a->fd,&r,sizeof(r),NULL,0)==0,"derived_net_reply");
 }return failures?1:0;
}
static void query_net(int ctl,int ns,uint32_t id,uint32_t flags,const char*name){
 struct stat st;must(fstat(ns,&st)==0,"query_net_fstat");struct p4_lsm_netns q={.size=sizeof(q),.version=P4_LSM_CONTEXT_ABI,.netns_fd=ns,.expected_ns_inum=st.st_ino};int e=errno_result(ioctl(ctl,P4_LSM_NETNS_GET,&q));result(name,e==0&&q.lsm_id==id&&q.flags==flags,e?(long)e:(long)q.flags,flags);
}
static void net_case(int used,int active){
 int pair[2];must(socketpair(AF_UNIX,SOCK_SEQPACKET|SOCK_CLOEXEC,0,pair)==0,"net_channel");void*stack=mmap(NULL,1024*1024,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_STACK,-1,0);must(stack!=MAP_FAILED,"net_stack");
 struct net_args a={.fd=pair[1],.other=pair[0],.used=used,.active=active};pid_t p=clone(net_child,(char*)stack+1024*1024,CLONE_NEWUSER|CLONE_NEWNET|SIGCHLD,&a);must(p>=0,"net_clone");close(pair[1]);map_child(p);write_full(pair[0],"G",1);
 struct net_hello h;int ns;must(recv_packet(pair[0],&h,sizeof(h),&ns,1)==1,"net_identity_receive");struct stat st;must(fstat(ns,&st)==0&&st.st_ino==h.inode,"net_identity_inode");
 int ctl=open("/dev/p4_lsm_context",O_RDWR|O_CLOEXEC);must(ctl>=0,"context_control_open");query_net(ctl,ns,0,used?P4_LSM_NETNS_USED:0,"context.initial_state_exact");
 struct p4_lsm_netns req={.size=sizeof(req),.version=P4_LSM_CONTEXT_ABI,.netns_fd=ns,.lsm_id=SELINUX_ID,.expected_ns_inum=h.inode};struct net_reply r={.active=active};int rc=ioctl(ctl,P4_LSM_NETNS_SET,&req);r.error=rc<0?errno:0;
 if(active&&!used&&rc==0){query_net(ctl,ns,SELINUX_ID,P4_LSM_NETNS_FIXED,"context.selected_before_use");int e=errno_result(ioctl(ctl,P4_LSM_NETNS_SET,&req));result("context.repeat_set_rejected",e==-EBUSY,e,-EBUSY);}send_packet(pair[0],&r,sizeof(r),NULL,0);
 if(active&&!used&&rc==0){int derived;must(recv_packet(pair[0],&h,sizeof(h),&derived,1)==1,"derived_identity_receive");query_net(ctl,ns,SELINUX_ID,P4_LSM_NETNS_FIXED|P4_LSM_NETNS_USED,"context.selected_parent_used");query_net(ctl,derived,SELINUX_ID,P4_LSM_NETNS_FIXED,"context.child_inherits_fixed_provider");req.netns_fd=derived;req.expected_ns_inum=h.inode;int e=errno_result(ioctl(ctl,P4_LSM_NETNS_SET,&req));result("context.derived_reselection_rejected",e==-EBUSY,e,-EBUSY);send_packet(pair[0],&r,sizeof(r),NULL,0);close(derived);}
 close(ns);close(ctl);wait_ok(p,used?"context.used_worker_exit":"context.fresh_worker_exit");close(pair[0]);munmap(stack,1024*1024);
}
static int binder_write(int fd,void*data,size_t len){struct binder_write_read b={.write_size=len,.write_buffer=(uintptr_t)data};int r=ioctl(fd,BINDER_WRITE_READ,&b);must(r==0&&b.write_consumed==len,"binder_write_consumed");return r;}
static bool binder_read_code(int fd,uint32_t wanted,void*out,size_t out_size){
 struct timespec begin;clock_gettime(CLOCK_MONOTONIC,&begin);
 for(;;){unsigned char bytes[1024];struct binder_write_read b={.read_size=sizeof(bytes),.read_buffer=(uintptr_t)bytes};int r=ioctl(fd,BINDER_WRITE_READ,&b);
  if(r<0&&errno!=EAGAIN&&errno!=EINTR)fatal("binder_read_ioctl");
  if(r==0){size_t off=0;while(off<b.read_consumed){uint32_t code;must(off+sizeof(code)<=b.read_consumed,"binder_code_bound");memcpy(&code,bytes+off,sizeof(code));off+=sizeof(code);size_t n=_IOC_SIZE(code);must(off+n<=b.read_consumed,"binder_payload_bound");if(code==wanted){must(n==out_size,"binder_payload_size");if(n)memcpy(out,bytes+off,n);return true;}if(code==BR_FAILED_REPLY||code==BR_DEAD_REPLY||code==BR_ERROR){printf("P4OBS unexpected_binder_return=%u\n",code);return false;}off+=n;}}
  struct timespec now;clock_gettime(CLOCK_MONOTONIC,&now);if(now.tv_sec-begin.tv_sec>=8)return false;struct pollfd p={.fd=fd,.events=POLLIN};poll(&p,1,50);
 }
}
static void binder_case(int denied){
 int ctl=open("/dev/binder-test/binder-control",O_RDWR|O_CLOEXEC);must(ctl>=0,"binder_control_open");struct binderfs_device dev={0};snprintf(dev.name,sizeof(dev.name),"probe%d",denied);must(ioctl(ctl,BINDER_CTL_ADD,&dev)==0,"binder_device_create");close(ctl);
 char path[512];snprintf(path,sizeof(path),"/dev/binder-test/%s",dev.name);int fd=open(path,O_RDWR|O_NONBLOCK|O_CLOEXEC);must(fd>=0,"binder_server_open");size_t mapsize=1024*1024;void*map=mmap(NULL,mapsize,PROT_READ,MAP_PRIVATE,fd,0);must(map!=MAP_FAILED,"binder_server_mmap");
 struct flat_binder_object mgr={.hdr.type=BINDER_TYPE_BINDER,.flags=FLAT_BINDER_FLAG_TXN_SECURITY_CTX};must(ioctl(fd,BINDER_SET_CONTEXT_MGR_EXT,&mgr)==0,"binder_context_manager");uint32_t enter=BC_ENTER_LOOPER;binder_write(fd,&enter,sizeof(enter));
 pid_t p=fork();must(p>=0,"binder_client_fork");if(!p){
  failures=0;close(fd);setcon(denied?DENY_BINDER:SENDER);int client=open(path,O_RDWR|O_NONBLOCK|O_CLOEXEC);must(client>=0,"binder_client_open");setcon(RECEIVER);
  char current[256];getcon(current,sizeof(current));trim(current);result("binder.client_current_changed",!strcmp(current,RECEIVER),strcmp(current,RECEIVER),0);
  uint32_t value=0x618643a;struct binder_transaction_data t={.target.handle=0,.code=0xf00d,.flags=TF_ONE_WAY,.data_size=sizeof(value),.data.ptr.buffer=(uintptr_t)&value};unsigned char writebuf[sizeof(uint32_t)+sizeof(t)];uint32_t cmd=BC_TRANSACTION;memcpy(writebuf,&cmd,sizeof(cmd));memcpy(writebuf+sizeof(cmd),&t,sizeof(t));binder_write(client,writebuf,sizeof(writebuf));
  bool ok=binder_read_code(client,denied?BR_FAILED_REPLY:BR_TRANSACTION_COMPLETE,NULL,0);result(denied?"binder.saved_open_cred_mac_denied":"binder.transaction_complete",ok,ok,1);close(client);_exit(failures?1:0);
 }
 if(!denied){struct binder_transaction_data_secctx t={0};bool ok=binder_read_code(fd,BR_TRANSACTION_SEC_CTX,&t,sizeof(t));result("binder.actual_transaction_secctx",ok,ok,1);
  if(ok){uintptr_t ctx=t.secctx;bool bounds=ctx>=(uintptr_t)map&&ctx+256<=(uintptr_t)map+mapsize;must(bounds,"binder_context_in_original_mapping");const char*s=(const char*)ctx;size_t n=strnlen(s,256);result("binder.saved_open_credential_context",n<256&&!strcmp(s,SENDER),n,strlen(SENDER));printf("P4OBS binder_open_context=%.*s\n",(int)n,s);
   result("binder.transaction_identity",t.transaction_data.code==0xf00d&&t.transaction_data.data_size==4,t.transaction_data.code,0xf00d);uint32_t value;must(t.transaction_data.data.ptr.buffer>=(uintptr_t)map&&t.transaction_data.data.ptr.buffer+4<=(uintptr_t)map+mapsize,"binder_data_in_mapping");memcpy(&value,(void*)(uintptr_t)t.transaction_data.data.ptr.buffer,4);result("binder.transaction_payload",value==0x618643a,value,0x618643a);
   unsigned char freebuf[sizeof(uint32_t)+sizeof(binder_uintptr_t)];uint32_t freecmd=BC_FREE_BUFFER;memcpy(freebuf,&freecmd,4);memcpy(freebuf+4,&t.transaction_data.data.ptr.buffer,sizeof(binder_uintptr_t));binder_write(fd,freebuf,sizeof(freebuf));}
 }
 wait_ok(p,denied?"binder.denied_client_exit":"binder.client_exit");
 if(denied){unsigned char buf[512];struct binder_write_read b={.read_size=sizeof(buf),.read_buffer=(uintptr_t)buf};int rc=ioctl(fd,BINDER_WRITE_READ,&b);bool got=false;if(rc==0){for(size_t off=0;off+4<=b.read_consumed;){uint32_t cmd;memcpy(&cmd,buf+off,4);off+=4;size_t n=_IOC_SIZE(cmd);must(off+n<=b.read_consumed,"denied_binder_reply_bound");got|=cmd==BR_TRANSACTION||cmd==BR_TRANSACTION_SEC_CTX;off+=n;}}result("binder.denied_not_delivered",!got,got,0);}
 munmap(map,mapsize);close(fd);
}
int main(int argc,char**argv){
 setvbuf(stdout,NULL,_IONBF,0);alarm(180);int active=argc==2&&!strcmp(argv[1],"active");
 char lsms[1024];read_path("/sys/kernel/security/lsm",lsms,sizeof(lsms));result("context.apparmor_active",strstr(lsms,"apparmor")!=NULL,strstr(lsms,"apparmor")!=NULL,1);result("context.selinux_presence_exact",(strstr(lsms,"selinux")!=NULL)==active,strstr(lsms,"selinux")!=NULL,active);printf("P4OBS active_lsms=%s\n",lsms);
 if(active){char enforced[32];read_path("/sys/fs/selinux/enforce",enforced,sizeof(enforced));result("context.selinux_enforcing",enforced[0]=='1',enforced[0],'1');char legacy[256],typed[256],aa[256];read_path("/proc/self/attr/current",legacy,sizeof(legacy));getcon(typed,sizeof(typed));read_path("/proc/self/attr/apparmor/current",aa,sizeof(aa));trim(legacy);trim(typed);trim(aa);result("context.typed_selfattr_selinux",!strcmp(typed,BASE),strcmp(typed,BASE),0);result("context.legacy_proc_apparmor",!strcmp(legacy,aa)&&strstr(aa,"unconfined"),strcmp(legacy,aa),0);mac_tests("before_selection");}
 int ctl=open("/dev/p4_lsm_context",O_RDWR|O_CLOEXEC),ns=open("/proc/self/ns/net",O_RDONLY|O_CLOEXEC);must(ctl>=0&&ns>=0,"initial_context_fds");struct p4_lsm_netns q={.size=sizeof(q),.version=P4_LSM_CONTEXT_ABI,.netns_fd=ns,.lsm_id=SELINUX_ID,.expected_ns_inum=ns_inode("net")};int e=errno_result(ioctl(ctl,P4_LSM_NETNS_SET,&q));result("context.initial_net_selection_denied",e==-EPERM,e,-EPERM);close(ns);close(ctl);
 proc_tests(active);
 if(active)proc_transfer_test();
 net_case(0,active);if(active)net_case(1,active);
 must(mkdir("/dev/binder-test",0700)==0,"binder_mount_directory");e=errno_result(mount("binder","/dev/binder-test","binder",MS_NOSUID|MS_NOEXEC,"lsm_context=selinux"));result(active?"binder.typed_mount":"binder.inactive_typed_mount_rejected",e==(active?0:-EOPNOTSUPP),e,active?0:-EOPNOTSUPP);
 if(active&&e==0){binder_case(0);binder_case(1);must(umount("/dev/binder-test")==0,"binder_unmount");}
 printf("P4GROUP {\"name\":\"context\",\"pass\":%s,\"failures\":%d}\n",failures?"false":"true",failures);return failures?1:0;
}
