"""Prepare one immutable, fresh VM diagnostic input; never install on host."""
from pathlib import Path
import gzip, hashlib, json, os, re, shutil, stat, struct, subprocess, time

ROOT=Path('/home/qq/work/p4-kernel-6.18.64-cp3a-20261118-r1')
INPUT=ROOT/'inputs/vm-fresh-r7'
WORK=ROOT/'vm-fresh-r7'
SOURCE=ROOT/'source/linux-6.18.64'
OUT=ROOT/'out-full-r2'
STAGE=ROOT/'modules-full-r2'
DEPS=Path('/home/qq/work/p4-kernel61864-vm-deps-20261118-162b-r1/root')
RELEASE='6.18.64-p4ctx6181'
ENV=dict(os.environ,LC_ALL='C',PATH='/usr/sbin:/usr/bin:/sbin:/bin',LD_LIBRARY_PATH=str(DEPS/'usr/lib/x86_64-linux-gnu'))
WORK.mkdir(mode=0o700,exist_ok=False)
start=time.monotonic()
report={'schema':'p4-fresh-61864-vm-preparation-v1','started_ns':time.time_ns(),'commands':[],
        'host_policy_loaded':False,'host_kernel_installed':False,'private_keys_read':False,
        'diagnostic_policy_only':True,'production_runtime_qualified':False}

def digest(p):
 p=Path(p);assert p.name!='signing_key.pem'
 s=p.stat();h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 t=p.stat();a=lambda x:[x.st_dev,x.st_ino,x.st_mode,x.st_uid,x.st_gid,x.st_nlink,x.st_size,x.st_mtime_ns,x.st_ctime_ns]
 assert a(s)==a(t)
 return {'path':str(p),'bytes':s.st_size,'sha256':h.hexdigest(),'identity':a(s)}

def run(name,args,timeout=60,binary=False):
 assert time.monotonic()-start<540
 p=subprocess.run([str(x) for x in args],env=ENV,cwd=WORK,capture_output=True,timeout=timeout)
 (WORK/(name+'.stdout')).write_bytes(p.stdout);(WORK/(name+'.stderr')).write_bytes(p.stderr)
 report['commands'].append({'name':name,'argv':list(map(str,args)),'exit':p.returncode,
                            'stdout':digest(WORK/(name+'.stdout')),'stderr':digest(WORK/(name+'.stderr'))})
 if p.returncode:raise RuntimeError((name,p.returncode,p.stderr.decode(errors='replace')[:6000]))
 return p.stdout if binary else p.stdout.decode()

def save():
 (WORK/'preparation-receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')

def main():
 raw=(ROOT/'control/full-r2/full-observation.json').read_bytes()
 assert hashlib.sha256(raw).hexdigest()=='36c451a847b595f3fe1de59726b38fc72312903bccb8c0aff5f6ab5e35dc8390'
 full=json.loads(raw);assert full['full_kernel_build_passed'] and full['whole_source_unchanged'] and full['tool_inputs_unchanged']
 term=json.loads((ROOT/'control/full-r2/full-terminal.json').read_text())
 assert term['systemd_run_exit']==0 and term['cgroup_absent'] and term['lock_records_after']==[]
 report['full_receipt_sha256']=hashlib.sha256(raw).hexdigest();report['full_terminal']=term
 pins={x['path']:x for group in ['artifacts','modules','staged_modules'] for x in full[group]}
 def verified(p):
  d=digest(p);assert d==pins[str(p)],str(p);return d
 report['kernel']=verified(OUT/'arch/x86/boot/bzImage')
 report['config']=verified(OUT/'.config');report['certificate']=verified(OUT/'certs/signing_key.x509')
 report['input_files']=[digest(p) for p in sorted(INPUT.rglob('*')) if p.is_file()]
 report['tool_files']=[digest(Path(p).resolve()) for p in ['/usr/bin/x86_64-linux-gnu-gcc-15','/usr/bin/busybox','/usr/lib/x86_64-linux-gnu/libc.a','/usr/sbin/apparmor_parser',str(DEPS/'usr/bin/checkpolicy'),str(DEPS/'usr/bin/qemu-system-x86_64')]]
 for name in ['grant_probe','context_probe','basic_probe']:
  run('compile-'+name,['/usr/bin/x86_64-linux-gnu-gcc-15','-std=gnu11','-static','-O2','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-Wno-unused-function','-I'+str(INPUT/'include'),INPUT/(name+'.c'),'-o',WORK/name])
  elf=run('elf-'+name,['/usr/bin/readelf','-l',WORK/name]);assert 'INTERP' not in elf
 run('compile-mdp',['/usr/bin/x86_64-linux-gnu-gcc-15','-O2','-I'+str(SOURCE/'include'),'-I'+str(SOURCE/'security/selinux/include'),'-I'+str(OUT/'include'),SOURCE/'scripts/selinux/mdp/mdp.c','-o',WORK/'mdp'])
 run('generate-mdp',[WORK/'mdp',WORK/'base-policy.conf',WORK/'base-file-contexts'])
 policy=(WORK/'base-policy.conf').read_text()
 caps=['network_peer_controls','open_perms','extended_socket_class','always_check_network']
 report['diagnostic_policy_capabilities']=caps
 report['kernel_capabilities_not_exercised_by_this_policy']=[x for x in re.findall(r'^policycap (\w+);$',policy,re.M) if x not in caps]
 policy=re.sub(r'^policycap (\w+);\n',lambda m:m.group(0) if m.group(1) in caps else '',policy,flags=re.M)
 classes=re.findall(r'^class ([a-zA-Z0-9_]+)\n\{',policy,re.M);assert len(classes)==96
 types=['base_t','sender_t','receiver_t','denied_t','secret_t','deny_binder_t']
 body=''.join('type '+t+';\n' for t in types)+'role base_r;\nrole base_r types { '+' '.join(types)+' };\n'
 for src in types:
  for dst in types:
   for cl in classes:
    if src=='denied_t' and dst=='secret_t' and cl=='file':body+='allow denied_t secret_t:file { getattr open };\n'
    elif src=='deny_binder_t' and dst=='base_t' and cl=='binder':continue
    else:body+=f'allow {src} {dst}:{cl} *;\n'
 policy,n=re.subn(r'type base_t;\n.*?(?=user user_u roles)',lambda _:body,policy,flags=re.S);assert n==1
 (WORK/'diagnostic-policy.conf').write_text(policy)
 run('compile-policy',[DEPS/'usr/bin/checkpolicy','-c','35','-o',WORK/'policy.bin',WORK/'diagnostic-policy.conf'])
 run('compile-apparmor',['/usr/sbin/apparmor_parser','--config-file','/dev/null','-Q','-K','--features-file',INPUT/'apparmor.features','-j','1','--max-jobs','1','-o',WORK/'apparmor.bin',INPUT/'apparmor.profile'])
 report['policy_inputs']=[digest(p) for p in [SOURCE/'scripts/selinux/mdp/mdp.c',SOURCE/'security/selinux/include/classmap.h',SOURCE/'security/selinux/include/initial_sid_to_string.h',SOURCE/'security/selinux/include/policycap_names.h',OUT/'include/generated/autoconf.h',WORK/'diagnostic-policy.conf',WORK/'policy.bin',WORK/'apparmor.bin']]
 modules=[]
 for name in ['binder_linux','erofs','dm_verity','loop']:
  text=run('moddeps-'+name,['/usr/sbin/modprobe','--show-depends','--dirname',STAGE,'--set-version',RELEASE,name])
  for line in text.splitlines():
   if line.startswith('builtin '):continue
   words=line.split();assert len(words)==2 and words[0]=='insmod',line
   p=Path(words[1]);assert p.is_relative_to(STAGE) and p.suffix=='.ko'
   if p not in modules:modules.append(p)
 assert any(p.name=='binder_linux.ko' for p in modules)
 report['modules']=[verified(p) for p in modules]
 run('public-cert',['/usr/bin/openssl','x509','-inform','DER','-in',OUT/'certs/signing_key.x509','-out',WORK/'public-cert.pem'])
 for i,p in enumerate(modules):
  payload=run('module-payload-'+str(i),['/usr/bin/perl',SOURCE/'scripts/extract-module-sig.pl','-0',p],binary=True)
  sig=run('module-signature-'+str(i),['/usr/bin/perl',SOURCE/'scripts/extract-module-sig.pl','-s',p],binary=True)
  (WORK/'signature-content').write_bytes(payload);(WORK/'signature-cms').write_bytes(sig)
  run('module-verify-'+str(i),['/usr/bin/openssl','cms','-verify','-inform','DER','-in',WORK/'signature-cms','-content',WORK/'signature-content','-certfile',WORK/'public-cert.pem','-nointern','-noverify','-binary','-out','/dev/null'])
  signer=run('module-signer-'+str(i),['/usr/sbin/modinfo','-F','signer',p]);assert signer.strip()
  vermagic=run('module-vermagic-'+str(i),['/usr/sbin/modinfo','-F','vermagic',p]);assert vermagic.startswith(RELEASE+' ')
 (WORK/'signature-content').unlink();(WORK/'signature-cms').unlink()
 report['unsigned_module']=verified(OUT/'drivers/android/binder_linux.ko')
 original=next(p for p in modules if p.name=='binder_linux.ko').read_bytes();offset=original.index(b'description=')+len(b'description=');assert 32<=original[offset]<127
 bad=bytearray(original);bad[offset]=ord('X') if original[offset]!=ord('X') else ord('Y');(WORK/'binder-tampered.ko').write_bytes(bad)
 report['tamper']={'offset':offset,'original_byte':original[offset],'tampered_byte':bad[offset],'file':digest(WORK/'binder-tampered.ko')}
 build_initramfs(modules)
 for d in report['modules']+[report['kernel'],report['config'],report['certificate'],report['unsigned_module']]+report['input_files']+report['tool_files']:
  assert digest(d['path'])==d,'input changed while preparing'
 report['prepared']=True;report['finished_ns']=time.time_ns();save()
 print(json.dumps({'prepared':True,'directory':str(WORK),'modules':len(modules),'initramfs':report['initramfs'],'receipt':digest(WORK/'preparation-receipt.json')}),flush=True)

def build_initramfs(modules):
 entries={}
 def add(name,data=b'',mode=stat.S_IFREG|0o644,major=0,minor=0):
  assert not name.startswith('/') and '..' not in Path(name).parts and name not in entries
  entries[name]=(data,mode,major,minor)
 for name in ['bin','dev','proc','sys','tmp','mnt','mnt/mutate','modules']:
  add(name,mode=stat.S_IFDIR|0o755)
 add('dev/console',mode=stat.S_IFCHR|0o600,major=5,minor=1)
 busybox=Path('/usr/bin/busybox');assert 'INTERP' not in run('busybox-static',['/usr/bin/readelf','-l',busybox])
 add('bin/busybox',busybox.read_bytes(),stat.S_IFREG|0o755)
 for name in ['sh','mount','mkdir','cat','echo','uname','sync','poweroff','sleep','sha256sum','zcat']:
  add('bin/'+name,b'busybox',stat.S_IFLNK|0o777)
 for name in ['grant_probe','context_probe','basic_probe']:
  add(name,(WORK/name).read_bytes(),stat.S_IFREG|0o755)
 add('policy.bin',(WORK/'policy.bin').read_bytes())
 add('apparmor.bin',(WORK/'apparmor.bin').read_bytes())
 add('modules/binder-unsigned.ko',(OUT/'drivers/android/binder_linux.ko').read_bytes())
 add('modules/binder-tampered.ko',(WORK/'binder-tampered.ko').read_bytes())
 commands=[]
 for index,p in enumerate(modules):
  name='modules/'+str(index)+'-'+p.name;add(name,p.read_bytes());commands.append('/basic_probe module /'+name+' 0 || rc=1')
 init='''#!/bin/sh
PATH=/bin
export PATH
mount -t devtmpfs devtmpfs /dev || exit 91
exec >/dev/console 2>&1
mount -t proc proc /proc || exit 92
mount -t sysfs sysfs /sys || exit 93
mkdir -p /sys/kernel/security /sys/fs/selinux
mount -t securityfs securityfs /sys/kernel/security || exit 94
mount -t tmpfs -o mode=1777,nosuid,nodev tmpfs /tmp || exit 95
mode=none
nonce=none
for arg in $(cat /proc/cmdline); do
 case "$arg" in p4_mode=*) mode=${arg#p4_mode=};; p4_nonce=*) nonce=${arg#p4_nonce=};; esac
done
echo "P4VM_BEGIN $mode $nonce"
rc=0
/basic_probe module /modules/binder-unsigned.ko -129 || rc=1
/basic_probe module /modules/binder-tampered.ko -129 || rc=1
'''+ '\n'.join(commands)+'''
/basic_probe || rc=1
/basic_probe features || rc=1
zcat /proc/config.gz >/tmp/running-config || rc=1
echo "bccb147083a909408e25dc63f1dd58cf465ee19bcabc660916a1fa28cc67a3e1  /tmp/running-config" | sha256sum -c - || rc=1
if [ "$mode" = active ]; then
 mount -t selinuxfs selinuxfs /sys/fs/selinux || rc=1
 /basic_probe load /policy.bin /sys/fs/selinux/load || rc=1
 /basic_probe load /apparmor.bin /sys/kernel/security/apparmor/.load || rc=1
 echo secret >/tmp/secret
 echo aa-secret >/tmp/aa-secret
 /basic_probe label /tmp/secret user_u:object_r:secret_t || rc=1
fi
/grant_probe || rc=1
/context_probe "$mode" || rc=1
echo "P4VM_END $mode $nonce $rc"
sync
poweroff -f
sleep 3600
'''
 add('init',init.encode(),stat.S_IFREG|0o755)
 (WORK/'init').write_text(init)
 archive=bytearray();inventory=[]
 def entry(name,data,mode,major,minor,ino):
  fields=[ino,mode,0,0,1,0,len(data),0,0,major,minor,len(name.encode())+1,0]
  archive.extend(b'070701'+b''.join(f'{v:08x}'.encode() for v in fields))
  archive.extend(name.encode()+b'\0');archive.extend(b'\0'*((-len(archive))%4));archive.extend(data);archive.extend(b'\0'*((-len(archive))%4))
 for i,(name,(data,mode,major,minor)) in enumerate(entries.items(),1):
  entry(name,data,mode,major,minor,i);inventory.append({'path':name,'mode':mode,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'rdev':[major,minor]})
 entry('TRAILER!!!',b'',0,0,0,len(entries)+1)
 (WORK/'initramfs.cpio.gz').write_bytes(gzip.compress(archive,compresslevel=6,mtime=0))
 (WORK/'initramfs-files.json').write_text(json.dumps(inventory,sort_keys=True,indent=2)+'\n')
 report['initramfs']=digest(WORK/'initramfs.cpio.gz');report['initramfs_inventory']=digest(WORK/'initramfs-files.json')
 report['boot_firmware']=digest(DEPS/'usr/share/seabios/bios-256k.bin')
 report['qemu_library_inputs']=[]
 qlibs=run('qemu-libraries',['/usr/bin/ldd',DEPS/'usr/bin/qemu-system-x86_64'])
 assert 'not found' not in qlibs
 for line in qlibs.splitlines():
  paths=re.findall(r'(/[^\s()]+)',line)
  if paths:report['qemu_library_inputs'].append(digest(Path(paths[0]).resolve()))

if __name__=='__main__':
 try:main()
 except BaseException as e:
  report['error']=repr(e);report['failed_ns']=time.time_ns();save();raise
