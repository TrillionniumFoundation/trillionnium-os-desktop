// SPDX-License-Identifier: GPL-2.0-only
/* Deliberately narrow, opt-in, host-minted single-task mount namespace grant.
 * This is NOT a capability bypass for mount(), unshare(), setns() or clone().
 * Review candidate: not enabled, built, installed or runtime-qualified.
 */
#include <linux/anon_inodes.h>
#include <linux/capability.h>
#include <linux/compat.h>
#include <linux/cred.h>
#include <linux/file.h>
#include <linux/fs.h>
#include <linux/fs_struct.h>
#include <linux/init.h>
#include <linux/jiffies.h>
#include <linux/ktime.h>
#include <linux/miscdevice.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/mnt_namespace.h>
#include <linux/mutex.h>
#include <linux/nsproxy.h>
#include <linux/p4_guest_mntns.h>
#include <linux/perf_event.h>
#include <linux/pid.h>
#include <linux/pid_namespace.h>
#include <linux/proc_fs.h>
#include <linux/proc_ns.h>
#include <linux/sched/mm.h>
#include <linux/sched/signal.h>
#include <linux/sched/task.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/uaccess.h>
#include <linux/user_namespace.h>
#include <linux/workqueue.h>
#include <uapi/linux/p4_guest_mntns.h>

struct p4_mntns_grant {
	struct mutex lock;
	struct delayed_work expiry;
	bool spent;
	bool expired;
	u64 deadline_ns;
	u64 nonce[2];
	struct pid *pid;
	struct mm_struct *mm;         /* mmgrab: does NOT increment mm_users */
	const struct cred *cred;
	struct nsproxy *ns;
	struct pid_namespace *pid_ns;
	struct fs_struct *fs;         /* one explicitly counted users reference */
	unsigned int fs_seq;
	int fs_umask;
	struct path root, pwd;
	u64 mount_event;
};

/* The sole additional fs users reference prevents pointer ABA after unshare.
 * Normal fs users is one at MINT; while this grant is live it must be two.
 * Lock order matches exit_fs(): task_lock -> fs->seq. Never put under spinlock.
 */
static void p4_fs_put(struct fs_struct *fs)
{
	bool destroy;

	read_seqlock_excl(&fs->seq);
	destroy = !--fs->users;
	read_sequnlock_excl(&fs->seq);
	if (destroy)
		free_fs_struct(fs);
}

/* Called with grant mutex, or before the grant has been published. */
static void p4_drop_bindings(struct p4_mntns_grant *g)
{
	if (g->fs) {
		p4_fs_put(g->fs);
		g->fs = NULL;
	}
	if (g->root.mnt) {
		path_put(&g->root);
		g->root.mnt = NULL;
	}
	if (g->pwd.mnt) {
		path_put(&g->pwd);
		g->pwd.mnt = NULL;
	}
	if (g->ns) {
		put_nsproxy(g->ns);
		g->ns = NULL;
	}
	if (g->pid_ns) {
		put_pid_ns(g->pid_ns);
		g->pid_ns = NULL;
	}
	if (g->cred) {
		put_cred(g->cred);
		g->cred = NULL;
	}
	if (g->mm) {
		mmdrop(g->mm);
		g->mm = NULL;
	}
	if (g->pid) {
		put_pid(g->pid);
		g->pid = NULL;
	}
}

static void p4_expire(struct work_struct *work)
{
	struct p4_mntns_grant *g = container_of(to_delayed_work(work),
					struct p4_mntns_grant, expiry);

	mutex_lock(&g->lock);
	if (!g->spent) {
		g->spent = true;
		g->expired = true;
		p4_drop_bindings(g);
	}
	mutex_unlock(&g->lock);
}

static bool p4_no_admin(const struct cred *c)
{
	return !cap_raised(c->cap_effective, CAP_SYS_ADMIN) &&
	       !cap_raised(c->cap_permitted, CAP_SYS_ADMIN) &&
	       !cap_raised(c->cap_inheritable, CAP_SYS_ADMIN) &&
	       !cap_raised(c->cap_bset, CAP_SYS_ADMIN) &&
	       !cap_raised(c->cap_ambient, CAP_SYS_ADMIN);
}

static bool p4_single_task(struct task_struct *t)
{
	return thread_group_leader(t) && thread_group_empty(t) &&
	       !READ_ONCE(t->ptrace) && !(READ_ONCE(t->flags) & PF_EXITING);
}

static bool p4_namespace_fd(struct file *f, const struct ns_common *expected,
			    const struct proc_ns_operations *ops)
{
	struct ns_common *ns;

	if (!f || !proc_ns_file(f))
		return false;
	ns = get_proc_ns(file_inode(f));
	return ns == expected && ns->ops == ops;
}

static int p4_capture(struct p4_mntns_grant *g, struct task_struct *t,
		      struct file *user, struct file *mnt, struct file *pid)
{
	struct fs_struct *fs;
	int ret = -ESTALE;

	/* No sleeping operation while task_lock/fs seq are held. RCU protects the
	 * task credential load; its get reference pins pointer identity.
	 */
	task_lock(t);
	if (!p4_single_task(t) || !t->mm || !t->fs || !t->nsproxy ||
	    atomic_read(&t->mm->mm_users) != 1)
		goto unlock;
	g->cred = get_task_cred(t);
	if (g->cred->user_ns == &init_user_ns || !p4_no_admin(g->cred) ||
	    t->mm->user_ns != g->cred->user_ns ||
	    task_active_pid_ns(t) == &init_pid_ns ||
	    task_pid_nr_ns(t, task_active_pid_ns(t)) <= 1 ||
	    task_active_pid_ns(t)->user_ns != g->cred->user_ns ||
	    !p4_namespace_fd(user, &g->cred->user_ns->ns, &userns_operations) ||
	    !p4_namespace_fd(mnt, from_mnt_ns(t->nsproxy->mnt_ns), &mntns_operations) ||
	    !p4_namespace_fd(pid, &task_active_pid_ns(t)->ns, &pidns_operations))
		goto unlock;
	fs = t->fs;
	read_seqlock_excl(&fs->seq);
	if (fs->users != 1 || fs->in_exec) {
		read_sequnlock_excl(&fs->seq);
		goto unlock;
	}
	fs->users++;
	g->fs = fs;
	g->fs_seq = read_seqbegin(&fs->seq);
	g->fs_umask = fs->umask;
	g->root = fs->root;
	g->pwd = fs->pwd;
	path_get(&g->root);
	path_get(&g->pwd);
	read_sequnlock_excl(&fs->seq);
	g->mm = t->mm;
	mmgrab(g->mm);
	g->pid = get_pid(task_pid(t));
	g->pid_ns = get_pid_ns(task_active_pid_ns(t));
	g->ns = t->nsproxy;
	get_nsproxy(g->ns);
	ret = 0;
unlock:
	task_unlock(t);
	if (ret)
		return ret;
	return p4_mntns_snapshot(g->ns->mnt_ns, g->cred->user_ns,
				 &g->root, &g->pwd, &g->mount_event);
}

static int p4_validate_current(struct p4_mntns_grant *g)
{
	struct fs_struct *fs;
	bool same;

	if (ktime_get_boottime_ns() >= g->deadline_ns)
		return -ETIME;
	if (task_pid(current) != g->pid || current->mm != g->mm ||
	    current_cred() != g->cred || current_real_cred() != g->cred ||
	    current->nsproxy != g->ns || task_active_pid_ns(current) != g->pid_ns ||
	    current->fs != g->fs || !p4_single_task(current) ||
	    atomic_read(&current->mm->mm_users) != 1 || !p4_no_admin(current_cred()))
		return -ESTALE;
	fs = g->fs;
	read_seqlock_excl(&fs->seq);
	same = fs->users == 2 && !fs->in_exec &&
	       read_seqbegin(&fs->seq) == g->fs_seq && fs->umask == g->fs_umask &&
	       path_equal(&fs->root, &g->root) && path_equal(&fs->pwd, &g->pwd);
	read_sequnlock_excl(&fs->seq);
	return same ? 0 : -ESTALE;
}

static long p4_consume(struct file *file, unsigned int command, unsigned long arg)
{
	struct p4_mntns_grant *g = file->private_data;
	struct p4_guest_mntns_consume input;
	struct fs_struct *new_fs = NULL, *old_fs;
	struct nsproxy *new_ns = NULL;
	int ret;

	if (command != P4_GUEST_MNTNS_CONSUME)
		return -ENOTTY;
	/* No failure-prone user copies occur after the namespace commit. */
	if (copy_from_user(&input, (void __user *)arg, sizeof(input)))
		return -EFAULT;
	mutex_lock(&g->lock);
	if (g->spent) {
		ret = g->expired ? -ETIME : -EALREADY;
		goto unlock;
	}
	/* Even a wrong-recipient/nonce/ABI attempt burns this descriptor. */
	g->spent = true;
	if (input.abi != P4_GUEST_MNTNS_ABI || input.flags ||
	    memchr_inv(input.reserved, 0, sizeof(input.reserved)) ||
	    memcmp(input.nonce, g->nonce, sizeof(g->nonce))) {
		ret = -EINVAL;
		goto out;
	}
	ret = p4_validate_current(g);
	if (ret)
		goto out;
	new_fs = copy_fs_struct(g->fs);
	if (!new_fs) {
		ret = -ENOMEM;
		goto out;
	}
	new_ns = p4_copy_guest_nsproxy(new_fs, g->mount_event);
	if (IS_ERR(new_ns)) {
		ret = PTR_ERR(new_ns);
		new_ns = NULL;
		goto out;
	}
	/* Allocation and mount-copy time count toward the same fixed deadline. */
	ret = p4_validate_current(g);
	if (ret)
		goto out;
	/* Single thread, mm_users==1, exactly one task fs user. From this point
	 * there are no fallible operations. Order mirrors ksys_unshare().
	 */
	switch_task_namespaces(current, new_ns);
	new_ns = NULL;
	task_lock(current);
	old_fs = current->fs;
	read_seqlock_excl(&old_fs->seq);
	current->fs = new_fs;
	new_fs = NULL;
	old_fs->users--;             /* grant still owns the remaining reference */
	read_sequnlock_excl(&old_fs->seq);
	task_unlock(current);
	perf_event_namespaces(current);
	ret = 0;
out:
	/* A never-installed nsproxy owns the initial reference allocated by
	 * create_new_namespaces(). The fs has independent path references.
	 */
	if (new_ns)
		put_nsproxy(new_ns);
	if (new_fs)
		free_fs_struct(new_fs);
	p4_drop_bindings(g);
unlock:
	mutex_unlock(&g->lock);
	return ret;
}

static int p4_release(struct inode *inode, struct file *file)
{
	struct p4_mntns_grant *g = file->private_data;

	/* Worker never owns a file reference; release synchronously drains it. */
	cancel_delayed_work_sync(&g->expiry);
	mutex_lock(&g->lock);
	p4_drop_bindings(g);
	mutex_unlock(&g->lock);
	kfree(g);
	return 0;
}

static const struct file_operations p4_grant_fops = {
	.owner = THIS_MODULE,
	.unlocked_ioctl = p4_consume,
#ifdef CONFIG_COMPAT
	.compat_ioctl = compat_ptr_ioctl,
#endif
	.release = p4_release,
};

static long p4_mint(struct file *control, unsigned int command, unsigned long arg)
{
	struct p4_guest_mntns_mint input;
	struct p4_mntns_grant *g;
	struct task_struct *target;
	struct file *user = NULL, *mnt = NULL, *pid = NULL, *token;
	unsigned int pidfd_flags;
	int fd, ret;

	if (command != P4_GUEST_MNTNS_MINT)
		return -ENOTTY;
	if (current_user_ns() != &init_user_ns ||
	    !uid_eq(current_euid(), GLOBAL_ROOT_UID) ||
	    !ns_capable(&init_user_ns, CAP_SYS_ADMIN))
		return -EPERM;
	if (copy_from_user(&input, (void __user *)arg, sizeof(input)))
		return -EFAULT;
	if (input.abi != P4_GUEST_MNTNS_ABI || input.flags ||
	    !(input.nonce[0] | input.nonce[1]) ||
	    memchr_inv(input.reserved, 0, sizeof(input.reserved)) ||
	    input.target_pidfd < 0 || input.userns_fd < 0 ||
	    input.mountns_fd < 0 || input.pidns_fd < 0)
		return -EINVAL;
	target = pidfd_get_task(input.target_pidfd, &pidfd_flags);
	if (IS_ERR(target))
		return PTR_ERR(target);
	g = kzalloc(sizeof(*g), GFP_KERNEL);
	if (!g) {
		ret = -ENOMEM;
		goto put_task;
	}
	mutex_init(&g->lock);
	INIT_DELAYED_WORK(&g->expiry, p4_expire);
	g->deadline_ns = ktime_get_boottime_ns() + 5000ULL * NSEC_PER_MSEC;
	memcpy(g->nonce, input.nonce, sizeof(g->nonce));
	user = fget(input.userns_fd);
	mnt = fget(input.mountns_fd);
	pid = fget(input.pidns_fd);
	ret = p4_capture(g, target, user, mnt, pid);
	if (ret)
		goto destroy;
	if (ktime_get_boottime_ns() >= g->deadline_ns) {
		ret = -ETIME;
		goto destroy;
	}
	fd = get_unused_fd_flags(O_CLOEXEC);
	if (fd < 0) {
		ret = fd;
		goto destroy;
	}
	token = anon_inode_create_getfile("p4-guest-mntns", &p4_grant_fops,
					 g, O_RDWR | O_CLOEXEC, file_inode(control));
	if (IS_ERR(token)) {
		ret = PTR_ERR(token);
		put_unused_fd(fd);
		goto destroy;
	}
	if (ktime_get_boottime_ns() >= g->deadline_ns) {
		put_unused_fd(fd);
		fput(token); /* unpublished file owns g; release drains all refs */
		g = NULL;
		ret = -ETIME;
		goto destroy;
	}
	/* Set up expiry before fd_install makes this visible to shared fd users.
	 * Deadline checks are authoritative; delayed scheduling never extends it.
	 */
	schedule_delayed_work(&g->expiry,
		nsecs_to_jiffies(max_t(s64, 0, (s64)(g->deadline_ns -
			ktime_get_boottime_ns()))) + 1);
	fd_install(fd, token);
	ret = fd;
	g = NULL;
destroy:
	if (user)
		fput(user);
	if (mnt)
		fput(mnt);
	if (pid)
		fput(pid);
	if (g) {
		p4_drop_bindings(g);
		kfree(g);
	}
put_task:
	put_task_struct(target);
	return ret;
}

static const struct file_operations p4_control_fops = {
	.owner = THIS_MODULE,
	.unlocked_ioctl = p4_mint,
#ifdef CONFIG_COMPAT
	.compat_ioctl = compat_ptr_ioctl,
#endif
};

static struct miscdevice p4_control = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = "p4_guest_mntns",
	.fops = &p4_control_fops,
	.mode = 0600,
};

static int __init p4_guest_mntns_init(void)
{
	BUILD_BUG_ON(sizeof(struct p4_guest_mntns_mint) != 64);
	BUILD_BUG_ON(sizeof(struct p4_guest_mntns_consume) != 48);
	return misc_register(&p4_control);
}
device_initcall(p4_guest_mntns_init);
