// SPDX-License-Identifier: GPL-2.0
/*
 * Immutable representation selection for explicitly configured Android
 * objects. This does not select, disable, or bypass any LSM access check.
 */
#include <linux/atomic.h>
#include <linux/build_bug.h>
#include <linux/capability.h>
#include <linux/compat.h>
#include <linux/cred.h>
#include <linux/err.h>
#include <linux/export.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/miscdevice.h>
#include <linux/module.h>
#include <linux/p4_lsm_context.h>
#include <linux/uaccess.h>
#include <linux/user_namespace.h>
#include <net/net_namespace.h>
#include <uapi/linux/p4_lsm_context.h>

#define P4_STATE_ID_MASK 0xffffU
#define P4_STATE_FIXED   (1U << 16)
#define P4_STATE_USED    (1U << 17)

static_assert(sizeof(struct p4_lsm_netns) == 32);

int p4_lsm_context_validate(u32 lsmid)
{
	if (lsmid == LSM_ID_UNDEF)
		return 0;
	if (lsmid != LSM_ID_SELINUX)
		return -EINVAL;
	if (current_user_ns() != &init_user_ns ||
	    !ns_capable(&init_user_ns, CAP_SYS_ADMIN))
		return -EPERM;
	if (!p4_lsm_context_active(lsmid))
		return -EOPNOTSUPP;
	return 0;
}
EXPORT_SYMBOL_GPL(p4_lsm_context_validate);

/*
 * This RMW and SET's cmpxchg linearize the first userspace socket against
 * selection. Even a later protocol-create failure leaves the namespace
 * used; closing sockets cannot enable a retrospective provider change.
 * Kernel-internal sockets retain the historical default.
 */
u32 p4_lsm_context_new_socket(struct net *net, bool kern)
{
	if (kern)
		return LSM_ID_UNDEF;
	return atomic_fetch_or(P4_STATE_USED, &net->context_lsm_state) &
	       P4_STATE_ID_MASK;
}

/*
 * Derivation is also a use: a parent cannot be selected after a child has
 * captured its default. Children of a selected parent inherit its fixed
 * provider before per-net initialization and publication.
 */
void p4_lsm_context_copy_net(struct net *net, struct net *old_net)
{
	unsigned int state;

	state = atomic_fetch_or(P4_STATE_USED, &old_net->context_lsm_state);
	atomic_set(&net->context_lsm_state,
		   state & (P4_STATE_ID_MASK | P4_STATE_FIXED));
}

static long p4_lsm_context_ioctl(struct file *file, unsigned int cmd,
				 unsigned long arg)
{
	struct p4_lsm_netns req;
	struct net *net;
	unsigned int state;
	long ret;

	if (cmd != P4_LSM_NETNS_SET && cmd != P4_LSM_NETNS_GET)
		return -ENOTTY;
	if (current_user_ns() != &init_user_ns ||
	    !ns_capable(&init_user_ns, CAP_SYS_ADMIN))
		return -EPERM;
	if (copy_from_user(&req, (void __user *)arg, sizeof(req)))
		return -EFAULT;
	if (req.size != sizeof(req) || req.version != P4_LSM_CONTEXT_ABI ||
	    req.flags || req.reserved || !req.expected_ns_inum ||
	    req.netns_fd < 0)
		return -EINVAL;
	if ((cmd == P4_LSM_NETNS_SET && req.lsm_id != LSM_ID_SELINUX) ||
	    (cmd == P4_LSM_NETNS_GET && req.lsm_id != LSM_ID_UNDEF))
		return -EINVAL;

	net = get_net_ns_by_fd(req.netns_fd);
	if (IS_ERR(net))
		return PTR_ERR(net);
	if (req.expected_ns_inum != net->ns.inum) {
		ret = -ESTALE;
		goto out;
	}

	if (cmd == P4_LSM_NETNS_SET) {
		if (net_eq(net, &init_net) || net->user_ns == &init_user_ns) {
			ret = -EPERM;
			goto out;
		}
		ret = p4_lsm_context_validate(req.lsm_id);
		if (ret)
			goto out;
		state = atomic_cmpxchg(&net->context_lsm_state, 0,
				       P4_STATE_FIXED | req.lsm_id);
		ret = state ? -EBUSY : 0;
	} else {
		state = atomic_read(&net->context_lsm_state);
		req.lsm_id = state & P4_STATE_ID_MASK;
		req.flags = (state & P4_STATE_FIXED ? P4_LSM_NETNS_FIXED : 0) |
			    (state & P4_STATE_USED ? P4_LSM_NETNS_USED : 0);
		ret = copy_to_user((void __user *)arg, &req, sizeof(req)) ?
		      -EFAULT : 0;
	}
out:
	put_net(net);
	return ret;
}

static const struct file_operations p4_lsm_context_fops = {
	.owner = THIS_MODULE,
	.unlocked_ioctl = p4_lsm_context_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl = compat_ptr_ioctl,
#endif
	.open = nonseekable_open,
};

static struct miscdevice p4_lsm_context_device = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = "p4_lsm_context",
	.fops = &p4_lsm_context_fops,
	.mode = 0600,
};

static int __init p4_lsm_context_init(void)
{
	return misc_register(&p4_lsm_context_device);
}
device_initcall(p4_lsm_context_init);
