/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _UAPI_LINUX_P4_GUEST_MNTNS_H
#define _UAPI_LINUX_P4_GUEST_MNTNS_H
#include <linux/ioctl.h>
#include <linux/types.h>

#define P4_GUEST_MNTNS_ABI 1U
#define P4_GUEST_MNTNS_LIFETIME_MS 5000U

/* All descriptors are looked up in the initial-userns issuer's fd table.
 * No PID, path, capability mask, propagation flag or timeout is accepted.
 * MINT returns one CLOEXEC descriptor as its nonnegative ioctl result.
 */
struct p4_guest_mntns_mint {
	__u32 abi;
	__u32 flags;                  /* zero */
	__s32 target_pidfd;
	__s32 userns_fd;
	__s32 mountns_fd;
	__s32 pidns_fd;
	__u64 nonce[2];               /* nonzero issuer nonce */
	__u64 reserved[3];            /* zero */
};

struct p4_guest_mntns_consume {
	__u32 abi;
	__u32 flags;                  /* zero */
	__u64 nonce[2];
	__u64 reserved[3];            /* zero */
};

#define P4_GUEST_MNTNS_MINT _IOW(0xb8, 0x70, struct p4_guest_mntns_mint)
#define P4_GUEST_MNTNS_CONSUME _IOW(0xb8, 0x71, struct p4_guest_mntns_consume)
#endif
