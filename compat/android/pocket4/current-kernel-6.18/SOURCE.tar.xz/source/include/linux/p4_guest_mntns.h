/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef _LINUX_P4_GUEST_MNTNS_H
#define _LINUX_P4_GUEST_MNTNS_H
#include <linux/types.h>
struct fs_struct;
struct mnt_namespace;
struct nsproxy;
struct path;
struct user_namespace;

#ifdef CONFIG_P4_GUEST_MNTNS
int p4_mntns_snapshot(struct mnt_namespace *ns, struct user_namespace *owner,
		     const struct path *root, const struct path *pwd, u64 *event);
struct mnt_namespace *p4_copy_private_mntns(struct mnt_namespace *old,
		struct user_namespace *owner, struct fs_struct *new_fs, u64 event);
struct nsproxy *p4_copy_guest_nsproxy(struct fs_struct *new_fs, u64 event);
#endif
#endif
