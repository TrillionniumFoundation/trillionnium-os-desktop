/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _LINUX_P4_LSM_CONTEXT_H
#define _LINUX_P4_LSM_CONTEXT_H

#include <linux/errno.h>
#include <linux/types.h>
#include <uapi/linux/lsm.h>

struct net;

#ifdef CONFIG_P4_LSM_CONTEXT
bool p4_lsm_context_active(u64 lsmid);
int p4_lsm_context_validate(u32 lsmid);
u32 p4_lsm_context_new_socket(struct net *net, bool kern);
void p4_lsm_context_copy_net(struct net *net, struct net *old_net);
#else
static inline int p4_lsm_context_validate(u32 lsmid)
{
	return lsmid == LSM_ID_UNDEF ? 0 : -EOPNOTSUPP;
}

static inline u32 p4_lsm_context_new_socket(struct net *net, bool kern)
{
	return LSM_ID_UNDEF;
}

static inline void p4_lsm_context_copy_net(struct net *net, struct net *old_net)
{
}
#endif

#endif /* _LINUX_P4_LSM_CONTEXT_H */
