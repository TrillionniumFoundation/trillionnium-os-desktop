import os,sys,stat,json,pathlib,hashlib,subprocess,time,resource
BASE=pathlib.Path('/home/qq/work/p4-vendor-source-fix-20261118-162b-r1')
CTL=BASE/'control'
OLD=pathlib.Path('/home/qq/work/pocket4-native-source597-ai395-20261108-8b88-r1/work/aosp-source/frameworks/libs/binary_translation')
UP=BASE/'teto-917021cf3ecd077eb1581146a79d2265011755b8'
NEW=BASE/'teto-engine-source-r1'
PIN='917021cf3ecd077eb1581146a79d2265011755b8'
TREE='5e2d7e1577a7bb03917fee7b2ad66b72d09bff85'
URL='https://github.com/denialwm/teto.git'
os.umask(0o077)
os.sched_setaffinity(0,{20})
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
def f9(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def save(name,obj):
 data=(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode()
 p=CTL/name
 with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'identity':f9(p.stat())}
def inv(root):
 rows={}
 for parent,dirs,files in os.walk(root,followlinks=False):
  dirs[:]=sorted(x for x in dirs if x!='.git')
  for name in sorted(list(dirs)+files):
   if name=='.git':continue
   p=pathlib.Path(parent)/name;s=p.lstat()
   if stat.S_ISDIR(s.st_mode):continue
   rel=str(p.relative_to(root))
   if stat.S_ISREG(s.st_mode):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
     a=os.fstat(fd);data=b''
     with os.fdopen(fd,'rb',closefd=False) as h:data=h.read()
     z=os.fstat(fd)
     assert f9(a)==f9(z)==f9(s),('unstable member',rel)
    finally:os.close(fd)
    row={'kind':'file','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'git_mode':'100755' if s.st_mode&0o111 else '100644','mode':stat.S_IMODE(s.st_mode),'identity':f9(s)}
   elif stat.S_ISLNK(s.st_mode):
    target=os.readlink(p);data=os.fsencode(target)
    assert p.resolve(strict=True).is_relative_to(root.resolve()),('escaping link',rel)
    assert f9(s)==f9(p.lstat())
    row={'kind':'symlink','bytes':len(data),'target':target,'sha256':hashlib.sha256(data).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'git_mode':'120000','mode':stat.S_IMODE(s.st_mode),'identity':f9(s)}
   else:raise RuntimeError(('special object',rel))
   rows[rel]=row
 return dict(sorted(rows.items()))
def comparable(rows):
 return {p:{k:v for k,v in r.items() if k!='identity'} for p,r in rows.items()}
def semantic(rows):
 return {p:{k:v for k,v in r.items() if k not in ['identity','mode']} for p,r in rows.items()}
commands=[]
env=dict(os.environ,GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0',LC_ALL='C')
def run(args,expect=0):
 n=len(commands);t=time.time_ns()
 r=subprocess.run(args,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
 out=CTL/f'snapshot-cmd-{n}.stdout';err=CTL/f'snapshot-cmd-{n}.stderr'
 for p,data in [(out,r.stdout),(err,r.stderr)]:
  with p.open('xb') as f:f.write(data)
 commands.append({'argv':args,'exit':r.returncode,'start_ns':t,'end_ns':time.time_ns(),'stdout':{'path':str(out),'bytes':len(r.stdout),'sha256':hashlib.sha256(r.stdout).hexdigest()},'stderr':{'path':str(err),'bytes':len(r.stderr),'sha256':hashlib.sha256(r.stderr).hexdigest()}})
 assert r.returncode==expect,(args,r.returncode,r.stderr[-1000:])
 return r.stdout
def git(root,*args):return run(['/usr/bin/git','-c','core.hooksPath=/dev/null','-C',str(root),*args])
start=time.time_ns()
mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert mem>=24*1024**3,mem
assert not NEW.exists()
raw=(CTL/'source-preparation-receipt.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='80ada6d9c5385c19ecd3e3743d1ae0559455f0df688d9b568a0ccab6f7b38704'
previous=json.loads((CTL/'original-export-before.json').read_bytes())
old=inv(OLD);assert old==previous,'original export changed'
up=inv(UP)
verified=json.loads((CTL/'verified-git-members.json').read_bytes())
assert up==verified['files'],'upstream checkout changed'
assert git(UP,'rev-parse','HEAD').decode().strip()==PIN
assert git(UP,'rev-parse','HEAD^{tree}').decode().strip()==TREE
run(['/usr/bin/git','-c','core.hooksPath=/dev/null','clone','--no-hardlinks','--no-checkout','--quiet',str(UP),str(NEW)])
git(NEW,'remote','set-url','origin',URL)
git(NEW,'checkout','--detach','--quiet',PIN)
assert semantic(inv(NEW))==semantic(up)
run(['/usr/bin/rsync','-a','--checksum','--no-times','--delete','--exclude','.git',str(OLD)+'/',str(NEW)])
new=inv(NEW)
assert comparable(new)==comparable(old),'copied full bytes/mode/link mismatch'
assert inv(OLD)==old,'original changed during copy'
changed=[{'path':p,'base':semantic(up)[p],'snapshot':semantic(old)[p]} for p in sorted(up.keys()&old.keys()) if semantic(up)[p]!=semantic(old)[p]]
extra=[{'path':p,'snapshot':semantic(old)[p]} for p in sorted(old.keys()-up.keys())]
missing=sorted(up.keys()-old.keys())
assert len(changed)==30 and len(extra)==24 and not missing
before_status=git(NEW,'status','--porcelain=v1','--untracked-files=all').decode()
git(NEW,'add','--all')
patch=git(NEW,'diff','--cached','--binary','--full-index',PIN)
patch_path=BASE/'existing-engine-fixes.patch'
with patch_path.open('xb') as f:f.write(patch)
# A real child commit records the exact previously observed worktree; it does not
# attribute upstream authorship or claim those changes are upstream.
run(['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','user.name=Pocket4 source snapshot','-c','user.email=pocket4-source-snapshot@localhost','-C',str(NEW),'commit','--no-gpg-sign','--quiet','-m','Record observed Pocket4 native engine worktree','-m','Exact copy of the retired build input, including existing engine fixes. Upstream base: '+PIN+'. No new functional source changes.'])
head=git(NEW,'rev-parse','HEAD').decode().strip()
tree=git(NEW,'rev-parse','HEAD^{tree}').decode().strip()
assert git(NEW,'rev-parse','HEAD^').decode().strip()==PIN
git(NEW,'merge-base','--is-ancestor',PIN,'HEAD')
assert git(NEW,'status','--porcelain=v1','--untracked-files=all')==b''
assert git(NEW,'remote','get-url','origin').decode().strip()==URL
git(NEW,'fsck','--strict','--no-reflogs')
members={}
for line in git(NEW,'ls-tree','-rz','--full-tree','HEAD').split(b'\0'):
 if not line:continue
 meta,path=line.split(b'\t',1);mode,kind,oid=meta.decode().split()
 assert kind=='blob'
 members[os.fsdecode(path)]={'mode':mode,'oid':oid}
assert members=={p:{'mode':r['git_mode'],'oid':r['git_blob_sha1']} for p,r in new.items()},'real child tree mismatch'
final=inv(NEW)
assert comparable(final)==comparable(old)
assert inv(OLD)==old and inv(UP)==up
manifest=save('engine-snapshot-members.json',{'schema':1,'origin':URL,'upstream_commit':PIN,'upstream_tree':TREE,'commit':head,'tree':tree,'parent':PIN,'files':final,'git_members':members,'source_export':str(OLD),'source_export_before':old})
diff=save('engine-snapshot-differences.json',{'schema':1,'content_or_git_mode_changed':changed,'added':extra,'removed':missing,'non_git_permission_difference_count':sum(up[p]['mode']!=old[p]['mode'] for p in up.keys()&old.keys()),'note':'The permission count records the clone umask and is not a content difference.','patch':{'path':str(patch_path),'bytes':len(patch),'sha256':hashlib.sha256(patch).hexdigest()},'initial_working_status':before_status})
receipt=save('engine-snapshot-receipt.json',{'schema':1,'prepared':True,'normal_parameter':'DROIDLOOM_NATIVE_BRIDGE_SOURCE','normal_source_path':str(NEW),'origin':URL,'upstream_commit':PIN,'upstream_tree':TREE,'commit':head,'tree':tree,'parent':PIN,'clean_git_status':True,'manifest':manifest,'differences':diff,'commands':commands,'member_count':len(final),'modified_count':len(changed),'added_count':len(extra),'removed_count':len(missing),'original_export_bookends_unchanged':True,'upstream_bookends_unchanged':True,'source_export_modified':False,'source_semantics_requalified':False,'normal_prepare_function_tested':False,'full_vendor_build_passed':False,'production_runtime_qualified':False,'started_ns':start,'finished_ns':time.time_ns(),'fresh_mem_available':mem})
print(json.dumps({'receipt':receipt,'commit':head,'tree':tree,'members':len(final),'changes':len(changed),'added':len(extra),'normal_source_path':str(NEW)},sort_keys=True))
