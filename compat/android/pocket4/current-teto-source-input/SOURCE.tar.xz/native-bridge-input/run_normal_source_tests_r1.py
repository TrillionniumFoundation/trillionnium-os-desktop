import os,sys,stat,json,pathlib,hashlib,subprocess,time,shutil,signal,tomllib,traceback
BASE=pathlib.Path('/home/qq/work/p4-vendor-source-fix-20261118-162b-r1')
CTL=BASE/'control'
ORIG=pathlib.Path('/home/qq/work/p4-official-vendor-cp3a-20261118-162b-r1/producer')
SHARED=pathlib.Path('/home/qq/work/p4-runtime-continuation-20261118-162b-r1')
REPO=BASE/'producer-test-r1'
CARGO=BASE/'cargo-home-r1'
TARGET=BASE/'target-test-r1'
LOCAL=BASE/'teto-engine-source-r1'
OLD=pathlib.Path('/home/qq/work/pocket4-native-source597-ai395-20261108-8b88-r1/work/aosp-source/frameworks/libs/binary_translation')
start=time.time_ns();deadline=time.monotonic()+1720
os.umask(0o077)
def f9(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def file(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode)
 h=hashlib.sha256()
 with p.open('rb') as f:
  a=os.fstat(f.fileno());assert f9(a)==f9(s)
  while True:
   b=f.read(1048576)
   if not b:break
   h.update(b)
  assert f9(os.fstat(f.fileno()))==f9(s)
 return {'path':str(p),'bytes':s.st_size,'sha256':h.hexdigest(),'identity':f9(s)}
def save(name,obj):
 p=CTL/name
 with p.open('x') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
 return file(p)
def member_bookend(root,rows):
 actual=set()
 for parent,dirs,files in os.walk(root,followlinks=False):
  dirs[:]=sorted(x for x in dirs if x!='.git')
  for name in sorted(dirs+files):
   if name=='.git':continue
   p=pathlib.Path(parent)/name;s=p.lstat()
   if stat.S_ISDIR(s.st_mode):continue
   relative=str(p.relative_to(root));actual.add(relative);r=rows[relative]
   assert f9(s)==r['identity'],('member identity changed',relative)
   if stat.S_ISREG(s.st_mode):assert file(p)['sha256']==r['sha256']
   else:assert stat.S_ISLNK(s.st_mode) and os.readlink(p)==r['target']
 assert actual==set(rows)
def source_inventory(root):
 result={}
 for parent,dirs,files in os.walk(root,followlinks=False):
  dirs[:]=sorted(x for x in dirs if x not in ['.git','.work','target'])
  for name in sorted(dirs+files):
   p=pathlib.Path(parent)/name;s=p.lstat()
   if stat.S_ISDIR(s.st_mode):continue
   relative=str(p.relative_to(root))
   if stat.S_ISREG(s.st_mode):result[relative]=file(p)
   elif stat.S_ISLNK(s.st_mode):result[relative]={'identity':f9(s),'target':os.readlink(p)}
   else:raise RuntimeError(('special producer member',relative))
 return result
def cmp_inv(rows):return {p:{k:v for k,v in r.items() if k not in ['path','identity']} for p,r in rows.items()}
commands=[]
env=dict(os.environ)
env.update(PATH=str(SHARED/'rust-1.93.0/bin')+':/usr/bin:/bin',CARGO_HOME=str(CARGO),CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',DROIDLOOM_NATIVE_BRIDGE_SOURCE=str(LOCAL),P4_TEST_REPO=str(REPO),GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0')
for k in ['RUSTC','RUSTFLAGS','RUST_MIN_STACK','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']:env.pop(k,None)
def run(argv,name):
 remaining=deadline-time.monotonic()
 assert remaining>10
 out=CTL/(name+'.stdout');err=CTL/(name+'.stderr')
 with out.open('xb') as o,err.open('xb') as e:
  p=subprocess.Popen(argv,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=o,stderr=e,start_new_session=True)
  while p.poll() is None:
   if time.monotonic()>=deadline or shutil.disk_usage(BASE).free<24*1024**3:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise RuntimeError('bounded test deadline or disk floor reached')
   time.sleep(1)
  rc=p.wait()
 r={'argv':argv,'exit':rc,'stdout':file(out),'stderr':file(err)}
 commands.append(r);print(json.dumps({'test_command':name,'exit':rc,'stdout_bytes':r['stdout']['bytes'],'stderr_bytes':r['stderr']['bytes']}),flush=True)
 assert rc==0,(name,rc)
 return r
report={'schema':1,'started_ns':start,'source_changes_shipped':False,'production_runtime_qualified':False,'full_vendor_build_passed':False}
try:
 mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 assert mem>=24*1024**3,mem
 cg_rel=next(x.split(':',2)[2] for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::'))
 cg=pathlib.Path('/sys/fs/cgroup')/cg_rel.lstrip('/')
 limits={n:(cg/n).read_text().strip() for n in ['memory.max','memory.high','memory.swap.max','cpu.max','pids.max']}
 assert limits['memory.max']=='4294967296' and limits['memory.swap.max']=='0' and limits['cpu.max'].split()[0]=='200000',limits
 assert os.sched_getaffinity(0)=={20,21}
 report['admission']={'mem_available':mem,'free_bytes':shutil.disk_usage(BASE).free,'cgroup':str(cg),'limits':limits,'affinity':sorted(os.sched_getaffinity(0))}
 assert not REPO.exists() and not CARGO.exists() and not TARGET.exists()
 expected=json.loads((CTL/'engine-snapshot-members.json').read_bytes())
 member_bookend(LOCAL,expected['files']);member_bookend(OLD,expected['source_export_before'])
 before=source_inventory(ORIG)
 assert before['tools/droidloom-update/src/native_bridge.rs']['sha256']=='301378540ea1ba4bbe794540906dfb601583ecc4c484444c9129be4cee3b0a85'
 report['production_sources_before']=save('producer-test-inputs-before.json',before)
 shutil.copytree(ORIG,REPO,symlinks=True,ignore=shutil.ignore_patterns('.git','.work','target'))
 copied=source_inventory(REPO)
 assert cmp_inv(copied)==cmp_inv(before)
 CARGO.mkdir()
 shutil.copytree(SHARED/'cargo-home/registry',CARGO/'registry',symlinks=True)
 lock=tomllib.loads((REPO/'Cargo.lock').read_text())
 checked=[]
 for p in lock['package']:
  if not p.get('source','').startswith('registry+'):continue
  found=list((CARGO/'registry/cache').glob('*/'+p['name']+'-'+p['version']+'.crate'))
  assert len(found)==1,(p['name'],len(found))
  r=file(found[0]);assert r['sha256']==p['checksum'],p['name'];checked.append(r)
 report['private_crates']=save('private-cargo-crate-inputs.json',checked)
 report['rustc']=file(SHARED/'rust-1.93.0/bin/rustc')
 report['cargo']=file(SHARED/'rust-1.93.0/bin/cargo')
 test=(BASE/'actual_normal_source_test.rs').read_bytes()
 p=REPO/'tools/droidloom-update/src/native_bridge.rs'
 with p.open('ab') as f:f.write(test)
 report['test_only_append']=file(BASE/'actual_normal_source_test.rs')
 report['instrumented_native_bridge']=file(p)
 print(json.dumps({'prepared':True,'producer_members':len(before),'private_crates':len(checked),'normal_input':str(LOCAL)}),flush=True)
 run([str(SHARED/'rust-1.93.0/bin/cargo'),'test','--locked','--offline','-j','2','-p','droidloom-update','--bin','droidloom-update','native_bridge::','--','--test-threads=1','--nocapture'],'native-bridge-source-tests')
 result=file(CTL/'actual-normal-source-snapshot.json')
 snapshot=json.loads((CTL/'actual-normal-source-snapshot.json').read_bytes())
 assert snapshot['commit']=='9587399bccdbb7ec6f7de3edd3452609b974eb7c'
 assert snapshot['base_commit']=='917021cf3ecd077eb1581146a79d2265011755b8' and snapshot['working_tree'] is True
 assert len(snapshot['files'])==926
 member_bookend(LOCAL,expected['files']);member_bookend(OLD,expected['source_export_before'])
 assert source_inventory(ORIG)==before
 report.update(passed=True,actual_prepare_source_passed=True,source_export_bookends_unchanged=True,local_git_input_bookends_unchanged=True,production_source_bookends_unchanged=True,actual_snapshot=result)
except BaseException as e:
 report.update(passed=False,error=repr(e),traceback=traceback.format_exc())
finally:
 report['commands']=commands;report['finished_ns']=time.time_ns()
 receipt=save('normal-source-test-receipt.json',report)
 print(json.dumps({'receipt':receipt,'passed':report.get('passed',False)}),flush=True)
sys.exit(0 if report.get('passed') else 1)
