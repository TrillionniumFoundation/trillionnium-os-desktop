
#[cfg(test)]
mod pocket4_actual_source_input {
    use super::*;
    use std::io::Write;
    use std::os::unix::fs::MetadataExt;
    #[test]
    fn actual_repaired_source_uses_unchanged_normal_prepare() {
        let base = PathBuf::from("/home/qq/work/p4-vendor-source-fix-20261118-162b-r1");
        let local = base.join("teto-engine-source-r1");
        assert_eq!(std::env::var_os("DROIDLOOM_NATIVE_BRIDGE_SOURCE").unwrap(), local.as_os_str());
        let manifest: serde_json::Value = serde_json::from_slice(
            &fs::read(base.join("control/engine-snapshot-members.json")).unwrap()).unwrap();
        let source = base.join("normal-import-fixture-r1");
        fs::create_dir(&source).unwrap();
        let repo = PathBuf::from(std::env::var_os("P4_TEST_REPO").unwrap());
        let before = source_inventory(&local).unwrap();
        assert_eq!(before.len(), 926);
        let snapshot = prepare_source(&repo, &source).unwrap();
        assert_eq!(snapshot["working_tree"], true);
        assert_eq!(snapshot["base_commit"], "917021cf3ecd077eb1581146a79d2265011755b8");
        assert_eq!(snapshot["commit"], "9587399bccdbb7ec6f7de3edd3452609b974eb7c");
        assert_eq!(snapshot["files"].as_object().unwrap().len(), 926);
        let imported = source.join("frameworks/libs/binary_translation");
        assert_eq!(source_inventory(&imported).unwrap(), before);
        assert_eq!(source_inventory(&local).unwrap(), before);
        assert!(fs::symlink_metadata(imported.join(".git")).is_err());
        for (relative, row) in manifest["files"].as_object().unwrap() {
            let p = imported.join(relative);
            let m = fs::symlink_metadata(&p).unwrap();
            assert_eq!(u64::from(m.mode() & 0o7777), row["mode"].as_u64().unwrap(), "{relative}");
            if row["kind"] == "symlink" {
                assert!(m.file_type().is_symlink(), "{relative}");
                assert_eq!(fs::read_link(&p).unwrap().to_string_lossy(), row["target"].as_str().unwrap(), "{relative}");
            } else {
                assert!(m.is_file(), "{relative}");
                assert_eq!(hash(&p).unwrap(), row["sha256"].as_str().unwrap(), "{relative}");
                assert_eq!(m.len(), row["bytes"].as_u64().unwrap(), "{relative}");
            }
        }
        let mut f = fs::OpenOptions::new().write(true).create_new(true)
            .open(base.join("control/actual-normal-source-snapshot.json")).unwrap();
        f.write_all(&serde_json::to_vec_pretty(&snapshot).unwrap()).unwrap();
        f.sync_all().unwrap();
    }
}
