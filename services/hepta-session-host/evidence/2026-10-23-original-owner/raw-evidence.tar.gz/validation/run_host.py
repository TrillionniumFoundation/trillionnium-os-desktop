#!/usr/bin/env python3
"""Run the real pinned host graph with source identities and bounded resources."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import tomllib

ROOT = Path(__file__).resolve().parents[1]
VALIDATION = ROOT / "validation"
DESKTOP = ROOT / "desktop"
HOST = DESKTOP / "services/hepta-session-host"
HEPTA_CACHE = Path("/dev/shm/organ-3d6a75235bcb-hepta3398")
TARGET = HEPTA_CACHE / "target"
TOOLCHAIN = Path("/tmp/hepta-native-rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin")


def identity():
    result = {}
    for folder in ("ui", "services/hepta-os", "services/hepta-session-host", "libs/os-abi"):
        for path in sorted((DESKTOP / folder).rglob("*")):
            if path.is_file() and (path.suffix in (".rs", ".toml", ".json") or path.name == "Cargo.lock"):
                data = path.read_bytes()
                result[path.relative_to(DESKTOP).as_posix()] = {
                    "sha256": hashlib.sha256(data).hexdigest(),
                    "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
                    "bytes": len(data),
                }
    return result


def resources():
    available = next(int(line.split()[1]) * 1024 for line in Path("/proc/meminfo").read_text().splitlines() if line.startswith("MemAvailable:"))
    return {
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "memory_available_bytes": available,
        "shm_free_bytes": shutil.disk_usage(HEPTA_CACHE).free,
        "target_apparent_bytes": int(subprocess.check_output(["du", "-sb", str(TARGET)], text=True).split()[0]),
    }


def main():
    stage, name = sys.argv[1:]
    assert name.replace("-", "").isalnum()
    prefix = VALIDATION / name
    assert not prefix.with_suffix(".json").exists(), "Do not overwrite an execution receipt."
    manifest = tomllib.loads((HOST / "Cargo.toml").read_text())
    original = manifest["dependencies"]["codex-hepta-memory"]
    assert original["git"] == "https://github.com/TrillionniumFoundation/hepta-private-ci"
    assert len(original["rev"]) == 40 and "path" not in original
    assert not manifest.get("patch")
    args = ["--manifest-path", str(HOST / "Cargo.toml"), "--locked", "--all-targets", "--profile", "dev-small", "--jobs", "1"]
    if stage == "test":
        command = [str(TOOLCHAIN / "cargo"), "test", *args, "--", "--test-threads=1"]
    elif stage == "red-recovery":
        command = [str(TOOLCHAIN / "cargo"), "test", *args, "recovered_", "--", "--test-threads=1", "--nocapture"]
    elif stage == "format-check":
        command = [str(TOOLCHAIN / "cargo"), "fmt", "--manifest-path", str(HOST / "Cargo.toml"), "--package", "hepta-session-host", "--", "--check"]
    elif stage == "clippy":
        command = [str(TOOLCHAIN / "cargo"), "clippy", *args, "--", "-D", "warnings"]
    else:
        raise ValueError(stage)
    env = os.environ.copy()
    overrides = {
        "CARGO_HOME": str(HEPTA_CACHE / "cargo-home"),
        "CARGO_TARGET_DIR": str(TARGET),
        "RUSTC": str(TOOLCHAIN / "rustc"),
        "RUSTDOC": str(TOOLCHAIN / "rustdoc"),
        "RUSTUP_HOME": "/tmp/hepta-native-rustup",
        "RUSTUP_TOOLCHAIN": "1.95.0",
        "RUSTUP_AUTO_INSTALL": "0",
        "CARGO_INCREMENTAL": "0",
        "CARGO_BUILD_JOBS": "1",
        "CARGO_HTTP_TIMEOUT": "30",
        "CARGO_NET_RETRY": "1",
        "CARGO_NET_GIT_FETCH_WITH_CLI": "true",
        "GIT_TERMINAL_PROMPT": "0",
        "OPENSSL_INCLUDE_DIR": "/usr/include",
        "OPENSSL_LIB_DIR": "/usr/lib/x86_64-linux-gnu",
        "TMPDIR": str(HEPTA_CACHE / "tmp"),
    }
    env.update(overrides)
    env["PATH"] = str(ROOT.parent / "shared-presenter/probes/git-bin") + ":" + str(TOOLCHAIN) + ":" + env.get("PATH", "")
    before = identity()
    tools = {}
    for binary in ("rustc", "cargo"):
        run = subprocess.run([str(TOOLCHAIN / binary), "-Vv"], env=env, text=True, capture_output=True)
        tools[binary] = {"exit_code": run.returncode, "stdout": run.stdout, "stderr": run.stderr}
    measurements = [resources()]
    assert measurements[0]["memory_available_bytes"] >= 1536 * 1024 * 1024
    assert measurements[0]["shm_free_bytes"] >= 256 * 1024 * 1024
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stopped = None
    with prefix.with_suffix(".stdout").open("w") as stdout, prefix.with_suffix(".stderr").open("w") as stderr:
        process = subprocess.Popen(command, cwd=DESKTOP, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        print(json.dumps({"command": command, "original_git_pin": original["rev"], "initial_resources": measurements[0]}), flush=True)
        last = time.monotonic()
        while process.poll() is None:
            time.sleep(1)
            if time.monotonic() - last < 10:
                continue
            last = time.monotonic()
            sample = resources()
            measurements.append(sample)
            print(json.dumps(sample), flush=True)
            if sample["memory_available_bytes"] < 1536 * 1024 * 1024:
                stopped = "Available memory fell below the coordinated 1.5 GiB boundary."
            elif sample["shm_free_bytes"] < 256 * 1024 * 1024:
                stopped = "Shared-memory capacity fell below the coordinated 256 MiB boundary."
            if stopped:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                break
        code = process.wait()
    after = identity()
    receipt = {
        "command": command,
        "original_git_pin": original["rev"],
        "started_at": started,
        "finished_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "environment_overrides": overrides,
        "tool_versions": tools,
        "exit_code": code,
        "controlled_stop_reason": stopped,
        "resources": measurements + [resources()],
        "source_before": before,
        "source_after": after,
        "source_unchanged": before == after,
        "graph_scope": "New legitimate host Cargo graph, with exact original Git packages; not an execution of the original Hepta workspace's separate Cargo.lock.",
    }
    for suffix in ("stdout", "stderr"):
        data = prefix.with_suffix("." + suffix).read_bytes()
        receipt[suffix + "_file"] = prefix.with_suffix("." + suffix).name
        receipt[suffix + "_sha256"] = hashlib.sha256(data).hexdigest()
    prefix.with_suffix(".json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"receipt": str(prefix.with_suffix(".json")), "exit_code": code, "controlled_stop_reason": stopped, "source_unchanged": before == after, "stderr_tail": prefix.with_suffix(".stderr").read_text()[-6000:]}), flush=True)
    if stopped:
        return 130
    if before != after:
        return 3
    return code if code >= 0 else 128 - code


if __name__ == "__main__":
    raise SystemExit(main())
