#!/usr/bin/env python3
"""Resolve the actual Git-pinned owner; no patched or vendored replacement."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tomllib

ROOT=Path(__file__).resolve().parents[1]
DESKTOP=ROOT/'desktop'
HOST=DESKTOP/'services/hepta-session-host'
TASK=Path('/dev/shm/organ-3d6a75235bcb-hepta3398')
TOOL=Path('/tmp/hepta-native-rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
URL='https://github.com/TrillionniumFoundation/hepta-private-ci'

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    revision=sys.argv[1]
    assert re.fullmatch('[0-9a-f]{40}',revision)
    prefix=ROOT/'validation/git-host-resolution'
    assert not prefix.with_suffix('.json').exists(), 'Do not overwrite an execution receipt.'
    template=(HOST/'Cargo.toml').read_text()
    for package in ('memory','contracts','paths'):
        old=f'codex-hepta-{package} = {{ path = "/dev/shm/organ-3d6a75235bcb-hepta3398/source/codex-rs/hepta-{package}" }}'
        new=f'codex-hepta-{package} = {{ git = "{URL}", rev = "{revision}" }}'
        assert template.count(old)==1, package
        template=template.replace(old,new)
    changes=ROOT/'change'
    (changes/'services/hepta-session-host/Cargo.toml').write_text(template)
    for path in sorted(changes.rglob('*')):
        if not path.is_file() or '.github' in path.parts:
            continue
        target=DESKTOP/path.relative_to(changes)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(path.read_bytes())
    before_lock=sha(HOST/'Cargo.lock')
    overrides={'PATH':str(ROOT.parent/'shared-presenter/probes/git-bin')+':'+str(TOOL)+':'+os.environ.get('PATH',''),'CARGO_HOME':str(TASK/'cargo-home'),'CARGO_TARGET_DIR':str(TASK/'target'),'CARGO_INCREMENTAL':'0','RUSTC':str(TOOL/'rustc'),'RUSTDOC':str(TOOL/'rustdoc'),'RUSTUP_HOME':'/tmp/hepta-native-rustup','RUSTUP_TOOLCHAIN':'1.95.0','RUSTUP_AUTO_INSTALL':'0','CARGO_NET_GIT_FETCH_WITH_CLI':'true','GIT_TERMINAL_PROMPT':'0','CARGO_HTTP_TIMEOUT':'30','CARGO_NET_RETRY':'1','TMPDIR':str(TASK/'tmp')}
    env=os.environ.copy();env.update(overrides)
    command=[str(TOOL/'cargo'),'metadata','--manifest-path',str(HOST/'Cargo.toml'),'--format-version','1','--filter-platform','x86_64-unknown-linux-gnu']
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with prefix.with_suffix('.stdout').open('w') as out,prefix.with_suffix('.stderr').open('w') as err:
        result=subprocess.run(command,cwd=DESKTOP,env=env,stdout=out,stderr=err)
    record={'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'exit_code':result.returncode,'original_git_pin':revision,'manifest_sha256':sha(HOST/'Cargo.toml'),'Cargo_lock_sha256_before':before_lock,'Cargo_lock_sha256_after':sha(HOST/'Cargo.lock'),'stdout_sha256':sha(prefix.with_suffix('.stdout')),'stderr_sha256':sha(prefix.with_suffix('.stderr')),'environment_overrides':overrides,'graph_scope':'New legitimate standalone host graph, not the original Hepta workspace lock.'}
    if result.returncode==0:
        metadata=json.loads(prefix.with_suffix('.stdout').read_text())
        source='git+'+URL+'?rev='+revision+'#'+revision
        for name in ('codex-hepta-memory','codex-hepta-contracts','codex-hepta-paths'):
            packages=[p for p in metadata['packages'] if p['name']==name]
            assert len(packages)==1 and packages[0]['source']==source,(name,packages)
        hepta=[p for p in metadata['packages'] if (p.get('source') or '').startswith('git+'+URL)]
        assert all(p['source']==source for p in hepta)
        record['original_git_packages']=[{'name':p['name'],'source':p['source'],'manifest_path':p['manifest_path']} for p in hepta]
        record['metadata_package_count']=len(metadata['packages'])
        record['lock_generated_by_cargo']=True
        (changes/'services/hepta-session-host/Cargo.lock').write_bytes((HOST/'Cargo.lock').read_bytes())
    prefix.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:v for k,v in record.items() if k not in ('environment_overrides','original_git_packages')}))
    print(prefix.with_suffix('.stderr').read_text()[-4500:])
    return result.returncode

if __name__=='__main__':raise SystemExit(main())
