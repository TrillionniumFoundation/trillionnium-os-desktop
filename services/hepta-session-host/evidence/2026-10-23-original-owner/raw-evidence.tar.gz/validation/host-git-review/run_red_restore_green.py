#!/usr/bin/env python3
"""Explicitly execute the original-owner host ACK negative control, then restore.

Do not run concurrently with any other Cargo/formatter operation on this host.
Only the active Desktop copy of owner.rs is temporarily changed. The frozen
change/ tree, original Git dependency and test files are never written here.
SIGKILL/power loss cannot run Python finally; an exclusive original-byte backup
and fsynced event journal are created before the mutation for that case.
"""

import argparse
import datetime
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time

from check_git_provenance import digest, regular_identity


REVIEW = Path(__file__).resolve().parent
ROOT = REVIEW.parents[1]
DESKTOP = ROOT / "desktop"
CHANGES = ROOT / "change"
VALIDATION = ROOT / "validation"
OWNER_REL = "services/hepta-session-host/src/owner.rs"
TEST_REL = "services/hepta-session-host/tests/original_owner.rs"
REVISION = "db91f9ec316ba1472e7adf97f8415949de012469"
TREE = "81c03af04be56659d3eb4da71bf61aeac34c949f"
OLD_CALL = b"self.sender.snapshot_acknowledged(&ticket).await"
RED_CALL = b"self.sender.snapshot(&ticket).await"
EXPECTED_TESTS = {
    "exact_original_is_durable_before_connect_and_one_socket_send_is_never_rearmed",
    "lost_reply_recovers_exact_original_from_owner_enumeration_without_a_sender",
    "checkpoint_refusal_or_timeout_after_commit_never_rearms_a_fresh_prepare",
    "live_revocation_after_prepare_consumes_permission_without_connect_or_local_cancel",
    "admission_receipt_ack_failure_retries_only_the_same_owner_record_without_connecting",
    "recovered_submission_cannot_promote_a_committed_but_unacknowledged_receipt",
    "recovered_history_cannot_promote_a_committed_but_unacknowledged_publication",
    "recovered_local_cancellation_requires_ack_without_regranting_cancel_permission",
    "admitted_publication_then_unknown_survive_recovery_with_the_original_first_response_generation",
    "wrong_canonical_body_digest_is_neither_displayed_nor_appended_as_a_publication",
    "contradictory_publication_keeps_first_and_does_not_poison_the_original_chain",
    "concurrent_recovery_cannot_display_a_publication_rejected_against_another_handles_retained_first",
    "durable_local_cancellation_recovers_without_send_or_cancellation_rights",
    "tokio_context_is_rejected_before_retention_or_any_socket_operation",
}
RED_TESTS = {name for name in EXPECTED_TESTS if name.startswith("recovered_")}
PANIC_PATTERN = r"thread '([^']+)'(?: \(\d+\))? panicked at ([^\n]+):(\d+):(\d+):"
UNQUIESCED_GROUPS = set()
QUIESCENCE_RECORDS = []


def require(condition, explanation):
    if not condition:
        raise ValueError(explanation)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save_new(path, data):
    with path.open("x") as destination:
        json.dump(data, destination, indent=2, sort_keys=True)
        destination.write("\n")
        destination.flush()
        os.fsync(destination.fileno())


def snapshot(root):
    files, directories = {}, {}
    for current, dirs, names in os.walk(root, followlinks=False):
        relative = Path(current).relative_to(root)
        directories[relative.as_posix()] = oct(stat.S_IMODE(Path(current).lstat().st_mode))
        for name in list(dirs):
            path = Path(current) / name
            if path.is_symlink():
                dirs.remove(name)
                names.append(name)
        for name in names:
            path = Path(current) / name
            key = path.relative_to(root).as_posix()
            if path.is_symlink():
                raw = os.fsencode(os.readlink(path))
                files[key] = {"mode": "120000", "target": os.fsdecode(raw), "sha256": digest(raw)}
            else:
                files[key] = regular_identity(path)
    return {"files": files, "directories": directories}


def runner_identity(full_snapshot):
    result = {}
    for name, item in full_snapshot["files"].items():
        path = Path(name)
        in_scope = any(name.startswith(folder + "/") for folder in
                       ("ui", "services/hepta-os", "services/hepta-session-host", "libs/os-abi"))
        if in_scope and (path.suffix in (".rs", ".toml", ".json") or path.name == "Cargo.lock"):
            result[name] = {field: item[field] for field in ("sha256", "git_blob", "bytes")}
    return result


def compare_frozen_copy(changes, desktop):
    for name, identity in changes["files"].items():
        if ".github" in Path(name).parts:
            continue  # The resolver explicitly does not copy workflow files.
        require(desktop["files"].get(name) == identity, "change/ and desktop/ differ: " + name)


def verify_run(receipt_path, expected, red=False, expected_source=None, capture_binary=False):
    receipt = json.loads(receipt_path.read_text())
    require(receipt.get("original_git_pin") == REVISION, "Receipt has the wrong original Git pin")
    require(receipt.get("controlled_stop_reason") is None, "A resource stop is not a test result")
    require(receipt.get("exit_code") == (101 if red else 0), "Unexpected Cargo exit status")
    require(receipt.get("source_unchanged") is True and receipt["source_before"] == receipt["source_after"],
            "The tested local source changed during the gate")
    if expected_source is not None:
        require(receipt["source_before"] == runner_identity(expected_source),
                "Receipt source does not match the intended local source snapshot")
    logs = {}
    for stream in ("stdout", "stderr"):
        path = receipt_path.parent / receipt[stream + "_file"]
        raw = path.read_bytes()
        require(digest(raw) == receipt[stream + "_sha256"], "Raw " + stream + " hash mismatch")
        logs[stream] = raw.decode(errors="replace")
    command = receipt["command"]
    require("test" in command and "--locked" in command and "--all-targets" in command,
            "Gate did not use the required locked host test command")
    require(("recovered_" in command) == red, "Unexpected test-name filter")
    if not red:
        require(command[command.index("--jobs") + 2:] == ["--", "--test-threads=1"],
                "Green gate has additional Cargo/libtest filters")
    combined = logs["stdout"] + "\n" + logs["stderr"]
    require("could not compile" not in combined and not re.search(r"error\[E\d+\]", combined),
            "Compilation failure cannot qualify a negative control")
    statuses = re.findall(r"^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$", logs["stdout"], re.M)
    require(len(statuses) == len(expected) and {name for name, _ in statuses} == expected,
            "The exact expected test set did not run")
    require(all(status == ("FAILED" if red else "ok") for _, status in statuses),
            "The actual test statuses differ from the expected gate")
    summaries = re.findall(
        r"^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
        r"(\d+) measured; (\d+) filtered out;", logs["stdout"], re.M)
    require(bool(summaries), "No actual libtest result summary was captured")
    totals = [sum(int(row[index]) for row in summaries) for index in range(5)]
    require(totals == ([0, 3, 0, 0, 11] if red else [14, 0, 0, 0, 0]),
            "Unexpected libtest totals: " + repr(totals))
    if red:
        source = (DESKTOP / TEST_REL).read_text()
        start = source.index("fn recovery_still_requires_ack(")
        assertion = source.index("    assert!(matches!(", start)
        line = source[:assertion].count("\n") + 1
        panics = list(re.finditer(PANIC_PATTERN, combined))
        require(len(panics) == 3 and {match[1] for match in panics} == RED_TESTS,
                "Red failures did not come only from the three recovery tests")
        for index, match in enumerate(panics):
            tail = combined[match.end():panics[index + 1].start() if index + 1 < len(panics) else len(combined)]
            require(match[2].replace("\\", "/").endswith("tests/original_owner.rs") and int(match[3]) == line,
                    "Red failure was not at the recovery ACK assertion")
            require("assertion failed:" in tail and "PersistenceUnknown" in tail,
                    "Red failure did not assert the missing independent ACK")
    result = {"path": str(receipt_path), "sha256": digest(receipt_path.read_bytes()),
              "test_names": sorted(expected), "libtest_totals": totals,
              "raw_stdout_sha256": receipt["stdout_sha256"], "raw_stderr_sha256": receipt["stderr_sha256"]}
    if capture_binary:
        binaries = re.findall(r"Running tests/original_owner\.rs \(([^\n)]+)\)", logs["stderr"])
        require(len(binaries) == 1, "Expected one actual integration-test executable")
        binary = Path(binaries[0])
        if not binary.is_absolute():
            binary = DESKTOP / binary
        result["executed_test_binary"] = {"path": str(binary.resolve()), **regular_identity(binary)}
    return result


def descendant_groups(process):
    parents = {}
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            status = (entry / "status").read_text()
            match = re.search(r"^PPid:\s*(\d+)$", status, re.M)
            if match:
                parents[int(entry.name)] = int(match[1])
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
    descendants = {process.pid}
    while True:
        children = {pid for pid, parent in parents.items() if parent in descendants}
        if children <= descendants:
            break
        descendants.update(children)
    groups = set()
    for pid in descendants:
        try:
            group = os.getpgid(pid)
            if group != os.getpgrp():
                groups.add(group)
        except ProcessLookupError:
            pass
    return groups


def live_group_members(groups):
    live = {}
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            # The command name in parentheses can contain spaces or ')'.
            fields = (entry / "stat").read_text().rsplit(")", 1)[1].split()
            state, group = fields[0], int(fields[2])
            if group in groups and state not in ("Z", "X", "x"):
                live.setdefault(group, []).append(int(entry.name))
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
    return live


def quiesce(process, groups):
    initial = live_group_members(groups)
    for signum in (signal.SIGTERM, signal.SIGKILL):
        live = live_group_members(groups)
        if not live:
            break
        for group in live:
            try:
                os.killpg(group, signum)
            except ProcessLookupError:
                pass
        deadline = time.monotonic() + 10
        while live_group_members(groups) and time.monotonic() < deadline:
            process.poll()  # Reap our direct child; zombie tasks are not readers.
            time.sleep(0.1)
    remaining = live_group_members(groups)
    QUIESCENCE_RECORDS.append({"at": now(), "owned_groups": sorted(groups),
                               "cleanup_needed": bool(initial), "remaining_live": remaining})
    require(not remaining, "Owned build workers are still live; do not restore owner.rs: " + repr(remaining))
    process.wait(timeout=1)


def run(command):
    process = subprocess.Popen(command, start_new_session=True)
    groups = {process.pid}
    UNQUIESCED_GROUPS.update(groups)
    try:
        while True:
            groups.update(descendant_groups(process))
            UNQUIESCED_GROUPS.update(groups)
            code = process.poll()
            if code is not None:
                return code
            time.sleep(0.1)
    finally:
        # Cargo has its own new session. Retain its group identity while its
        # parent is alive, and clean on *every* return, including wrapper errors.
        # Repeated catchable signals cannot skip worker shutdown into restoration.
        handlers = {number: signal.signal(number, signal.SIG_IGN)
                    for number in (signal.SIGINT, signal.SIGTERM)}
        try:
            groups.update(descendant_groups(process))
            UNQUIESCED_GROUPS.update(groups)
            quiesce(process, groups)
            UNQUIESCED_GROUPS.difference_update(groups)
        finally:
            for number, previous in handlers.items():
                signal.signal(number, previous)


def rewrite_existing(path, expected, replacement):
    with path.open("r+b") as stream:
        require(stream.read() == expected, "Active owner bytes changed before the deliberate replacement")
        stream.seek(0)
        stream.write(replacement)
        stream.truncate()
        stream.flush()
        os.fsync(stream.fileno())


def require_idle_runner():
    active = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            arguments = (entry / "cmdline").read_bytes().split(b"\0")
            for raw in arguments:
                if os.fsdecode(raw).endswith("run_host.py"):
                    path = Path(os.fsdecode(raw))
                    if not path.is_absolute():
                        path = (entry / "cwd").resolve() / path
                    if path.resolve() == VALIDATION / "run_host.py":
                        active.append(int(entry.name))
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
    require(not active, "Another host runner is active; release its window first. PIDs: " + repr(active))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--name", required=True)
    parser.add_argument("--initial-green", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, default=VALIDATION / "git-host-resolution.stdout")
    parser.add_argument("--full-git-baseline", type=Path, default=REVIEW / "git-provenance-during-01.json")
    parser.add_argument("--execute", action="store_true", help="Required explicit opt-in to the temporary mutation and real gates")
    args = parser.parse_args()
    require(args.execute, "Use --execute only after the root has released the host compilation window")
    require(re.fullmatch(r"[A-Za-z0-9-]+", args.name) is not None, "Invalid evidence name")
    prefix = REVIEW / args.name
    controller = prefix.with_suffix(".json")
    baseline_path = REVIEW / (args.name + "-baseline.json")
    before_proof = REVIEW / (args.name + "-git-before.json")
    after_proof = REVIEW / (args.name + "-git-after.json")
    backup = REVIEW / (args.name + "-owner-original.rs")
    red_backup = REVIEW / (args.name + "-owner-red.rs")
    journal_path = REVIEW / (args.name + "-events.jsonl")
    red_name, green_name = args.name + "-red-recovery", args.name + "-green"
    reserved = [controller, baseline_path, before_proof, after_proof, backup, red_backup, journal_path]
    for name in (red_name, green_name):
        reserved += [VALIDATION / (name + suffix) for suffix in (".json", ".stdout", ".stderr")]
    require(not any(path.exists() for path in reserved), "Refusing to overwrite an execution or recovery artifact")
    owner = DESKTOP / OWNER_REL
    original, red, baseline = None, None, None
    mutation_started = False
    record = {"started_at": now(), "passed": False, "revision": REVISION, "tree": TREE,
              "scope": "Real original-owner adapter Git graph; not the original Hepta workspace lock or production checkpoint qualification.",
              "red_scope": "Each recovery test fails in its first REFUSE loop iteration. HOLD timeout is exercised by the final green suite, not proved by the early failing red loop.",
              "script_sha256": digest(Path(__file__).read_bytes()), "errors": []}
    journal = journal_path.open("x")

    def event(stage, **data):
        journal.write(json.dumps({"at": now(), "stage": stage, **data}) + "\n")
        journal.flush()
        os.fsync(journal.fileno())

    def proof(path, phase):
        command = [sys.executable, str(REVIEW / "check_git_provenance.py"),
                   "--metadata", str(args.metadata.resolve()), "--revision", REVISION,
                   "--tree", TREE, "--phase", phase, "--output", str(path)]
        for relative in ("objective-owner/publication/manifest.json",
                         "owner-recovery-ack/validation/source-manifest.json",
                         "owner-recovery-ack/validation/documentation-manifest.json"):
            command += ["--expected-manifest", str(ROOT.parent / relative)]
        command += ["--compare", str(args.full_git_baseline.resolve()), "--compact-compared"]
        require(run(command) == 0, "Original Git checkout proof failed")
        return {"path": str(path), "sha256": digest(path.read_bytes())}

    def handle_signal(number, frame):
        raise InterruptedError("Controller interrupted by signal " + str(number))

    prior_handlers = {number: signal.signal(number, handle_signal) for number in (signal.SIGINT, signal.SIGTERM)}
    try:
        require_idle_runner()
        changes, desktop = snapshot(CHANGES), snapshot(DESKTOP)
        compare_frozen_copy(changes, desktop)
        actual_tests = set(re.findall(r"#\[test\]\s+fn\s+(\w+)\s*\(", (DESKTOP / TEST_REL).read_text()))
        require(actual_tests == EXPECTED_TESTS, "Frozen host test set is not the expected fourteen tests")
        record["initial_green"] = verify_run(args.initial_green.resolve(), EXPECTED_TESTS, expected_source=desktop)
        record["git_before"] = proof(before_proof, "before-build")
        baseline = {"change": changes, "desktop": desktop,
                    "runner": regular_identity(VALIDATION / "run_host.py"),
                    "proof_script": regular_identity(REVIEW / "check_git_provenance.py")}
        save_new(baseline_path, baseline)
        record["baseline"] = {"path": str(baseline_path), "sha256": digest(baseline_path.read_bytes())}
        original = owner.read_bytes()
        require(original.count(OLD_CALL) == 1 and RED_CALL not in original,
                "The exact single ACK call is not present for the negative control")
        red = original.replace(OLD_CALL, RED_CALL, 1)
        with backup.open("xb") as stream:
            stream.write(original)
            stream.flush()
            os.fsync(stream.fileno())
        with red_backup.open("xb") as stream:
            stream.write(red)
            stream.flush()
            os.fsync(stream.fileno())
        event("original-backed-up", original_sha256=digest(original), red_sha256=digest(red))
        try:
            mutation_started = True
            rewrite_existing(owner, original, red)
            red_source = snapshot(DESKTOP)
            expected_red = json.loads(json.dumps(desktop))
            expected_red["files"][OWNER_REL] = regular_identity(owner)
            require(red_source == expected_red and snapshot(CHANGES) == changes,
                    "The negative control changed more than the active owner.rs call")
            event("red-installed", mutated_path=OWNER_REL)
            code = run([sys.executable, str(VALIDATION / "run_host.py"), "red-recovery", red_name])
            record["red_runner_exit"] = code
            require(code == 101, "Negative control did not finish with the expected test failure exit")
            record["red"] = verify_run(VALIDATION / (red_name + ".json"), RED_TESTS,
                                        red=True, expected_source=red_source, capture_binary=True)
            require(snapshot(DESKTOP) == expected_red and snapshot(CHANGES) == changes,
                    "Files changed during the negative control")
            event("red-assertions-confirmed", count=3)
        finally:
            if mutation_started:
                restore_handlers = {number: signal.signal(number, signal.SIG_IGN)
                                    for number in (signal.SIGINT, signal.SIGTERM)}
                try:
                    require(not UNQUIESCED_GROUPS,
                            "Restoration deferred: known build groups have not quiesced: " + repr(sorted(UNQUIESCED_GROUPS)))
                    current = owner.read_bytes()
                    if current not in (original, red):
                        conflict = REVIEW / (args.name + "-unexpected-owner-bytes.bin")
                        with conflict.open("xb") as stream:
                            stream.write(current)
                        record["errors"].append("Unexpected owner mutation preserved at " + str(conflict))
                    rewrite_existing(owner, current, original)
                    mutation_started = False
                    require(regular_identity(owner) == desktop["files"][OWNER_REL],
                            "Original owner bytes or mode were not exactly restored")
                    event("original-restored", sha256=digest(original))
                finally:
                    for number, previous in restore_handlers.items():
                        signal.signal(number, previous)
        require(not record["errors"], "A concurrent mutation invalidated the control")
        require(snapshot(DESKTOP) == desktop and snapshot(CHANGES) == changes,
                "Final candidate was not completely restored before green")
        require(regular_identity(VALIDATION / "run_host.py") == baseline["runner"] and
                regular_identity(REVIEW / "check_git_provenance.py") == baseline["proof_script"],
                "A gate script changed during execution")
        code = run([sys.executable, str(VALIDATION / "run_host.py"), "test", green_name])
        record["green_runner_exit"] = code
        require(code == 0, "Final green suite did not exit successfully")
        record["green"] = verify_run(VALIDATION / (green_name + ".json"), EXPECTED_TESTS,
                                      expected_source=desktop, capture_binary=True)
        require(snapshot(DESKTOP) == desktop and snapshot(CHANGES) == changes,
                "Final local source or modes differ from the frozen candidate")
        record["local_source_unchanged"] = True
        record["passed"] = True
        event("green-confirmed", count=14)
    except BaseException as error:
        record["errors"].append(type(error).__name__ + ": " + str(error))
        record["passed"] = False
    finally:
        # Also verify the untouched original dependency after a failed red/green.
        if before_proof.exists():
            try:
                record["git_after"] = proof(after_proof, "after-build")
            except BaseException as error:
                record["errors"].append("Final Git proof: " + type(error).__name__ + ": " + str(error))
                record["passed"] = False
        if baseline is not None:
            try:
                record["final_local_matches_baseline"] = (snapshot(DESKTOP) == baseline["desktop"] and
                                                          snapshot(CHANGES) == baseline["change"])
                require(record["final_local_matches_baseline"], "Final full local source differs from baseline")
                require(regular_identity(VALIDATION / "run_host.py") == baseline["runner"] and
                        regular_identity(REVIEW / "check_git_provenance.py") == baseline["proof_script"],
                        "Final gate-script identity differs from baseline")
            except BaseException as error:
                record["errors"].append("Final local proof: " + type(error).__name__ + ": " + str(error))
                record["passed"] = False
        for number, previous in prior_handlers.items():
            signal.signal(number, previous)
        record["finished_at"] = now()
        record["process_quiescence"] = QUIESCENCE_RECORDS
        record["unquiesced_groups"] = sorted(UNQUIESCED_GROUPS)
        event("finished", passed=record["passed"], errors=record["errors"])
        journal.close()
        record["journal_sha256"] = digest(journal_path.read_bytes())
        save_new(controller, record)
    print(json.dumps({"receipt": str(controller), "passed": record["passed"], "errors": record["errors"]}))
    return 0 if record["passed"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
