#!/usr/bin/env python3
"""Read-only audit of Cargo's actual Git checkout, with no Cargo/network calls.

The output is new evidence only. This does not repair, normalize or stage files.
Run before and after a gate; a during-build audit must be labelled as such.
"""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tomllib


URL = "https://github.com/TrillionniumFoundation/hepta-private-ci"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git_object(kind, data):
    return hashlib.sha1(kind.encode() + b" " + str(len(data)).encode() + b"\0" + data).hexdigest()


def regular_identity(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError(f"Expected regular file: {path}")
    sha256 = hashlib.sha256()
    blob = hashlib.sha1(b"blob " + str(before.st_size).encode() + b"\0")
    with path.open("rb") as source:
        opened = os.fstat(source.fileno())
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
            raise ValueError(f"File changed while opening: {path}")
        for chunk in iter(lambda: source.read(128 * 1024), b""):
            sha256.update(chunk)
            blob.update(chunk)
        final_fd = os.fstat(source.fileno())
    after = path.lstat()
    fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_mode")
    if any(getattr(before, field) != getattr(after, field) or
           getattr(before, field) != getattr(final_fd, field) for field in fields):
        raise ValueError(f"File changed while hashing: {path}")
    return {"bytes": before.st_size, "sha256": sha256.hexdigest(),
            "git_blob": blob.hexdigest(), "mode": "100755" if before.st_mode & 0o111 else "100644",
            "permissions": oct(stat.S_IMODE(before.st_mode))}


class Audit:
    def __init__(self, git):
        self.git = git
        self.errors = []
        self.repositories = {}
        self.heads = {}
        self.env = os.environ.copy()
        self.env.update(GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL="/dev/null",
                        GIT_OPTIONAL_LOCKS="0", GIT_NO_REPLACE_OBJECTS="1",
                        GIT_TERMINAL_PROMPT="0")

    def command(self, root, *args):
        return [self.git, "-c", "core.fsmonitor=false", "-c", "core.hooksPath=/dev/null",
                "-c", "core.untrackedCache=false", "-C", str(root), *args]

    def run(self, root, *args):
        result = subprocess.run(self.command(root, *args), env=self.env,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result.returncode:
            raise ValueError(f"Local Git {args!r} failed ({result.returncode}): " +
                             result.stderr.decode(errors="replace")[-1200:])
        return result.stdout

    def require(self, condition, message):
        if not condition:
            self.errors.append(message)

    def verify_trees(self, root, objects):
        process = subprocess.Popen(self.command(root, "cat-file", "--batch"), env=self.env,
                                   stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            for oid in sorted(objects):
                process.stdin.write((oid + "\n").encode())
                process.stdin.flush()
                header = process.stdout.readline().strip().split()
                if len(header) != 3 or header[:2] != [oid.encode(), b"tree"]:
                    raise ValueError(f"Unexpected Git tree object header for {oid}: {header!r}")
                size = int(header[2])
                data = process.stdout.read(size)
                if len(data) != size or process.stdout.read(1) != b"\n":
                    raise ValueError(f"Incomplete Git tree object {oid}")
                self.require(git_object("tree", data) == oid, f"Git tree object hash differs: {oid}")
            process.stdin.close()
            error = process.stderr.read()
            code = process.wait()
            if code:
                raise ValueError(f"Local cat-file batch failed ({code}): {error[-1200:]!r}")
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait()

    def repository(self, root, revision, expected_tree=None, depth=0):
        root = root.resolve()
        if depth > 8:
            raise ValueError("Unexpected recursive Git submodule depth")
        key = str(root)
        if key in self.repositories:
            self.require(self.repositories[key]["revision"] == revision, f"Mixed revision at {root}")
            return self.repositories[key]
        head = self.run(root, "rev-parse", "--verify", "HEAD^{commit}").decode().strip()
        self.heads[key] = head
        self.require(head == revision, f"HEAD differs at {root}: {head} != {revision}")
        raw_commit = self.run(root, "cat-file", "commit", revision)
        self.require(git_object("commit", raw_commit) == revision, f"Commit object hash differs: {revision}")
        first_line = raw_commit.split(b"\n", 1)[0]
        if not re.fullmatch(b"tree [0-9a-f]{40}", first_line):
            raise ValueError("Malformed commit tree header")
        tree = first_line[5:].decode()
        if expected_tree is not None:
            self.require(tree == expected_tree, f"Root tree differs: {tree} != {expected_tree}")
        entries, trees = {}, {tree}
        for record in self.run(root, "ls-tree", "-r", "-t", "-z", "--full-tree", revision).split(b"\0"):
            if not record:
                continue
            header, raw_path = record.split(b"\t", 1)
            mode, kind, oid = header.decode().split()
            path = os.fsdecode(raw_path)
            relative = Path(path)
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError(f"Unsafe tracked path: {path!r}")
            if kind == "tree":
                trees.add(oid)
            else:
                entries[path] = {"mode": mode, "kind": kind, "oid": oid}
        self.verify_trees(root, trees)
        index = {}
        for record in self.run(root, "ls-files", "--stage", "-z").split(b"\0"):
            if not record:
                continue
            header, raw_path = record.split(b"\t", 1)
            mode, oid, stage = header.decode().split()
            path = os.fsdecode(raw_path)
            self.require(stage == "0" and path not in index, f"Unmerged/duplicate index entry: {path}")
            index[path] = (mode, oid)
        expected_index = {path: (entry["mode"], entry["oid"]) for path, entry in entries.items()}
        self.require(index == expected_index, f"Git index differs from published tree at {root}")
        files, gitlinks = {}, {}
        expected_dirs = {"."}
        for name, entry in entries.items():
            path = root / name
            expected_dirs.update(str(parent) for parent in Path(name).parents)
            if entry["mode"] == "160000":
                self.require(path.is_dir() and not path.is_symlink(), f"Missing gitlink checkout: {path}")
                gitlinks[name] = entry["oid"]
                self.repository(path, entry["oid"], depth=depth + 1)
                continue
            if entry["mode"] == "120000":
                info = path.lstat()
                if not stat.S_ISLNK(info.st_mode):
                    raise ValueError(f"Tracked symlink was replaced: {path}")
                target = os.fsencode(os.readlink(path))
                actual = {"mode": "120000", "bytes": len(target), "sha256": digest(target),
                          "git_blob": git_object("blob", target), "target": os.fsdecode(target)}
            elif entry["mode"] in ("100644", "100755"):
                actual = regular_identity(path)
            else:
                raise ValueError(f"Unsupported tracked mode: {entry['mode']} {path}")
            self.require(actual["mode"] == entry["mode"], f"Tracked mode differs: {path}")
            self.require(actual["git_blob"] == entry["oid"], f"Tracked bytes differ: {path}")
            files[name] = actual
        markers = {}
        for current, dirs, names in os.walk(root, followlinks=False):
            relative_dir = Path(current).relative_to(root)
            for name in list(dirs):
                rel = (relative_dir / name).as_posix()
                if rel == ".git" or rel in gitlinks:
                    dirs.remove(name)
                elif (Path(current) / name).is_symlink():
                    dirs.remove(name)
                    if rel not in entries:
                        self.errors.append(f"Unexpected directory symlink: {root / rel}")
                elif rel not in expected_dirs:
                    self.errors.append(f"Unexpected untracked directory: {root / rel}")
            for name in names:
                rel = (relative_dir / name).as_posix()
                if rel == ".git":
                    continue
                if rel == ".cargo-ok" and rel not in entries:
                    markers[rel] = regular_identity(root / rel)
                    self.require(markers[rel]["mode"] == "100644", "Cargo metadata marker is executable")
                elif rel not in entries:
                    self.errors.append(f"Unexpected untracked/ignored file: {root / rel}")
        result = {"revision": revision, "tree": tree, "tracked_files": files, "gitlinks": gitlinks,
                  "verified_tree_objects": len(trees), "generated_cargo_markers": markers,
                  "index_matches_tree": index == expected_index}
        self.repositories[key] = result
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--tree", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--phase", choices=("before-build", "during-build", "after-build"), required=True)
    parser.add_argument("--compare", type=Path)
    parser.add_argument("--compact-compared", action="store_true",
                        help="After a successful complete comparison, reference the retained full baseline instead of repeating its file list")
    parser.add_argument("--expected-manifest", action="append", type=Path, default=[])
    parser.add_argument("--git", default="/usr/bin/git")
    args = parser.parse_args()
    if not re.fullmatch("[0-9a-f]{40}", args.revision) or not re.fullmatch("[0-9a-f]{40}", args.tree):
        parser.error("revision and tree must be exact forty-character lowercase Git IDs")
    if args.output.exists():
        parser.error("refusing to overwrite evidence")
    if args.compact_compared and args.compare is None:
        parser.error("--compact-compared requires a retained complete --compare baseline")
    audit = Audit(args.git)
    record = {"started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "phase": args.phase, "revision": args.revision, "tree": args.tree,
              "metadata": str(args.metadata.resolve()), "metadata_sha256": digest(args.metadata.read_bytes()),
              "auditor_sha256": digest(Path(__file__).read_bytes()),
              "operation": "Read-only local Git/file audit; no Cargo, build, fetch or network operation."}
    try:
        git_path = Path(args.git).resolve()
        version = subprocess.run([str(git_path), "--version"], env=audit.env,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        audit.require(version.returncode == 0, "Unable to identify local Git tool")
        record["local_git_tool"] = {"path": str(git_path), **regular_identity(git_path),
                                    "version": version.stdout.decode(errors="replace").strip()}
        metadata = json.loads(args.metadata.read_text())
        source = "git+" + URL + "?rev=" + args.revision + "#" + args.revision
        packages = [p for p in metadata["packages"] if (p.get("source") or "").startswith("git+" + URL)]
        for name in ("codex-hepta-memory", "codex-hepta-contracts", "codex-hepta-paths"):
            matches = [p for p in metadata["packages"] if p["name"] == name]
            audit.require(len(matches) == 1 and matches[0]["source"] == source, f"Wrong direct original package: {name}")
        roots = set()
        record["original_packages"] = []
        for package in packages:
            audit.require(package["source"] == source, f"Mixed original source: {package['id']}")
            manifest = Path(package["manifest_path"]).resolve()
            root = Path(audit.run(manifest.parent, "rev-parse", "--show-toplevel").decode().strip()).resolve()
            roots.add(root)
            snapshot = audit.repository(root, args.revision, args.tree)
            relative = manifest.relative_to(root).as_posix()
            audit.require(relative in snapshot["tracked_files"], f"Package manifest is not a tracked original file: {manifest}")
            record["original_packages"].append({"name": package["name"], "id": package["id"],
                                                "manifest_path": str(manifest), "source": package["source"]})
        audit.require(len(roots) == 1, f"Expected one original checkout, found {len(roots)}")
        host = Path(metadata["workspace_root"]).resolve()
        desktop = host.parents[1]
        record["host_manifest"] = regular_identity(host / "Cargo.toml")
        record["host_lock"] = regular_identity(host / "Cargo.lock")
        lock = tomllib.loads((host / "Cargo.lock").read_text())
        for package in lock["package"]:
            if (package.get("source") or "").startswith("git+" + URL):
                audit.require(package["source"] == source, f"Mixed Git pin in lock: {package['name']}")
        record["local_packages"] = []
        for package in metadata["packages"]:
            if package.get("source") is None:
                path = Path(package["manifest_path"]).resolve()
                audit.require(path.is_relative_to(desktop), f"Unexpected local replacement outside Desktop: {package['id']}")
                record["local_packages"].append({"id": package["id"], "manifest_path": str(path)})
        expected = {}
        for path in args.expected_manifest:
            data = json.loads(path.read_text())
            for entry in data["files"]:
                expected[entry["path"]] = entry
        for root in roots:
            files = audit.repositories[str(root)]["tracked_files"]
            for path, entry in expected.items():
                audit.require(path in files, f"Expected reviewed source missing: {path}")
                if path in files:
                    audit.require(files[path]["sha256"] == entry["candidate_sha256"], f"Reviewed candidate bytes differ: {path}")
                    audit.require(files[path]["mode"] == entry["mode"], f"Reviewed candidate mode differs: {path}")
        record["reviewed_candidate_paths"] = sorted(expected)
        record["repositories"] = audit.repositories
        if args.compare:
            before = json.loads(args.compare.read_text())
            audit.require(before.get("passed") is True, "Comparison baseline did not pass")
            audit.require(isinstance(before.get("repositories"), dict), "Comparison baseline must retain the full repository manifest")
            for key in ("revision", "tree", "repositories", "host_manifest", "host_lock", "original_packages", "local_packages"):
                audit.require(record.get(key) == before.get(key), f"Provenance changed since comparison baseline: {key}")
            differences = []
            old_repos = before.get("repositories", {})
            for root in sorted(set(old_repos) | set(audit.repositories)):
                old = old_repos.get(root, {})
                new = audit.repositories.get(root, {})
                old_files, new_files = old.get("tracked_files", {}), new.get("tracked_files", {})
                for name in sorted(set(old_files) | set(new_files)):
                    if old_files.get(name) != new_files.get(name):
                        differences.append({"repository": root, "path": name,
                                            "before": old_files.get(name), "after": new_files.get(name)})
                old_other = {key: value for key, value in old.items() if key != "tracked_files"}
                new_other = {key: value for key, value in new.items() if key != "tracked_files"}
                if old_other != new_other:
                    differences.append({"repository": root, "metadata_before": old_other, "metadata_after": new_other})
            record["comparison_differences"] = differences
            record["comparison"] = {"path": str(args.compare.resolve()), "sha256": digest(args.compare.read_bytes())}
    except Exception as error:
        audit.errors.append(f"{type(error).__name__}: {error}")
    record["finished_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record["errors"] = audit.errors
    record["passed"] = not audit.errors
    record["observed_git_heads"] = audit.heads
    canonical = json.dumps(audit.repositories, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()
    record["complete_repository_manifest_sha256"] = digest(canonical)
    record["complete_repository_manifest_serialization"] = "UTF-8 JSON, sort_keys=True, separators=(',', ':'), ensure_ascii=True; repositories value only"
    record["complete_tracked_file_count"] = sum(len(repo["tracked_files"]) for repo in audit.repositories.values())
    if args.compact_compared and record["passed"]:
        record["repository_summaries"] = {
            root: {"revision": repo["revision"], "tree": repo["tree"],
                   "tracked_file_count": len(repo["tracked_files"]),
                   "verified_tree_objects": repo["verified_tree_objects"],
                   "index_matches_tree": repo["index_matches_tree"],
                   "gitlinks": repo["gitlinks"], "generated_cargo_markers": repo["generated_cargo_markers"],
                   "complete_manifest_sha256": digest(json.dumps(repo, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode())}
            for root, repo in audit.repositories.items()
        }
        del record["repositories"]
        record["compact_compared"] = True
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as destination:
        json.dump(record, destination, indent=2, sort_keys=True)
        destination.write("\n")
    print(json.dumps({"receipt": str(args.output), "passed": record["passed"], "errors": audit.errors[:12],
                      "repositories": len(audit.repositories),
                      "tracked_files": sum(len(r["tracked_files"]) for r in audit.repositories.values())}))
    return 0 if record["passed"] else 3


if __name__ == "__main__":
    sys.exit(main())
