#!/usr/bin/env python3
"""Compile the exact CpuMax and quota ktests with controlled TSC frequencies."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

BASE = Path('/workspace/scratch/499c7902de8e')
TREE = BASE / 'nextstep-cpu-fix'
OUT = Path(__file__).resolve().parent / 'clock-oracle-replay'
SOURCE = 'kernel/asterinas/kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu.rs'
BASELINE = '01caff4fb3651f57ea32e648ade5a351d20df569'
OUT.mkdir(exist_ok=False)
env = os.environ.copy()
env['RUSTUP_HOME'] = str(BASE / 'implementation-tools/rustup')
env['CARGO_HOME'] = str(BASE / 'implementation-tools/cargo')
env['PATH'] = env['CARGO_HOME'] + '/bin:' + env['PATH']

original = subprocess.check_output(['git', 'show', BASELINE + ':' + SOURCE], cwd=TREE, text=True)
candidate = (TREE / SOURCE).read_text()
boundary = '#[cfg(ktest)]\nmod final_charge_regressions;'
production = original.split(boundary)[0]
assert production == candidate.split(boundary)[0]

def extracted(source):
    first = source.index('/// A CPU bandwidth limit.')
    last = source.index('/// Specifies the cgroup CPU sub-controller')
    tests = source[source.index('mod quota_debt_regressions {'):]
    tests = tests.replace('    use ostd::prelude::ktest;\n', '')
    tests = tests.replace('#[ktest]', '#[test]')
    return (
        '#![allow(dead_code)]\n'
        'fn tsc_freq() -> u64 {\n'
        '    std::env::var("A06_ORACLE_TSC_HZ").unwrap().parse().unwrap()\n'
        '}\n' + source[first:last] + '\n' + tests
    )

reports = []
for label, source in [('baseline', original), ('candidate', candidate)]:
    harness = OUT / (label + '.rs')
    harness.write_text(extracted(source))
    binary = OUT / (label + '-tests')
    command = ['rustc', '+nightly-2026-07-21', '--edition=2024', '--test', str(harness), '-o', str(binary)]
    compiled = subprocess.run(command, env=env, text=True, capture_output=True)
    (OUT / (label + '-build.log')).write_text(compiled.stdout + compiled.stderr)
    assert compiled.returncode == 0
    for frequency in [2_000_000_000, 2_441_165_790]:
        case = f'{label}-{frequency}'
        run_env = env | {'A06_ORACLE_TSC_HZ': str(frequency)}
        run_command = [str(binary), '--test-threads=1', '--nocapture']
        run = subprocess.run(run_command, env=run_env, text=True, capture_output=True)
        output = run.stdout + run.stderr
        (OUT / (case + '.log')).write_text(output)
        match = re.search(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', output)
        assert match, output
        failing = re.findall(r'^test ([^ ]+) \.\.\. FAILED$', output, re.M)
        reports.append({
            'case': case, 'frequency_hz': frequency,
            'period_clocks': frequency * 100_000 // 1_000_000,
            'quota_clocks': frequency * 1_000 // 1_000_000,
            'argv': run_command, 'exit_code': run.returncode,
            'passed': int(match[2]), 'failed': int(match[3]), 'ignored': int(match[4]),
            'filtered': int(match[6]), 'failed_tests': failing,
            'harness_sha256': hashlib.sha256(harness.read_bytes()).hexdigest(),
            'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
            'log_sha256': hashlib.sha256(output.encode()).hexdigest(),
        })

negative = [r for r in reports if r['case'] == 'baseline-2441165790'][0]
assert negative['exit_code'] != 0 and negative['failed'] == 2
assert set(negative['failed_tests']) == {
    'quota_debt_regressions::idle_skipped_periods_never_subsidize_late_burst',
    'quota_debt_regressions::long_continuous_interval_has_constant_time_bounded_debt_accounting',
}
assert all(r['exit_code'] == 0 and r['failed'] == 0 for r in reports if r is not negative)
report = {
    'schema': 1, 'passed': True, 'baseline_commit': BASELINE,
    'source_path': SOURCE,
    'baseline_source_sha256': hashlib.sha256(original.encode()).hexdigest(),
    'candidate_source_sha256': hashlib.sha256(candidate.encode()).hexdigest(),
    'non_ktest_prefix_bytes': len(production.encode()),
    'non_ktest_prefix_sha256': hashlib.sha256(production.encode()).hexdigest(),
    'production_unchanged': True,
    'scope': 'Actual extracted Rust CpuMax and its quota ktests, with only ostd ktest attributes mapped to host test attributes and tsc_freq supplied by a controlled input. This does not replace the full original QEMU gate.',
    'reports': reports,
}
(OUT / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
