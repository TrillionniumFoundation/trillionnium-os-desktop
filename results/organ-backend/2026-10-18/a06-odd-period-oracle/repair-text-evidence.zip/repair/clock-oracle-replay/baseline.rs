#![allow(dead_code)]
fn tsc_freq() -> u64 {
    std::env::var("A06_ORACLE_TSC_HZ").unwrap().parse().unwrap()
}
/// A CPU bandwidth limit.
#[derive(Clone, Copy)]
struct CpuMax {
    quota_usec: u64,
    period_usec: u64,
    window_start: u64,
    used_clocks: u64,
    /// Positive overrun from earlier quota windows. Never grants unused credit.
    carry_debt_clocks: u64,
    nr_periods: u64,
    nr_throttled: u64,
    throttled_since: Option<u64>,
    throttled_clocks: u64,
}

impl CpuMax {
    /// N0 uses a single vCPU and invariant TSC; these fields are not nanoseconds.
    fn us_to_clocks(us: u64) -> u64 {
        (u128::from(tsc_freq()) * u128::from(us) / 1_000_000)
            .try_into()
            .unwrap_or(u64::MAX)
    }

    fn period_clocks(&self) -> u64 {
        Self::us_to_clocks(self.period_usec).max(1)
    }

    /// Compute the periods visible to a cpu.stat observer WITHOUT closing a
    /// quota window. The running task's interval may not have been charged
    /// yet, so an observational read must not call advance() and erase it.
    fn observed_nr_periods(&self, now: u64) -> u64 {
        let period = self.period_clocks();
        let start = now / period * period;
        if self.window_start == 0 || start <= self.window_start {
            self.nr_periods
        } else {
            self.nr_periods
                .saturating_add((start - self.window_start) / period)
        }
    }

    fn advance(&mut self, now: u64) {
        let period = self.period_clocks();
        let start = now / period * period;
        // A stale timestamp must not rewind the accounting window and grant
        // the same CPU quota again. N0's invariant TSC is monotonic, but the
        // state transition still needs to fail closed on an old observation.
        if start > self.window_start {
            if let Some(since) = self.throttled_since.take() {
                self.throttled_clocks = self
                    .throttled_clocks
                    .saturating_add(start.max(since).min(now).saturating_sub(since));
            }
            if self.window_start != 0 && start > self.window_start {
                self.nr_periods = self
                    .nr_periods
                    .saturating_add((start - self.window_start) / period);
            }
            // When a 1000Hz tick preempts after a small quota is spent,
            // discarding the overrun on every period would systematically
            // grant another full quota. Repay *positive* debt from elapsed
            // budgets; do not bank unused runtime as transferable credit.
            let elapsed = start.saturating_sub(self.window_start) / period;
            let allowance = if self.quota_usec == u64::MAX {
                u64::MAX
            } else {
                Self::us_to_clocks(self.quota_usec).saturating_mul(elapsed)
            };
            self.carry_debt_clocks = self.carry_debt_clocks
                .saturating_add(self.used_clocks)
                .saturating_sub(allowance);
            self.window_start = start;
            self.used_clocks = 0;
        }
    }

    /// Settle the positive debt of completed windows touched by a runtime
    /// interval. A timer tick may straddle a quota boundary: charging only
    /// the current window loses the CPU time before that boundary.
    ///
    /// This is O(1), even if the scheduler reports an unusually long interval.
    /// Empty periods repay existing debt but do not accumulate positive credit.
    fn debt_after_crossing(&self, from: u64, new_start: u64, period: u64) -> u64 {
        let quota = Self::us_to_clocks(self.quota_usec);
        let old_end = self.window_start.saturating_add(period);
        let old_spent = old_end.saturating_sub(from.max(self.window_start));
        let mut debt = self
            .carry_debt_clocks
            .saturating_add(self.used_clocks)
            .saturating_add(old_spent)
            .saturating_sub(quota);

        // Completed periods after the old window and before the new one.
        let middle_start = old_end;
        let middle_count = new_start.saturating_sub(middle_start) / period;
        if middle_count == 0 {
            return debt;
        }
        // Process completely idle periods before the first execution period.
        let idle_count = (from.max(middle_start).saturating_sub(middle_start) / period)
            .min(middle_count);
        debt = debt.saturating_sub(quota.saturating_mul(idle_count));
        let first_active = middle_start.saturating_add(period.saturating_mul(idle_count));
        if first_active == new_start {
            return debt;
        }

        // The first non-idle completed period may contain only a suffix of
        // the interval; all remaining completed periods ran continuously.
        let first_spent = first_active
            .saturating_add(period)
            .saturating_sub(from.max(first_active));
        debt = debt.saturating_add(first_spent).saturating_sub(quota);
        let full_count = new_start
            .saturating_sub(first_active.saturating_add(period)) / period;
        if period >= quota {
            debt.saturating_add(period.saturating_sub(quota).saturating_mul(full_count))
        } else {
            debt.saturating_sub(quota.saturating_sub(period).saturating_mul(full_count))
        }
    }

    fn charge(&mut self, from: u64, until: u64) {
        if until < from {
            return;
        }
        let period = self.period_clocks();
        let new_start = until / period * period;
        // Never re-open an earlier accounting window on a backward clock.
        if new_start < self.window_start {
            return;
        }

        // Save the true debt from completed periods before the normal advance
        // updates nr_periods/throttled_usec and resets used_clocks. This avoids
        // counting older idle periods as transferable positive CPU credit.
        let corrected_debt = if new_start > self.window_start
            && self.quota_usec != u64::MAX
        {
            Some(self.debt_after_crossing(from, new_start, period))
        } else {
            None
        };
        self.advance(until);
        if let Some(debt) = corrected_debt {
            self.carry_debt_clocks = debt;
        }
        self.used_clocks = self
            .used_clocks
            .saturating_add(until.saturating_sub(from.max(self.window_start)));
    }

    fn eligible(&mut self, now: u64) -> bool {
        self.advance(now);
        if self.quota_usec == u64::MAX
            || self.used_clocks.saturating_add(self.carry_debt_clocks)
                < Self::us_to_clocks(self.quota_usec)
        {
            if let Some(since) = self.throttled_since.take() {
                self.throttled_clocks = self
                    .throttled_clocks
                    .saturating_add(now.saturating_sub(since));
            }
            return true;
        }
        if self.throttled_since.is_none() {
            self.nr_throttled = self.nr_throttled.saturating_add(1);
            self.throttled_since = Some(now);
        }
        false
    }

    fn reconfigure(&mut self, quota_usec: u64, period_usec: u64, now: u64) {
        self.advance(now);
        let already_used = self.used_clocks;
        self.quota_usec = quota_usec;
        self.period_usec = period_usec;
        let period = self.period_clocks();
        self.window_start = now / period * period;
        self.used_clocks = already_used;
        if quota_usec == u64::MAX {
            if let Some(since) = self.throttled_since.take() {
                self.throttled_clocks = self
                    .throttled_clocks
                    .saturating_add(now.saturating_sub(since));
            }
        }
    }

    fn throttled_usec(&self, now: u64) -> u64 {
        let clocks = self.throttled_clocks.saturating_add(
            self.throttled_since
                .map_or(0, |since| now.saturating_sub(since)),
        );
        (u128::from(clocks) * 1_000_000 / u128::from(tsc_freq()))
            .try_into()
            .unwrap_or(u64::MAX)
    }
}


mod quota_debt_regressions {
    use super::CpuMax;

    fn sample(quota_usec: u64, period_usec: u64, start: u64) -> CpuMax {
        CpuMax {
            quota_usec,
            period_usec,
            window_start: start,
            used_clocks: 0,
            carry_debt_clocks: 0,
            nr_periods: 0,
            nr_throttled: 0,
            throttled_since: None,
            throttled_clocks: 0,
        }
    }

    #[test]
    fn cpu_stat_projection_must_not_close_unsettled_quota_window() {
        let period = CpuMax::us_to_clocks(100_000).max(1);
        let quota = CpuMax::us_to_clocks(1_000);
        let start = period.saturating_mul(2);
        let mut budget = sample(1_000, 100_000, start);
        budget.nr_periods = 7;
        budget.used_clocks = quota.saturating_mul(2);
        budget.throttled_since = Some(start + period / 2);
        let from = start + period - quota / 2;
        let until = start + period + quota / 2;

        // cpu.stat can run while a scheduling interval is not yet charged.
        // Its projected number of periods may change, but it must not
        // mutate used clocks, positive debt, throttling or window origin.
        let before = budget;
        assert_eq!(budget.observed_nr_periods(until), 8);
        assert_eq!(budget.window_start, before.window_start);
        assert_eq!(budget.nr_periods, before.nr_periods);
        assert_eq!(budget.used_clocks, before.used_clocks);
        assert_eq!(budget.carry_debt_clocks, before.carry_debt_clocks);
        assert_eq!(budget.throttled_since, before.throttled_since);

        // The later scheduler debit can still account the old-period tail.
        budget.charge(from, until);
        assert_eq!(budget.window_start, start + period);
        assert_eq!(budget.used_clocks, quota / 2);
        assert_eq!(budget.carry_debt_clocks, quota + quota / 2);
        assert_eq!(budget.nr_periods, 8);
        assert!(!budget.eligible(until));
    }

    #[test]
    fn cpu_stat_projection_cannot_rewind_accounting_or_mint_credit() {
        let period = CpuMax::us_to_clocks(100_000).max(1);
        let quota = CpuMax::us_to_clocks(1_000);
        let start = period.saturating_mul(4);
        let mut budget = sample(1_000, 100_000, start);
        budget.nr_periods = 9;
        budget.used_clocks = quota;
        budget.carry_debt_clocks = quota / 2;
        assert_eq!(budget.observed_nr_periods(start - period / 2), 9);
        assert_eq!(budget.observed_nr_periods(start + 3 * period + 1), 12);
        assert_eq!(budget.window_start, start);
        assert_eq!(budget.used_clocks, quota);
        assert_eq!(budget.carry_debt_clocks, quota / 2);
        // Unlike a statistics read, the real scheduler advances and settles.
        budget.advance(start + 3 * period + 1);
        assert_eq!(budget.nr_periods, 12);
        assert_eq!(budget.carry_debt_clocks, 0);
    }

    #[test]
    fn overrun_must_carry_then_repay_without_refill() {
        let period = CpuMax::us_to_clocks(100_000).max(1);
        let quota = CpuMax::us_to_clocks(1_000);
        let start = period.saturating_mul(2);
        let mut budget = sample(1_000, 100_000, start);
        budget.used_clocks = quota.saturating_mul(2);
        budget.advance(start + period);
        assert_eq!(budget.used_clocks, 0);
        assert_eq!(budget.carry_debt_clocks, quota);
        assert!(!budget.eligible(start + period));
        budget.advance(start + period * 2);
        assert_eq!(budget.carry_debt_clocks, 0);
        assert!(budget.eligible(start + period * 2));
    }

    #[test]
    fn unused_budget_must_not_accumulate_as_credit() {
        let period = CpuMax::us_to_clocks(100_000).max(1);
        let quota = CpuMax::us_to_clocks(1_000);
        let start = period.saturating_mul(2);
        let mut budget = sample(1_000, 100_000, start);
        budget.used_clocks = quota / 2;
        budget.advance(start + period);
        assert_eq!(budget.carry_debt_clocks, 0);
        budget.used_clocks = quota;
        assert!(!budget.eligible(start + period));
    }

    #[test]
    fn reconfiguration_in_same_window_must_not_refill() {
        let period = CpuMax::us_to_clocks(100_000).max(1);
        let quota = CpuMax::us_to_clocks(1_000);
        let start = period.saturating_mul(2);
        let mut budget = sample(1_000, 100_000, start);
        budget.used_clocks = quota;
        budget.carry_debt_clocks = quota / 2;
        let now = start + period / 2;
        budget.reconfigure(1_000, 100_000, now);
        assert_eq!(budget.used_clocks, quota);
        assert_eq!(budget.carry_debt_clocks, quota / 2);
        assert!(!budget.eligible(now));
    }

    #[test]
    fn scheduler_runtime_crossing_tick_window_keeps_previous_cpu_charge() {
        let period = CpuMax::us_to_clocks(100_000).max(1);
        let quota = CpuMax::us_to_clocks(1_000);
        let start = period.saturating_mul(2);
        let mut budget = sample(1_000, 100_000, start);
        // A non-preemptible interval extends two quotas before the 100ms
        // boundary, and another quarter quota into the next period.
        budget.charge(start + period - quota * 2, start + period + quota / 4);
        assert_eq!(budget.window_start, start + period);
        assert_eq!(budget.carry_debt_clocks, quota);
        assert_eq!(budget.used_clocks, quota / 4);
        assert!(!budget.eligible(start + period + quota / 4));
    }

    #[test]
    fn crossing_splits_already_charged_and_new_cpu_without_double_count() {
        let period = CpuMax::us_to_clocks(100_000).max(1);
        let quota = CpuMax::us_to_clocks(1_000);
        let start = period.saturating_mul(2);
        let mut budget = sample(1_000, 100_000, start);
        budget.used_clocks = quota / 2;
        budget.charge(start + period - quota * 3, start + period + quota / 2);
        assert_eq!(budget.carry_debt_clocks, quota * 2 + quota / 2);
        assert_eq!(budget.used_clocks, quota / 2);
    }

    #[test]
    fn idle_skipped_periods_never_subsidize_late_burst() {
        let period = CpuMax::us_to_clocks(100_000).max(1);
        let quota = CpuMax::us_to_clocks(1_000);
        let start = period.saturating_mul(2);
        let mut budget = sample(1_000, 100_000, start);
        let last_completed = start + 6 * period;
        budget.charge(last_completed + period / 2,
                      last_completed + period + quota / 2);
        assert_eq!(budget.window_start, last_completed + period);
        assert_eq!(budget.carry_debt_clocks, period / 2 - quota);
        assert_eq!(budget.used_clocks, quota / 2);
        assert!(!budget.eligible(last_completed + period + quota / 2));
    }

    #[test]
    fn long_continuous_interval_has_constant_time_bounded_debt_accounting() {
        let period = CpuMax::us_to_clocks(100_000).max(1);
        let quota = CpuMax::us_to_clocks(1_000);
        let start = period.saturating_mul(2);
        let mut budget = sample(1_000, 100_000, start);
        budget.charge(start + period / 2, start + 5 * period + quota / 2);
        // First completed period: P/2 work - Q budget. The following four
        // completed periods were fully busy; no per-period heap work or loop.
        let expected = period / 2 - quota + 4 * (period - quota);
        assert_eq!(budget.carry_debt_clocks, expected);
        assert_eq!(budget.used_clocks, quota / 2);
    }

    #[test]
    fn earlier_clock_value_cannot_reopen_or_refill_previous_period() {
        let period = CpuMax::us_to_clocks(100_000).max(1);
        let quota = CpuMax::us_to_clocks(1_000);
        let start = period.saturating_mul(4);
        let mut budget = sample(1_000, 100_000, start);
        budget.used_clocks = quota;
        budget.carry_debt_clocks = quota / 2;
        budget.advance(start - period / 2);
        budget.charge(start - period / 2, start - 1);
        assert_eq!(budget.window_start, start);
        assert_eq!(budget.used_clocks, quota);
        assert_eq!(budget.carry_debt_clocks, quota / 2);
        assert!(!budget.eligible(start));
    }

    #[test]
    fn charging_500_intervals_matches_simple_period_by_period_reference() {
        // Adversarial reference oracle runs only in ktest; the real scheduler
        // hot path remains O(1) even if multiple windows elapsed between ticks.
        fn next(seed: &mut u64) -> u64 {
            *seed = seed
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407);
            *seed
        }

        let period = CpuMax::us_to_clocks(100_000).max(1);
        let start = period.saturating_mul(2);
        let mut seed = 0xA03A06_A11CEu64;
        for _ in 0..500 {
            let quota_us = 1_000 + next(&mut seed) % 99_001;
            let quota = CpuMax::us_to_clocks(quota_us);
            let mut budget = sample(quota_us, 100_000, start);
            let old_used = next(&mut seed) % period;
            let old_debt = next(&mut seed) % period;
            budget.used_clocks = old_used;
            budget.carry_debt_clocks = old_debt;

            let from = start
                + (next(&mut seed) % 10) * period
                + next(&mut seed) % period;
            let until = from + next(&mut seed) % (period * 11);
            let new_start = until / period * period;
            let mut slow_debt = old_debt;
            let mut window = start;
            while window < new_start {
                let work = (window + period)
                    .min(until)
                    .saturating_sub(from.max(window));
                let spent = work + if window == start { old_used } else { 0 };
                slow_debt = slow_debt.saturating_add(spent).saturating_sub(quota);
                window += period;
            }
            let slow_used = if new_start == start {
                old_used.saturating_add(until.saturating_sub(from.max(start)))
            } else {
                until.saturating_sub(from.max(new_start))
            };
            budget.charge(from, until);
            assert_eq!(budget.window_start, new_start);
            assert_eq!(budget.used_clocks, slow_used);
            assert_eq!(budget.carry_debt_clocks, slow_debt);
        }
    }

    #[test]
    fn skipped_periods_pay_down_debt_but_never_mint_credit() {
        let period = CpuMax::us_to_clocks(100_000).max(1);
        let quota = CpuMax::us_to_clocks(1_000);
        let start = period.saturating_mul(2);
        let mut budget = sample(1_000, 100_000, start);
        budget.used_clocks = quota.saturating_mul(3);
        budget.advance(start + period * 4);
        assert_eq!(budget.carry_debt_clocks, 0);
        assert_eq!(budget.used_clocks, 0);
        budget.used_clocks = quota;
        assert!(!budget.eligible(start + period * 4));
    }
}
