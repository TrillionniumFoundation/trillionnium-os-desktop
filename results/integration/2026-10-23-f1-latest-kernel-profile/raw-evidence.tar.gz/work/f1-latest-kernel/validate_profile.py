#!/usr/bin/env python3
"""Host-only qualification of the reviewed F1 source-pair update."""
import ast
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import yaml

ROOT = Path(__file__).resolve().parent
VALIDATION = ROOT / "validation"
CANDIDATE = ROOT / "candidate"
HERE = CANDIDATE / "tests/workloads/hepta_agentd_runtime"
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE))
import test_agentd_runtime as fixture
import run_agentd_runtime as gate

def require(ok, message):
    if not ok:
        raise ValueError(message)

def inventory():
    return {str(p.relative_to(CANDIDATE)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(CANDIDATE.rglob("*")) if p.is_file() and "__pycache__" not in p.parts}

def main():
    before = inventory()
    started = datetime.now(timezone.utc).isoformat()
    command = [sys.executable, "-B", "-m", "unittest", "discover", "-s", str(HERE), "-p", "test_*.py", "-v"]
    result = subprocess.run(command, capture_output=True, timeout=60,
                            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
    for name, raw in (("stdout", result.stdout), ("stderr", result.stderr)):
        (VALIDATION / ("host-suite-02." + name)).write_bytes(raw)
    suite = {"argv": command, "started_at_utc": started,
             "finished_at_utc": datetime.now(timezone.utc).isoformat(), "exit_code": result.returncode,
             "scope": "Unchanged original host tests; retained archive fixture and synthetic inputs, no native execution"}
    (VALIDATION / "host-suite-02.json").write_text(json.dumps(suite, indent=2) + "\n")
    require(result.returncode == 0, result.stderr.decode())
    require(re.search(rb"Ran 42 tests in .*\n\nOK\n", result.stderr) is not None, "unexpected suite or skip count")
    review = json.loads((HERE / "source-review.json").read_bytes())
    old = json.loads((ROOT / "base/tests/workloads/hepta_agentd_runtime/source-review.json").read_bytes())
    tests = []
    for name in ("current_positive", "previous_pair", "previous_desktop_tree", "previous_selected_files", "altered_mount_blob"):
        case = fixture.FrozenInputTests("test_freeze_binds_each_real_file_identity")
        case.setUp()
        try:
            if name == "previous_pair":
                case.value["sources"] = {key: copy.deepcopy(old[key]) for key in ("desktop", "hepta")}
            elif name == "previous_desktop_tree":
                case.value["sources"]["desktop"]["tree"] = old["desktop"]["tree"]
            elif name == "previous_selected_files":
                case.value["source_files"] = old["source_files"]
            elif name == "altered_mount_blob":
                item = next(x for x in case.value["source_files"] if x["path"].endswith("/path/mount.rs"))
                item["git_blob"] = "0" * 40
            error = None
            try:
                case.read()
            except ValueError as exc:
                error = str(exc)
            require((error is None) == (name == "current_positive"), "incorrect profile acceptance: " + name)
            tests.append({"name": name, "accepted": error is None, "error": error,
                          "scope": "Synthetic host fixture; never executed binary or guest"})
        finally:
            case.doCleanups()
    workflow = yaml.safe_load((CANDIDATE / ".github/workflows/f1-original-runtime-native.yml").read_text())
    job = workflow["jobs"]["original-owner-native-lifecycle"]
    require(job["env"]["DESKTOP_SOURCE_PIN"] == review["desktop"]["head"], "Desktop workflow pin drift")
    require(job["env"]["HEPTA_SOURCE_PIN"] == review["hepta"]["head"], "Hepta workflow pin drift")
    require(review["hepta"] == old["hepta"], "Hepta identity must remain unchanged")
    selected = {(x["repository"], x["path"]): x for x in review["source_files"]}
    require(len(selected) == len(review["source_files"]) == 89, "duplicate or unexpected source selections")
    for item in old["source_files"]:
        require(selected[item["repository"], item["path"]] == item, "old selected identity changed")
    shells = []
    for index, step in enumerate(job["steps"]):
        if "run" in step:
            code = re.sub(r"\$\{\{.*?\}\}", "EXPRESSION", step["run"])
            path = VALIDATION / ("workflow-step-%02d.sh" % index)
            path.write_text(code)
            check = subprocess.run(["bash", "-n", str(path)], capture_output=True, timeout=10)
            require(check.returncode == 0, check.stderr.decode())
            shells.append({"step": step.get("name", str(index)), "exit_code": check.returncode})
    python_files = sorted(CANDIDATE.rglob("*.py"))
    for path in python_files:
        ast.parse(path.read_bytes(), filename=str(path))
    after = inventory()
    require(before == after, "source changed during validation")
    record = {"started_at_utc": started, "finished_at_utc": datetime.now(timezone.utc).isoformat(),
              "host_tests": 42, "failed": 0, "ignored": 0, "profile_fixture_controls": tests,
              "workflow_shell_syntax": shells, "python_syntax_files": len(python_files),
              "source_before": before, "source_after": after,
              "desktop": review["desktop"], "hepta": review["hepta"], "selected": 89,
              "kernel_built": False, "guest_executed": False, "f1_complete": False, "g2_complete": False}
    (VALIDATION / "profile-validation.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({k: record[k] for k in ("host_tests", "failed", "ignored", "profile_fixture_controls", "python_syntax_files", "selected", "kernel_built", "guest_executed")}))

if __name__ == "__main__":
    main()
