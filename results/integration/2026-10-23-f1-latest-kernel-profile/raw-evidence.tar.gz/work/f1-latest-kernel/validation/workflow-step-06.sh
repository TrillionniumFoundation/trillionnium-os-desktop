set -euo pipefail
cargo_binary=$(rustup which --toolchain 1.95.0 cargo)
rustc_binary=$(rustup which --toolchain 1.95.0 rustc)
cargo_sha=$(sha256sum "$cargo_binary" | cut -d ' ' -f1)
rustc_sha=$(sha256sum "$rustc_binary" | cut -d ' ' -f1)
kernel_receipt_sha=$(sha256sum "$F1_CI_ROOT/kernel-inputs/kernel-build.json" | cut -d ' ' -f1)
# Dependency prefetch is explicit and uses original locked manifests.
# All builds and fixture resolution then run offline; no ELF is run here.
python3 -I -B tests/workloads/hepta_agentd_runtime/prepare_inputs.py \
  --execute --fetch-dependencies \
  --desktop-source "$F1_CI_ROOT/desktop-source" \
  --hepta-source "$F1_CI_ROOT/hepta-source" \
  --kernel "$F1_CI_ROOT/kernel-inputs/kernel.elf" \
  --kernel-receipt "$F1_CI_ROOT/kernel-inputs/kernel-build.json" \
  --expected-kernel-receipt-sha256 "$kernel_receipt_sha" \
  --cargo "$cargo_binary" --expected-cargo-sha256 "$cargo_sha" \
  --rustc "$rustc_binary" --expected-rustc-sha256 "$rustc_sha" \
  --cargo-home "$CARGO_HOME" --output "$F1_CI_ROOT/frozen-inputs" \
  2>&1 | tee "$F1_CI_ROOT/logs/userspace-preparation.log"
