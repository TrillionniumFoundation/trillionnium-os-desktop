set -euo pipefail
python3 -I -B - <<'PY'
from datetime import datetime, timezone
import json, os, subprocess
from pathlib import Path
root = Path(os.environ["F1_CI_ROOT"])
result = {"recorded_at_utc": datetime.now(timezone.utc).isoformat(),
          "run_url": f'{os.environ["GITHUB_SERVER_URL"]}/{os.environ["GITHUB_REPOSITORY"]}/actions/runs/{os.environ["GITHUB_RUN_ID"]}',
          "run_attempt": os.environ["GITHUB_RUN_ATTEMPT"], "checkouts": {},
          "f1_completed": False, "g2_completed": False, "hardware_verified": False}
for name, source in (("runner", Path(os.environ["GITHUB_WORKSPACE"])),
                     ("desktop", root / "desktop-source"), ("hepta", root / "hepta-source")):
    result["checkouts"][name] = {}
    for key, arguments in (("identity", ["rev-parse", "HEAD", "HEAD^{tree}"]),
                           ("status", ["status", "--porcelain=v1", "--untracked-files=all"])):
        command = subprocess.run(["git", "-C", str(source), *arguments], capture_output=True, text=True, timeout=30)
        result["checkouts"][name][key] = {"exit_code": command.returncode, "stdout": command.stdout, "stderr": command.stderr}
(root / "identity/final.json").write_text(json.dumps(result, indent=2) + "\n")
PY
