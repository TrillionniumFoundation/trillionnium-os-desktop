set -euo pipefail
qemu_binary=$(command -v qemu-system-x86_64)
qemu_sha=$(sha256sum "$qemu_binary" | cut -d ' ' -f1)
manifest_sha=$(sha256sum "$F1_CI_ROOT/frozen-inputs/input-manifest.json" | cut -d ' ' -f1)
python3 -I -B tests/workloads/hepta_agentd_runtime/run_agentd_runtime.py --execute \
  --input-manifest "$F1_CI_ROOT/frozen-inputs/input-manifest.json" \
  --expected-input-manifest-sha256 "$manifest_sha" \
  --initramfs "$F1_CI_ROOT/kernel-inputs/initramfs.cpio.gz" \
  --bios "$F1_CI_ROOT/kernel-inputs/bios.bin" \
  --qemu "$qemu_binary" --expected-qemu-sha256 "$qemu_sha" \
  --memory-mib 4096 --timeout 900 --output "$F1_CI_ROOT/guest" \
  2>&1 | tee "$F1_CI_ROOT/logs/guest-execution.log"
