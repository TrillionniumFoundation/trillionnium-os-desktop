set -euo pipefail
umask 077
test "$RUNNER_OS" = Linux
test "$RUNNER_ARCH" = X64
test "$(uname -m)" = x86_64
ci_root="$RUNNER_TEMP/f1-native-$GITHUB_RUN_ID-$GITHUB_RUN_ATTEMPT"
test ! -e "$ci_root"
mkdir -m 700 "$ci_root"
mkdir -m 700 "$ci_root/logs" "$ci_root/identity" "$ci_root/download" \
  "$ci_root/cargo-home" "$ci_root/rustup-home"
printf 'F1_CI_ROOT=%s\nCARGO_HOME=%s/cargo-home\nRUSTUP_HOME=%s/rustup-home\n' \
  "$ci_root" "$ci_root" "$ci_root" >> "$GITHUB_ENV"
git rev-parse HEAD HEAD^{tree} > "$ci_root/identity/runner-source.txt"
git status --porcelain=v1 --untracked-files=all > "$ci_root/identity/runner-status.txt"
test ! -s "$ci_root/identity/runner-status.txt"
sha256sum tests/workloads/hepta_agentd_runtime/*.py \
  tests/workloads/hepta_agentd_runtime/*.c \
  tests/workloads/hepta_agentd_runtime/source-review.json \
  .github/workflows/f1-original-runtime-native.yml \
  > "$ci_root/identity/runner-inputs.sha256"
