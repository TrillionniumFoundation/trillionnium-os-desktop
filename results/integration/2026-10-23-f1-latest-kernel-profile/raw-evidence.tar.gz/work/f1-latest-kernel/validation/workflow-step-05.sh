set -euo pipefail
review_sha=$(sha256sum tests/workloads/hepta_agentd_runtime/source-review.json | cut -d ' ' -f1)
python3 -I -B tests/workloads/hepta_agentd_runtime/build_kernel.py --execute \
  --desktop-source "$F1_CI_ROOT/desktop-source" \
  --hepta-source "$F1_CI_ROOT/hepta-source" \
  --expected-source-review-sha256 "$review_sha" \
  --cargo-home "$CARGO_HOME" --rustup-home "$RUSTUP_HOME" \
  --target-dir "$F1_CI_ROOT/kernel-target" \
  --vdso "$F1_CI_ROOT/linux-vdso" --output "$F1_CI_ROOT/kernel-inputs" \
  2>&1 | tee "$F1_CI_ROOT/logs/kernel-build-and-boot.log"
