set -euo pipefail
{
  git init "$F1_CI_ROOT/desktop-source"
  git -C "$F1_CI_ROOT/desktop-source" remote add origin \
    https://github.com/TrillionniumFoundation/trillionnium-os-desktop.git
  git -C "$F1_CI_ROOT/desktop-source" -c credential.helper= -c core.askPass= \
    fetch --depth=1 --no-tags origin "$DESKTOP_SOURCE_PIN"
  git -C "$F1_CI_ROOT/desktop-source" checkout --detach "$DESKTOP_SOURCE_PIN"
  git init "$F1_CI_ROOT/hepta-source"
  git -C "$F1_CI_ROOT/hepta-source" remote add origin \
    https://github.com/TrillionniumFoundation/hepta-private-ci.git
  git -C "$F1_CI_ROOT/hepta-source" -c credential.helper= -c core.askPass= \
    fetch --depth=1 --no-tags origin "$HEPTA_SOURCE_PIN"
  git -C "$F1_CI_ROOT/hepta-source" checkout --detach "$HEPTA_SOURCE_PIN"
} 2>&1 | tee "$F1_CI_ROOT/logs/source-checkout.log"
git -C "$F1_CI_ROOT/desktop-source" rev-parse HEAD HEAD^{tree} > "$F1_CI_ROOT/identity/desktop-source.txt"
git -C "$F1_CI_ROOT/hepta-source" rev-parse HEAD HEAD^{tree} > "$F1_CI_ROOT/identity/hepta-source.txt"
