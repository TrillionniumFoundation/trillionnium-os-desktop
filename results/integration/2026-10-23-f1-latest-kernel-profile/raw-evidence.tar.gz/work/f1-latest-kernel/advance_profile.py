#!/usr/bin/env python3
"""Advance only the fresh-build identity; retain all historical receipts."""
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE, CANDIDATE = ROOT / "base", ROOT / "candidate"
REVIEW = "tests/workloads/hepta_agentd_runtime/source-review.json"
WORKFLOW = ".github/workflows/f1-original-runtime-native.yml"
README = "tests/workloads/hepta_agentd_runtime/README.md"
OLD_HEAD = "7d8906ef9fbb5f3af4e6bb0843b79ac666394833"
OLD_TREE = "ca4b875cdb553291a99f4a550eb0b2bd6649de8c"
HEAD = "ce8378b71c426e6f5e0227b65624895cb81212cd"
TREE = "8fe94570ea0ad5d63c44c6c02e5872fa532abcca"
ADDED = [
    "kernel/asterinas/kernel/core/src/fs/vfs/path/mount.rs",
    "tests/workloads/linux/readonly/readonly_probe.c",
    "tests/workloads/linux/readonly/run_guest.py",
    "tests/workloads/linux/remount/remount_probe.c",
    "tests/workloads/linux/remount/run_guest.py",
]

def require(ok, message):
    if not ok:
        raise ValueError(message)

def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def main():
    retrieval = json.loads((ROOT / "latest-retrieval.json").read_text())
    leaves = {item["path"]: item for item in retrieval["current_tree"]["tree"] if item["type"] == "blob"}
    require(not retrieval["current_tree"]["truncated"], "full current tree required")
    review = json.loads((BASE / REVIEW).read_bytes())
    require(review["desktop"] == {"head": OLD_HEAD, "tree": OLD_TREE}, "unexpected old pair")
    retained = review["source_files"].copy()
    require(len(retained) == 84, "unexpected selected-source preimage")
    for item in retained:
        if item["repository"] == "desktop":
            require(leaves[item["path"]]["sha"] == item["git_blob"], "existing reviewed Desktop source changed")
    require(not set(ADDED) & {item["path"] for item in retained}, "new selections overlap old review")
    for path in ADDED:
        data = (BASE / path).read_bytes()
        require(blob(data) == leaves[path]["sha"], "new selected source differs from Git tree")
        review["source_files"].append({"git_blob": blob(data), "path": path,
                                       "repository": "desktop", "sha256": hashlib.sha256(data).hexdigest()})
    review["source_files"].sort(key=lambda item: (item["repository"], item["path"]))
    review["desktop"] = {"head": HEAD, "tree": TREE}
    review["scope"] = ("Reviewed integration source identities for an actual ordinary kernel build with UDP, exec argument, "
                       "family user-frame, stopped-stack, readonly and rejected unsupported live-readonly-transition fixes, "
                       "plus original Hepta owners and the Oct 23 recovery/issuer/composition stack. The readonly/remount "
                       "probe and runner identities are selected source inputs, not evidence that those probes ran. "
                       "Selected-file provenance and clean Git checks are not execution or production authority receipts.")
    (CANDIDATE / REVIEW).write_text(json.dumps(review, indent=2) + "\n")
    workflow = (BASE / WORKFLOW).read_text()
    require(workflow.count("DESKTOP_SOURCE_PIN: " + OLD_HEAD) == 1, "workflow preimage changed")
    (CANDIDATE / WORKFLOW).write_text(workflow.replace("DESKTOP_SOURCE_PIN: " + OLD_HEAD, "DESKTOP_SOURCE_PIN: " + HEAD))
    readme = (BASE / README).read_text()
    require(readme.count(OLD_HEAD) == readme.count(OLD_TREE) == 1, "README profile preimage changed")
    readme = readme.replace(OLD_HEAD, HEAD).replace(OLD_TREE, TREE)
    old = "argument, family user-frame, initial-stack and readonly fixes and the Oct 23\noriginal-owner recovery/issuer/composition stack. The 84 selected source\nidentities are a review input, not a runtime receipt."
    new = "argument, family user-frame, initial-stack, readonly and unsupported live\nreadonly-transition rejection fixes and the Oct 23 original-owner\nrecovery/issuer/composition stack. All 84 previous selections are retained\nunchanged; the mount transition implementation and the two readonly/remount\nprobe and runner pairs bring the selection to 89 source identities. They are\nreview inputs. This profile does not claim that the 57-case readonly or\n37-case remount guest regressions have executed.\n\nThe previous `7d8906ef9fbb5f3af4e6bb0843b79ac666394833` profile predates the\nlive-transition rejection. Its kernel and lifecycle receipts cannot qualify\nthis source pair. The workflow checkout pin and this manifest must advance\ntogether; the existing exact source, clean-tree and build-receipt checks stay\nmandatory. Hepta's source identity and the separate retained archive profile\nare unchanged."
    require(old in readme, "README text preimage changed")
    (CANDIDATE / README).write_text(readme.replace(old, new))
    paths = [WORKFLOW, README, REVIEW]
    patch, entries = [], []
    for path in paths:
        before, after = (BASE / path).read_bytes(), (CANDIDATE / path).read_bytes()
        patch += difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), "a/" + path, "b/" + path)
        entries.append({"path": path, "mode": "100644", "type": "blob", "preimage": blob(before),
                        "sha": blob(after), "sha256": hashlib.sha256(after).hexdigest(),
                        "bytes": len(after), "content": after.decode()})
    (ROOT / "source-entries.json").write_text(json.dumps(entries, ensure_ascii=False, indent=2) + "\n")
    (ROOT / "profile.patch").write_text("".join(patch))
    print(json.dumps({"changed": len(entries), "previous_selected": len(retained), "selected": len(review["source_files"]), "added": ADDED, "desktop": review["desktop"], "hepta": review["hepta"]}))

if __name__ == "__main__":
    main()
