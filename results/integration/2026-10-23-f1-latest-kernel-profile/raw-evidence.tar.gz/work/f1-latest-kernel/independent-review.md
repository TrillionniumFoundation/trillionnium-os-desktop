# F1 latest-kernel profile 独立审查

**结论：这组三文件增量未发现阻止发布的确定错误。** 本次只读核对保留的来源记录、候选字节、补丁和原验证输出；没有运行 Cargo、kernel、guest 或 GitHub 操作，也没有修改候选。

- `source-entries.json` 恰好包含 workflow、runtime README、`source-review.json` 三个文件。逐项重算 UTF-8 字节数、SHA-256、Git blob 与前像，均匹配；重新计算的完整 unified diff 与 `profile.patch` 相等。base/candidate 的已有文件差异也恰好是这三项。
- workflow、README、source manifest 一致采用 Desktop `ce8378b71c426e6f5e0227b65624895cb81212cd` / tree `8fe94570ea0ad5d63c44c6c02e5872fa532abcca`。tree 身份与保留的 commit readback 相同，全部 Desktop 选中 blob 与保留的该版本完整 tree 条目一致。Hepta 仍为 `b3d3f2d4b01f123d7ac17575c27fb54d00094f7f` / tree `b035a577969cb503d7c09620694a6b6c54178c97`。
- 原 84 条选中记录逐字段完全保留，无重名或替换。新增恰为 `mount.rs`、readonly probe/runner、remount probe/runner 共五条，形成 89 条；五个本地输入的 SHA-256 和 Git blob 均与新增记录相同。
- README 与 manifest 明确区分来源选择和执行证据：没有把旧 `7d8906` kernel/lifecycle 收据提升为新 pair 的资格，也没有声称 57-case readonly、37-case remount guest 已执行。实际 `profile-validation.json` 的 kernel、guest、F1、G2 完成标志均为 false。
- 原 host suite 首轮 `01` 的 42 项中 1 error 原日志保留；错误为缺少历史 initramfs fixture。补齐后 `02` 的真实 stderr 为 `Ran 42 tests ... OK`，无 skip。四个 profile 拒绝项明确标为 synthetic host controls，验证脚本确实分别更换旧 pair、旧 tree、旧选中文件集合及 mount blob 后要求拒绝。未将这些检查描述为二进制或 guest 运行。
- candidate 多出的 initramfs 是已登记历史测试输入：1,107,990 字节、Git blob `d96438b6a33186ab1d2c906f6cbc04710f962a74`、SHA-256 `86be65ab9234cd20ea6ec8d44a12b8765fd7a3e241fde920c71b3621ca0047f3`；独立核对与 `work/native-kernel` 保留原件逐字相等。它不在三项 source entries 中。`retained-source-review.json` 及已有 runner/test 字节保持不变。
- 独立核对验证收据的全部 `source_before == source_after`，并逐文件确认当前候选仍等于该 final hash 集合。

审查输入 SHA-256：

| 文件 | SHA-256 |
| --- | --- |
| `source-entries.json` | `bf66df96258fa1b0c9a85f9906c3fa0318bb2566d78a4f0a0348a89722c38170` |
| `profile.patch` | `fb843741a82dfc6b550e3454ec83f6422fa233520a3b2f65b4f09c8c31e0c0c9` |
| `validation/profile-validation.json` | `daf01297e01c475438d03549ec574482c56fe016040965b37d5248878372c51b` |

本结论支持该来源 profile 增量的身份与证据表述；新 pair 的实际原 kernel 构建和 guest 生命周期资格仍待对应执行。
