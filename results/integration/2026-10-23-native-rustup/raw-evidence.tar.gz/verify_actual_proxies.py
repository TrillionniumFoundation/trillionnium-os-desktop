#!/usr/bin/env python3
"""Exercise the workflow's exact proxy bootstrap with an existing official toolchain.

No installation, network, Cargo build, kernel, or guest runs are performed.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
RUSTUP = Path('/tmp/hepta-native-cargo/bin/rustup')
RUSTUP_SHA = '5be191e8c70a5007074254cb74d78dbfdd25cd5a61c27de7b8e5410122ec24f4'
TOOLCHAIN_HOME = Path('/dev/shm/organ-3d6a75235bcb-objective-tests/rustup-home')
assert hashlib.sha256(RUSTUP.read_bytes()).hexdigest() == RUSTUP_SHA
stanza = (ROOT / 'bootstrap-stanza.sh').read_text()
workflow = (ROOT / 'change/.github/workflows/f1-original-runtime-native.yml').read_text()
assert ''.join('            ' + line + '\n' for line in stanza.splitlines()) in workflow
report = {'started_at_utc': datetime.now(timezone.utc).isoformat(),
          'rustup_sha256': RUSTUP_SHA, 'toolchain': '1.95.0',
          'workflow_sha256': hashlib.sha256(workflow.encode()).hexdigest(),
          'scope': 'actual Rustup proxies and existing official Rust 1.95; no network/toolchain installation/build/guest',
          'commands': []}
out = ROOT / 'validation'; out.mkdir(exist_ok=True)

def run(label, command, environment):
    result = subprocess.run(command, env=environment, cwd=ROOT,
                            text=True, capture_output=True, timeout=60)
    (out / (label + '.stdout')).write_text(result.stdout)
    (out / (label + '.stderr')).write_text(result.stderr)
    record = {'label': label, 'command': command, 'exit_code': result.returncode,
              'stdout_sha256': hashlib.sha256(result.stdout.encode()).hexdigest(),
              'stderr_sha256': hashlib.sha256(result.stderr.encode()).hexdigest()}
    report['commands'].append(record)
    return result

with tempfile.TemporaryDirectory(prefix='organ-rustup-proxies-') as directory:
    ci_root = Path(directory)
    (ci_root / 'cargo-home').mkdir()
    (ci_root / 'identity').mkdir()
    env = {**os.environ, 'CARGO_HOME': str(ci_root / 'cargo-home'),
           'RUSTUP_HOME': str(TOOLCHAIN_HOME), 'RUSTUP_TOOLCHAIN': '1.95.0',
           'RUSTUP_AUTO_INSTALL': '0', 'PATH': str(ci_root / 'cargo-home/bin') + ':/usr/bin:/bin:/usr/sbin:/sbin'}
    commands = [('rustc', ['rustc', '-Vv']), ('cargo', ['cargo', '-Vv']),
                ('rustup', ['rustup', 'component', 'list', '--installed'])]
    for name, command in commands:
        result = run('before-' + name, ['/bin/bash', '-c', 'exec "$@"', 'probe', *command], env)
        assert result.returncode == 127, (name, result.returncode, result.stdout, result.stderr)
    bootstrap_env = {**env, 'PATH': str(RUSTUP.parent) + ':/usr/bin:/bin:/usr/sbin:/sbin',
                     'ci_root': str(ci_root), 'GITHUB_PATH': str(ci_root / 'github-path')}
    bootstrap = run('bootstrap', ['/bin/bash', '-euo', 'pipefail', str(ROOT / 'bootstrap-stanza.sh')], bootstrap_env)
    assert bootstrap.returncode == 0, bootstrap.stderr
    assert hashlib.sha256((ci_root / 'cargo-home/bin/rustup').read_bytes()).hexdigest() == RUSTUP_SHA
    assert (ci_root / 'cargo-home/bin/rustup').resolve() == RUSTUP.resolve()
    for name, command in commands:
        result = run('after-' + name, ['/bin/bash', '-c', 'exec "$@"', 'probe', *command], env)
        assert result.returncode == 0, (name, result.returncode, result.stdout, result.stderr)
    report['proxy_links'] = {name: os.readlink(ci_root / 'cargo-home/bin' / name)
                             for name in ('cargo', 'rustc', 'rustdoc')}
    report['isolated_cargo_home'] = str(ci_root / 'cargo-home')

report['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
report['passed'] = True
(out / 'actual-proxy-validation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': True, 'before_failures': 3, 'after_successes': 3,
                  'toolchain_installation_executed': False, 'kernel_executed': False}))
