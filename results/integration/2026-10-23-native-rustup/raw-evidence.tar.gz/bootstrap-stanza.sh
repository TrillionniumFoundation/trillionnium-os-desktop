rustup_binary=$(command -v rustup)
mkdir -p "$CARGO_HOME/bin"
for proxy in rustup cargo rustc rustdoc; do
  ln -s "$rustup_binary" "$CARGO_HOME/bin/$proxy"
done
