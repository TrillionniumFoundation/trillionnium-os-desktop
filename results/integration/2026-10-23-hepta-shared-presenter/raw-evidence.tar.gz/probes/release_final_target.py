#!/usr/bin/env python3
"""Hash and remove only this task's completed, reproducible build target."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil


ROOT = Path(__file__).resolve().parents[1]
TARGET = Path("/dev/shm/trill-shared-presenter/target")
OUTPUT = ROOT / "validation/target-release-final.json"


def sha_file(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            value.update(chunk)
    return value.hexdigest()


def main():
    if OUTPUT.exists() or TARGET.is_symlink() or TARGET.resolve() != TARGET:
        raise ValueError("refusing overwritten receipt or unexpected target path")
    for name in ("final-core-and-shell-font-v1", "final-shell-default-font-v1",
                 "final-clippy-default-v3", "final-clippy-candidate-v3", "final-source-after-v1"):
        receipt = json.loads((ROOT / "validation" / (name + ".json")).read_text())
        if receipt.get("passed") is not True or receipt.get("exit") != 0:
            raise ValueError("final execution gate has not completed successfully")
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            executable = (entry / "exe").resolve()
        except (OSError, RuntimeError):
            continue
        if executable.is_relative_to(TARGET):
            raise ValueError("an executable from this task's target is still running")
    before = os.statvfs(TARGET)
    files = []
    for path in sorted(TARGET.rglob("*")):
        if path.is_symlink():
            files.append({"path": path.relative_to(TARGET).as_posix(), "symlink": os.readlink(path)})
        elif path.is_file():
            files.append({"path": path.relative_to(TARGET).as_posix(),
                          "bytes": path.stat().st_size, "sha256": sha_file(path)})
    result = {
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Only task-owned reproducible target; source, original Git checkout, Cargo cache and all execution receipts retained.",
        "target": str(TARGET), "file_count": len(files),
        "regular_file_bytes": sum(row.get("bytes", 0) for row in files),
        "shm_free_before": before.f_bavail * before.f_frsize,
        "files": files, "script_sha256": sha_file(Path(__file__)),
    }
    OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
    shutil.rmtree(TARGET)
    after = os.statvfs(TARGET.parent)
    result.update(target_removed=not TARGET.exists(), shm_free_after=after.f_bavail * after.f_frsize)
    result["shm_free_delta_bytes"] = result["shm_free_after"] - result["shm_free_before"]
    OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "files"}, indent=2))


if __name__ == "__main__":
    main()
