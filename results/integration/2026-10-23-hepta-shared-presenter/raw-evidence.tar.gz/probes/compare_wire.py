#!/usr/bin/env python3
"""Compare actual immutable gate output; only equal original bytes become golden."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original", required=True)
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--write-golden", action="store_true")
    args = parser.parse_args()
    base = Path(__file__).resolve().parents[1]
    directory = base / "validation"
    if not args.name or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in args.name):
        parser.error("use an evidence basename")
    output = directory / (args.name + ".json")
    if output.exists():
        parser.error("refusing to overwrite evidence")
    streams, receipts = {}, {}
    for kind, name in (("original", args.original), ("candidate", args.candidate)):
        receipt = directory / (name + ".json")
        record = json.loads(receipt.read_text())
        if not record["passed"] or record["exit"] != 0 or record["stopped"] is not None:
            raise ValueError(kind + " execution did not pass")
        if record["source_before"] != record["source_after"] or not record["source_unchanged"]:
            raise ValueError(kind + " execution changed source")
        path = directory / (name + ".stdout")
        streams[kind] = path.read_bytes()
        receipts[kind] = {"path": str(receipt), "sha256": sha(receipt.read_bytes()),
                          "stdout_path": str(path), "stdout_sha256": sha(streams[kind])}
    old, new = (json.loads(streams[kind]) for kind in ("original", "candidate"))
    if len(old) != 52 or len(new) != 52 or set(old) != set(new):
        raise ValueError("the two actual corpora must contain the same 52 named cases")
    if not all(isinstance(value, str) for corpus in (old, new) for value in corpus.values()):
        raise ValueError("unexpected corpus value type")
    differences = {name: {"original": old[name], "candidate": new[name]}
                   for name in old if old[name] != new[name]}
    equal = streams["original"] == streams["candidate"]
    record = {"at": datetime.now(timezone.utc).isoformat(),
              "command_arguments": vars(args), "script_sha256": sha(Path(__file__).read_bytes()),
              "receipts": receipts, "case_count": len(old), "case_differences": differences,
              "exact_stdout_bytes_equal": equal, "passed": equal,
              "scope": "Bounded real Desktop IPC/observer corpus; no production admission, device or renderer qualification."}
    if args.write_golden and equal:
        target = base / "tests/ui/wire-compatibility-v1.json"
        with target.open("xb") as destination:
            destination.write(streams["original"])
        record["golden"] = {"path": str(target), "sha256": sha(target.read_bytes()),
                            "origin": "verbatim original-source/original-lock actual stdout"}
    output.write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(record, indent=2, ensure_ascii=False))
    return 0 if equal else 1


if __name__ == "__main__":
    raise SystemExit(main())
