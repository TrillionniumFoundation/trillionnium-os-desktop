#!/usr/bin/env python3
"""Plan, then explicitly restore the official toolchain after the build window opens."""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parents[1]
RUSTUP = Path("/tmp/hepta-native-cargo/bin/rustup")
RUSTUP_HOME = Path("/dev/shm/organ-3d6a75235bcb-objective-tests/rustup-home")
TOOLCHAIN = RUSTUP_HOME / "toolchains/1.88.0-x86_64-unknown-linux-gnu"
EXPECTED = {
    "rustc": "ac3e92e45fe15c789939deedf7614f4f9578cc9609cb9ead39c9b1808a316c5b",
    "cargo": "de9be4299324f5c1f5d12103792d35e8b8ab195df3a374194b8ffc33562c7e3d",
    "clippy-driver": "a7a873792a901a1c916939dfbaa56d6ca64c1458bc883c1d01b6efe7ba6aea81",
}
RUSTUP_SHA256 = "5be191e8c70a5007074254cb74d78dbfdd25cd5a61c27de7b8e5410122ec24f4"
COMMAND = [str(RUSTUP), "toolchain", "install", "1.88.0", "--profile", "minimal",
           "--component", "rustfmt", "--component", "clippy", "--no-self-update"]
ENVIRONMENT = {
    "RUSTUP_HOME": str(RUSTUP_HOME),
    # The already installed rustup is here. This avoids the previous successful
    # component install ending with an unrelated missing-rustup CARGO_HOME error.
    "CARGO_HOME": "/tmp/hepta-native-cargo",
    "RUSTUP_DIST_SERVER": "https://static.rust-lang.org",
    "RUSTUP_UPDATE_ROOT": "https://static.rust-lang.org/rustup",
    "RUSTUP_CONCURRENT_DOWNLOADS": "1",
    "RUSTUP_DOWNLOAD_TIMEOUT": "120",
    "RUSTUP_TERM_COLOR": "never",
}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resources():
    memory = {line.split(":")[0]: int(line.split()[1]) * 1024
              for line in Path("/proc/meminfo").read_text().splitlines()}
    stat = os.statvfs("/dev/shm")
    return {"memory_available": memory["MemAvailable"],
            "shm_free": stat.f_bavail * stat.f_frsize}


def stop(process):
    if process is None or process.poll() is not None:
        return
    os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(5)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true",
                        help="Use only after root grants the resource window.")
    parser.add_argument("--name", default="official-rust188-restore-v1")
    args = parser.parse_args()
    if not args.name or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in args.name):
        parser.error("name must use lowercase letters, digits and hyphens")
    plan = {"status": "plan-only; no download or installation performed",
            "execution_requirement": "Use require_escalated for the shared /dev/shm mount; ordinary sandbox /dev/shm is different.",
            "command": COMMAND, "environment": ENVIRONMENT,
            "toolchain_directory": str(TOOLCHAIN), "expected_binary_sha256": EXPECTED,
            "rustup_binary_sha256": RUSTUP_SHA256,
            "expected_installed_bytes_from_prior_receipt": 602060632,
            "prior_identity_receipt": "work/objective-session/validation/toolchain-release-for-original-agentd.json",
            "minimum_start_shm_free_bytes": 1100 * 1024 * 1024,
            "minimum_start_memory_available_bytes": 2 * 1024 ** 3,
            "deadline_seconds": 300}
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return 0

    validation = BASE / "validation"
    outputs = [validation / f"{args.name}.{suffix}" for suffix in ("json", "stdout", "stderr")]
    if any(path.exists() for path in outputs):
        parser.error("refusing to overwrite an earlier execution receipt")
    result = dict(plan, status="failed", started_utc=datetime.now(timezone.utc).isoformat())
    result["script_sha256"] = sha256(Path(__file__))
    result["execution_namespace"] = {
        "uid": os.getuid(), "euid": os.geteuid(),
        "dev_shm_device": os.stat("/dev/shm").st_dev,
        "dev_shm_mountinfo": [line for line in Path("/proc/self/mountinfo").read_text().splitlines()
                              if line.split()[4] == "/dev/shm"],
    }
    process = None
    began = time.monotonic()
    try:
        if sha256(RUSTUP) != RUSTUP_SHA256:
            raise ValueError("cached rustup binary identity changed")
        result["resources_before"] = resources()
        if result["resources_before"]["shm_free"] < plan["minimum_start_shm_free_bytes"]:
            raise ValueError("insufficient RAM filesystem space before installation")
        if result["resources_before"]["memory_available"] < plan["minimum_start_memory_available_bytes"]:
            raise ValueError("insufficient available RAM before installation")
        env = os.environ.copy()
        env.update(ENVIRONMENT)
        with outputs[1].open("x") as stdout, outputs[2].open("x") as stderr:
            process = subprocess.Popen(COMMAND, env=env, cwd=BASE, stdout=stdout, stderr=stderr,
                                       start_new_session=True)
            while process.poll() is None:
                current = resources()
                if current["shm_free"] < 256 * 1024 * 1024:
                    raise ValueError("RAM filesystem free space below 256 MiB during installation")
                if current["memory_available"] < 1536 * 1024 * 1024:
                    raise ValueError("available RAM below 1.5 GiB during installation")
                if time.monotonic() - began > plan["deadline_seconds"]:
                    raise ValueError("bounded installation deadline exceeded")
                time.sleep(1)
            result["installer_exit"] = process.returncode
        if process.returncode != 0:
            raise ValueError("official rustup command failed; do not infer toolchain qualification")
        result["binary_sha256"] = {name: sha256(TOOLCHAIN / "bin" / name)
                                    for name in (*EXPECTED, "rustfmt")}
        if any(result["binary_sha256"][name] != digest for name, digest in EXPECTED.items()):
            raise ValueError("restored binaries differ from the previously executed official toolchain")
        result["versions"] = {}
        for name, flag in (("rustc", "-Vv"), ("cargo", "-Vv"),
                           ("clippy-driver", "-V"), ("rustfmt", "--version")):
            result["versions"][name] = subprocess.check_output(
                [str(TOOLCHAIN / "bin" / name), flag], env=env, text=True, timeout=15)
        if not result["versions"]["rustc"].startswith("rustc 1.88.0 "):
            raise ValueError("unexpected compiler version")
        result["status"] = "passed; official toolchain restored and exact binary identities verified"
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        result["error"] = str(error)
    finally:
        stop(process)
        if process is not None:
            result["installer_exit"] = process.returncode
        result["elapsed_seconds"] = time.monotonic() - began
        result["resources_after"] = resources()
        outputs[0].write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if result["status"].startswith("passed;") else 1


if __name__ == "__main__":
    sys.exit(main())
