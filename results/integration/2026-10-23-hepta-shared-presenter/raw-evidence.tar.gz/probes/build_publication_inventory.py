#!/usr/bin/env python3
"""List source and execution archive entries separately; never write remotely."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PREFIX = "results/integration/2026-10-23-hepta-shared-presenter"


def record(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def entry(local, remote):
    data = local.read_bytes()
    data.decode("utf-8")  # This inventory is deliberately text-only.
    return {"local_path": str(local), "path": remote, **record(data)}


def main():
    output = ROOT / "release/publication-manifest.json"
    archive_path = ROOT / "release/archive-manifest.json"
    if output.exists() or archive_path.exists():
        raise ValueError("refusing to replace a frozen publication inventory")
    source = json.loads((ROOT / "patches/review-manifest.json").read_text())
    proof = json.loads((ROOT / "publication/root-source-readback.json").read_text())
    if (proof["source_head"] != "0618dc8154e8b78cb91c5aa5558c597232d68023"
            or proof["source_entries"] != 26 or proof["expected_leaves"] != proof["actual_leaves"]
            or proof["full_readback_mismatches"]):
        raise ValueError("source publication proof is not the selected exact candidate")
    sources = []
    for row in source["files"]:
        value = entry(ROOT / row["path"], row["path"])
        if any(value[key] != row["after"][key] for key in ("bytes", "sha256", "git_blob")):
            raise ValueError("source changed after final freeze")
        value["before"] = row["before"]
        sources.append(value)
    selected = set()
    for path in (ROOT / "validation").rglob("*"):
        if path.is_file() and path.suffix != ".otf":
            selected.add(path)
    selected.update(path for path in (ROOT / "patches").iterdir() if path.is_file())
    for name in (
        "probes/run_stage.py", "probes/restore_rust_188.py", "probes/compare_wire.py",
        "probes/review_resource_consumers.py", "probes/make_review_bundle.py",
        "probes/check_final_source_scope.py", "probes/check_release_source_scope.py",
        "probes/finalize_evidence.py", "probes/provision_test_font.py",
        "probes/release_final_target.py", "probes/git-bin/git",
        "probes/final-validation-plan.json", "probes/build_publication_inventory.py",
        "research/makepad-integration/COMPOSITION_DESIGN.md",
        "research/makepad-integration/review-v2.json",
        "publication/root-source-readback.json",
        "desktop-ui-tree.json", "desktop-services-tree.json", "desktop-libs-tree.json",
        "desktop-tests-tree.json", "desktop-support-tree.json",
    ):
        selected.add(ROOT / name)
    archives = [entry(path, PREFIX + "/" + path.relative_to(ROOT).as_posix()) for path in sorted(selected)]
    archives.append(entry(ROOT / "release/README.md", PREFIX + "/README.md"))
    inventory = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "status": "Frozen text archive of actual local execution, historical failures and separate future renderer design; not new execution.",
        "source_commit": proof["source_head"], "source_tree": proof["tree"],
        "source_files": 26, "archive_prefix": PREFIX,
        "excluded_input": {"path": "validation/font-input/NotoSansSC-Regular.otf",
                           "reason": "Public immutable binary input is retained locally; exact URL, SHA256, original manifest and license declarations are archived. This text-only source/evidence commit does not bundle a new font into the product."},
        "files": archives, "text_files": len(archives), "text_bytes": sum(row["bytes"] for row in archives),
    }
    archive_path.write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + "\n")
    archives.append(entry(archive_path, PREFIX + "/archive-manifest.json"))
    publication = {
        "source_commit_already_published_by_root": proof["source_head"],
        "source_entries": sources,
        "archive_entries": archives,
        "source_entry_count": len(sources), "archive_entry_count": len(archives),
        "archive_bytes": sum(row["bytes"] for row in archives),
        "scope": "Source entries and follow-up archive entries are distinct. This script publishes nothing and does not change the 26 source files.",
    }
    output.write_text(json.dumps(publication, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"manifest": str(output), "source_entries": len(sources), "archive_entries": len(archives),
                      "archive_bytes": publication["archive_bytes"], "remote_write": False}))


if __name__ == "__main__":
    main()
