#!/usr/bin/env python3
"""Read-only source/consumer review; no Cargo, IPC, signature or device execution."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
HOST = ROOT.parent / "owner-adapter/change/services/hepta-session-host"
OUT = ROOT / "validation/host-resources-consumer-review-v1.json"


def identity():
    result = {}
    for base in (ROOT / "ui", ROOT / "services/hepta-os", ROOT / "libs/os-abi", HOST):
        for path in sorted(base.rglob("*")):
            if path.is_file() and (path.suffix in (".rs", ".toml") or path.name == "Cargo.lock"):
                data = path.read_bytes()
                result[str(path)] = {"sha256": hashlib.sha256(data).hexdigest(),
                                     "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
                                     "bytes": len(data)}
    return result


def main():
    if OUT.exists():
        raise ValueError("refusing to overwrite evidence")
    before = identity()
    searches = [
        ["rg", "-n", "--glob", "*.rs", r"\bHostResources\b|\bload_average_1m\b", "ui"],
        ["rg", "-n", "--glob", "*.rs", r"Response::Snapshot|\bresources\b", "ui/shell/src", "ui/session/src"],
        ["rg", "-n", "--glob", "*.rs", r"write_frame|read_frame|request_at|serde_json::(?:to_|from_)", "ui"],
        ["rg", "-n", "--glob", "*.rs", r"sha2|Sha256|digest|signature|checksum|hash|canonical", "ui", "services/hepta-os", "libs/os-abi"],
        ["rg", "-n", "--glob", "*.rs", r"\bHostResources\b|\bload_average_1m\b", "services/hepta-os", "libs/os-abi", str(HOST)],
    ]
    commands = []
    for command in searches:
        run = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        if run.returncode not in (0, 1):
            raise ValueError("rg failed: " + run.stderr)
        commands.append({"command": command, "cwd": str(ROOT), "exit": run.returncode,
                         "stdout": run.stdout, "stderr": run.stderr,
                         "meaning_of_exit_1": "No pattern match; not a build/test result."})
    snippets = {}
    ranges = {
        "ui/core/src/lib.rs": [(257, 310), (450, 490)],
        "ui/session/src/main.rs": [(548, 574), (660, 711)],
        "ui/shell/src/main.rs": [(344, 415), (750, 777)],
        "ui/session/src/bin/trill-ctl.rs": [(70, 93)],
        "ui/core/src/conversation.rs": [(1, 100)],
    }
    for relative, sections in ranges.items():
        lines = (ROOT / relative).read_text().splitlines()
        snippets[relative] = [
            {"first_line": start, "last_line": end,
             "text": "\n".join(f"{number}: {lines[number-1]}" for number in range(start, min(end, len(lines)) + 1))}
            for start, end in sections
        ]
    metadata_path = ROOT / "validation/final-metadata-v1.stdout"
    metadata = json.loads(metadata_path.read_text())
    after = identity()
    record = {
        "at": datetime.now(timezone.utc).isoformat(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "desktop_source_base": "64736996d310d597ffba513ee109264cd5f5f83f",
        "scope": "Current local Rust package source plus the separate host adapter; checked-in consumers only, no claim about unknown external consumers.",
        "operation": "Read source and execute rg only; no Rust/Cargo, network, Session, owner or device execution.",
        "local_packages_from_actual_metadata": [
            {"name": package["name"], "manifest_path": package["manifest_path"]}
            for package in metadata["packages"] if package["source"] is None
        ],
        "metadata_sha256": hashlib.sha256(metadata_path.read_bytes()).hexdigest(),
        "source_before": before, "source_after": after, "source_unchanged": before == after,
        "searches": commands, "read_snippets": snippets,
        "review_findings": [
            "The load field is produced from /proc/loadavg, returned as HostResources inside typed Response::Snapshot, and consumed as a Shell observation label.",
            "The CLI also reserializes/pretty-prints the typed Response. It is a known JSON-text consumer; unknown external scripts cannot be certified by this source review.",
            "Known local transport applies UID checks and a bounded newline frame, then deserializes Response. No checked-in hash/signature/canonical identity consumes HostResources JSON.",
            "Draft/context structures retain task/runtime references, not HostResources. Original signed Objective strings, digest bindings and owner receipts are separate types and paths.",
            "Frame byte length remains sensitive to the added exponent character. The existing limit/refusal is preserved; this is not a promise that every near-limit frame remains the same length.",
            "The wire conclusion is 51 identical cases plus one exact equal-valued exponent token in this 52-case corpus, not universal decimal-parser or byte equivalence.",
        ],
    }
    OUT.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"path": str(OUT), "source_files": len(before), "source_unchanged": before == after,
                      "search_statuses": [item["exit"] for item in commands]}))
    return 0 if before == after else 1


if __name__ == "__main__":
    raise SystemExit(main())
