#!/usr/bin/env python3
"""Fetch one exact upstream-manifested font for the existing explicit host test."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parents[1]
UPSTREAM = Path("/dev/shm/trill-shared-presenter/cargo/git/checkouts/hepta-private-ci-4e02da04eb01edbd/56630b1")
COMMIT = "56630b12b8a4c69fff2c47b95b36d88a7389c39f"
PREFIX = "apps/hepta-control-ui/rust/robrix-ui/resources/fonts/"
OUT = ROOT / "validation/font-input"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def record(data):
    return {"bytes": len(data), "sha256": digest(data),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def main():
    receipt = ROOT / "validation/pinned-font-input-v1.json"
    if receipt.exists() or OUT.exists():
        raise ValueError("refusing to overwrite an existing font input or receipt")
    actual = subprocess.check_output(["git", "-C", str(UPSTREAM), "rev-parse", "HEAD"], text=True).strip()
    if actual != COMMIT:
        raise ValueError("font manifest is not from the selected original Git commit")
    source = {}
    for name in ("MANIFEST.json", "OFL.txt", "NOTICE.txt"):
        original = subprocess.check_output(["git", "-C", str(UPSTREAM), "show", COMMIT + ":" + PREFIX + name])
        if (UPSTREAM / PREFIX / name).read_bytes() != original:
            raise ValueError("original font declaration has been edited")
        source[name] = original
    manifest = json.loads(source["MANIFEST.json"])
    for name, field in (("OFL.txt", "license"), ("NOTICE.txt", "notice")):
        if len(source[name]) != manifest[field]["bytes"] or digest(source[name]) != manifest[field]["sha256"]:
            raise ValueError("the original font notice no longer matches its manifest")
    entries = [item for item in manifest["assets"] if item["file"] == "NotoSansSC-Regular.otf"]
    if len(entries) != 1:
        raise ValueError("exactly one original regular-font declaration is required")
    entry = entries[0]
    expected = {
        "url": "https://raw.githubusercontent.com/notofonts/noto-cjk/523d033d6cb47f4a80c58a35753646f5c3608a78/Sans/SubsetOTF/SC/NotoSansSC-Regular.otf",
        "bytes": 8331336,
        "sha256": "faa6c9df652116dde789d351359f3d7e5d2285a2b2a1f04a2d7244df706d5ea9",
    }
    if any(entry[key] != value for key, value in expected.items()):
        raise ValueError("the selected exact public font input changed")
    OUT.mkdir()
    for name, data in source.items():
        (OUT / name).write_bytes(data)
    target = OUT / entry["file"]
    command = ["curl", "--silent", "--show-error", "--fail", "--proto", "=https",
               "--connect-timeout", "10", "--max-time", "45", "--max-filesize", str(entry["bytes"]),
               "--output", str(target), "--url", entry["url"]]
    started = datetime.now(timezone.utc).isoformat()
    completed = subprocess.run(command, capture_output=True, timeout=50)
    raw = target.read_bytes() if target.is_file() else b""
    passed = completed.returncode == 0 and len(raw) == entry["bytes"] and digest(raw) == entry["sha256"]
    result = {
        "scope": "One exact input for the existing egui host-font test; no renderer, platform or physical IME qualification.",
        "started_utc": started, "command": command, "exit": completed.returncode, "passed": passed,
        "stdout": completed.stdout.decode(errors="replace"), "stderr": completed.stderr.decode(errors="replace"),
        "upstream_commit": COMMIT, "upstream_source_prefix": PREFIX,
        "original_declarations": {name: record(data) for name, data in source.items()},
        "input": {"path": str(target), "url": entry["url"], **record(raw)},
        "expected_input": expected, "download_runner_sha256": digest(Path(__file__).read_bytes()),
    }
    receipt.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
