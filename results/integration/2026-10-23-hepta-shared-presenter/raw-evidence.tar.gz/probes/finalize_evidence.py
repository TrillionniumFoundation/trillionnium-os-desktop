#!/usr/bin/env python3
"""Freeze reviewable source and immutable raw execution evidence, without publishing."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess


ROOT = Path(__file__).resolve().parents[1]
PREFIX = "results/integration/2026-10-23-hepta-shared-presenter"
RUNNER = "e7a4fbce3df8f9724745cad48ff12d0bdb00a8da6094424e1fdd62cd1b768409"
OUTPUT = ROOT / "validation/final-execution-summary.json"
RESULT = re.compile(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;")
SHELL = "ui/shell/src/conversation.rs"
STAGES = {
    "final-core-and-shell-font-v1": (216, False),
    "final-shell-default-font-v1": (82, False),
    "final-session-aligned-v1": (45, True),
    "final-observer-aligned-v1": (51, True),
    "final-clippy-default-v3": (None, False),
    "final-clippy-candidate-v3": (None, False),
    "final-clippy-observer-v1": (None, True),
    "final-fmt-v3": (None, False),
    "final-source-after-v1": (None, False),
    "final-source-unit-tests-v1": (None, True),
    "final-wire-unit-tests-v2": (None, True),
    "final-wire-unit-optimized-v1": (None, True),
    "final-wire-original-v2": (None, True),
    "final-wire-default-v2": (None, True),
    "final-wire-candidate-v3": (None, True),
    "final-wire-original-golden-v1": (None, True),
    "final-wire-default-golden-v1": (None, True),
    "final-wire-candidate-golden-v1": (None, True),
    "final-wire-default-review-v1": (None, True),
    "final-wire-candidate-review-v1": (None, True),
}


def record(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def identify(path):
    return {"path": path.relative_to(ROOT).as_posix(), **record(path.read_bytes())}


def read_json(name):
    return json.loads((ROOT / name).read_text())


def stage(name, expected_tests, permit_uncompiled_shell_delta):
    path = ROOT / "validation" / (name + ".json")
    value = json.loads(path.read_text())
    if (value.get("passed") is not True or value.get("exit") != 0
            or value.get("stopped") is not None
            or value["source_before"] != value["source_after"]
            or value["runner_sha256"] != RUNNER or value["runner_after_sha256"] != RUNNER
            or not value["rustc"].startswith("rustc 1.88.0 ")):
        raise ValueError("final gate did not pass with its recorded exact source: " + name)
    changes = [path for path, before in value["source_after"].items()
               if record((ROOT / path).read_bytes()) != before]
    if changes and (not permit_uncompiled_shell_delta or changes != [SHELL]):
        raise ValueError("unexpected source drift since final component execution: " + name)
    streams = {}
    for stream in ("stdout", "stderr"):
        raw = ROOT / "validation" / (name + "." + stream)
        data = raw.read_bytes()
        declared = value["raw_streams"][stream]
        if record(data)["sha256"] != declared["sha256"] or len(data) != declared["bytes"]:
            raise ValueError("raw execution stream no longer matches its original receipt")
        streams[stream] = identify(raw)
    units = [list(map(int, match)) for match in RESULT.findall((ROOT / streams["stdout"]["path"]).read_text())]
    totals = [sum(row[index] for row in units) for index in range(5)] if units else None
    if expected_tests is not None and totals != [expected_tests, 0, 0, 0, 0]:
        raise ValueError("test count/filter result differs from the actual required final gate: " + name)
    return {"name": name, "receipt": identify(path), "command": value["command"],
            "exit": value["exit"], "stopped": value["stopped"], "started_utc": value["started_utc"],
            "duration_seconds": value["duration_seconds"], "raw_streams": streams,
            "test_units": units, "test_totals_pass_fail_ignore_measure_filter": totals,
            "source_unchanged_during_execution": True, "current_snapshot_difference": changes,
            "current_snapshot_difference_scope": (
                "Only the unrelated Shell editor clone-on-Copy and rustfmt change followed this component/Python/wire run. "
                "The executed component sources, manifests and locks are still byte-identical. "
                "Final Shell and workspace Clippy are separately executed at the frozen complete source."
                if changes else "Complete recorded source snapshot equals current final source."),
            "resource_bounds": value["resource_bounds"],
            "maximum_task_cache_target_bytes": value["maximum_task_ram_bytes"],
            "minimum_memory_available_bytes": value["minimum_observed_memory_available_bytes"],
            "minimum_shm_free_bytes": value["minimum_observed_shm_free_bytes"]}


def main():
    if OUTPUT.exists():
        raise ValueError("refusing to replace a final execution summary")
    manifest = read_json("patches/review-manifest.json")
    if len(manifest["files"]) != 26 or manifest["missing_planned_files"]:
        raise ValueError("complete final source manifest is required")
    for row in manifest["files"]:
        if record((ROOT / row["path"]).read_bytes()) != row["after"]:
            raise ValueError("frozen source manifest drift: " + row["path"])
    stages = [stage(name, *parameters) for name, parameters in STAGES.items()]
    static = read_json("validation/final-static-source-review-v2.json")
    if static.get("exit") != 0 or static.get("candidate_source_unchanged") is not True:
        raise ValueError("final static-only scope review failed")
    for name, count in (("final-source-unit-tests-v1", 10), ("final-wire-unit-tests-v2", 8),
                        ("final-wire-unit-optimized-v1", 8)):
        text = (ROOT / "validation" / (name + ".stderr")).read_text()
        if f"Ran {count} tests" not in text or not text.rstrip().endswith("OK"):
            raise ValueError("Python gate count is not the required actual result")
    wire = json.loads((ROOT / "validation/final-wire-candidate-review-v1.stdout").read_text())
    if (wire.get("passed") is not True or wire.get("exact_stdout_bytes_equal") is not False
            or wire.get("case_count") != 52 or wire.get("exact_case_values") != 51
            or len(wire["allowed_observer_exponent_changes"]) != 1):
        raise ValueError("wire comparison did not establish its narrow reviewed result")
    font = read_json("validation/pinned-font-input-v1.json")
    font_path = Path(font["input"]["path"])
    if font.get("passed") is not True or record(font_path.read_bytes())["sha256"] != font["input"]["sha256"]:
        raise ValueError("actual font input changed after the real glyph tests")
    history = []
    for name in ("final-original-core-v1", "final-original-core-v2", "final-original-core-v3"):
        value = read_json("validation/" + name + ".json")
        counts = [list(map(int, match)) for match in RESULT.findall((ROOT / "validation" / (name + ".stdout")).read_text())]
        history.append({"receipt": identify(ROOT / "validation" / (name + ".json")),
                        "test_count": sum(row[0] for row in counts),
                        "core_source": value["source_after"]["ui/core/src/lib.rs"],
                        "scope": "Historical execution at its own recorded source; never promoted to a later source revision."})
    summary = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "status": "Actual Rust 1.88 local host gates passed for the frozen default-off original presenter candidate.",
        "desktop_base": manifest["desktop_base"], "desktop_tree": manifest["desktop_tree"],
        "original_git_package_commit": manifest["upstream_commit"],
        "source_manifest": identify(ROOT / "patches/review-manifest.json"),
        "changed_source_files": 26, "verified_original_preimages": 12,
        "test_count_interpretation": {
            "original_hepta_control_core": {"lib": 42, "canonical_differential": 2, "controller": 20, "total": 64},
            "original_hepta_robrix_ui_presenter_only": 23,
            "desktop_trill_ui_core": {"lib": 36, "host_load_legacy": 6, "total": 42},
            "core_package_union": 129,
            "final_shared_shell_with_explicit_font_include_ignored": 87,
            "final_core_and_shared_shell_single_invocation": 216,
            "final_default_shell_with_explicit_font_include_ignored": 82,
            "aligned_base_session": 45, "aligned_base_observer": 51,
            "normal_shell_invocations": "81 default / 86 candidate passed with 1 existing font test ignored in each; raw results are retained.",
            "separate_explicit_font_tests": "1/1 each, 81/86 unrelated tests filtered respectively; final include-ignored invocations also pass the real font test at final bytes.",
            "warning": "Counts overlap across invocations. 129 is 64+23+42, not 129 Desktop-core tests. These Session/observer packages are the #251 baseline, not root's newer #255 64/52 packages."
        },
        "gates": stages, "historical_core_counts": history,
        "wire": {**wire, "scope_limit": "Bounded actual 52-case corpus plus six public-type legacy tests; not a proof for every decimal JSON input. Unknown external resource-JSON consumers remain outside the audited checked-in paths."},
        "font": {"provision_receipt": identify(ROOT / "validation/pinned-font-input-v1.json"),
                 "post_execution_identity": record(font_path.read_bytes()),
                 "scope": "Real CJK glyph coverage/outline rasterization and egui font fallback; no physical IME, Weston or Makepad runtime evidence."},
        "preserved_failures_and_stops": [
            "Initial original/new wire comparison: three differences with shared feature; one exponent spelling without it.",
            "Legacy floating boundary/overflow tests: original 4 green, candidate 2 expected red, intermediate 4 green.",
            "Independent integer rounding cases: original 6 green, Option<f64> 2 independent expected red, numeric Visitor 6 green.",
            "Initial 750 MiB task cache/target cap controlled stop; later explicit 1250 MiB cap retained RAM>=1.5GiB and shm>=512MiB.",
            "Actual clone_on_copy feature Clippy failure and exact minimal correction; real rustfmt line-wrap failure and correction."
        ],
        "not_qualified": [
            "GitHub Actions or fresh Weston/Wayland window execution for this candidate",
            "Original Makepad renderer/native App composition (separate design, not in the 26-file implementation)",
            "Physical input methods, accessibility/screen reader, Web/mobile or bare-metal deployment",
            "Production Send/AuthBus signer/SourceEnvelope/owner composition; original SendUnavailable remains unchanged",
            "All possible decimal JSON values or unknown external raw-JSON consumers"
        ],
        "source_and_execution_notes": [
            "All source changes are local and frozen; publication is performed by root separately.",
            "Both original Git packages come from the same exact original commit, default Makepad/native-host features disabled; final gate verifies all 85 package files.",
            "Every recorded gate used official Rust1.88, locked dependencies, jobs1, no debug/incremental; task size is cache+target storage, not resident RAM.",
            "The six dependency files and 01 patch retain the original frozen digest. Source entries and archive entries are separate.",
            "Preserve #247 README workflow migration and #255 Objective source/gates when composing; do not overwrite those newer files with base snapshots.",
            "The original pre-execution plan and old 21-file manifest are retained as historical documents. The final freeze contains 26 source files."
        ],
        "static_scope_review": identify(ROOT / "validation/final-static-source-review-v2.json"),
        "target_release": identify(ROOT / "validation/target-release-final.json"),
        "makepad_design_only": [identify(ROOT / "research/makepad-integration/COMPOSITION_DESIGN.md"),
                                identify(ROOT / "research/makepad-integration/review-v2.json")],
        "finalizer": identify(Path(__file__).resolve()),
    }
    OUTPUT.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"summary": str(OUTPUT), "frozen_source_files": 26, "actual_final_gates": len(stages),
                      "core_union": 129, "core_and_shared_shell_with_font": 216,
                      "default_shell_with_font": 82, "remote_publication_performed": False}))


if __name__ == "__main__":
    main()
