#!/usr/bin/env python3
"""Read-only source and shell-syntax checks, never Rust or runtime qualification."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "validation/final-static-source-review-v2.json"


def identify(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def item(source, marker):
    start = source.index(marker)
    opening = source.index("{", start)
    depth = 0
    for end in range(opening, len(source)):
        if source[end] == "{":
            depth += 1
        elif source[end] == "}":
            depth -= 1
            if depth == 0:
                return source[start:end + 1]
    raise ValueError(f"unbalanced item: {marker}")


def main():
    if OUTPUT.exists():
        raise ValueError("refusing to overwrite an earlier review receipt")
    receipt = {"status": "failed", "command": [sys.executable, str(Path(__file__).resolve())],
               "started_utc": datetime.now(timezone.utc).isoformat(),
               "script": identify(Path(__file__).read_bytes()),
               "scope": "source byte comparisons and bash -n only; no Rust, GUI, native host, authority or device execution",
               "desktop_commit": "64736996d310d597ffba513ee109264cd5f5f83f"}
    try:
        manifest = json.loads((ROOT / "patches/review-manifest.json").read_text())
        changed = {row["path"]: row for row in manifest["files"]}
        if len(changed) != 26:
            raise ValueError("the final candidate is not exactly 26 files")
        for path, row in changed.items():
            if identify((ROOT / path).read_bytes()) != row["after"]:
                raise ValueError(f"candidate manifest drift: {path}")
        frozen = json.loads((ROOT / "patches/dependency-alignment-frozen.json").read_text())
        for row in frozen["files"]:
            if identify((ROOT / row["path"]).read_bytes()) != row["after"]:
                raise ValueError(f"frozen dependency drift: {row['path']}")
        receipt["frozen_dependencies"] = frozen["files"]
        receipt["candidate_files"] = manifest["files"]

        comparisons = []
        sources = {}
        for path in ("ui/activation_policy.rs", "ui/activation.rs"):
            old = (ROOT / "base" / path).read_text()
            new = (ROOT / path).read_text()
            sources[path] = (old, new)
            comparisons.append({"path": path, "before": identify(old.encode()),
                                "after": identify(new.encode())})
        old, new = sources["ui/activation_policy.rs"]
        original = item(old, "pub fn begin_frame(")
        candidate = item(new, "pub fn begin_frame(")
        additions = [
            "        let ime_confirmation_pending_at_start = self.ime_confirmation_pending();\n",
            "            ime_confirmation_fenced: ime_confirmation_pending_at_start\n"
            "                || blocks_effects\n"
            "                || self.wait_for_confirmation_release,\n",
        ]
        normalized = candidate
        for addition in additions:
            if normalized.count(addition) != 1:
                raise ValueError("read-only frame projection differs from the exact reviewed addition")
            normalized = normalized.replace(addition, "", 1)
        if normalized != original:
            raise ValueError("original activation policy transition function changed")
        methods = []
        for path, marker in [
            ("ui/activation_policy.rs", "pub struct ActivationPolicy"),
            ("ui/activation_policy.rs", "pub fn allows("),
            ("ui/activation_policy.rs", "pub fn confirmation_key_seen("),
            ("ui/activation.rs", "pub fn begin_frame("),
            ("ui/activation.rs", "pub fn activated("),
            ("ui/activation.rs", "pub fn composing("),
        ]:
            old, new = sources[path]
            before, after = item(old, marker), item(new, marker)
            if before != after:
                raise ValueError(f"original state or method changed: {path}: {marker}")
            methods.append({"path": path, "item": marker,
                            "identical_bytes": identify(before.encode())})
        receipt["activation_projection_review"] = {
            "files": comparisons, "original_transition": identify(original.encode()),
            "candidate_transition": identify(candidate.encode()),
            "candidate_after_removing_exact_read_only_additions": identify(normalized.encode()),
            "removed_additions": additions, "unchanged_original_items": methods,
            "result": "original transition body and original state fields/methods are byte-identical; only the recorded read-only frame projection is added",
        }

        checked = []
        original_paths = set()
        for tree_file, prefix, selected in [
            ("desktop-ui-tree.json", "ui/", lambda p: True),
            ("desktop-services-tree.json", "services/", lambda p: p.startswith("hepta-os/")),
        ]:
            tree = json.loads((ROOT / tree_file).read_text())
            if tree.get("truncated"):
                raise ValueError("source tree is truncated")
            for entry in tree["tree"]:
                if entry["type"] != "blob" or not selected(entry["path"]):
                    continue
                path = prefix + entry["path"]
                original_paths.add(path)
                before = identify((ROOT / "base" / path).read_bytes())
                after = identify((ROOT / path).read_bytes())
                if before["git_blob"] != entry["sha"]:
                    raise ValueError(f"original preimage changed: {path}")
                if path not in changed and before != after:
                    raise ValueError(f"out-of-scope original source changed: {path}")
                checked.append({"path": path, "original_git_blob": entry["sha"],
                                "current": after, "declared_change": path in changed})
        for folder in ("ui", "services/hepta-os"):
            for path in (ROOT / folder).rglob("*"):
                if path.is_file() and (path.suffix in (".rs", ".toml") or path.name == "Cargo.lock"):
                    relative = path.relative_to(ROOT).as_posix()
                    if relative not in original_paths and relative not in changed:
                        raise ValueError(f"unlisted Rust source or manifest: {relative}")
        receipt["original_source_scope"] = {
            "checked_files": len(checked), "files": checked,
            "unlisted_original_changes": [], "unlisted_rust_sources_or_manifests": [],
        }

        workflow = ROOT / ".github/workflows/a10-host.yml"
        before_workflow = ROOT / "base/.github/workflows/a10-host.yml"
        original_workflow = yaml.safe_load(before_workflow.read_text())
        candidate_workflow = yaml.safe_load(workflow.read_text())
        names = {"Verify original shared presenter source and default-off candidate",
                 "Test original shared packages and real egui edit transactions"}
        original_names = {step.get("name") for job in original_workflow["jobs"].values()
                          for step in job["steps"]}
        if names & original_names:
            raise ValueError("candidate step already exists in the original workflow")
        steps = [step for job in candidate_workflow["jobs"].values() for step in job["steps"]
                 if step.get("name") in names]
        if len(steps) != 2:
            raise ValueError("expected exactly two added candidate steps")
        syntax = []
        for step in steps:
            result = subprocess.run(["bash", "-n"], input=step["run"],
                                    text=True, capture_output=True, check=False)
            syntax.append({"name": step["name"], "command": ["bash", "-n"],
                           "stdin_script": step["run"], "stdin_identity": identify(step["run"].encode()),
                           "exit": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
            if result.returncode != 0:
                raise ValueError("added CI step does not pass Bash syntax checking")
        receipt["added_workflow_steps"] = {
            "before": identify(before_workflow.read_bytes()),
            "after": identify(workflow.read_bytes()), "syntax_checks": syntax,
            "scope": "YAML parsing and Bash syntax only; no GitHub Actions job or Cargo command was executed",
        }
        receipt["candidate_source_unchanged"] = all(
            identify((ROOT / path).read_bytes()) == row["after"] for path, row in changed.items())
        if not receipt["candidate_source_unchanged"]:
            raise ValueError("candidate changed during read-only review")
        receipt["status"] = "passed within the declared static-only scope"
        receipt["exit"] = 0
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        receipt["error"] = str(error)
        receipt["exit"] = 1
    OUTPUT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"receipt": str(OUTPUT), "status": receipt["status"],
                      "exit": receipt["exit"], "error": receipt.get("error")}, ensure_ascii=False))
    return receipt["exit"]


if __name__ == "__main__":
    sys.exit(main())
