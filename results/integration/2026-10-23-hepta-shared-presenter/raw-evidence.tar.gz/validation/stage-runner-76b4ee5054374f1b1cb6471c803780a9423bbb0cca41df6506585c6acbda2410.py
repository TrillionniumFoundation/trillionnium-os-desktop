#!/usr/bin/env python3
"""Bounded task-local validation with exact source/lock identity receipts."""
from pathlib import Path
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument("--name", required=True)
parser.add_argument("--limit-mib", type=int, default=500)
parser.add_argument("--deadline", type=int, default=240)
parser.add_argument("command", nargs=argparse.REMAINDER)
args = parser.parse_args()
if not args.name or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in args.name):
    parser.error("name must use lowercase letters, digits and hyphens")
command = args.command[1:] if args.command[:1] == ["--"] else args.command
if not command:
    parser.error("an explicit command is required")
base = Path(__file__).resolve().parents[1]
ram = Path("/dev/shm/trill-shared-presenter")
toolchain = Path("/dev/shm/organ-3d6a75235bcb-objective-tests/rustup-home/toolchains/1.88.0-x86_64-unknown-linux-gnu/bin")
env = os.environ.copy()
env.update(CARGO_HOME=str(ram / "cargo"), RUSTC=str(toolchain / "rustc"),
           RUSTDOC=str(toolchain / "rustdoc"), CARGO_INCREMENTAL="0",
           RUSTUP_HOME=str(toolchain.parents[2]), RUSTUP_TOOLCHAIN="1.88.0",
           CARGO_TARGET_DIR=str(ram / "target"), CARGO_BUILD_JOBS="1",
           CARGO_PROFILE_DEV_DEBUG="0", CARGO_PROFILE_TEST_DEBUG="0",
           CARGO_NET_GIT_FETCH_WITH_CLI="true", GIT_TERMINAL_PROMPT="0")
env["PATH"] = str(base / "probes/git-bin") + ":" + str(toolchain) + ":" + env["PATH"]

def identity():
    result = {}
    for folder in ("ui", "services/hepta-os", "libs/os-abi", "tests/ui", "support/ui",
                   "base/ui", "base/services/hepta-os", "base/libs/os-abi", "base/tests/ui"):
        for path in sorted((base / folder).rglob("*")):
            if path.is_file() and (path.suffix in (".rs", ".toml", ".json", ".py", ".md", ".txt")
                                   or path.name == "Cargo.lock"):
                data = path.read_bytes()
                result[path.relative_to(base).as_posix()] = {
                    "sha256": hashlib.sha256(data).hexdigest(),
                    "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
                    "bytes": len(data),
                }
    workflow = base / ".github/workflows/a10-host.yml"
    data = workflow.read_bytes()
    result[workflow.relative_to(base).as_posix()] = {
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
        "bytes": len(data),
    }
    return result

before = identity()
validation = base / "validation"
outputs = [validation / f"{args.name}.{suffix}" for suffix in ("json", "stdout", "stderr")]
if any(path.exists() for path in outputs):
    parser.error("refusing to overwrite an earlier execution receipt")
started = time.time()
stopped = None
maximum = 0
proc = None
code = None
rustc = None
try:
    rustc = subprocess.check_output([str(toolchain / "rustc"), "-Vv"], text=True, timeout=15)
    if not rustc.startswith("rustc 1.88.0 "):
        raise ValueError("final UI gate requires the original Rust 1.88.0 toolchain")
    with outputs[1].open("x") as stdout, outputs[2].open("x") as stderr:
        proc = subprocess.Popen(command, cwd=base, env=env, stdout=stdout, stderr=stderr,
                                start_new_session=True)
        while proc.poll() is None:
            used = int(subprocess.check_output(["du", "-sb", str(ram)], text=True).split()[0])
            maximum = max(maximum, used)
            mem = {line.split(":")[0]: int(line.split()[1]) * 1024
                   for line in Path("/proc/meminfo").read_text().splitlines()}
            stat = os.statvfs(ram)
            free = stat.f_bavail * stat.f_frsize
            if used >= args.limit_mib * 1024 * 1024:
                stopped = f"Task RAM ownership reached {args.limit_mib} MiB"
            elif mem["MemAvailable"] < 1536 * 1024 * 1024:
                stopped = "Global RAM available below 1.5 GiB"
            elif free < 512 * 1024 * 1024:
                stopped = "Shared RAM filesystem free below 512 MiB"
            elif time.time() - started > args.deadline:
                stopped = f"Bounded {args.deadline} second deadline"
            if stopped:
                break
            time.sleep(1)
except (OSError, ValueError, subprocess.SubprocessError) as error:
    stopped = f"Validation runner or preflight failed: {error}"
finally:
    if proc is not None:
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
        code = proc.returncode
after = identity()
passed = code == 0 and stopped is None and before == after
result = {"command": command, "exit": code, "stopped": stopped, "passed": passed,
          "started_utc": datetime.fromtimestamp(started, timezone.utc).isoformat(),
          "duration_seconds": time.time() - started, "maximum_task_ram_bytes": maximum,
          "rustc": rustc,
          "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "resolved_command": shutil.which(command[0], path=env["PATH"]),
          "execution_namespace": {
              "uid": os.getuid(), "euid": os.geteuid(),
              "dev_shm_device": os.stat("/dev/shm").st_dev,
              "dev_shm_mountinfo": [line for line in Path("/proc/self/mountinfo").read_text().splitlines()
                                    if line.split()[4] == "/dev/shm"],
              "task_ram_directory": str(ram), "toolchain_bin": str(toolchain),
          },
          "profile_overrides": {"debug": 0, "incremental": False, "jobs": 1},
          "source_unchanged": before == after, "source_before": before, "source_after": after}
outputs[0].write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if not k.startswith("source_")}, indent=2))
print("source_unchanged", result["source_unchanged"])
sys.exit(0 if passed else 1)
