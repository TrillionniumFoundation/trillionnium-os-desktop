#!/usr/bin/env python3
"""Create local review diffs against verified Git preimages, never publish."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
COMMIT = "64736996d310d597ffba513ee109264cd5f5f83f"
PATHS = [
    "ui/Cargo.toml", "ui/Cargo.lock", "ui/core/Cargo.toml", "ui/shell/Cargo.toml",
    "services/hepta-os/Cargo.toml", "services/hepta-os/Cargo.lock",
    "ui/activation.rs", "ui/activation_policy.rs", "ui/core/src/lib.rs",
    "ui/core/src/shared_chat.rs", "ui/core/examples/wire_compatibility.rs",
    "ui/shell/src/conversation.rs", "ui/shell/src/main.rs",
    "tests/ui/test_shared_presenter_source.py", "tests/ui/verify_shared_presenter.py",
    "tests/ui/wire-compatibility-v1.json",
    "support/ui/HEPTA_SHARED_PRESENTER.json", "support/ui/HEPTA_SHARED_PRESENTER.md",
    "support/ui/licenses/HEPTA-LICENSE.txt", "support/ui/licenses/HEPTA-NOTICE.txt",
    "support/ui/licenses/ROBRIX-MIT.txt", ".github/workflows/a10-host.yml",
]
DEPENDENCIES = set(PATHS[:6])


def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def record(data):
    return {"git_blob": blob(data), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


original = {}
for folder in ("ui", "services", "libs", "tests", "support"):
    tree = json.loads((ROOT / f"desktop-{folder}-tree.json").read_text())
    if tree.get("truncated"):
        raise ValueError("source tree is truncated")
    original.update({folder + "/" + item["path"]: item["sha"]
                     for item in tree["tree"] if item["type"] == "blob"})
original[".github/workflows/a10-host.yml"] = "e845909fa48508222cce75be9e2a73d1324ccef2"

records = []
patches = {"01-dependency-alignment.patch": [], "02-presenter-candidate.patch": []}
preimages = {}
missing = []
for path in sorted(PATHS):
    actual = ROOT / path
    if not actual.is_file():
        missing.append(path)
        continue
    after = actual.read_bytes()
    if path in original:
        before = (ROOT / "base" / path).read_bytes()
        if blob(before) != original[path]:
            raise ValueError(f"preimage differs from exact original Git tree: {path}")
        preimages[path] = before
    else:
        before = None
    if before == after:
        continue
    diff = [f"diff --git a/{path} b/{path}\n"]
    if before is None:
        diff.append("new file mode 100644\n")
    diff.append(f"index {blob(before) if before is not None else '0' * 40}..{blob(after)}"
                + (" 100644\n" if before is not None else "\n"))
    diff.extend(difflib.unified_diff(
        before.decode().splitlines(keepends=True) if before is not None else [],
        after.decode().splitlines(keepends=True),
        fromfile=f"a/{path}" if before is not None else "/dev/null", tofile=f"b/{path}"))
    name = "01-dependency-alignment.patch" if path in DEPENDENCIES else "02-presenter-candidate.patch"
    patches[name].extend(diff)
    records.append({"path": path, "before": record(before) if before is not None else None,
                    "after": record(after), "patch": name})

output = ROOT / "patches"
output.mkdir(exist_ok=True)
for name, lines in patches.items():
    (output / name).write_text("".join(lines))

with tempfile.TemporaryDirectory(prefix="presenter-apply-", dir=ROOT / "validation") as temp:
    stage = Path(temp)
    subprocess.run(["git", "init", "--quiet", str(stage)], check=True)
    for path, data in preimages.items():
        target = stage / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    for name in patches:
        for check in (True, False):
            subprocess.run(["git", "-C", str(stage), "apply", *(["--check"] if check else []),
                            str(output / name)], check=True)
    for item in records:
        if (stage / item["path"]).read_bytes() != (ROOT / item["path"]).read_bytes():
            raise ValueError("applied patch bytes differ from candidate")

manifest = {
    "status": "in-progress review only; final formatting, wire corpus and GUI execution pending",
    "desktop_base": COMMIT,
    "desktop_tree": "363700005afb52d2ac88aab709c3e0d0f78bcc0a",
    "upstream_commit": "56630b12b8a4c69fff2c47b95b36d88a7389c39f",
    "missing_planned_files": missing,
    "patch_apply_check": "both ordered patches checked and applied to exact preimages; all resulting bytes compared",
    "files": records,
    "patches": {name: record((output / name).read_bytes()) for name in patches},
    "composition_notes": [
        "Preserve PR #247 README guard migration; this workflow diff only adds candidate steps.",
        "Preserve PR #255 final Objective Session/transport source; this patch does not replace those files.",
        "The baseline copy of the new wire example is a validation harness, not an original preimage.",
    ],
}
(output / "review-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"changed_files": len(records), "missing": missing,
                  "modified_preimages": sum(item["before"] is not None for item in records),
                  "ordered_patch_check": "passed", "status": manifest["status"]}))
