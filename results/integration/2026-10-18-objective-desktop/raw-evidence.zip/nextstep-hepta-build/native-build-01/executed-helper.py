#!/usr/bin/env python3
"""Build the unchanged original Agentd with a bounded, resource-observed child."""
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
base = Path('/workspace/scratch/499c7902de8e')
source = base / 'audit2-hepta'
desktop = base / 'nextstep-integration'
work = base / 'nextstep-hepta-build'
attempt = work / sys.argv[1]
attempt.mkdir(mode=0o700)
gate_path = desktop / 'tests/integration/hepta/run_original_agentd.py'
spec = importlib.util.spec_from_file_location('original_build_gate', gate_path)
gate = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = gate
spec.loader.exec_module(gate)
record = {
    'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'qualification': 'unchanged_original_agentd_native_x86_64_build_only',
    'original_runtime_executed': False,
    'minimum_free_bytes_at_start': gate.MIN_FREE_BYTES,
    'minimum_free_bytes_while_building': 700 * 1024**2,
    'maximum_nonreclaimable_bytes': 7 * 1024**3,
    'deadline_seconds': 3600,
    'resource_samples': [],
}
group = None
code = 1
try:
    record['upstream_before'] = gate.verify_source(source)
    record['desktop_commit'] = gate.git(desktop, 'rev-parse', 'HEAD')
    record['gate_sha256'] = gate.sha256(gate_path)
    record['helper_sha256'] = gate.sha256(Path(__file__).resolve())
    record['free_bytes_at_start'] = shutil.disk_usage(work).free
    if record['free_bytes_at_start'] < record['minimum_free_bytes_at_start']:
        raise RuntimeError('conservative_build_preflight_failed')
    (work / 'tmp').mkdir(mode=0o700, exist_ok=True)
    env = gate.build_environment(work / 'target')
    env.update({
        'CARGO_HOME': str(work / 'cargo'),
        'RUSTUP_HOME': str(base / 'implementation-tools/rustup'),
        'TMPDIR': str(work / 'tmp'),
        'RUSTUP_NO_UPDATE_CHECK': '1',
        'PATH': str(base / 'implementation-tools/cargo/bin') + ':' + env.get('PATH', '/usr/bin:/bin'),
    })
    record['build_paths'] = {key: env[key] for key in [
        'CARGO_HOME', 'RUSTUP_HOME', 'TMPDIR', 'PATH', 'CARGO_TARGET_DIR',
        'CARGO_INCREMENTAL', 'CARGO_BUILD_JOBS',
    ]}
    command = [str(base / 'implementation-tools/cargo/bin/rustup'), 'run', '1.95.0', 'cargo',
               'build', '--locked', '--offline', '--profile', 'dev-small',
               '--no-default-features', '-p', 'codex-hepta-agentd', '--bin', 'codex-hepta-agentd', '-j1']
    record['command'] = command
    record['cwd'] = str(source / 'codex-rs')
    if not gate.child_anchor_available():
        raise RuntimeError('waitable_child_anchor_unavailable')
    print(json.dumps({'started': record['started_at_utc'], 'attempt': str(attempt),
                      'source': record['upstream_before'], 'free_GiB': round(record['free_bytes_at_start']/1024**3, 2)}), flush=True)
    started = time.monotonic()
    last_sample = -60
    with (attempt / 'cargo-build.log').open('xb') as log:
        process = subprocess.Popen(command, cwd=source / 'codex-rs', env=env,
                                   stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        group = gate.ChildGroup(process)
        record['build_pid'] = process.pid
        while True:
            state = group.observe_exit()
            elapsed = time.monotonic() - started
            free = shutil.disk_usage(work).free
            mempath = Path('/sys/fs/cgroup/memory.stat')
            values = {key: int(value) for key, value in (line.split() for line in mempath.read_text().splitlines())} if mempath.is_file() else {}
            nonreclaimable = sum(values.get(key, 0) for key in ['anon', 'shmem', 'kernel_stack', 'pagetables', 'sock', 'slab_unreclaimable', 'file_dirty'])
            if elapsed - last_sample >= 30 or state is not None:
                sample = {'elapsed_seconds': round(elapsed, 3), 'free_bytes': free,
                          'nonreclaimable_bytes': nonreclaimable}
                record['resource_samples'].append(sample)
                last_sample = elapsed
                print(json.dumps(sample), flush=True)
            if state is not None:
                code = group.reap() if state.si_code == os.CLD_EXITED and state.si_status == 0 else gate.terminate_group(group)
                break
            if free < record['minimum_free_bytes_while_building']:
                record['stop_reason'] = 'filesystem_reserve_reached'
            elif nonreclaimable > record['maximum_nonreclaimable_bytes']:
                record['stop_reason'] = 'memory_reserve_reached'
            elif elapsed >= record['deadline_seconds']:
                record['stop_reason'] = 'build_deadline_exceeded'
            if 'stop_reason' in record:
                code = gate.terminate_group(group)
                break
            time.sleep(1)
    record['exit_code'] = code
    record['upstream_after'] = gate.verify_source(source)
    record['status'] = 'passed' if code == 0 and 'stop_reason' not in record else 'failed'
    binary = work / 'target/dev-small/codex-hepta-agentd'
    if record['status'] == 'passed':
        record['binary'] = {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': gate.sha256(binary)}
except (gate.GateError, OSError, subprocess.SubprocessError, ValueError, RuntimeError) as error:
    if group is not None and group.armed:
        gate.terminate_group(group)
    record['status'] = 'failed'
    record['error'] = {'type': type(error).__name__, 'detail': str(error)}
    code = 1
finally:
    record['ended_at_utc'] = datetime.now(timezone.utc).isoformat()
    record['free_bytes_after'] = shutil.disk_usage(work).free
    (attempt / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: value for key, value in record.items() if key != 'resource_samples'}), flush=True)
sys.exit(code if code else (0 if record['status'] == 'passed' else 1))
