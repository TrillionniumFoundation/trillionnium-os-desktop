#!/usr/bin/env python3
"""Bind prebuilt native inputs, then execute the real original owner probe."""
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

base = Path('/workspace/scratch/499c7902de8e')
repo = base / 'nextstep-integration'
parser = argparse.ArgumentParser()
parser.add_argument('attempt')
parser.add_argument('--session', action='store_true')
parser.add_argument('--phase-dir', type=Path)
args = parser.parse_args()
if not args.attempt.isascii() or not all(ch.isalnum() or ch == '-' for ch in args.attempt):
    raise SystemExit('simple new attempt name required')
if args.phase_dir is not None and not args.session:
    raise SystemExit('phase directory requires the actual Session')
out = base / 'nextstep-objective-evidence' / args.attempt
out.mkdir(mode=0o700)
work = base / ('nextstep-hepta-' + args.attempt)
def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()
def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=repo, text=True).strip()
if git('status', '--porcelain=v1', '--untracked-files=all'):
    raise SystemExit('clean committed integration source required')
receipt_paths = {
    'agentd': base / 'nextstep-hepta-build/native-build-02/receipt.json',
    'probe': base / 'nextstep-hepta-build/probe-build-01/receipt.json',
    'cli': base / 'nextstep-objective-evidence/cli-integration-build/build-receipt.json',
}
if args.session:
    receipt_paths['ui'] = base / 'nextstep-objective-evidence/ui-integration-01/build-receipt.json'
receipts = {name: json.loads(path.read_text()) for name, path in receipt_paths.items()}
for name, value in receipts.items():
    if value.get('status') != 'passed':
        raise SystemExit('passing native build receipt required: ' + name)
for relative, expected in receipts['probe']['sources_before'].items():
    if digest(repo / relative) != expected:
        raise SystemExit('prebuilt probe source differs from actual reviewed build')
for relative, expected in receipts['cli']['sources_before'].items():
    if digest(repo / relative) != expected:
        raise SystemExit('CLI source differs from actual integrated build')
if args.session:
    for relative, expected in receipts['ui']['source_sha256_before'].items():
        if digest(repo / relative) != expected:
            raise SystemExit('Session/UI source differs from actual integrated build')
binaries = {
    'agentd': receipts['agentd']['binary'], 'probe': receipts['probe']['binary'],
    'observer': receipts['cli']['binaries']['hepta-observe'],
    'submitter': receipts['cli']['binaries']['hepta-submit'],
}
if args.session:
    binaries.update({'session': receipts['ui']['binaries']['trill-session'],
                     'ctl': receipts['ui']['binaries']['trill-ctl']})
for name, item in binaries.items():
    path = Path(item['path'])
    if not path.is_file() or not os.access(path, os.X_OK) or path.stat().st_size != item['bytes'] or digest(path) != item['sha256']:
        raise SystemExit('native input differs from actual build: ' + name)
command = ['python3', '-B', 'tests/integration/hepta/run_original_objective.py',
           '--hepta-source', str(base / 'audit2-hepta'), '--work-dir', str(work),
           '--target-dir', str(base / 'nextstep-hepta-build/target'), '--execute', '--offline']
for name, item in binaries.items():
    command += ['--' + name + '-bin', item['path']]
if args.phase_dir:
    command += ['--session-phase-dir', str(args.phase_dir.absolute()), '--session-ack-seconds', '120']
record = {'source_commit': git('rev-parse', 'HEAD'), 'source_tree': git('rev-parse', 'HEAD^{tree}'),
          'started_at_utc': datetime.now(timezone.utc).isoformat(),
          'receipt_inputs': {name: {'path': str(path), 'sha256': digest(path)} for name, path in receipt_paths.items()},
          'source_inputs_match_build_receipts': True, 'command': command,
          'binaries': binaries, 'session_requested': args.session,
          'phase_dir': str(args.phase_dir) if args.phase_dir else None}
(out / 'native-build-bindings.json').write_text(json.dumps(record, indent=2) + '\n')
(out / 'executed-helper.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'runtime_started_at_utc': record['started_at_utc'], 'work': str(work), 'session': args.session}), flush=True)
with (out / 'runner.log').open('xb') as log:
    result = subprocess.run(command, cwd=repo, env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1'},
                            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
record['exit_code'] = result.returncode
record['ended_at_utc'] = datetime.now(timezone.utc).isoformat()
record['status'] = 'passed' if result.returncode == 0 else 'failed'
report_path = work / 'report.json'
if report_path.is_file():
    record['report_sha256'] = digest(report_path)
    report = json.loads(report_path.read_text())
    record['report_status'] = report.get('status')
    record['runtime_executed'] = report.get('runtime_executed')
    record['runtime_record_count'] = len(report.get('runtime_records', []))
(out / 'execution.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({name: record[name] for name in ['status', 'exit_code', 'ended_at_utc', 'report_status', 'runtime_executed', 'runtime_record_count'] if name in record}), flush=True)
raise SystemExit(result.returncode)
