#!/usr/bin/env python3
"""Record the locked external original-objective probe build; no runtime."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

base = Path('/workspace/scratch/499c7902de8e')
repo = base / 'nextstep-integration'
out = base / 'nextstep-hepta-build' / 'probe-build-01'
out.mkdir(mode=0o700)
work = base / 'nextstep-hepta-objective-build-01'
command = ['python3', '-B', 'tests/integration/hepta/run_original_objective.py',
           '--hepta-source', str(base / 'audit2-hepta'),
           '--work-dir', str(work), '--target-dir', str(base / 'nextstep-hepta-build/target'),
           '--rustup', str(base / 'implementation-tools/cargo/bin/rustup'), '--offline']
env = os.environ.copy()
env.update({'CARGO_HOME': str(base / 'nextstep-hepta-build/cargo'),
            'RUSTUP_HOME': str(base / 'implementation-tools/rustup'),
            'PATH': str(base / 'implementation-tools/cargo/bin') + ':' + env.get('PATH', '/usr/bin:/bin'),
            'PYTHONDONTWRITEBYTECODE': '1'})
sources = [path for path in (repo / 'tests/integration/hepta').iterdir()
           if path.name.startswith('original_objective_') or path.name in
           ['run_original_objective.py', 'run_original_agentd.py']]
def identities():
    return {str(path.relative_to(repo)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sources}
record = {'started_at_utc': datetime.now(timezone.utc).isoformat(),
          'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
          'source_tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=repo, text=True).strip(),
          'command': command, 'cwd': str(repo), 'runtime_executed': False,
          'sources_before': identities(),
          'build_environment': {key: env[key] for key in ['CARGO_HOME', 'RUSTUP_HOME', 'PATH']},
          'serialization': 'Cargo shares the original target lock; it may wait for the original Agentd build.'}
(out / 'started.json').write_text(json.dumps(record, indent=2) + '\n')
(out / 'executed-helper.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'started_at_utc': record['started_at_utc'], 'work': str(work)}), flush=True)
with (out / 'runner.log').open('xb') as log:
    result = subprocess.run(command, cwd=repo, env=env, stdin=subprocess.DEVNULL,
                            stdout=log, stderr=subprocess.STDOUT)
record['exit_code'] = result.returncode
record['ended_at_utc'] = datetime.now(timezone.utc).isoformat()
record['sources_after'] = identities()
record['source_inputs_unchanged'] = record['sources_before'] == record['sources_after']
record['status'] = 'passed' if result.returncode == 0 and record['source_inputs_unchanged'] else 'failed'
report = work / 'report.json'
if report.is_file():
    record['runner_report_sha256'] = hashlib.sha256(report.read_bytes()).hexdigest()
    built = json.loads(report.read_text())
    record['binary'] = built.get('binaries', {}).get('probe')
    record['resolved_lock_sha256'] = built.get('resolved_lock_sha256')
(out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['status', 'exit_code', 'source_inputs_unchanged', 'ended_at_utc']}), flush=True)
raise SystemExit(0 if record['status'] == 'passed' else 1)
