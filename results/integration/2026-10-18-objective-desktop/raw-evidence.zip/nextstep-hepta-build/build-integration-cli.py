#!/usr/bin/env python3
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

base = Path('/workspace/scratch/499c7902de8e')
repo = base / 'nextstep-integration'
out = base / 'nextstep-objective-evidence/cli-integration-build'
out.mkdir(mode=0o700)
target = base / 'implementation-tools/integration-target'
env = {'PATH': str(base / 'implementation-tools/cargo/bin') + ':/usr/bin:/bin',
       'CARGO_HOME': str(base / 'implementation-tools/cargo'),
       'RUSTUP_HOME': str(base / 'implementation-tools/rustup'),
       'CARGO_TARGET_DIR': str(target), 'CARGO_INCREMENTAL': '0',
       'CARGO_BUILD_JOBS': '1', 'LANG': 'C.UTF-8'}
command = [str(base / 'implementation-tools/cargo/bin/rustup'), 'run', '1.88.0',
           'cargo', 'build', '--manifest-path', 'services/hepta-os/Cargo.toml',
           '--features', 'objective-transport', '--bins', '--locked', '--offline']
def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=repo, text=True).strip()
paths = git('ls-files', 'services/hepta-os').splitlines()
def sources():
    return {path: hashlib.sha256((repo / path).read_bytes()).hexdigest() for path in paths}
record = {'source_commit': git('rev-parse', 'HEAD'),
          'source_tree': git('rev-parse', 'HEAD^{tree}'),
          'hepta_os_tree': git('rev-parse', 'HEAD:services/hepta-os'),
          'started_at_utc': datetime.now(timezone.utc).isoformat(),
          'command': command, 'environment': env, 'sources_before': sources(),
          'runtime_executed': False}
(out / 'executed-helper.py').write_bytes(Path(__file__).read_bytes())
with (out / 'build.log').open('xb') as log:
    result = subprocess.run(command, cwd=repo, env=env, stdin=subprocess.DEVNULL,
                            stdout=log, stderr=subprocess.STDOUT, timeout=300)
record['exit_code'] = result.returncode
record['source_inputs_unchanged'] = record['sources_before'] == sources()
record['ended_at_utc'] = datetime.now(timezone.utc).isoformat()
record['status'] = 'passed' if result.returncode == 0 and record['source_inputs_unchanged'] else 'failed'
if record['status'] == 'passed':
    record['binaries'] = {}
    for name in ['hepta-observe', 'hepta-submit']:
        path = target / 'debug' / name
        record['binaries'][name] = {'path': str(path), 'bytes': path.stat().st_size,
                                  'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
(out / 'build-receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['status', 'exit_code', 'source_inputs_unchanged', 'ended_at_utc']}))
raise SystemExit(0 if record['status'] == 'passed' else 1)
