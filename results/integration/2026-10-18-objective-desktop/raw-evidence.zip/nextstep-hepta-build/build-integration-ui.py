#!/usr/bin/env python3
"""Qualify the frozen integrated UI source and record actual native outputs."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
base = Path('/workspace/scratch/499c7902de8e')
repo = base / 'nextstep-integration'
out = base / 'nextstep-objective-evidence/ui-integration-01'
out.mkdir(mode=0o700)
spec = importlib.util.spec_from_file_location('integrated_ui_guard', repo / 'tests/integration/hepta/run_original_agentd.py')
guard = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = guard
spec.loader.exec_module(guard)
target = base / 'implementation-tools/a10-target'
environment = {'PATH': str(base / 'implementation-tools/cargo/bin') + ':/usr/bin:/bin',
               'CARGO_HOME': str(base / 'implementation-tools/cargo'),
               'RUSTUP_HOME': str(base / 'implementation-tools/rustup'),
               'CARGO_TARGET_DIR': str(target), 'CARGO_INCREMENTAL': '0',
               'CARGO_BUILD_JOBS': '1', 'LANG': 'C.UTF-8'}
prefix = [str(base / 'implementation-tools/cargo/bin/rustup'), 'run', '1.88.0', 'cargo']
commands = [
    ('workspace-tests', ['test', '--manifest-path', 'ui/Cargo.toml', '--workspace', '--locked', '--offline']),
    ('workspace-clippy', ['clippy', '--manifest-path', 'ui/Cargo.toml', '--workspace', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings']),
    ('workspace-fmt', ['fmt', '--manifest-path', 'ui/Cargo.toml', '--all', '--', '--check']),
    ('workspace-build', ['build', '--manifest-path', 'ui/Cargo.toml', '--workspace', '--bins', '--locked', '--offline']),
]
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()
tracked = git('ls-files', 'ui', 'services/hepta-os').splitlines()
def sources():
    return {name: guard.sha256(repo / name) for name in tracked}
record = {'source_repo': str(repo), 'source_commit': git('rev-parse', 'HEAD'),
          'source_tree': git('rev-parse', 'HEAD^{tree}'), 'ui_tree': git('rev-parse', 'HEAD:ui'),
          'hepta_os_tree': git('rev-parse', 'HEAD:services/hepta-os'),
          'ui_lock_sha256': guard.sha256(repo / 'ui/Cargo.lock'),
          'started_at_utc': datetime.now(timezone.utc).isoformat(),
          'environment': environment, 'source_sha256_before': sources(),
          'runtime_scope': 'Rust workspace tests and actual native builds; no original Agentd or Shell pixels',
          'build_commands': [], 'verification_commands': [], 'status': 'running'}
(out / 'executed-helper.py').write_bytes(Path(__file__).read_bytes())
def save():
    (out / 'build-receipt.json').write_text(json.dumps(record, indent=2) + '\n')
save()
try:
    if git('status', '--porcelain=v1', '--untracked-files=all'):
        raise RuntimeError('integration_source_must_be_clean')
    for label, arguments in commands:
        item = {'name': label, 'command': prefix + arguments,
                'started_at_utc': datetime.now(timezone.utc).isoformat(),
                'log': str(out / (label + '.log'))}
        record['build_commands' if label == 'workspace-build' else 'verification_commands'].append(item)
        save()
        print(json.dumps({'started': label, 'at_utc': item['started_at_utc']}), flush=True)
        guard.bounded_command(item['command'], repo, environment, Path(item['log']), 900)
        item.update({'exit_code': 0, 'ended_at_utc': datetime.now(timezone.utc).isoformat()})
        if label == 'workspace-tests':
            matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', Path(item['log']).read_text())
            record['test_totals'] = dict(zip(['passed', 'failed', 'ignored'], [sum(int(row[column]) for row in matches) for column in range(3)]))
        save()
        print(json.dumps({'finished': label, 'exit_code': 0}), flush=True)
    record['source_inputs_unchanged'] = sources() == record['source_sha256_before']
    record['source_head_unchanged'] = git('rev-parse', 'HEAD') == record['source_commit']
    if not record['source_inputs_unchanged'] or not record['source_head_unchanged']:
        raise RuntimeError('integrated_source_changed_during_qualification')
    record['binaries'] = {}
    for name in ['trill-shell', 'trill-session', 'trill-ctl', 'trill-app']:
        path = target / 'debug' / name
        if name == 'trill-app' and not path.is_file():
            continue
        record['binaries'][name] = {'path': str(path.resolve(strict=True)), 'bytes': path.stat().st_size,
                                   'sha256': guard.sha256(path)}
    record['status'] = 'passed'
except Exception as error:
    record['status'] = 'failed'
    record['error'] = str(error)
finally:
    record['ended_at_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({key: record[key] for key in ['status', 'ended_at_utc', 'test_totals', 'error'] if key in record}), flush=True)
raise SystemExit(0 if record['status'] == 'passed' else 1)
