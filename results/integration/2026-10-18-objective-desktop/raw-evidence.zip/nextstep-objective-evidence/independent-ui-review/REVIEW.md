# Independent UI integration and capture review

**Result: no implementation or evidence-binding blocker found.** Reviewed frozen desktop `25298f5d87cf3db90deefe9c0405ecd241dc6581` and the completed `ui-integration-01` / `nextstep-objective-capture-01` artifacts. One low-priority overview-documentation clarification is recorded below.

This was a read-only integration/evidence review by the prior UI leaf implementation agent. No build, Session, Shell, Agentd or CLI under review was started, and no integration source was edited.

## Source and build binding

The frozen source tree `9584997da412dd10c0960f69011b40a4b26d2862`, UI tree `42857c1bda95681f0c482fef8eb8da0f53979020`, services tree, lockfile and all **44 recorded build source hashes** match the build receipt. The three recorded Shell/Session/ctl executable sizes and SHA-256 hashes match their actual files. The capture's copied build receipt is byte-identical to the integration receipt, and all four executed capture/helper copies match their frozen Git blobs, sizes and hashes.

Raw workspace logs independently total **125 passed / 0 failed / 2 ignored**; the two ignored cases require a selected real CJK font. Declared test, strict all-target Clippy, formatting and workspace-binary build commands exited zero. This review inspected those records and did not rerun them.

## Six actual snapshots and three reviewed frames

All six snapshot hashes, sizes, Session identities and copied metadata match the capture manifest. All snapshots contain an empty host-task list. All three PNG hashes match, and each image was directly viewed.

| Phase | Evidence and interpretation |
| --- | --- |
| Compiled run projected | The same seven original run fields are present before/after: `run.desktop-compiled`, revision 1, phase `admitted`, authority epoch 1, generation 2, terminal observed false, idempotent false. Independent read sequence advances 4 to 7. Source ages 379 / 98 ms plus measured rounded RTTs 96 / 90 ms give 475 / 188 ms bounds at the respective receipts, both below 7,000 ms. Source wall ages also pass independently. |
| Old endpoint stale | The same Session and Shell retain the exact last run observation and last-attempt timestamp `1792305396104`; `protocol_mismatch` and the history gap remain visible. Run source age advances **3,221 to 5,939 ms** while only the health-attempt time advances. The retained owner phase `admitted` is visibly labelled historical/current unknown. |
| Replacement projection missing | A new explicit Session instance observes the replacement owner at spawn 5/current generation 6. It retains the exact selected run ID but has `last_observation: null`, omits sample age, and keeps gap=false. The frame states that current in-memory projection absence leaves objective admission and durable outcome unknown. No non-admission, completion or cancellation is inferred. |

One Shell PID and one X11 window span all phases. Its English card is readable in the captured 1440 by 1000 frames. The **Chinese suffix after the top submission-unavailable label renders as tofu**. These images qualify the English Runtime card only; they do not qualify CJK fonts/IME, physical display, keyboard interaction, model execution or a device effect.

## Freshness and authority boundary

The frozen UI tree matches the reviewed total-age implementation: Session computes read-start to snapshot monotonic age with upward millisecond rounding; Bridge records request start and actual transport return before queue delivery; Shell composes source age, full RTT and queued age. Repeated sequences retain the larger advancing bound without rejuvenation or duplicate RTT accumulation. The actual capture checker requires this source age, checks before/after independently, and preserves history while excluding only the advancing age field from stale equality.

Session's dependency enables no `objective-transport` feature, that feature defaults off, and `hepta-submit` requires it explicitly. UI IPC still exposes Snapshot/Launch/Cancel only. The trusted CLI entrypoint and its document agree on pre-existing raw input, retained original envelope, caller-closed stdin and whole-child deadline, one transport attempt, finite output, and unknown on lost/invalid output. RunStatus null is explicitly not journal non-admission. This review does not requalify the separate issuer/authentication/journal execution; those claims belong to the separately bound original-objective process report.

## Nonblocking documentation note

At frozen 25298, `support/ui/CHAT_WORKSPACE.md` still describes Hepta generically as using the R6 dual-clock rule. Qualify that text as runtime health and link the known-run total-age section. `support/ui/HEPTA_OBSERVER.md` and `ui/shell/OBSERVATION_FRESHNESS.md` already document the new rule, upward rounding, conservative RTT bound, 7,000 ms threshold and unchanged unconfigured JSON accurately.

## Inputs

`input-manifest.json` records every reviewed frozen-source/evidence input and its SHA-256. `review.json` records the individual binding/semantic checks, phase values and scope. Input manifest SHA-256: `cddca1a78479feee7718af2d5a0f318a246bdc5acde2037c094d6dce1417abb2`.
