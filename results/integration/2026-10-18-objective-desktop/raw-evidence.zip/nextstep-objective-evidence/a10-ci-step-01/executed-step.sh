set -euo pipefail
mkdir -p "$RUNNER_TEMP/a10"
python3 -B -m unittest discover -s tests/ui \
  -p 'test_original_objective_shell.py' -v 2>&1 | tee "$RUNNER_TEMP/a10/original-objective-shell-contracts.log"
