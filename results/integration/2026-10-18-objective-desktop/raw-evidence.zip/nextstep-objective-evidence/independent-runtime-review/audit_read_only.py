#!/usr/bin/env python3
"""Offline artifact review only. Never starts an owner, CLI, Session or display."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import struct
import subprocess
import sys

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

sys.dont_write_bytecode = True
BASE = Path('/workspace/scratch/499c7902de8e')
REPO = BASE / 'nextstep-integration'
OUT = BASE / 'nextstep-objective-evidence/independent-runtime-review'
COMMIT = '25298f5d87cf3db90deefe9c0405ecd241dc6581'
ORIGINAL = 'f8c9419df6ddeb36ff8b522a50219981fb8d9345'
AGENT = '33333333-3333-4333-8333-333333333333'
RUN_FIELDS = ('run_id', 'revision', 'phase', 'authority_epoch', 'generation', 'terminal_observed', 'idempotent')
PHASES = ('compiled_run_projected', 'old_endpoint_run_stale', 'replacement_run_projection_missing')
CHECKS = ('compiled_original_admission', 'exact_replay_same_publication',
    'explicit_abstain_durable_without_run', 'invalid_signature_owner_rejected',
    'body_generation_fenced_before_send', 'revoked_issuer_owner_rejected',
    'owner_restart_retains_historical_journal', 'old_spawn_not_accepted',
    'original_journal_matches_receipts', 'controlled_stop')
inputs = {}
checks = []
binary_inputs = {}


def sha(path):
    path = Path(path)
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def record(path):
    path = Path(path).absolute()
    metadata = path.lstat()
    assert stat.S_ISREG(metadata.st_mode), str(path)
    inputs[str(path)] = {'sha256': sha(path), 'bytes': metadata.st_size,
        'mode': oct(stat.S_IMODE(metadata.st_mode)), 'uid': metadata.st_uid, 'links': metadata.st_nlink}
    return path


def read_json(path):
    return json.loads(record(path).read_bytes())


def check(name, condition):
    checks.append({'check': name, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(name)


def git(*arguments, repo=REPO):
    return subprocess.check_output(['git', '-C', str(repo), *arguments], stderr=subprocess.PIPE, timeout=15)


def source_matches(relative, expected, commit=COMMIT):
    raw = git('show', commit + ':' + relative)
    record(REPO / relative)
    check('source:' + relative, hashlib.sha256(raw).hexdigest() == expected
        and (REPO / relative).read_bytes() == raw)


def verify_elf(role, value):
    path = record(Path(value['path']))
    check('native-elf:' + role, path.stat().st_size == value['bytes']
        and inputs[str(path)]['sha256'] == value['sha256'] and path.open('rb').read(4) == b'\x7fELF')
    binary_inputs[role] = value


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()


def run_fields(value):
    return {key: value[key] for key in RUN_FIELDS}


def signed_preimage(value):
    # Read from the fixed original SignedMessageClaims::signing_bytes/push_id
    # and the fixture's scope construction. This verifies existing public
    # signatures only; it creates no identity, issuer, ledger or admission.
    def ident(text):
        raw = text.encode()
        return struct.pack('>I', len(raw)) + raw
    return (b'hepta.authbus.signed-message.v1\0' + ident(value['issuer_id'])
        + struct.pack('>Q', value['key_epoch']) + ident(value['message_id']) + ident(AGENT)
        + hashlib.sha256(b'hepta:agentd:signed-objective:v1\0' + AGENT.encode()).digest()
        + hashlib.sha256(compact(value['body'])).digest()
        + struct.pack('>QQ', value['sequence'], value['expires_at_ms']))


report = {'schema_version': 1, 'reviewer': '/root/hepta_task_contract',
    'evidence_class': 'independent_read_only_actual_artifact_review',
    'review_relationship': 'Harness/capture contributor independently checking parent-operated artifacts; not an external review independent of implementation authorship.',
    'started_at_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': COMMIT,
    'new_runtime_or_build_executed': False, 'status': 'review_in_progress',
    'runtime_summaries': {}, 'limitations': [
        'Two distinct disposable executions use different ephemeral test public keys. The Shell captures only the second execution.',
        'Compiled admission remains nonterminal admitted. No model turn, canonical intelligence, Operations dispatch, resumed historical run or device effect is qualified.',
        'Known run is supplied by a trusted test launcher; the visible Shell has no Objective submit control.',
        'English Runtime pixels pass visual review. The Chinese suffix at the top shows missing-glyph boxes; CJK/IME is not qualified.',
        'This is a native Linux x86_64 host prototype with private Xvfb and software rendering requested, not a target-kernel/mobile/physical-GPU/display qualification.',
        'The original Agentd was built with --no-default-features. Its recorded native build command has --locked but no --offline; do not describe that build as offline solely from this receipt.',
        'Journal binary hashes and recorded original public-API decoding/publication binding were audited. This review does not rerun journal recovery or implement an alternative durable journal decoder.',
        'Capture ACKs are coordination only. Manual pixel review is recorded separately below.'],
    'visual_review': [
        {'phase': PHASES[0], 'file': 'phase-1-compiled_run_projected.png',
         'view_image_opened': True, 'result': 'passed_english_runtime_scope',
         'observed': 'Known run run.desktop-compiled; OBSERVED READ ONLY; admitted revision 1, generation 2, authority epoch 1, terminal false. Old owner PID 323523, spawn 1/current 2. Visible run sample sequence 6 lies between recorded before 4 and after 7.'},
        {'phase': PHASES[1], 'file': 'phase-2-old_endpoint_run_stale.png',
         'view_image_opened': True, 'result': 'passed_english_runtime_scope',
         'observed': 'STALE CURRENT RUN STATE UNKNOWN, protocol_mismatch, retained owner metadata, history gap warning. Original admitted fields remain visible; retained sample sequence 7 and old owner PID 323523 are consistent with snapshots.'},
        {'phase': PHASES[2], 'file': 'phase-3-replacement_run_projection_missing.png',
         'view_image_opened': True, 'result': 'passed_english_runtime_scope',
         'observed': 'PROJECTION MISSING CURRENT RUN STATE UNKNOWN; no successful run observation. Text leaves admission/durable outcome unknown to this view. Current owner PID 323803, spawn 5/current 6; no false completed or not-admitted claim.'}],
    'scope_blockers': []}

try:
    check('frozen-integration-tree', git('rev-parse', COMMIT + '^{tree}').decode().strip()
        == '9584997da412dd10c0960f69011b40a4b26d2862')
    original_repo = BASE / 'audit2-hepta'
    check('original-source-still-fixed-clean', git('rev-parse', 'HEAD', repo=original_repo).decode().strip() == ORIGINAL
        and not git('status', '--porcelain=v1', '--untracked-files=all', repo=original_repo))
    for relative in ['codex-rs/hepta-authbus/src/signed.rs', 'codex-rs/hepta-authbus/src/lib.rs']:
        record(original_repo / relative)
    executions = {}
    runtime_reports = {}
    public_keys = []
    for kind in ['core', 'session']:
        prefix = kind + ':'
        root = BASE / ('nextstep-hepta-objective-' + kind + '-runtime-01')
        evidence = root / 'runtime-evidence'
        runtime = read_json(root / 'report.json')
        execution_root = BASE / ('nextstep-objective-evidence/objective-' + kind + '-runtime-01')
        execution = read_json(execution_root / 'execution.json')
        binding = read_json(execution_root / 'native-build-bindings.json')
        record(execution_root / 'executed-helper.py')
        record(execution_root / 'runner.log')
        check(prefix + 'passing-original-execution', runtime['status'] == execution['status'] == 'passed'
            and runtime['runtime_executed'] is True and execution['exit_code'] == 0
            and execution['source_commit'] == COMMIT and execution['report_sha256'] == sha(root / 'report.json')
            and runtime['session_projection_requested'] is (kind == 'session'))
        check(prefix + 'execution-binding-exact', all(execution[key] == value for key, value in binding.items()))
        check(prefix + 'fixed-original-source', runtime['upstream']['commit'] == ORIGINAL
            and runtime['upstream']['clean_checkout'] is True)
        receipts = {}
        for name, value in execution['receipt_inputs'].items():
            receipts[name] = read_json(value['path'])
            check(prefix + 'build-receipt:' + name, sha(value['path']) == value['sha256']
                and receipts[name]['status'] == 'passed')
            if 'source_commit' in receipts[name]:
                check(prefix + 'build-git-tree:' + name,
                    git('rev-parse', receipts[name]['source_commit'] + '^{tree}').decode().strip() == receipts[name]['source_tree'])
        native = receipts['agentd']
        check(prefix + 'original-build-identities', native['exit_code'] == 0
            and native['upstream_before'] == native['upstream_after'] == runtime['upstream'])
        probe_build = receipts['probe']
        check(prefix + 'probe-sources-unchanged', probe_build['sources_before'] == probe_build['sources_after']
            and probe_build['source_inputs_unchanged'] is True and probe_build['exit_code'] == 0)
        build_directory = Path(probe_build['command'][probe_build['command'].index('--work-dir') + 1])
        build_report = read_json(build_directory / 'report.json')
        resolved_lock = record(build_directory / 'probe/Cargo.lock')
        check(prefix + 'actual-probe-build-report-and-lock', sha(build_directory / 'report.json') == probe_build['runner_report_sha256']
            and sha(resolved_lock) == probe_build['resolved_lock_sha256'] == build_report['resolved_lock_sha256']
            and build_report['binaries']['probe'] == probe_build['binary'] and build_report['runtime_executed'] is False)
        for relative, digest in probe_build['sources_before'].items():
            source_matches(relative, digest)
            check(prefix + 'runtime-source-map:' + relative, runtime['source_sha256'][Path(relative).name] == digest)
        for relative, digest in receipts['cli']['sources_before'].items():
            source_matches(relative, digest)
        if kind == 'session':
            for relative, digest in receipts['ui']['source_sha256_before'].items():
                source_matches(relative, digest)
            check('ui-subtree-bound', git('rev-parse', COMMIT + ':ui').decode().strip() == receipts['ui']['ui_tree'])
        role_map = {'agentd': native['binary'], 'probe': probe_build['binary'],
            'observer': receipts['cli']['binaries']['hepta-observe'],
            'submitter': receipts['cli']['binaries']['hepta-submit']}
        if kind == 'session':
            role_map.update(session=receipts['ui']['binaries']['trill-session'], ctl=receipts['ui']['binaries']['trill-ctl'])
        check(prefix + 'all-runtime-elf-bindings', role_map == execution['binaries'] == runtime['binaries'])
        for name, value in role_map.items():
            if name not in binary_inputs:
                verify_elf(name, value)
            else:
                check(prefix + 'same-built-elf:' + name, value == binary_inputs[name])
        log = record(root / 'runtime.log').read_text().splitlines()
        values = [json.loads(line) for line in log]
        check(prefix + 'raw-log-exact', values == runtime['runtime_records']
            and len(values) == execution['runtime_record_count'])
        submissions = [value for value in values if value['event'] == 'submission_observed']
        checks_by_name = {value['check']: value['evidence'] for value in values if value['event'] == 'objective_check'}
        check(prefix + 'seven-submits-ten-checks', len(submissions) == 7 and tuple(checks_by_name) == CHECKS)
        final = values[-1]
        check(prefix + 'explicit-acceptance-scope', final['event'] == 'acceptance_pass' and tuple(final['checks']) == CHECKS
            and final['original_commit'] == ORIGINAL and final['isolated_test_issuer'] is True
            and final['session_projection'] is (kind == 'session') and all(final[key] is False for key in
            ['production_issuer', 'model_turn', 'operations_dispatch', 'device_effect', 'canonical_intelligence', 'historical_run_resumed']))
        owners = [value['observation'] for value in values if value['event'] == 'owner_running']
        check(prefix + 'original-owner-restarted', len(owners) == 2 and all(owner['agent_id'] == AGENT for owner in owners)
            and owners[0]['health']['process_id'] != owners[1]['health']['process_id']
            and owners[1]['spawn_generation'] > owners[0]['spawn_generation'])
        trust = read_json(evidence / 'initial-public-trust.json')
        revoked = read_json(evidence / 'revoked-public-trust.json')
        check(prefix + 'isolated-public-trust-revocation', trust['agent_id'] == AGENT
            and trust['issuer_id'] == 'issuer.desktop-isolated-objective.v1'
            and trust['revoked'] is False and revoked == dict(trust, revoked=True))
        public_keys.append(trust['public_key_hex'])
        public = Ed25519PublicKey.from_public_bytes(bytes.fromhex(trust['public_key_hex']))
        body_hashes, request_raws = {}, []
        submission_summary = []
        for ordinal, entry in enumerate(submissions, 1):
            label, result = entry['label'], entry['result']
            raw = record(evidence / (label + '-request.json')).read_bytes()
            request = json.loads(raw)
            request_raws.append(raw)
            body = request['body']
            check(prefix + label + ':raw-compact-envelope', compact(request) == raw and not raw.endswith(b'\n'))
            check(prefix + label + ':stdout-exact', read_json(evidence / (label + '-stdout.json')) == result)
            record(evidence / (label + '-stderr.log'))
            expected_identity = {key: request[key] for key in ['issuer_id', 'key_epoch', 'message_id', 'sequence', 'expires_at_ms']}
            expected_identity.update({key: body[key] for key in ['run_id', 'objective_revision', 'authority_epoch',
                'runtime_body_digest', 'preference_state_digest', 'model_tuple_digest', 'prompt_registry_digest', 'artifact_set_digest']})
            expected_identity.update(request_id=100 + ordinal, agent_id=AGENT, spawn_generation=owners[0]['spawn_generation'],
                peer_uid=0, peer_pid=owners[1 if ordinal == 7 else 0]['health']['process_id'])
            check(prefix + label + ':all-identities', result['schema_version'] == 1 and result['identity'] == expected_identity)
            valid = True
            try:
                public.verify(bytes.fromhex(request['signature_hex']), signed_preimage(request))
            except InvalidSignature:
                valid = False
            check(prefix + label + ':independent-ed25519', valid is (ordinal != 4))
            body_hashes[body['run_id']] = hashlib.sha256(compact(body)).hexdigest()
            status, issue, code = [('admitted', None, 0), ('admitted', None, 0), ('admitted', None, 0),
                ('submit_unknown', 'objective_owner_request_rejected', 12),
                ('not_sent', 'objective_generation_fenced', 10),
                ('submit_unknown', 'objective_owner_request_rejected', 12),
                ('submit_unknown', 'objective_protocol_mismatch', 12)][ordinal - 1]
            check(prefix + label + ':conservative-status', result['status'] == status and result.get('issue') == issue
                and entry['exit_code'] == code)
            frame = compact({'schema_version': 2, 'request_id': 100 + ordinal,
                'spawn_generation': expected_identity['spawn_generation'],
                'method': {'type': 'objective_start', 'request': request}}) + b'\n'
            if ordinal == 5:
                check(prefix + label + ':zero-publication', result['bytes_written'] == 0 and result['request_frame_bytes'] is None
                    and body['spawn_generation'] != expected_identity['spawn_generation'])
            else:
                check(prefix + label + ':exact-frame-count', result['bytes_written'] == result['request_frame_bytes'] == len(frame) > 0)
            submission_summary.append({'label': label, 'status': status, 'issue': issue, 'bytes_written': result['bytes_written'],
                'signature_valid': valid, 'request_sha256': hashlib.sha256(raw).hexdigest()})
        check(prefix + 'exact-duplicate-and-old-spawn-bytes', request_raws[0] == request_raws[1] == request_raws[6])
        first, duplicate, abstain = [entry['result']['receipt'] for entry in submissions[:3]]
        check(prefix + 'same-publication-idempotence', first['idempotent'] is False and duplicate == dict(first, idempotent=True)
            and first['disposition'] == 'compiled' and abstain['disposition'] == 'explicit_abstain')
        compiled_bytes = record(evidence / 'compiled-journal.bin').read_bytes()
        final_bytes = record(evidence / 'final-journal.bin').read_bytes()
        inspection = read_json(evidence / 'journal-inspection.json')
        check(prefix + 'journal-prefix-and-hash', len(final_bytes) > len(compiled_bytes)
            and final_bytes.startswith(compiled_bytes) and inspection['journal_sha256'] == hashlib.sha256(final_bytes).hexdigest()
            and checks_by_name['exact_replay_same_publication']['journal_sha256'] == hashlib.sha256(compiled_bytes).hexdigest()
            and inspection == checks_by_name['original_journal_matches_receipts'])
        check(prefix + 'journal-two-acknowledged-records', inspection['acknowledged_sequence'] == 2
            and len(inspection['records']) == 2 and inspection['first_acknowledged_chain_digest'] == first['chain_digest']
            and inspection['acknowledged_chain_digest'] == abstain['chain_digest'])
        for ordinal, (entry, receipt) in enumerate(zip(inspection['records'], [first, abstain]), 1):
            check(prefix + 'original-publication:' + str(ordinal), all(entry[key] == receipt[key] for key in
                ['run_id', 'objective_digest', 'hard_constraint_digest', 'publication_digest', 'chain_digest', 'disposition'])
                and entry['signed_body_digest'] == body_hashes[entry['run_id']]
                and entry['generation'] == receipt['response_generation']
                and entry['journal_sequence'] == entry['sequence'] == ordinal
                and entry['publication_binding_checked'] is True and entry['changed_publication_digest_rejected'] is True
                and entry['authority_grants_any'] is False)
        for name in ['invalid_signature_owner_rejected', 'body_generation_fenced_before_send', 'revoked_issuer_owner_rejected']:
            check(prefix + name + ':durable-rejection', checks_by_name[name]['journal_unchanged'] is True)
        old = checks_by_name['old_spawn_not_accepted']
        restart = checks_by_name['owner_restart_retains_historical_journal']
        check(prefix + 'restart-preserves-history-without-resume', restart['historical_run_absent'] is True
            and restart['journal_sha256'] == inspection['journal_sha256'] and old['journal_unchanged'] is True
            and old['post_request_run'] is None and old['post_request_owner'] == owners[1]
            and old['issue'] == 'objective_protocol_mismatch' and old['transport_status'] == 'submit_unknown')
        check(prefix + 'controlled-stop-and-disposable-root-removed', checks_by_name['controlled_stop']['active'] is False
            and not Path(runtime['runtime_command'][4]).exists())
        report['runtime_summaries'][kind] = {'record_count': len(values), 'submission_count': 7, 'check_count': 10,
            'old_owner_pid': owners[0]['health']['process_id'], 'new_owner_pid': owners[1]['health']['process_id'],
            'old_spawn': owners[0]['spawn_generation'], 'new_spawn': owners[1]['spawn_generation'],
            'compiled_publication_digest': first['publication_digest'], 'final_journal_sha256': inspection['journal_sha256'],
            'journal_records': 2, 'submissions': submission_summary}
        executions[kind], runtime_reports[kind] = execution, runtime
        for path in root.rglob('*'):
            if path.is_file():
                record(path)
    check('independent-disposable-producers', len(set(public_keys)) == 2)

    capture_root = BASE / 'nextstep-objective-capture-01'
    capture = read_json(capture_root / 'capture-receipt.json')
    config = read_json(capture_root / 'capture-config.json')
    namespace = read_json(capture_root / 'namespace.json')
    ui_receipt = read_json(capture_root / 'rust-build-receipt.json')
    provenance = capture['source_provenance']
    check('capture-clean-source-and-build-receipt', capture['capture_passed'] is True
        and provenance == config['provenance'] and provenance['harness_commit'] == provenance['production_ui_commit'] == COMMIT
        and sha(capture_root / 'rust-build-receipt.json') == provenance['build_receipt_sha256']
        == executions['session']['receipt_inputs']['ui']['sha256']
        and all(command['exit_code'] == 0 for command in ui_receipt['build_commands']))
    verify_elf('shell', provenance['binaries']['trill-shell'])
    check('same-built-shell', provenance['binaries']['trill-shell'] == ui_receipt['binaries']['trill-shell'])
    source_files = {'harness': 'capture-source.py', 'reviewed_helpers': 'reviewed-capture-helpers.py',
        'pixels': 'x11-capture-source.py', 'guard': 'child-guard-source.py'}
    for role, value in provenance['tracked_sources'].items():
        raw = record(capture_root / source_files[role]).read_bytes()
        check('captured-source:' + role, raw == git('show', COMMIT + ':' + value['path'])
            and hashlib.sha256(raw).hexdigest() == value['sha256'] and len(raw) == value['bytes']
            and git('rev-parse', COMMIT + ':' + value['path']).decode().strip() == value['git_blob'])
    dependencies = read_json(capture_root / 'host-dependencies.json')
    check('host-manifest-bound', sha(capture_root / 'host-dependencies.json') == provenance['host_dependencies_sha256']
        == namespace['host_dependencies_sha256'] and dependencies['package_stage_receipt_used'] is False)
    for path, value in dependencies['files'].items():
        actual = record(Path(path))
        check('host-file:' + path, inputs[str(actual)]['sha256'] == value['sha256'] and actual.stat().st_size == value['bytes'])
    for name, value in dependencies['tools'].items():
        check('host-tool:' + name, str(Path(value['path']).resolve()) == value['resolved'])
    check('private-namespace-display', namespace['returncode'] == 0 and namespace['isolation_succeeded'] is True
        and namespace['shared_pid_namespace'] is True and '--unshare-pid' not in namespace['argv']
        and all(arg in namespace['argv'] for arg in ['--unshare-net', '--unshare-user', '--unshare-uts', '--unshare-ipc', '--clearenv'])
        and capture['private_display_rejects_no_cookie'] is True
        and capture['shell_processes_started'] == 1 and capture['same_shell_pid_all_phases'] is True
        and capture['same_shell_window_all_phases'] is True)
    actual_phases = [value for value in runtime_reports['session']['runtime_records'] if value['event'] == 'objective_session_phase_observed']
    check('three-original-session-phases', len(actual_phases) == len(capture['phases']) == 3)
    first_run = next(value['evidence']['run'] for value in runtime_reports['session']['runtime_records'] if value.get('check') == 'compiled_original_admission')
    phase_summary = []
    for ordinal, (phase, item) in enumerate(zip(actual_phases, capture['phases']), 1):
        phase_path = BASE / 'nextstep-objective-phase-01' / f'phase-{ordinal}.json'
        ack_path = phase_path.with_name(f'ack-{ordinal}.json')
        held, ack = read_json(phase_path), read_json(ack_path)
        check('phase:' + str(ordinal) + ':all-copies-bound', held == phase
            == read_json(capture_root / item['phase_file'])
            == read_json(BASE / 'nextstep-hepta-objective-session-runtime-01/runtime-evidence' / f'session-phase-{ordinal}.json')
            and sha(phase_path) == item['phase_sha256'] == sha(capture_root / item['phase_file'])
            and held['phase'] == item['phase'] == PHASES[ordinal - 1]
            and held['sequence'] == item['sequence'] == ordinal
            and ack == held['ack'] == {'sequence': ordinal, 'phase': PHASES[ordinal - 1], 'session_instance': held['session_instance']})
        for path in [phase_path, ack_path]:
            metadata = path.stat()
            check('private-phase-or-ack:' + path.name, stat.S_IMODE(metadata.st_mode) == 0o600 and metadata.st_nlink == 1 and metadata.st_uid == 0)
        check('phase:' + str(ordinal) + ':same-shell-and-socket', item['shell_pid'] == capture['shell_pid']
            and item['shell_window_xid'] == capture['shell_window']['xid']
            and held['runtime_dir'] == actual_phases[0]['runtime_dir'] == config['runtime_dir']
            and held['session_socket_path'] == actual_phases[0]['session_socket_path'])
        expected_owner = runtime_reports['session']['runtime_records'][0]['observation'] if ordinal < 3 else next(
            value['observation'] for value in reversed(runtime_reports['session']['runtime_records']) if value['event'] == 'owner_running')
        snapshots = []
        for side in ['before', 'after']:
            saved = item[side]
            path = capture_root / saved['file']
            snapshot = read_json(path)
            hepta, run = snapshot['hepta'], snapshot['hepta']['run']
            check(f'phase:{ordinal}:{side}:actual-peer-and-snapshot', sha(path) == saved['sha256']
                and path.stat().st_size == saved['bytes'] and snapshot['type'] == 'snapshot' and snapshot['tasks'] == []
                and snapshot['session_instance'] == saved['session_instance'] == held['session_instance']
                and saved['peer_pid'] == held['session_pid'] == item['session_pid'] and saved['peer_uid'] == saved['peer_gid'] == 0
                and hepta == saved['hepta'])
            observed = hepta['last_observation']
            check(f'phase:{ordinal}:{side}:original-owner', observed['agent_id'] == AGENT
                and observed['spawn_generation'] == expected_owner['spawn_generation']
                and observed['current_generation'] == expected_owner['current_generation']
                and observed['health'] == expected_owner['health'])
            check(f'phase:{ordinal}:{side}:run-state', run['run_id'] == first_run['run_id']
                and run['connection'] == ('observed', 'stale', 'projection_missing')[ordinal - 1])
            if ordinal < 3:
                check(f'phase:{ordinal}:{side}:original-seven-fields', run_fields(run['last_observation']) == first_run
                    and type(run['sample_age_at_snapshot_ms']) is int and run['sample_age_at_snapshot_ms'] >= 0)
            if ordinal == 1:
                check(f'phase:{ordinal}:{side}:independent-source-age', run['sample_age_at_snapshot_ms'] + saved['transport_elapsed_ms_rounded_up'] <= 7000
                    and 0 <= saved['finished_unix_ms'] - run['last_observation']['sampled_unix_ms'] <= 7000
                    and 0 <= saved['finished_unix_ms'] - observed['sampled_unix_ms'] <= 7000 and run['observation_gap'] is False)
            elif ordinal == 2:
                prior = held['snapshot']['hepta']
                check(f'phase:{ordinal}:{side}:exact-stale-history', observed == prior['last_observation']
                    and run['last_observation'] == prior['run']['last_observation']
                    and run['last_attempt_unix_ms'] == prior['run']['last_attempt_unix_ms']
                    and run['error_code'] == 'protocol_mismatch' and run['observation_gap'] is True)
            else:
                check(f'phase:{ordinal}:{side}:missing-not-rejected', run['last_observation'] is None
                    and 'sample_age_at_snapshot_ms' not in run and run['observation_gap'] is False
                    and run['error_code'] == 'run_projection_missing')
            snapshots.append(snapshot)
            properties = record(capture_root / (item['phase_file'][:-5] + '-' + side + '-properties.stdout.log')).read_text().splitlines()
            visible = record(capture_root / (item['phase_file'][:-5] + '-' + side + '-visible.stdout.log')).read_text().split()
            check(f'phase:{ordinal}:{side}:actual-window-properties', f'_NET_WM_PID(CARDINAL) = {capture["shell_pid"]}' in properties
                and 'WM_CLASS(STRING) = "trill-shell", "trill-shell"' in properties and visible == [capture['shell_window']['xid']])
        if ordinal == 2:
            before_run, after_run = [snapshot['hepta']['run'] for snapshot in snapshots]
            check('stale-source-age-advances-without-renewal', after_run['sample_age_at_snapshot_ms'] > before_run['sample_age_at_snapshot_ms']
                and {key: value for key, value in after_run.items() if key != 'sample_age_at_snapshot_ms'}
                == {key: value for key, value in before_run.items() if key != 'sample_age_at_snapshot_ms'})
        check('phase:' + str(ordinal) + ':snapshot-png-ack-order', held['recorded_unix_ms'] <= item['before']['started_unix_ms']
            <= item['before']['finished_unix_ms'] <= item['capture_started_unix_ms'] <= item['capture_finished_unix_ms']
            <= item['after']['started_unix_ms'] <= item['after']['finished_unix_ms'] <= item['acknowledged_unix_ms']
            and item['acknowledged_unix_ms'] - held['recorded_unix_ms'] < held['ack_timeout_seconds'] * 1000)
        picture = record(capture_root / item['screenshot']['file'])
        raw = picture.read_bytes()
        check('phase:' + str(ordinal) + ':actual-png-bound', sha(picture) == item['screenshot']['sha256']
            and len(raw) == item['screenshot']['bytes'] and raw[:8] == b'\x89PNG\r\n\x1a\n'
            and struct.unpack('>II', raw[16:24]) == (1440, 1000))
        report['visual_review'][ordinal - 1]['sha256'] = sha(picture)
        phase_summary.append({'phase': held['phase'], 'session_pid': held['session_pid'], 'worker_tid': held['worker_tid'],
            'session_instance': held['session_instance'], 'original': held['original'], 'png_sha256': sha(picture)})
    check('session-continuity-then-explicit-replacement', all(actual_phases[0][key] == actual_phases[1][key]
        for key in ['session_pid', 'session_instance', 'worker_tid']) and all(actual_phases[1][key] != actual_phases[2][key]
        for key in ['session_pid', 'session_instance', 'worker_tid']))
    stops = [value for value in runtime_reports['session']['runtime_records'] if value['event'] == 'objective_session_stopped']
    check('two-owned-session-stops', len(stops) == 2 and all(stop['signal'] == 9 and all(stop[key] == actual_phases[index][key]
        for key in ['session_pid', 'session_instance', 'worker_tid']) for stop, index in zip(stops, [1, 2])))
    check('capture-owned-child-cleanup', {value['label']: value['pid'] for value in capture['children']}
        == {value['label']: value['pid'] for value in capture['cleanup']} and len(capture['cleanup']) == 2
        and all(type(value['observed_returncode']) is int for value in capture['cleanup']) and not capture.get('cleanup_errors'))
    pids = {value['pid'] for value in capture['children']} | {phase['session_pid'] for phase in actual_phases}
    for value in report['runtime_summaries'].values():
        pids.update([value['old_owner_pid'], value['new_owner_pid']])
    report['recorded_pids_absent_at_review'] = {str(pid): not Path('/proc', str(pid)).exists() for pid in sorted(pids)}
    check('recorded-test-processes-currently-absent', all(report['recorded_pids_absent_at_review'].values()))
    for path in capture_root.rglob('*'):
        if path.is_file():
            record(path)
    report['capture_summary'] = {'shell_pid': capture['shell_pid'], 'window_xid': capture['shell_window']['xid'],
        'session_runtime_dir': config['runtime_dir'], 'phase_count': 3, 'phases': phase_summary,
        'source_tree': provenance['harness_tree'], 'ui_tree': provenance['unchanged_ui_subtree'],
        'host_dependency_files': len(dependencies['files']), 'actual_pngs_independently_viewed': 3}
    report['status'] = 'passed_for_scoped_original_admission_and_english_runtime_pixels'
except Exception as error:
    report['status'] = 'failed'
    report['scope_blockers'].append(str(error))
finally:
    report['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    report['offline_assertions'] = {'passed': sum(value['passed'] for value in checks), 'total': len(checks),
        'meaning': 'artifact consistency checks, not additional runtime executions or tests'}
    report['binary_bindings'] = binary_inputs
    report['inputs_manifest'] = 'inputs-sha256.json'
    report['checks_file'] = 'offline-checks.json'
    (OUT / 'inputs-sha256.json').write_text(json.dumps(inputs, indent=2) + '\n')
    (OUT / 'offline-checks.json').write_text(json.dumps(checks, indent=2) + '\n')
    report['inputs_manifest_sha256'] = sha(OUT / 'inputs-sha256.json')
    report['offline_review_script_sha256'] = sha(Path(__file__))
    (OUT / 'audit.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'status': report['status'], 'assertions': report['offline_assertions'],
        'inputs': len(inputs), 'blockers': report['scope_blockers']}))
    if report['scope_blockers']:
        sys.exit(1)
