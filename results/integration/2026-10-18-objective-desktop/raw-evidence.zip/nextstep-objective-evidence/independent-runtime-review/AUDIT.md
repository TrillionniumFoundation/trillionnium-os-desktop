# 原始 Objective 与三阶段实际 Shell：只读证据复核

**结论：在“隔离测试身份签名 → 原始 Agentd 持久受理 → 真实 Session → 同一 Rust Shell 的英文 Runtime 展示”范围内通过。未发现阻断该范围结论的身份、摘要、阶段或清理不一致。** 完整机器记录为 [audit.json](audit.json)，实际输入摘要为 [inputs-sha256.json](inputs-sha256.json)。

冻结集成源码：`25298f5d87cf3db90deefe9c0405ecd241dc6581`，树 `9584997da412dd10c0960f69011b40a4b26d2862`。原始 Hepta 固定为 `f8c9419df6ddeb36ff8b522a50219981fb8d9345`。本次审查只读取已有产物，没有启动新的 owner、CLI、Session、显示或构建，也没有修改集成源码。

审查者 `/root/hepta_task_contract` 曾贡献 Probe/capture 实现，本次独立复核的是 root 实际操作生成的证据；这不应表述为独立于实现作者的外部安全审计。

## 证据覆盖

对 **294 个实际输入文件**记录了 SHA-256、字节数及文件属性，完成 **401 项离线字段与摘要一致性断言**。这些断言用于核对已存在的证据，不是额外 401 次真实运行或产品测试。逐项结果在 [offline-checks.json](offline-checks.json)，复核脚本在 [audit_read_only.py](audit_read_only.py)。

核对了原 Agentd、Probe、observer、submitter、Session、ctl、Shell 七个实际 ELF 的当前字节数和 SHA-256，并与各自成功构建 receipt、冻结 Git 树、源文件摘要和执行绑定对齐。Probe 的实际构建报告与 resolved Cargo.lock 也吻合。原始 Hepta checkout 在审查时仍为固定、干净的源码。

| 实际执行 | 原 owner PID | spawn generation | 实际记录 | 原始 journal |
| --- | --- | --- | --- | --- |
| core runtime | `322526 → 322713` | `1 → 5` | 7 次提交、10 个核心检查、20 行原始记录 | 2 条受理记录 |
| Session runtime | `323523 → 323803` | `1 → 5` | 7 次提交、10 个核心检查、25 行原始记录 | 2 条受理记录 |

两轮使用不同的临时测试公钥，属于两个独立的一次性环境。Shell 截图只绑定第二轮；没有将第一轮的受理记录冒充第二轮的窗口证据。

## 签名、受理与持久身份

对每轮七个保留的原始 compact JSON，核对了 CLI stdout 与运行日志完全相同，且 request ID、agent、spawn、peer PID/UID、issuer、message、sequence、revision、authority epoch 及所有绑定摘要一致。外层实际协议帧长度也按冻结 wire 格式复算：正向及送达用例的 `bytes_written == request_frame_bytes`，body generation 用例在发送前保持零字节。

按固定原版 `SignedMessageClaims::signing_bytes` 和 `push_id` 的格式进行了独立的离线 Ed25519 验证：每轮六个应有效的封套均有效，坏签名封套无效。错 generation 和 revoked 用例本身具有有效签名，分别由发送前 generation 约束、原 owner 的信任状态限制处理；审查没有生成新密钥或身份。

正向 compiled 受理仍为 `admitted`、generation `2`、terminal `false`。完全相同的原始封套重送返回同一 publication/chain，仅 idempotent 变为 true；未新增 journal 记录。`explicit_abstain` 形成第二条持久受理，但没有当前运行投影。坏签名、撤销和旧 spawn 的 CLI 结果保持保守的 `submit_unknown`；没有被解释为通用的“肯定未发布”。旧 spawn 用例还精确记录了 `objective_protocol_mismatch`、完整发送字节，以及新 owner 仍健康、run 仍为 null。

compiled journal 是最终 journal 的原样前缀。两个实际 journal 文件的摘要、原 owner 重启前后的不变摘要、两个已确认 chain anchor，以及原始公有 API 输出的 publication record digest 全部对齐。两个原始记录的签名 body digest 也与离线重算相同，authority grants 均为 false。记录中的受控 publication digest 改写负例被原公有 API 绑定校验拒绝。

本次只读复核核对了原始解码与 publication 绑定的实际输出和对应二进制文件摘要，没有再次运行恢复过程，也没有另写一套持久 journal 解码器。

## Session、同一窗口与实际 PNG

运行目录全程为 `/tmp/ho-hls8lm03/objective-ui`，Socket 路径不变。实际 Shell **PID `323732`、XID `2097155`** 在三阶段一致。

| 阶段 | 实际 Session / worker | 原 owner 与 run 语义 | 像素复核 |
| --- | --- | --- | --- |
| `compiled_run_projected` | PID `323665` / TID `323667` | owner `323523`，run 七原字段为 admitted / revision 1 / generation 2 / authority epoch 1 / terminal false | `OBSERVED · READ ONLY`，关键字段完整可见 |
| `old_endpoint_run_stale` | 同一 PID、instance、worker | 新 owner 已为 `323803`；原 Session 保留旧受理和旧 owner 元数据，明确 stale 与 gap | `STALE · CURRENT RUN STATE UNKNOWN`，历史保留和中断提示完整可见 |
| `replacement_run_projection_missing` | PID `323923` / TID `323925`，新 instance | 同一个重启后的 owner，spawn 5 / current 6；新 Session 无 run 成功样本 | `PROJECTION MISSING · CURRENT RUN STATE UNKNOWN`，没有伪造完成或未受理结论 |

每张 PNG 前后的实际快照文件、收据内副本与原阶段身份一致，包含正确的 kernel peer PID/UID、Session instance、原 owner 和七个 run 字段。phase/ACK 均为单链接、UID 0、0600 文件，ACK 内容与原阶段精确一致，时间顺序为“前快照 → 实际 PNG → 后快照 → ACK”。所有 ACK 均在原 120 秒期限内。

活跃 run 的源单调年龄加实际 UDS RTT 满足捕获新鲜度约束。stale 阶段的原样本、last attempt、七个 run 字段完全保留，仅 `sample_age_at_snapshot_ms` 从 `3221` 前进到 `5939`；新 Session 的首次 null 没有伪造年龄或历史样本。

**本审查已使用 `view_image` 独立打开全部三张实际 1440×1000 PNG。** 三张英文 Runtime 卡片通过可见性和状态语义复核，图片摘要如下：

| PNG | SHA-256 |
| --- | --- |
| phase 1 | `724bcd24eb8d6462a26475ac99a4847d93070a567f1f1cbb634ce0c86a4d4586` |
| phase 2 | `e68e2d7ec2b038d69d650774c0e15b87a09bc131ebc66d12613f7c6941b04a8a` |
| phase 3 | `9958922769c3d52d8594830fbe3714a4c2c9b048625a4e9f40be7ef99a05f671` |

Xvfb 的私有 Xauthority 无 cookie 拒绝检查、bwrap namespace 成功退出、共享 PID 配置、相同窗口属性及受控子进程清理收据均一致。两次 Session 停止记录匹配真实 PID/instance/worker；两轮 Agentd 最终均 inactive。一次性运行目录已删除，记录中的 Agentd、Session、Shell 和 Xvfb PID 在本次只读检查时均不存在。

## 必须保留的范围限制

1. **任务仍停留在非终态受理。** 本证据不验证 canonical intelligence、模型 turn、Operations 调度、历史 run 恢复执行或任何设备效果。已知 run 来自可信测试 launcher；Shell 没有 Objective 提交控件。
2. **顶部中文后缀存在缺字方框。** 这是实际可见的字体覆盖缺口，英文卡片范围内不阻断本次结论；不得声称 CJK/IME 通过。
3. **这是 Linux x86_64 宿主原型与私有 Xvfb。** 它不构成 Asterinas/自研内核 GUI、移动设备、物理 GPU 或物理显示测试。
4. 原始 Agentd 构建使用了 `--no-default-features`。`native-build-02/receipt.json` 的实际命令包含 `--locked`，**不含 `--offline`**；仅凭该 receipt 不应把这次 Agentd 构建描述为离线构建。此点不改变本次运行及像素证据的一致性。
5. ACK 和首屏 layout marker 各自仅承担协调及首次布局绑定。像素结论来自本次实际 PNG 的人工查看，并与单独通过的原始受理/journal 报告共同限定使用。
