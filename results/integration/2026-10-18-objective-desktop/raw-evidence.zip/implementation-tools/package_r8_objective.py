#!/usr/bin/env python3
"""Archive the executed R8 evidence without changing any source receipts."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/499c7902de8e')
REPO = ROOT / 'nextstep-integration'
OUT = REPO / 'results/integration/2026-10-18-objective-desktop'
LOCAL = '25298f5d87cf3db90deefe9c0405ecd241dc6581'
REMOTE = 'ca5e7d8473690df1bf7636de0808e58414c40abe'
TREE = '9584997da412dd10c0960f69011b40a4b26d2862'

def read(path):
    return json.loads((ROOT / path).read_text())

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(path):
    p = Path(path)
    raw = p.read_bytes()
    return {'bytes': len(raw), 'sha256': digest(raw)}

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()

COPIES = {
    'native-agentd-build.json': 'nextstep-hepta-build/native-build-02/receipt.json',
    'probe-build.json': 'nextstep-hepta-objective-build-01/report.json',
    'probe-build-execution.json': 'nextstep-hepta-build/probe-build-01/receipt.json',
    'cli-checks.json': 'nextstep-objective-evidence/cli-02/execution.json',
    'cli-build.json': 'nextstep-objective-evidence/cli-integration-build/build-receipt.json',
    'ui-build.json': 'nextstep-objective-evidence/ui-integration-01/build-receipt.json',
    'core-runtime.json': 'nextstep-hepta-objective-core-runtime-01/report.json',
    'session-runtime.json': 'nextstep-hepta-objective-session-runtime-01/report.json',
    'core-execution.json': 'nextstep-objective-evidence/objective-core-runtime-01/execution.json',
    'session-execution.json': 'nextstep-objective-evidence/objective-session-runtime-01/execution.json',
    'capture-receipt.json': 'nextstep-objective-capture-01/capture-receipt.json',
    'namespace.json': 'nextstep-objective-capture-01/namespace.json',
    'pr191-publication.json': 'nextstep-ci-evidence/pr191-publication.json',
    'pr191-merge-ci-success.json': 'nextstep-ci-evidence/pr191-merge-ci-success.json',
}

def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    assert git('rev-parse', LOCAL + '^{tree}') == TREE
    for dst, src in COPIES.items():
        shutil.copyfile(ROOT / src, OUT / dst)
    capture = read('nextstep-objective-capture-01/capture-receipt.json')
    ui = read('nextstep-objective-evidence/ui-integration-01/build-receipt.json')
    assert ui['status'] == 'passed' and ui['source_commit'] == LOCAL
    assert capture['capture_passed'] is True
    images = []
    visible = [
        {'status': 'OBSERVED · READ ONLY', 'owner_phase': 'admitted',
         'revision': 1, 'run_generation': 2, 'authority_epoch': 1,
         'terminal_observed': False, 'run_id_visible': 'run.desktop-compiled',
         'owner_pid_visible': 323523, 'spawn_current_visible': [1, 2],
         'note': 'English known-run card is visible and readable. PNG sample sequence may lie between the before/after snapshots; no byte-equality claim across a live sampling interval.'},
        {'status': 'STALE · CURRENT RUN STATE UNKNOWN', 'diagnostic': 'protocol_mismatch',
         'last_observation_preserved': True, 'run_id_visible': 'run.desktop-compiled',
         'owner_pid_visible': 323523, 'spawn_current_visible': [1, 2],
         'observation_gap_text_visible': True,
         'note': 'Stale card preserves admitted/revision 1/generation 2/epoch 1/terminal false. It does not present old health as current. Phase-2 history is checked before/after; phase-1 and phase-2 PNG samples need not be identical.'},
        {'status': 'PROJECTION MISSING · CURRENT RUN STATE UNKNOWN',
         'run_id_visible': 'run.desktop-compiled', 'owner_pid_visible': 323803,
         'spawn_current_visible': [5, 6], 'last_observation': None,
         'admission_and_durable_outcome_unknown_text_visible': True,
         'no_successful_observation_text_visible': True,
         'note': 'New owner health is visible; absent current in-memory run projection is explicitly unknown and is not rendered as never submitted, resumed or completed.'},
    ]
    for phase, observations in zip(capture['phases'], visible, strict=True):
        s = phase['screenshot']
        src = ROOT / 'nextstep-objective-capture-01' / s['file']
        assert identity(src) == {'bytes': s['bytes'], 'sha256': s['sha256']}
        shutil.copyfile(src, OUT / s['file'])
        images.append({'sequence': phase['sequence'], 'phase': phase['phase'],
                       'file': s['file'], 'bytes': s['bytes'], 'sha256': s['sha256'],
                       'width': s['width'], 'height': s['height'],
                       'review_method': 'root viewed original PNG with view_image during the live task',
                       'observations': observations})
    if not (OUT / 'visual-review.json').exists():
        write('visual-review.json', {
            'recorded_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'reviewer': 'root', 'review_type': 'manual visual inspection; not OCR or layout-marker inference',
            'source_commit': LOCAL, 'source_tree': TREE,
            'capture_receipt': identity(ROOT / 'nextstep-objective-capture-01/capture-receipt.json'),
            'verdict': 'English_Runtime_card_passed_with_known_font_limitation',
            'images_actually_viewed': 3, 'images': images,
            'limitations': [
                'A Chinese suffix after Objective submission unavailable renders as missing-font boxes in all three PNGs. Whole-UI CJK rendering is not qualified by this run.',
                'No keyboard/IME, physical display/input, GPU, Wayland pixels, Asterinas or mobile qualification.',
                'Visible admitted and terminal false describe the original owner run projection, not a model turn or device result.',
                'Capture ACKs coordinate the probe and do not independently certify pixels.'
            ],
            'same_shell_pid_from_capture_receipt': capture['shell_pid'],
            'same_window_xid_from_capture_receipt': capture['shell_window']['xid'],
        })
    runtimes = []
    for mode in ['core', 'session']:
        report = read(f'nextstep-hepta-objective-{mode}-runtime-01/report.json')
        execution = read(f'nextstep-objective-evidence/objective-{mode}-runtime-01/execution.json')
        records = report['runtime_records']
        checks = [r['check'] for r in records if r['event'] == 'objective_check']
        submissions = [r for r in records if r['event'] == 'submission_observed']
        phases = [r for r in records if r['event'] == 'objective_session_phase_observed']
        assert report['status'] == 'passed' and execution['exit_code'] == 0
        assert len(checks) == 10 and len(submissions) == 7
        assert len(phases) == (3 if mode == 'session' else 0)
        acceptance = next(r for r in records if r['event'] == 'acceptance_pass')
        runtimes.append({'mode': mode, 'status': report['status'],
                         'started_at_utc': execution['started_at_utc'],
                         'ended_at_utc': execution['ended_at_utc'],
                         'runtime_record_count': len(records), 'checks': checks,
                         'explicit_submission_attempts': len(submissions),
                         'session_phases': [p['phase'] for p in phases],
                         'original_acceptance_record': acceptance,
                         'report': mode + '-runtime.json',
                         'execution': mode + '-execution.json'})
    write('acceptance-summary.json', {
        'schema': 'trillionnium.r8-objective-desktop-evidence.v1',
        'recorded_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'pull_request': 'https://github.com/TrillionniumFoundation/trillionnium-os-desktop/pull/192',
        'qualified_source': {'local_commit': LOCAL, 'same_tree_remote_commit': REMOTE,
                             'tree': TREE, 'ui_tree': git('rev-parse', LOCAL + ':ui'),
                             'services_tree': git('rev-parse', LOCAL + ':services'),
                             'hepta_os_tree': git('rev-parse', LOCAL + ':services/hepta-os'),
                             'parents_of_remote_code_commit': ['89e06fa83b6614e9b20ea946b4399b0ac5293f4b', 'c4d4224c9daf1a5b22997930000f43001525d531']},
        'original_hepta': read('nextstep-hepta-objective-session-runtime-01/report.json')['upstream'],
        'ui_tests': ui['test_totals'], 'ui_build_receipt': 'ui-build.json',
        'cli_frozen_tests': {'passed': 41, 'failed': 0,
                             'source_commit': 'fbaa6fa9582424a1c02bd71d9b1edaaaa4fe53c2',
                             'actual_receipt': 'cli-checks.json',
                             'scope': 'scripted UDS/library/CLI/doc tests, separately from actual original-owner runtime'},
        'python_contracts': {'receipt_parser': 12, 'actual_new_capture_ci_step': 10},
        'runtimes': runtimes,
        'native_binaries': read('nextstep-objective-evidence/objective-session-runtime-01/execution.json')['binaries'] | {'shell': capture['source_provenance']['binaries']['trill-shell']},
        'shell_capture': {'passed': True, 'same_shell_pid': capture['shell_pid'],
                          'same_window_xid': capture['shell_window']['xid'],
                          'phases': 3, 'actual_pngs': 3,
                          'visual_review': 'visual-review.json',
                          'english_runtime_only': True, 'cjk_font_limitation_observed': True},
        'scope': {'linux_x86_64_host': True, 'isolated_test_issuer': True,
                  'original_hepta_modified': False, 'production_issuer': False,
                  'model_turn': False, 'canonical_intelligence': False,
                  'operations_dispatch': False, 'device_effect': False,
                  'historical_run_resumed': False, 'online_durable_reconciliation': False,
                  'asterinas_g1': False, 'asterinas_g2': False, 'mobile': False},
        'raw_receipt_copy_map': COPIES,
        'ci_note': 'Local execution and exact tree publication are recorded here. New PR/merge CI is separately timestamped; no CI success is inherited from another head.'
    })

def pack():
    roots = [
        'nextstep-objective-evidence', 'nextstep-hepta-build/native-build-01',
        'nextstep-hepta-build/native-build-02', 'nextstep-hepta-build/probe-build-01',
        'nextstep-hepta-objective-build-01', 'nextstep-hepta-objective-core-runtime-01',
        'nextstep-hepta-objective-session-runtime-01', 'nextstep-objective-capture-01',
        'nextstep-objective-phase-01', 'nextstep-ui-evidence/run-projection',
        'nextstep-ui-evidence/run-projection-queue-age',
        'nextstep-hepta-review/objective-shell-preparation',
    ]
    inputs = set()
    for name in roots:
        p = ROOT / name
        if not p.is_dir():
            raise ValueError(f'Missing archive input: {name}')
        inputs.update(f for f in p.rglob('*') if f.is_file() and not f.is_symlink())
    inputs.update(p for p in (ROOT / 'nextstep-hepta-build').iterdir() if p.is_file())
    for name in ['nextstep-ci-evidence/pr191-publication.json',
                 'nextstep-ci-evidence/pr191-merge-ci-success.json',
                 'nextstep-ci-evidence/pr189-job-117592973270.log',
                 'nextstep-hepta-review/objective-shell-current-host-dependencies.json',
                 'implementation-tools/package_r8_objective.py']:
        p = ROOT / name
        if p.is_file():
            inputs.add(p)
    excluded = []
    rows = []
    with zipfile.ZipFile(OUT / 'raw-evidence.zip', 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as z:
        for p in sorted(inputs):
            rel = p.relative_to(ROOT).as_posix()
            if p.name == 'Xauthority' or p.suffix == '.png' or 'publish-input' in p.name or '__pycache__' in p.parts:
                excluded.append({'path': rel, 'reason': 'private X cookie, separately delivered PNG, transient API payload or reproducible cache'})
                continue
            raw = p.read_bytes()
            if any(line.startswith(b'-----BEGIN ') and line.endswith(b'PRIVATE KEY-----')
                   for line in raw.splitlines()):
                raise ValueError(f'Private key must not be archived: {rel}')
            info = zipfile.ZipInfo(rel, date_time=(2026, 10, 18, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, raw)
            rows.append({'path': rel, 'bytes': len(raw), 'sha256': digest(raw)})
    with zipfile.ZipFile(OUT / 'raw-evidence.zip') as z:
        assert z.testzip() is None
        for row in rows:
            raw = z.read(row['path'])
            assert len(raw) == row['bytes'] and digest(raw) == row['sha256']
    write('raw-evidence-manifest.json', {
        'archive': 'raw-evidence.zip', 'archive_identity': identity(OUT / 'raw-evidence.zip'),
        'entries': len(rows), 'uncompressed_bytes': sum(r['bytes'] for r in rows),
        'files': rows, 'excluded_inputs': excluded,
        'actual_runtime_signing_private_key_archived': False,
        'elf_binaries_archived': False,
        'note': 'Original receipts are byte copies. Absolute paths record their execution environment; zip entry paths preserve scratch-relative provenance. ELF byte hashes and exact source/build commands are retained without large build caches.'
    })
    manifest()

def manifest():
    rows = []
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and p.name != 'artifact-manifest.json':
            rows.append({'path': p.relative_to(OUT).as_posix(), **identity(p)})
    write('artifact-manifest.json', {'schema': 'trillionnium.artifact-manifest.v1',
                                   'files': rows, 'manifest_excludes_itself': True})
    print(json.dumps({'output': str(OUT), 'files': len(rows), 'bytes': sum(r['bytes'] for r in rows)}))

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('action', choices=['prepare', 'pack', 'manifest'])
    a = p.parse_args()
    {'prepare': prepare, 'pack': pack, 'manifest': manifest}[a.action]()
