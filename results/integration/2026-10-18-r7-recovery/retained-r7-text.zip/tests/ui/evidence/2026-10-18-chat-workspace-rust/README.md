# R7 Rust chat workspace — source-bound verification

The final frozen source is `5f6915cc8136514f8da2b636fef1ba66559ac5aa`
(`ui` tree `8dfb8dc61af8dea14ca5d2f50b0379821161aabb`). On this source the
complete UI workspace has **103 passing tests**, the two explicit real-font
tests pass separately, strict Clippy and formatting pass, and all four native
production binaries build successfully. Each completed command retains its
actual source before/after, raw log, exit code and pre-execution helper copies.

This archive records Rust, import, source and build verification. Native
window interaction/presented pixels have their own capture evidence and are
not inferred from these tests. None of these commands starts original Agentd,
submits an AI objective or controls a physical/mobile device.

## Implemented behavior

The native Shell opens Workspace / Chat. Local drafts, composer text and
Tasks / Context / Console tabs belong to the selected workspace. A user can
quote a task from an actual complete Session snapshot, save the local draft
with its typed context, and open the matching current task inside the same
workspace. Console remains an embedded read-only tab.

A host reference is `(session_instance, task_id)` plus the quoted workspace
and app metadata. Reusing the task number in a replacement Session leaves the
old quote historical. A missing bounded task row does not imply a terminal
outcome. A Hepta runtime quote uses its independent observing Session and
original agent/spawn/process identity; it does not associate a host process
with an AI objective. The renderer adds no objective request or authority.

Current cards use the complete snapshot's resource sample and local receipt
age. Both must be at most 7,000 ms; 7,001 ms, missing times and future times
are unknown. A task's last-update timestamp does not establish freshness, and
an action reply cannot refresh the complete snapshot cache. The shared pure
predicate preserves the R6 Hepta visible-state codes and history semantics.

Typed local export uses `local-context-drafts-v2.json`, with explicit
workspace/text/context data. Imported content carries no current receipt or
authority. Only genuine v2 absence permits legacy v1 fallback. The full
module/identity/storage contract is in `support/ui/CHAT_WORKSPACE.md` at the
recorded source.

## Source sequence

| Source | Role |
| --- | --- |
| `db54f734b6cca7cd6b278bfd982d168a10b1b2e0` | First typed chat/context implementation; 102 ordinary tests pass |
| `e78680ea8ca5176b5058591f4809449aabaf06b7` | Adds the actual bounded FIFO import RED regression and resolves two strict-Clippy test-style diagnostics |
| `c3c388056d896c940ea1c8fa7a974b214252773e` | Adds nonblocking open before the existing regular-file descriptor check; the same FIFO regression passes |
| `5f6915cc8136514f8da2b636fef1ba66559ac5aa` | Ordinary merge of current main `9a858dceb3a0ede6c3a021b9d16f3bf41e8503d5`; retains its independent exec-owner Session lock regression; final gates/build run here |

`source-identities.json` records full trees and parents. Every command records
all tracked file hashes under both `ui` and the linked path dependency
`services/hepta-os`, as well as both Git trees. The dependency tree is
`7ebe43051e1cebb8049ba50e9da4a9fb59d1a0c7` throughout these A10 runs. Later
integration or publication sources must have their relationship to these
actual execution objects recorded separately.

## Complete attempt record

| Attempt | Actual result | Interpretation |
| --- | --- | --- |
| `test-01` | exit 0; 102 passed, 2 ignored | First frozen implementation; ignored entries are explicit real-font tests |
| `clippy-01` | exit 2 | Wrapper argument parsing rejected Cargo's literal `-- -D warnings` before Cargo ran; not a Rust lint result |
| `clippy-02` | exit 101 | Actual Clippy reported `field_reassign_with_default` and `type_complexity` in new tests; both corrected without relaxing `-D warnings` |
| `fifo-red-01` | exit 101; one test fails after 2.00 s | Actual Desktop import blocks on an owned 0600 FIFO with no writer; cleanup happens after the failed deadline |
| `fifo-green-01` | exit 0; one test passes in 0.00 s | The same actual import path rejects the FIFO without any writer |
| `test-02` | exit 0; 103 passed, 2 ignored | Final merged source, including FIFO regression and current main Session lock test |
| `clippy-03` | exit 0 | Final `--workspace --all-targets -- -D warnings` |
| `fmt-01` | exit 0 | Final `cargo fmt --all -- --check` |
| `build-01` | exit 0 | All four native production binaries from final source |
| `font-01` | exit 0; 2 passed | The previously ignored Shell and AppWindow tests executed against the selected real Noto CJK font |

`attempt-summary.json` retains exact Cargo argv and log-derived aggregate
counts. Each `attempts/<name>/` directory contains the original receipt,
launch record, raw combined output, source bindings, executed runner and
existing anchored child-group / parent-death exec helper copies. All ten
attempts have equal clean source before/after and a disarmed child guard at
completion. Failed attempts remain failed; no receipt was rewritten.

The first runner's wrapper-argument failure is preserved. Subsequent runners
forward the raw Cargo argv directly to the existing fresh-process exec
function. This is a harness correction separate from the two source lint
corrections and the FIFO production fix.

## Actual FIFO RED/GREEN boundary

The test
`workspace_context_tests::actual_import_refuses_fifo_without_writer_and_never_restores_legacy`
creates a private directory, a real 0600 v2 FIFO and an ordinary legacy v1
file. It calls the actual Desktop restore path, then requires rejection
within two seconds while no writer exists. It also checks that the draft
book stays empty, the older v1 bytes remain unchanged, no legacy fallback
occurs, and the operation queue stays empty.

In RED, the read does not return during that window. Only after the failed
deadline does cleanup open that owned FIFO's nonblocking writer and join the
reader. The final assertion still fails with the actual message:

> FIFO import blocked for 2 seconds with no writer; only the later cleanup writer released it

GREEN adds Linux `O_NONBLOCK` alongside `O_NOFOLLOW`. The descriptor is still
checked as a private regular file before any bounded payload read. The same
test now rejects the FIFO immediately with no writer. Ordinary v2 import and
genuine v2-absence/v1 import remain separate positive controls in the final
suite.

The actual Shell test executable hashes are different across the RED and
GREEN sources:

| Executed test source | Shell test ELF SHA-256 |
| --- | --- |
| First implementation `db54f734…` | `d8145a16b0f837d66d7445cce054df2b45f6b43532f8726ea5b906c48b59590c` |
| FIFO RED `e78680ea…` | `f2cfaf7323149013ed156582000ed9a32b4dff3dcae2f3bc824f17d229dd1aa6` |
| FIFO GREEN `c3c38805…`, final Shell suite `5f6915cc…` | `bac47bbb7c278d4dcc82b972790ce4ba8be59d27e1367b50df7dff948b6d3e3b` |

The first suite's original receipt predates automatic test-ELF recording.
Its separate `test-binaries-before-fifo-build.json` was recorded after that
suite and before any FIFO rebuild; the original receipt is unchanged. The
RED/GREEN/final receipts identify executables from the actual Cargo log.
Preserved local test ELF bytes were rehashed during archive assembly;
`retained-test-elf-identities.json` records that check. Binary bytes are not
included in this text archive.

## Final production artifacts

Actual build receipt SHA-256:
`8eba9c89863f636a929ee6fe3147e1a0850e87b066bc3ad876fef9809d2aca41`.

| Binary | Bytes | SHA-256 |
| --- | ---: | --- |
| `trill-shell` | 143,661,008 | `f1db6e3443617ea052de89c6356d2ca91b32330de3760f4a1babd54ed1dded8b` |
| `trill-session` | 19,027,392 | `38b0cf5f948fb85d663e6b67ca7755f2ecd01fd690e6938cd9b3c8ca0b3ee679` |
| `trill-app-window` | 139,431,328 | `6baceb035657d73e62598c8464837d204442850f9d53a749c059c08b21c2c717` |
| `trill-ctl` | 7,974,008 | `9983514ae71154978a70c9c9cd17073983d1d5b657bff07d8bf30940902c21b4` |

The build receipt and `production-binary-identities.json` record exact local
paths and source closure. Archive assembly rehashed the actual artifacts
without modifying the target or source. Native capture must bind these
artifacts and its own process/snapshot/pixel records, rather than infer
execution from a successful build.

## Restored environment and limits

Rust 1.88.0, Cargo 1.88.0, rustfmt and Clippy were restored in task-private
paths. The official rustup installer was checked against its separately
downloaded official SHA-256 before execution. `environment/` includes the
download/install receipts, exact tool versions/hashes, install/fetch logs and
the root-owned native dependency receipt. Cargo verification uses the
existing lock, offline mode and two jobs. No system package or service was
installed by these A10 commands.

The selected new R7 Noto CJK font is 19,484,784 bytes, SHA-256
`b76b0433203017ca80401b2ee0dd69350349871c4b19d504c34dbdd80541690a`.
The font receipt checks it before/after and the actual egui proportional and
monospace glyph coverage. It does not establish an input-method run or
presented pixels, and it is not represented as the older R5 font artifact.

`preflight/` preserves two earlier diagnostic compile logs. The first failed
at a native build-script execution permission boundary in the default
sandbox; the second reached the Shell test source and found the test-only
`Result<Request>` equality type error, fixed before the first frozen source.
They are setup diagnostics without frozen-source receipts and are not part
of the final pass claim. The permitted native command path subsequently
completed the frozen gates recorded above.

Synthetic in-process response/egui tests are explicitly contract tests.
Their success proves the checked draft/reference/rendering behavior, not
real AI execution. Changing the v2 IME finish oracle alone is not a new IME
qualification. Existing R6 original-Agentd and IME evidence keeps its original
source and scope.

`reviews/a07-independent-review-01.json` independently checks the final
source paths, FIFO RED/GREEN, final test/lint/format/build/font receipts and
raw logs, preserved test ELF bytes and four production ELF bytes. It also
records the separately frozen native harness review, including a cleanup
failure propagation issue that was corrected before capture. Its approval
is explicitly source/existing-check review; the native pixels remain a
separate review scope.

`SHA256SUMS` lists the archive files. Targets, caches, ELF bytes, font bytes,
native package payloads, X authentication material and runtime state are
excluded.

## Raw log storage in the published archive

Selected raw logs are stored as deterministic gzip files (`mtime=0`) to
preserve their exact output bytes through Git whitespace validation. For
each logical `.log` path listed below, `archive-manifest.json` retains the
original raw `bytes` and `sha256`; its new `stored` field identifies the
physical `.log.gz` path, encoding, stored size and stored SHA-256. Other
manifest entries are stored directly at their logical paths. The manifest
`payload_bytes` total uses physical stored bytes.

- `attempts/fifo-green-01/stdout-stderr.log` → `attempts/fifo-green-01/stdout-stderr.log.gz`
- `attempts/font-01/stdout-stderr.log` → `attempts/font-01/stdout-stderr.log.gz`
- `attempts/test-01/stdout-stderr.log` → `attempts/test-01/stdout-stderr.log.gz`
- `attempts/test-02/stdout-stderr.log` → `attempts/test-02/stdout-stderr.log.gz`
- `environment/install.log` → `environment/install.log.gz`

Every compressed file was decompressed and compared byte-for-byte with
the original log and the unchanged original staging archive. Receipts,
recorded raw log paths and hashes, and the initial archive-assembly script
remain unchanged. `gzip -cd <stored-path>` recovers the original output;
`SHA256SUMS` checks the actual stored files. This storage transform changes
no test result or source/ELF identity.
