# R7 Console scroll-state correction

The corrected source is `bc47f8024ff093927294095e27e8d20790ee1a49`,
with UI tree `5bc82eb52c42358371c1cc3725f15621d54a631e`. It passes the
same two actual-egui regressions that fail on the preceding RED source,
the complete **105-test** UI workspace, two separately executed real-font
tests, strict Clippy, formatting and the four-binary native build.

This is an additive follow-up to the R7 chat/context implementation at
`5f6915cc8136514f8da2b636fef1ba66559ac5aa`. The earlier source and its
receipts remain unchanged. The native capture that exposed the defect and
the repeat native capture have separate pixel evidence.

## Observed defect and exact fix

In the actual `capture02` native run on source `5f6915cc…`, the embedded
Console displayed red egui `First use of ScrollArea ID 72DB` and
`Second use of ScrollArea ID 72DB` warnings. The process and notice regions
used the same default ScrollArea identity. The run completed its owned
process/snapshot/export/cleanup protocol, and task-reference history across
Session replacement remained correct, but **Console visual acceptance
failed**. A completed harness receipt is not a substitute for that visual
result.

`reviews/a07-pixel-review-capture02.json` retains the independent inspection
of all 11 actual baseline PNGs. Actions 020, 022 and 024 show the collision.
The complete native baseline archive, including images and source/owner
records, is managed separately by the native acceptance owner.

The production fix consists of exactly two calls in
`ui/shell/src/main.rs::Desktop::console`:

```rust
.id_salt(("console-processes", self.workspace.code()))
.id_salt(("console-notices", self.workspace.code()))
```

Each region now has its own stable identity within each workspace.
The change isolates GUI scroll positions. It does not change the Console's
read-only contents, task ownership, Hepta observations, draft schema,
Session operations or permissions. ID-clash warnings remain enabled.

## RED and GREEN sources

| Source | Role |
| --- | --- |
| `5f6915cc8136514f8da2b636fef1ba66559ac5aa` | Actual native defect baseline; original typed-chat/FIFO implementation and evidence |
| `08fb5901befc0790271b661d834b287c502a535b` | Adds two actual-egui Console regressions; leaves production collision present |
| `bc47f8024ff093927294095e27e8d20790ee1a49` | Adds the two production scroll IDs and 12 lines of contract/validation documentation |

The publishing owner supplied these corresponding remote objects, with the
same complete source trees: baseline `bacda3cd22c4e84aa5c44301672e5e403bc9a4e2`,
RED `ffca91caabc5ee35bd949ad1058f92e7cddd5588`, and corrected source
`af1167f4d4f3ade530938c5365a24d09ccbe16e2`. `publication-map.json` records
the checkpoint and checks each local execution tree against that map.
The original execution SHA identities in every receipt are preserved.

The complete `workspace_context_tests` module is byte-identical between
RED and GREEN. `red-green-contract.json` records its hash and the source
comparison. No predicate or test was relaxed to make GREEN pass.

The first regression renders the actual embedded Console with both regions
overflowing, explicitly enables egui ID warnings, and refuses the collision
text painted by egui in any of the three workspaces.

The second uses actual `PointerMoved` and `MouseWheel` egui events. It
locates a visible text row's intersection with its clipping rectangle and
places the pointer inside that region. After scrolling the process region,
it checks that the notice region's first visible row and uncut vertical
position remain unchanged. It then performs the converse operation. A
workspace switch starts the other workspace at its own positions; returning
restores both original positions. The test never injects scroll state or
compares generated IDs. It also requires the host-operation queue to remain
empty.

In RED, both regressions fail. The actual frame contains the same `72DB`
ScrollArea warnings as the native image. Scrolling the process region also
moves the notice region's first visible row from `local-scroll-notice-29`
to `local-scroll-notice-16`. This demonstrates shared state in addition to
the visible warning. In GREEN, both tests pass without changes.

These are in-process UI/input contract tests using bounded synthetic
completed task rows. They do not start host applications, original Agentd,
an AI model or physical-device actions. Native presented pixels are
reviewed separately on the newly built binaries.

## Recorded commands and results

| Attempt | Source | Actual result |
| --- | --- | --- |
| `red-01` | `08fb5901…` | exit 101; 0 passed / 2 failed; 0.10 s test execution |
| `green-01` | `bc47f802…` | exit 0; 2 passed; 0.29 s test execution |
| `test-01` | `bc47f802…` | exit 0; 105 passed / 2 explicit real-font tests ignored |
| `clippy-01` | `bc47f802…` | exit 0; `--workspace --all-targets -- -D warnings` |
| `fmt-01` | `bc47f802…` | exit 0; `cargo fmt --all -- --check` |
| `build-01` | `bc47f802…` | exit 0; all four native production binaries |
| `font-01` | `bc47f802…` | exit 0; both ignored font tests executed and passed against the selected real Noto CJK file |

Each `attempts/<name>/` contains the exact launch, receipt, command, raw
combined log, clean source before/after and pre-execution runner/child-guard
copies. The source binding covers all tracked files under both `ui` and its
linked `services/hepta-os` dependency. All seven attempts retain equal
source before/after and a disarmed owned-child guard. The failed RED result
remains failed.

The raw logs show actual Shell compilation from the respective frozen
worktree. The executed Shell test ELF hashes differ:

| Source | Actual Shell test ELF SHA-256 |
| --- | --- |
| RED `08fb5901…` | `04d1dff0ad9724f65e4893207d4518ad7e83f9995ea41c0b5dc4690afdc4c1ca` |
| GREEN `bc47f802…` | `d77e838981d08a4b755908d130fc6f07ba428bd544401b78d58bdd6a98443ca6` |

The preserved local test ELF copies were rehashed during archive assembly;
their identities are recorded, but their bytes are excluded from this
archive. The earlier baseline's build receipt is included unchanged under
`baseline/`. Its temporary target path subsequently contains the new build;
its original source, timestamp and hashes remain the historical record,
not a claim about the current bytes at that path.

## New native build

Build receipt SHA-256:
`3977064dad5cdef49f8f175efe10f4267631153755fc70b788e0b5a3c1a49acd`.

| Binary | Bytes | SHA-256 |
| --- | ---: | --- |
| `trill-shell` | 143,661,072 | `f69a0cc788e9ec71f71a93707394954f3736669ee27f10e2c47d289b3ab39b98` |
| `trill-session` | 19,028,320 | `bc9da2ecc39c935db3122ab09cdea4c0c5dce3ba3ab24a9a14a846b43bf4a6bc` |
| `trill-app-window` | 139,431,328 | `8370c80e48d6f4a5e30450b8a6d64a67380d53d52e02dfa105a1ed1a7de1bffc` |
| `trill-ctl` | 7,974,008 | `a4dae0f18c4996d415285e7b251a6470bc284be7b067d109b48ba18eb6f73a47` |

`production-binary-identities.json` records all four current artifact
paths, the actual build receipt and the independently checked source
closure. These identities are distinct from the `5f6915cc…` baseline;
none of the old artifact hashes is relabelled as the corrected source.

The private environment remains Rust 1.88.0 and the verified native sysroot,
with Cargo offline/locked and two build jobs. The selected Noto font remains
19,484,784 bytes, SHA-256
`b76b0433203017ca80401b2ee0dd69350349871c4b19d504c34dbdd80541690a`.
Its hash is checked before and after the explicit font tests. Font glyph
coverage does not establish an IME, physical display or mobile-device run.

The corrected native run uses the independently frozen harness
`c7528e1fd06e6637b8accad4d8e4e0cd8b9f92f8`; its own process, snapshot,
export and PNG review records determine the native result. This text
archive does not infer a pixel pass from the GREEN Rust tests.

`reviews/r7-console-scroll-independent-review.json` independently checks
the production diff, identical regression bytes, actual RED/GREEN and
complete-workspace results, source/Git/hash bindings and preserved test
ELF bytes. It approves those source and execution checks while keeping
native pixels outside that review's qualification.

`reviews/a10-targeted-console-pixels-capture03.json` records the author's
actual inspection of the three corrected Console images at actions 020,
022 and 024. All three render without the earlier collision overlays. They
retain the expected cancelled observation, offline historical quote and old
reference that remains unbound after Session replacement. This is a targeted
three-image author check. The complete 11-image independent result belongs
to the separate native evidence archive.

`SHA256SUMS` lists the included text records. No target/cache, executable,
font/package payload, X authentication material or private runtime state
is included.

## Raw log storage in the published archive

Selected raw logs are stored as deterministic gzip files (`mtime=0`) to
preserve their exact output bytes through Git whitespace validation. For
each logical `.log` path listed below, `archive-manifest.json` retains the
original raw `bytes` and `sha256`; its new `stored` field identifies the
physical `.log.gz` path, encoding, stored size and stored SHA-256. Other
manifest entries are stored directly at their logical paths. The manifest
`payload_bytes` total uses physical stored bytes.

- `attempts/font-01/stdout-stderr.log` → `attempts/font-01/stdout-stderr.log.gz`
- `attempts/green-01/stdout-stderr.log` → `attempts/green-01/stdout-stderr.log.gz`
- `attempts/test-01/stdout-stderr.log` → `attempts/test-01/stdout-stderr.log.gz`

Every compressed file was decompressed and compared byte-for-byte with
the original log and the unchanged original staging archive. Receipts,
recorded raw log paths and hashes, and the initial archive-assembly script
remain unchanged. `gzip -cd <stored-path>` recovers the original output;
`SHA256SUMS` checks the actual stored files. This storage transform changes
no test result or source/ELF identity.
