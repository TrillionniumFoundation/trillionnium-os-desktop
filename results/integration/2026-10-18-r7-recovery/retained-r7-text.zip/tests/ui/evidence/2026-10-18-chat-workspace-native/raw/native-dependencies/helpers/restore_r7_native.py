from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import subprocess
import urllib.request
from datetime import datetime, timezone

root = Path('/workspace/scratch/98f315e377b2/next-tools/r7-native')
apt_args = [
    '-o', f'Dir::State::lists={root}/apt/lists',
    '-o', f'Dir::Cache={root}/apt/cache',
    '-o', f'Dir::Etc::sourcelist={root}/apt/sources.list',
    '-o', 'Dir::Etc::sourceparts=-',
]
packages = [
    'pkgconf', 'pkgconf-bin', 'libpkgconf3',
    'libxkbcommon-dev', 'libxkbcommon0',
    'libwayland-dev', 'libwayland-client0', 'libwayland-cursor0',
    'libwayland-egl1', 'libwayland-server0', 'libwayland-bin',
    'libegl-dev', 'libegl1', 'libgl-dev', 'libgl1',
    'libglx-dev', 'libglx0', 'libglvnd0',
    'libx11-dev', 'libx11-6', 'libxext-dev', 'libxext6',
    'libxi-dev', 'libxi6', 'libxrandr-dev', 'libxrandr2',
    'libxcursor-dev', 'libxcursor1', 'libxinerama-dev', 'libxinerama1',
    'libxfixes-dev', 'libxfixes3', 'libxrender-dev', 'libxrender1',
    'libxcb1-dev', 'libxcb1', 'x11proto-dev', 'xtrans-dev',
    'libxau-dev', 'libxau6', 'libxdmcp-dev', 'libxdmcp6',
]
entries = []
for name in packages:
    raw = subprocess.check_output(['apt-cache', *apt_args, 'show', name], text=True)
    records = []
    for paragraph in raw.split('\n\n'):
        fields = {}
        for line in paragraph.splitlines():
            if ': ' in line and not line.startswith(' '):
                key, value = line.split(': ', 1)
                fields[key] = value
        if fields.get('Filename') and fields.get('SHA256'):
            records.append(fields)
    if not records:
        raise RuntimeError(f'No signed repository package metadata: {name}')
    d = records[0]
    entries.append({'package': name, 'version': d['Version'],
                    'url': 'https://archive.ubuntu.com/ubuntu/'+d['Filename'],
                    'expected_sha256': d['SHA256'], 'expected_bytes': int(d['Size']),
                    'source': 'private signed noble main/universe package index'})

def download(entry):
    dest = root/'downloads'/entry['url'].rsplit('/', 1)[1]
    if not dest.exists():
        with urllib.request.urlopen(entry['url'], timeout=30) as response:
            data = response.read()
        dest.write_bytes(data)
    data = dest.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if len(data) != entry['expected_bytes'] or digest != entry['expected_sha256']:
        raise RuntimeError(f'Package checksum/size mismatch: {entry["package"]}')
    return {**entry, 'path': str(dest), 'actual_sha256': digest, 'actual_bytes': len(data)}

started = datetime.now(timezone.utc).isoformat()
with ThreadPoolExecutor(max_workers=4) as pool:
    completed = list(pool.map(download, entries))
for entry in completed:
    subprocess.run(['dpkg-deb', '-x', entry['path'], str(root/'sysroot')], check=True)

receipt = {'schema_version': 1, 'started_at': started,
           'finished_at': datetime.now(timezone.utc).isoformat(),
           'host_system_packages_installed': False,
           'system_services_changed': False,
           'sysroot': str(root/'sysroot'), 'packages': completed}
(root/'receipts/native-build-packages.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'packages': len(completed), 'bytes': sum(x['actual_bytes'] for x in completed),
                  'sysroot': receipt['sysroot']}))
