from pathlib import Path
import json,os,select,signal,subprocess,time,sys
from datetime import datetime,timezone

root=Path('/workspace/scratch/98f315e377b2/next-tools/r7-native')
name=sys.argv[1] if len(sys.argv)>1 else 'display-preflight'
assert name.replace('-','').isalnum()
out=root/'receipts'/name
out.mkdir(mode=0o700,exist_ok=False)
started=datetime.now(timezone.utc).isoformat()
env=dict(os.environ,LIBGL_ALWAYS_SOFTWARE='1')
with (out/'Xvfb.stderr.log').open('xb') as err:
    p=subprocess.Popen(['/usr/bin/Xvfb','-displayfd','1','-screen','0','1440x1000x24',
                        '-nolisten','tcp','-noreset','-ac'],stdout=subprocess.PIPE,
                       stderr=err,env=env,start_new_session=True)
    try:
        ready,_,_=select.select([p.stdout],[],[],12)
        if not ready: raise RuntimeError('bounded Xvfb startup timeout')
        line=p.stdout.readline().decode().strip()
        if not line.isdigit(): raise RuntimeError('Xvfb exited before display publication')
        env['DISPLAY']=':'+line
        info=subprocess.run(['/usr/bin/xdpyinfo'],env=env,capture_output=True,timeout=10)
        (out/'xdpyinfo.stdout.log').write_bytes(info.stdout)
        (out/'xdpyinfo.stderr.log').write_bytes(info.stderr)
        assert info.returncode==0
        assert b'XKEYBOARD' in info.stdout and b'GLX' in info.stdout
        geometry=subprocess.run(['/usr/bin/xdotool','getdisplaygeometry'],env=env,
                                capture_output=True,timeout=5)
        assert geometry.returncode==0 and geometry.stdout.strip()==b'1440 1000'
        receipt={'started_at':started,'finished_at':datetime.now(timezone.utc).isoformat(),
                 'Xvfb_pid':p.pid,'display':env['DISPLAY'],'dimensions':[1440,1000],
                 'XKEYBOARD':True,'GLX_extension_present':True,
                 'Rust_UI_started':False,'original_Hepta_started':False,
                 'system_install_performed':False}
    finally:
        if p.poll() is None: os.killpg(p.pid,signal.SIGTERM)
        p.wait(timeout=5)
receipt['Xvfb_reaped']=True
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
