from pathlib import Path
import os,json,sys
root=Path('/workspace/scratch/98f315e377b2/next-tools/r7-native')
overlay=root/'sysroot/usr'
view=sys.argv[1] if len(sys.argv)>1 else 'view'
assert view.isalnum()
dest=root/view/'usr'
assert not dest.exists()
counts={'directories':0,'host_links':0,'package_links':0}
def merge(host,package,target,relative):
    target.mkdir(parents=True,exist_ok=False);counts['directories']+=1
    names={p.name for p in host.iterdir()} if host.is_dir() else set()
    if package.is_dir(): names.update(p.name for p in package.iterdir())
    for name in sorted(names):
        a,b,c=host/name,package/name,target/name
        rel=relative/name
        if b.is_dir() and not b.is_symlink() and a.is_dir() and not a.is_symlink():
            merge(a,b,c,rel)
        elif b.exists() or b.is_symlink():
            c.symlink_to(Path('/r7-sysroot/usr')/rel);counts['package_links']+=1
        else:
            c.symlink_to(Path('/host/usr')/rel);counts['host_links']+=1
merge(Path('/usr'),overlay,dest,Path())
(root/'receipts'/('usr-'+view+'.json')).write_text(json.dumps({'view':str(dest),'counts':counts,'host_usr_mutated':False},indent=2)+'\n')
print(json.dumps(counts))
