#!/usr/bin/env python3
"""Copy scoped native evidence as inert archive data; never launch its commands."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import stat
import subprocess

BASE = Path('/workspace/scratch/98f315e377b2')
NATIVE = BASE / 'next-tools/r7-native'
STAGE = BASE / 'next-tools/r7-native-archive-stage'
REPOSITORY = BASE / 'next-r7-candidate'
CAPTURES = ('capture01', 'capture02')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_regular(path):
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), 'rb') as stream:
        info = os.fstat(stream.fileno())
        assert stat.S_ISREG(info.st_mode), str(path)
        data = stream.read()
    assert not data.startswith(b'\x7fELF'), 'ELF payload is outside this archive'
    return data, info


def git_bytes(commit, path):
    return subprocess.check_output(
        ['git', '-C', str(REPOSITORY), 'show', f'{commit}:{path}'], timeout=30)


def whitespace_sensitive_log(path, data):
    return path.endswith('.log') and (
        data.endswith(b'\n\n') or any(line.endswith((b' ', b'\t', b'\r')) for line in data.split(b'\n')))


def collect():
    STAGE.mkdir(mode=0o700)
    records = []

    def add_bytes(destination, data, provenance):
        compressed = whitespace_sensitive_log(destination, data)
        stored = gzip.compress(data, compresslevel=9, mtime=0) if compressed else data
        if compressed:
            assert gzip.decompress(stored) == data
            destination += '.gz'
        path = STAGE / destination
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(stored)
        os.chmod(path, 0o600)
        assert path.read_bytes() == stored
        record = {
            'stored_path': destination, 'original_bytes': len(data),
            'original_sha256': digest(data), 'stored_bytes': len(stored),
            'stored_sha256': digest(stored), 'storage_encoding': 'gzip' if compressed else 'identity',
            'provenance': provenance,
        }
        if compressed:
            record.update(gzip_mtime=0, reason='retain exact original log whitespace without git whitespace rewriting')
        records.append(record)

    def add_file(source, destination):
        data, info = read_regular(source)
        add_bytes(destination, data, {
            'kind': 'original_file', 'path': str(source), 'mode': oct(stat.S_IMODE(info.st_mode)),
            'mtime_ns': info.st_mtime_ns, 'uid': info.st_uid, 'gid': info.st_gid,
        })

    captures = []
    helper_paths = (
        'tests/ui/probe-chat-workspace.py', 'tests/ui/probe-original-hepta-shell.py',
        'tests/ui/x11-ime-client.py', 'tests/integration/hepta/run_original_agentd.py',
    )
    for name in CAPTURES:
        capture = NATIVE / name
        outer = json.loads((capture / 'receipt.json').read_text())
        binding = json.loads((capture / 'inside/input-binding.json').read_text())
        assert outer['namespace_guard_armed_after'] is False
        assert all(outer[k] for k in ('product_source_unchanged', 'harness_source_unchanged', 'executable_bytes_unchanged'))
        if name == 'capture01':
            assert outer['status'] == 'failed' and outer['exit_code'] == 1
            assert not (capture / 'inside/capture-receipt.json').exists()
            qualification = 'FAILED_environment_proc_mount_EPERM_before_Rust_UI_start'
        else:
            inner = json.loads((capture / 'inside/capture-receipt.json').read_text())
            visual = json.loads((NATIVE / 'a07-pixel-review-capture02.json').read_text())
            assert outer['status'] == 'completed' and outer['exit_code'] == 0
            assert len(inner['actions']) == 31 and len(inner['screenshots']) == 11
            assert visual['review_complete'] and visual['overall_pixels_passed'] is False
            qualification = 'mechanical_capture_completed_but_Console_pixels_FAILED_P2_duplicate_ScrollArea_72DB'
        original_count = 0
        for folder, directories, files in os.walk(capture, followlinks=False):
            directories[:] = sorted(d for d in directories if d not in {'runtime', 'cache', 'config', 'data', 'state'})
            for filename in sorted(files):
                source = Path(folder) / filename
                assert source.suffix in {'.json', '.log', '.png'}, str(source)
                add_file(source, 'raw/' + str(source.relative_to(NATIVE)))
                original_count += 1
        export = capture / 'inside/state/trillionnium-ui/local-context-drafts-v2.json'
        if export.exists():
            add_file(export, 'raw/' + str(export.relative_to(NATIVE)))
            original_count += 1
        commit = binding['harness']['head']
        for path in helper_paths:
            data = git_bytes(commit, path)
            if path == 'tests/ui/probe-chat-workspace.py':
                assert digest(data) == binding['harness_sha256']
            add_bytes(f'raw/executed-harnesses/{name}/{path}', data, {
                'kind': 'fixed_git_blob', 'repository': str(REPOSITORY), 'commit': commit, 'path': path,
            })
        captures.append({'name': name, 'qualification': qualification,
                         'product_head': binding['source']['head'], 'harness_head': commit,
                         'raw_capture_files': original_count, 'outer_receipt_sha256': digest((capture / 'receipt.json').read_bytes())})

    for source in sorted((NATIVE / 'receipts').rglob('*')):
        if source.is_file():
            assert source.suffix in {'.json', '.log', '.py'}
            add_file(source, 'raw/native-dependencies/' + str(source.relative_to(NATIVE)))
    for source in (NATIVE / 'preflight_display.py', BASE / 'next-tools/restore_r7_native.py',
                   BASE / 'next-tools/restore_r7_runtime.py', BASE / 'next-tools/restore_r7_extra_packages.py',
                   BASE / 'next-tools/build_r7_usr_view.py'):
        add_file(source, 'raw/native-dependencies/helpers/' + source.name)
    add_file(BASE / 'next-tools/rust188/installed-receipt.json', 'raw/native-dependencies/rust188-installed-receipt.json')

    # Retain the exact small build/font bindings used by the captures; the
    # retained test/production ELF payloads remain outside this archive.
    for name in ('build-01', 'font-01'):
        folder = BASE / 'next-tools/r7-ui-verification' / name
        for source in sorted(folder.iterdir()):
            if source.is_file():
                assert source.suffix in {'.json', '.log', '.py'}
                add_file(source, f'raw/ui-inputs/{name}/{source.name}')
    for filename in ('a07-independent-review-01.json', 'a07-pixel-review-capture02.json'):
        add_file(NATIVE / filename, 'raw/independent-reviews/' + filename)
    add_file(Path(__file__), 'raw/curation/curate-stage01.py')

    manifest = {
        'schema': 'r7-native-evidence-curation-v1',
        'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'intended_repository_path': 'tests/ui/evidence/2026-10-18-chat-workspace-native/',
        'status': 'capture01_environment_failure_and_capture02_visual_failure_preserved; corrected_capture_pending',
        'captures': captures, 'original_inputs': len(records),
        'original_bytes': sum(r['original_bytes'] for r in records),
        'stored_input_bytes': sum(r['stored_bytes'] for r in records),
        'compressed_log_count': sum(r['storage_encoding'] == 'gzip' for r in records),
        'excluded': ['runtime directories and sockets', 'ELF/test binaries', 'cache/config/data directories',
                     'package archives and extracted system/font bytes', 'state except the actual local-context-drafts-v2 test export'],
        'command_records_are_inert_archive_data': True,
        'entries': records,
    }
    (STAGE / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({k: manifest[k] for k in ('original_inputs', 'original_bytes', 'stored_input_bytes', 'compressed_log_count')}))


if __name__ == '__main__':
    collect()
