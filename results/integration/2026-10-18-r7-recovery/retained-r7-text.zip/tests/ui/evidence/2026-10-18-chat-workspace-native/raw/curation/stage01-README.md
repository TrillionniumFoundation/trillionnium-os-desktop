# R7 原生 Chat 工作区：原始捕获与独立像素审查

本目录保留两次真实执行的原始结果。**当前没有原生 UI 全通过结论：`capture01` 在环境准备阶段失败；`capture02` 完成真实 Session／任务／引用流程，但 Console 出现可见的 P2 滚动区域 ID 冲突。** 修复后的新捕获和逐图审查将在完成后独立追加；旧失败记录保持不变。

这些证据使用实际 Rust `trill-session`、`trill-shell`、`trill-app-window`、`trill-ctl` 四个 ELF，在私有 Xvfb、PID、网络等 namespace 中执行。输入来自有界 XTEST ASCII／主指针动作，图像来自实际 XGetImage framebuffer。未启动原版 Agentd、issuer、签名器、objective 或模型；没有物理键盘、IME、实体显示器或移动设备的验收声明。

## 执行结果

| 尝试 | 实际源码绑定 | 实际结果 |
|---|---|---|
| `capture01` | 产品 `5f6915cc8136514f8da2b636fef1ba66559ac5aa`；harness `2883e5ef80e6e9052dcdd6f2d651bb3180ff3d12` | 新 `/proc` mount 被环境拒绝，namespace exit 1；尚未启动 Rust UI，没有内层捕获收据。外层正确记录失败，owned leader 已 reap，源与 ELF 保持不变。 |
| `capture02` | 同一产品源码及四个 ELF；harness `c7528e1fd06e6637b8accad4d8e4e0cd8b9f92f8` | 31 个实际动作、11 张 PNG，外层 exit 0、源和 ELF 保持不变，四组长期 owned child 均清理。独立像素审查发现 Console 三张画面失败；其余八张的相应画面及引用生命周期链通过。 |

`capture02` 的 `/proc` 为明确标注的只读 host 视图，用于 Linux host meminfo/loadavg；PID 与网络 namespace 仍隔离。任务身份和清理使用 kernel PID、SO_PEERCRED、X properties 及已拥有的 ChildGroup，未使用 host `/proc` 中的数字 PID 定位任务。

## 核心证据索引

| 内容 | 原始证据 |
|---|---|
| 首轮环境失败 | [外层收据](raw/capture01/receipt.json)、[原始错误](raw/capture01/namespace.stderr.log)、[输入绑定](raw/capture01/inside/input-binding.json) |
| 第二轮真实捕获 | [外层收据](raw/capture02/receipt.json)、[完整内层收据](raw/capture02/inside/capture-receipt.json)、[输入及构建绑定](raw/capture02/inside/input-binding.json) |
| 独立源码与既有检查复核 | [A07 source review](raw/independent-reviews/a07-independent-review-01.json) |
| 十一张图的独立像素结论 | [A07 pixel review](raw/independent-reviews/a07-pixel-review-capture02.json) |
| 四个实际 ELF 的构建 | [构建收据](raw/ui-inputs/build-01/receipt.json)、[实际构建前源码](raw/ui-inputs/build-01/source-before.json) |
| 两项实际 Noto 字体检查 | [字体收据](raw/ui-inputs/font-01/receipt.json) |
| Native 构建／运行包清单 | [构建包](raw/native-dependencies/receipts/native-build-packages.json)、[运行包](raw/native-dependencies/receipts/runtime-packages.json)、[补充 libxkbfile1](raw/native-dependencies/receipts/extra-libxkbfile1.json) |
| Display preflight | [首轮错误](raw/native-dependencies/receipts/preflight-namespace.stderr.log)、[首轮 Xvfb 输出](raw/native-dependencies/receipts/display-preflight/Xvfb.stderr.log.gz)、[第二轮收据](raw/native-dependencies/receipts/display-preflight02/receipt.json) |

Display preflight 只说明其明确检查的 Xvfb／extension 条件，不替代 Rust 窗口像素审查。首轮 preflight 没有生成成功收据，原始失败输出完整保留。

## 可见缺陷与引用结果

Console 的两个滚动区使用了同一 `72DB` ID。以下实际截图出现红色 First／Second use 诊断覆盖生命周期与通知面板，因而不能标为像素通过：

- [原 Session 的 Console](raw/capture02/inside/action-020-screenshot.png)
- [原 Session 离线后的 Console](raw/capture02/inside/action-022-screenshot.png)
- [新 Session 的 Console](raw/capture02/inside/action-024-screenshot.png)

引用闭环可以从[保存后的卡片](raw/capture02/inside/action-009-screenshot.png)、[取消后的独立 current 状态](raw/capture02/inside/action-018-screenshot.png)和[同号新任务画面](raw/capture02/inside/action-028-screenshot.png)核对：原 Session `75d2ae5464139c42de6adce302510eac` 的 Notes #1／PID 25 实际变为 cancelled；同一 Shell PID 9／XID 4194307 随后观察新 Session `007bf09aa44aa9fff517071b0f7225f5` 的 Notes #1／PID 100 running。旧卡始终保留原身份、quoted Running 和采样值 `1792298283037`；新 Session 出现后明确显示 reference not rebound，旧引用不出现 Open task 控件。

两次[真实 v2 测试导出](raw/capture02/inside/state/trillionnium-ui/local-context-drafts-v2.json)逐字节一致，SHA256 为 `8bcaac97f29125782b04928de54ef9ca989a4ae3bb928c8279372ab91f3710f3`。原始收据中的绝对执行路径保留原样；它们是证据数据，不是要求运行这些路径中的命令。

## 原样保留与范围

[MANIFEST.json](MANIFEST.json)列出全部 325 个原始输入，原始总量 2,198,798 B；[SHA256SUMS](SHA256SUMS)覆盖本目录实际存储文件。两个包含原样空行的日志采用 `gzip(mtime=0)` 无损存储，manifest 同时保留原始与存储字节数及 SHA256，解压结果已经逐字节验证。其他输入原样复制。

每次执行对应的四份 harness／guard／framebuffer helper 均从该次绑定的固定 Git 对象提取，保存在 `raw/executed-harnesses/`。Native 包恢复清单和 helper、两轮 preflight、实际构建及字体检查的小型原始记录也已保留。源码对象的远端映射由本轮总档案提供；没有将旧 ELF 改称为后继源码的新构建。

归档不包含 runtime 目录或 socket、ELF／测试二进制、cache／config／data、下载的包文件或提取后的系统／字体字节；state 中仅保留本次实际测试导出的 JSON。`capture02` 的进程清理成功与其 Console 像素失败是两个独立结果，均完整保留。
