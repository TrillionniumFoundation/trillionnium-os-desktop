#!/usr/bin/env python3
"""Replay reviewed capture02 coordinates in phases, inspecting capture03 pixels between phases.

This supplies only XTEST requests to the unchanged source-bound native harness.
An ACK is coordination, not a pixel pass. Session/task identities come from
actual IPC and window properties inside that harness, never this input list.
"""
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent / 'capture03' / 'inside'
TEXT = 'Review this Notes task across a Session restart.'
ACTIONS = [
    {'action': 'click', 'x': 245, 'y': 121},
    {'action': 'await-task', 'session': 'a', 'state': 'running'},
    {'action': 'screenshot'},
    {'action': 'click', 'x': 945, 'y': 298},
    {'action': 'click', 'x': 351, 'y': 273},
    {'action': 'ascii', 'text': TEXT},
    {'action': 'screenshot'},
    {'action': 'click', 'x': 247, 'y': 459},
    {'action': 'screenshot'},
    {'action': 'click', 'x': 276, 'y': 458},
    {'action': 'verify-export', 'text': TEXT},
    {'action': 'click', 'x': 287, 'y': 298},
    {'action': 'screenshot'},
    {'action': 'click', 'x': 1347, 'y': 805},
    {'action': 'screenshot'},
    {'action': 'click', 'x': 965, 'y': 768},
    {'action': 'await-task', 'session': 'a', 'state': 'cancelled'},
    {'action': 'screenshot'},
    {'action': 'click', 'x': 1039, 'y': 151},
    {'action': 'screenshot'},
    {'action': 'stop-session-a'},
    {'action': 'screenshot'},
    {'action': 'start-session-b'},
    {'action': 'screenshot'},
    {'action': 'click', 'x': 919, 'y': 152},
    {'action': 'click', 'x': 245, 'y': 121},
    {'action': 'await-task', 'session': 'b', 'state': 'running'},
    {'action': 'screenshot'},
    {'action': 'click', 'x': 275, 'y': 421},
    {'action': 'verify-export', 'text': TEXT},
    {'action': 'finish'},
]

first, last = map(int, sys.argv[1:])
assert 1 <= first <= last <= len(ACTIONS)
queue = ROOT / 'commands'
assert (ROOT / 'ready.json').is_file()
if first > 1:
    assert (queue / f'{first - 1:03}.done.json').is_file()
for number in range(first, last + 1):
    path = queue / f'{number:03}.json'
    temporary = queue / f'{number:03}.json.new'
    assert not path.exists() and not temporary.exists()
    with temporary.open('x') as stream:
        json.dump(ACTIONS[number - 1], stream)
        stream.write('\n')
    os.replace(temporary, path)
deadline = time.monotonic() + 45
while not (queue / f'{last:03}.done.json').is_file():
    if (ROOT / 'capture-receipt.json').exists():
        receipt = json.loads((ROOT / 'capture-receipt.json').read_text())
        assert receipt['status'].startswith('completed_'), receipt.get('failure')
    assert time.monotonic() < deadline, 'bounded phase coordination timeout'
    time.sleep(0.1)
print(json.dumps({'first': first, 'last': last, 'status': 'acked_requires_pixel_review',
                  'operator_input_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}))
