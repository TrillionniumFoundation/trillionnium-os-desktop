from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,urllib.request
r=Path('/workspace/scratch/98f315e377b2/next-tools/r7-native')
cfg=['-o',f'Dir::State::lists={r}/apt/lists','-o',f'Dir::Cache={r}/apt/cache',
     '-o',f'Dir::Etc::sourcelist={r}/apt/sources.list','-o','Dir::Etc::sourceparts=-']
entries=[]
for name in sys.argv[1:]:
    assert name.replace('-','').isalnum()
    raw=subprocess.check_output(['apt-cache',*cfg,'show',name],text=True)
    package=None
    for paragraph in raw.split('\n\n'):
        d=dict(x.split(': ',1) for x in paragraph.splitlines() if ': ' in x and not x.startswith(' '))
        if d.get('Filename') and d.get('SHA256'): package=d;break
    assert package, name
    url='https://archive.ubuntu.com/ubuntu/'+package['Filename']
    p=r/'downloads'/url.rsplit('/',1)[1]
    with urllib.request.urlopen(url,timeout=30) as response: data=response.read()
    digest=hashlib.sha256(data).hexdigest()
    assert digest==package['SHA256'] and len(data)==int(package['Size'])
    p.write_bytes(data)
    subprocess.run(['dpkg-deb','-x',str(p),str(r/'sysroot')],check=True)
    entries.append({'package':name,'version':package['Version'],'url':url,'sha256':digest,'bytes':len(data)})
receipt={'timestamp':datetime.now(timezone.utc).isoformat(),'system_install_performed':False,'packages':entries}
(r/'receipts'/('extra-'+'-'.join(sys.argv[1:])+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
