#!/usr/bin/env python3
"""Append completed capture03 as inert evidence; preserve stage01 + failures."""
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

BASE = Path('/workspace/scratch/98f315e377b2')
NATIVE = BASE / 'next-tools/r7-native'
STAGE = BASE / 'next-tools/r7-native-archive-stage'
REPOSITORY = BASE / 'next-r7-candidate'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_regular(path):
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), 'rb') as stream:
        info = os.fstat(stream.fileno())
        assert stat.S_ISREG(info.st_mode), path
        data = stream.read()
    assert not data.startswith(b'\x7fELF'), 'ELF is outside archive scope'
    return data, info


old_bytes = {name: read_regular(STAGE / name)[0] for name in ('MANIFEST.json', 'README.md', 'SHA256SUMS')}
assert sha(old_bytes['MANIFEST.json']) == 'a784f311c48b3373b214e1dba5a7b036612d763efea613e8c82ca9641570222f'
assert sha(old_bytes['SHA256SUMS']) == '477804097c11deac15ed711d88144d57c7b621a3e3832f8ec8b1f48ab702e075'
old = json.loads(old_bytes['MANIFEST.json'])
assert len(old['entries']) == old['original_inputs'] == 325
records = list(old['entries'])
for record in records:
    data = read_regular(STAGE / record['stored_path'])[0]
    assert sha(data) == record['stored_sha256'] and len(data) == record['stored_bytes']
    original = gzip.decompress(data) if record['storage_encoding'] == 'gzip' else data
    assert sha(original) == record['original_sha256'] and len(original) == record['original_bytes']
for line in old_bytes['SHA256SUMS'].decode().splitlines():
    expected, path = line.split('  ', 1)
    assert sha(read_regular(STAGE / path)[0]) == expected


def add_bytes(destination, data, provenance):
    compress = destination.endswith('.log') and (
        data.endswith(b'\n\n') or any(line.endswith((b' ', b'\t', b'\r')) for line in data.split(b'\n')))
    stored = gzip.compress(data, compresslevel=9, mtime=0) if compress else data
    if compress:
        destination += '.gz'
        assert gzip.decompress(stored) == data
    path = STAGE / destination
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(stored)
    path.chmod(0o600)
    record = {
        'stored_path': destination, 'original_bytes': len(data), 'original_sha256': sha(data),
        'stored_bytes': len(stored), 'stored_sha256': sha(stored),
        'storage_encoding': 'gzip' if compress else 'identity', 'provenance': provenance,
    }
    if compress:
        record.update(gzip_mtime=0, reason='retain exact original log whitespace without git whitespace rewriting')
    records.append(record)


def add_file(source, destination):
    data, info = read_regular(source)
    add_bytes(destination, data, {
        'kind': 'original_file', 'path': str(source), 'mode': oct(stat.S_IMODE(info.st_mode)),
        'mtime_ns': info.st_mtime_ns, 'uid': info.st_uid, 'gid': info.st_gid,
    })


# These are preserved historical curation records, not reissued runtime receipts.
for name, data in old_bytes.items():
    add_bytes('raw/curation/stage01-' + name, data, {
        'kind': 'preserved_historical_curation_record', 'original_stage_path': str(STAGE / name),
        'prior_stage_manifest_sha256': sha(old_bytes['MANIFEST.json']),
        'scope': 'Historical stage01 index; relative paths are preserved as inert original data.',
    })

capture = NATIVE / 'capture03'
outer = json.loads((capture / 'receipt.json').read_bytes())
inner = json.loads((capture / 'inside/capture-receipt.json').read_bytes())
binding = json.loads((capture / 'inside/input-binding.json').read_bytes())
review = json.loads((NATIVE / 'a07-pixel-review-capture03.json').read_bytes())
root_review = json.loads((NATIVE / 'root-pixel-review-capture03.json').read_bytes())
assert review['overall_pixels_passed'] and review['review_complete']
assert root_review['pixels_passed_for_bounded_capture'] is True
assert outer['status'] == 'completed' and outer['exit_code'] == 0
assert outer['namespace_guard_armed_after'] is False
assert all(outer[k] for k in ('product_source_unchanged', 'harness_source_unchanged', 'executable_bytes_unchanged'))
assert len(inner['actions']) == 31 and len(inner['screenshots']) == 11
assert all(item['guard_armed_after'] is False for item in inner['cleanup'])
assert binding['build_receipt_sha256'] == '3977064dad5cdef49f8f175efe10f4267631153755fc70b788e0b5a3c1a49acd'
raw_count = 0
for folder, directories, files in os.walk(capture, followlinks=False):
    directories[:] = sorted(d for d in directories if d not in {'runtime', 'cache', 'config', 'data', 'state'})
    for filename in sorted(files):
        source = Path(folder) / filename
        assert source.suffix in {'.json', '.log', '.png'}, source
        add_file(source, 'raw/' + str(source.relative_to(NATIVE)))
        raw_count += 1
export = capture / 'inside/state/trillionnium-ui/local-context-drafts-v2.json'
add_file(export, 'raw/' + str(export.relative_to(NATIVE)))
raw_count += 1

commit = binding['harness']['head']
for path in ('tests/ui/probe-chat-workspace.py', 'tests/ui/probe-original-hepta-shell.py',
             'tests/ui/x11-ime-client.py', 'tests/integration/hepta/run_original_agentd.py'):
    data = subprocess.check_output(['git', '-C', str(REPOSITORY), 'show', f'{commit}:{path}'], timeout=30)
    if path == 'tests/ui/probe-chat-workspace.py':
        assert sha(data) == binding['harness_sha256']
    add_bytes(f'raw/executed-harnesses/capture03/{path}', data, {
        'kind': 'fixed_git_blob', 'repository': str(REPOSITORY), 'commit': commit, 'path': path,
    })

for name in ('build-01', 'font-01'):
    for source in sorted((BASE / 'next-tools/r7-ui-scroll-verification' / name).iterdir()):
        if source.is_file():
            assert source.suffix in {'.json', '.log', '.py'}
            add_file(source, f'raw/ui-scroll-inputs/{name}/{source.name}')
for name in ('a07-pixel-review-capture03.json', 'root-pixel-review-capture03.json'):
    add_file(NATIVE / name, 'raw/independent-reviews/' + name)
add_file(NATIVE / 'capture03-operator-replay.py', 'raw/operators/capture03-operator-replay.py')
add_file(BASE / 'next-tools/review_r7_capture03.py', 'raw/curation/review-capture03.py')
add_file(Path(__file__), 'raw/curation/append-stage02.py')

manifest = {
    **{k: v for k, v in old.items() if k not in ('entries', 'status', 'captures', 'created_at_utc', 'original_inputs', 'original_bytes', 'stored_input_bytes', 'compressed_log_count')},
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'capture03_passed_bounded_native_pixel_review; capture01_environment_failure_and_capture02_Console_P2_failure_preserved',
    'prior_curation': {'manifest_sha256': sha(old_bytes['MANIFEST.json']), 'sha256sums_sha256': sha(old_bytes['SHA256SUMS']), 'original_entries_preserved_unchanged': 325},
    'captures': old['captures'] + [{
        'name': 'capture03', 'qualification': review['overall_visual_qualification'],
        'product_head': binding['source']['head'], 'harness_head': commit,
        'raw_capture_files': raw_count, 'outer_receipt_sha256': sha((capture / 'receipt.json').read_bytes()),
        'A07_pixel_review_sha256': sha((NATIVE / 'a07-pixel-review-capture03.json').read_bytes()),
        'root_pixel_review_sha256': sha((NATIVE / 'root-pixel-review-capture03.json').read_bytes()),
    }],
    'original_inputs': len(records), 'original_bytes': sum(r['original_bytes'] for r in records),
    'stored_input_bytes': sum(r['stored_bytes'] for r in records),
    'compressed_log_count': sum(r['storage_encoding'] == 'gzip' for r in records), 'entries': records,
}
(STAGE / 'MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')

readme = '''# R7 原生 Chat 工作区：实际捕获与独立像素审查

**`capture03` 的 31 个真实操作和 11 张 PNG 已通过两份独立像素审查，范围限于私有 Linux／X11 软件渲染的 Rust 窗口。** 它确认了聊天草稿、嵌入式 Tasks／Context／Console、任务取消、Session 替换和旧引用不重绑的可见流程。此前 `capture01` 的环境失败与 `capture02` 的 Console P2 像素失败均原样保留。

每次捕获使用实际 Rust `trill-session`、`trill-shell`、`trill-app-window`、`trill-ctl` 四个 ELF，输入来自有界 XTEST ASCII／主指针动作，图像来自 XGetImage 的实际 framebuffer。未运行原版 Agentd、issuer、objective 或模型；本目录没有物理显示器、键盘、GPU、Wayland 像素、IME、Asterinas 桌面或移动设备验收结论。

## 三次实际结果

| 尝试 | 产品与 harness 来源 | 结果 |
|---|---|---|
| `capture01` | 产品 `5f6915cc8136514f8da2b636fef1ba66559ac5aa`；harness `2883e5ef80e6e9052dcdd6f2d651bb3180ff3d12` | 新 `/proc` mount 被环境拒绝，exit 1；Rust UI 尚未启动，无内层收据。外层准确失败，owned leader 已 reap，源／ELF 不变。 |
| `capture02` | 同一产品和四个 ELF；harness `c7528e1fd06e6637b8accad4d8e4e0cd8b9f92f8` | 31 动作／11 PNG／exit 0；源／ELF 不变且清理完成。引用生命周期通过，但 Console 三张画面出现红色 ScrollArea ID `72DB` 冲突，整体像素失败。 |
| `capture03` | 修复后的产品 `bc47f8024ff093927294095e27e8d20790ee1a49`；同一 `c7528e1f` harness | 31 动作／11 PNG／exit 0，源／ELF 在捕获前后不变，四组长期 owned child 和外层 namespace 已清理。A07 与 root 各自实际查看全部 11 图；三张 Console 无红色冲突，限定范围内像素通过。 |

后两轮使用明确标注的只读 host `/proc` 视图，只供 Linux host meminfo/loadavg；PID、网络等 namespace 仍隔离。任务身份来自 kernel PID、SO_PEERCRED 和 X properties，清理由已拥有的 ChildGroup 负责，没有按 host `/proc` 数字 PID 定位任务。

## 原始证据索引

| 内容 | 原始记录 |
|---|---|
| 首轮环境失败 | [外层收据](raw/capture01/receipt.json)、[错误输出](raw/capture01/namespace.stderr.log)、[输入绑定](raw/capture01/inside/input-binding.json) |
| 第二轮失败基线 | [外层收据](raw/capture02/receipt.json)、[内层完整记录](raw/capture02/inside/capture-receipt.json)、[A07 逐图审查](raw/independent-reviews/a07-pixel-review-capture02.json) |
| 第三轮通过的实际捕获 | [外层收据](raw/capture03/receipt.json)、[内层完整记录](raw/capture03/inside/capture-receipt.json)、[源码／四 ELF 输入绑定](raw/capture03/inside/input-binding.json) |
| 第三轮两份完整逐图审查 | [A07 独立像素与原始 IPC 核对](raw/independent-reviews/a07-pixel-review-capture03.json)、[root 独立像素审查](raw/independent-reviews/root-pixel-review-capture03.json) |
| 既有 FIFO／typed reference／harness 源码核对 | [A07 独立 source review](raw/independent-reviews/a07-independent-review-01.json) |
| 前两轮构建和实际字体检查 | [原 build receipt](raw/ui-inputs/build-01/receipt.json)、[原 font receipt](raw/ui-inputs/font-01/receipt.json) |
| 第三轮构建和实际字体检查 | [修复后 build receipt](raw/ui-scroll-inputs/build-01/receipt.json)、[修复后 font receipt](raw/ui-scroll-inputs/font-01/receipt.json) |
| 第三轮操作输入 | [原始分阶段 replay helper](raw/operators/capture03-operator-replay.py)；全部 31 个请求和 ACK 在 `raw/capture03/inside/commands/` |
| Native 包清单 | [构建包](raw/native-dependencies/receipts/native-build-packages.json)、[运行包](raw/native-dependencies/receipts/runtime-packages.json)、[libxkbfile1](raw/native-dependencies/receipts/extra-libxkbfile1.json) |
| 两轮 display preflight | [首轮错误](raw/native-dependencies/receipts/preflight-namespace.stderr.log)、[首轮 Xvfb 输出](raw/native-dependencies/receipts/display-preflight/Xvfb.stderr.log.gz)、[第二轮收据](raw/native-dependencies/receipts/display-preflight02/receipt.json) |

第三轮前 1–3 个请求由操作员以相同字节写入队列，后 4–31 个由该 helper 分阶段写入。A07 只用 AST 提取字面请求，核对其与原始 queue／ACK／动作收据逐项一致，没有导入或重运行 helper。ACK 仅确认协调完成，像素结论来自实际逐图查看。Display preflight 也不替代 Rust 窗口像素审查。

## 引用身份与可见回归

第三轮同一 Shell PID **10**／XID **4194307** 先观察 Session A `a49ed743d7118f45f390725949bcff78`（PID 8）的 Notes #1／PID **26**，再观察 Session B `f1990a5300e475f96da98a2868784fb2`（PID 88）的新 Notes #1／PID **102**。这两个同号任务始终以各自 Session 身份区分。

- [保存后的草稿](raw/capture03/inside/action-009-screenshot.png)保留引用时的 Running、PID26、采样 `1792299492345` 和生命周期更新时间 `1792299441657`。
- [实际取消后](raw/capture03/inside/action-018-screenshot.png)，原引用的 quoted Running 没有被改写，旁边 Current Host Observation 与 Context 显示 Cancelled／Observed SIGKILL，生命周期更新时间 `1792299534518`。
- [Session 离线](raw/capture03/inside/action-022-screenshot.png)后，当前状态明确 unknown；[Session B 出现](raw/capture03/inside/action-024-screenshot.png)后，旧卡显示 reference not rebound，并移除 Open task。
- [新 Notes #1 运行](raw/capture03/inside/action-028-screenshot.png)时，右侧当前 PID102 与左侧历史 PID26 独立显示，旧引用没有重新绑定到同号新任务。

两次 362 B 的[第三轮 v2 实际测试导出](raw/capture03/inside/state/trillionnium-ui/local-context-drafts-v2.json)逐字节一致，SHA256 为 `45c2846ab214dba0dab558938382c6c78169b213f58e6aa6548c8977e8828819`。第二轮的[原测试导出](raw/capture02/inside/state/trillionnium-ui/local-context-drafts-v2.json)也原样保留，其 SHA256 为 `8bcaac97f29125782b04928de54ef9ca989a4ae3bb928c8279372ab91f3710f3`；两次不同捕获的身份和时间不会混用。

Console 回归可直接对照以下实际帧：

| 阶段 | 原失败画面：红色 `72DB` 冲突 | 修复后画面：无红色冲突 |
|---|---|---|
| A 的取消历史 | [capture02 / 020](raw/capture02/inside/action-020-screenshot.png) | [capture03 / 020](raw/capture03/inside/action-020-screenshot.png) |
| A 离线 | [capture02 / 022](raw/capture02/inside/action-022-screenshot.png) | [capture03 / 022](raw/capture03/inside/action-022-screenshot.png) |
| B 的空历史 | [capture02 / 024](raw/capture02/inside/action-024-screenshot.png) | [capture03 / 024](raw/capture03/inside/action-024-screenshot.png) |

独立滚轮路由由另行归档的源码绑定 RED／GREEN 回归覆盖；这些静态帧本身只证明此处可见冲突已消失。Context 的主动滚动会正常裁剪 viewport 外内容，1360×840 Shell 周围的黑色区域是 1440×1000 framebuffer 的预期边缘。

## 构建、清理与证据范围

第三轮实际 build receipt SHA256 为 `3977064dad5cdef49f8f175efe10f4267631153755fc70b788e0b5a3c1a49acd`，四个输入 ELF 的 SHA、字节数及源码闭包在该次 input binding 中完整保留。捕获完成、所有 guard 清理后，root 明确释放了共享 target，后续整合门禁重建了其中的 ELF。A07 最终审查如实记录了后来不同的 target 字节；没有声称此刻重新读取到旧 ELF，也没有复建旧版本来替换历史证据。后续整合的源码和 ELF 不转记为此次 native capture 的输入。

最后的 B 任务清理响应为 `cancel_requested`，本目录不从该响应推断后续 durable Cancelled；长期 owned group 的清理与 guard 解除另有明确收据。当前 UI sample 和前后 CLI Snapshot 来自独立 RPC，采样时间不要求相同，核对的是原身份、状态含义与时间顺序。

## 无损归档

[MANIFEST.json](MANIFEST.json)记录 __COUNT__ 个输入，原始总量 __BYTES__ B；[SHA256SUMS](SHA256SUMS)覆盖实际存储文件。__GZIP__ 个需要保留原样空行的日志以 `gzip(mtime=0)` 存储，同时记录原／存储 SHA256 和字节数，解压结果已验证。其余输入原样复制。

原 stage01 的 325 个输入保持逐字节不变；其[原 manifest](raw/curation/stage01-MANIFEST.json)、[原索引](raw/curation/stage01-README.md)与[原 SHA 清单](raw/curation/stage01-SHA256SUMS)作为历史归档记录保留。各次执行的四份 harness／guard／framebuffer helper 来自该次固定 Git 对象；远端源码映射由本轮总档案补充。

原始命令和绝对路径只是证据数据。归档排除 runtime／socket、ELF／测试二进制、cache／config／data、包文件及系统／字体字节；state 仅保留实际测试导出的 JSON。没有清除或重标记此前失败。
'''
readme = readme.replace('__COUNT__', f"{len(records):,}").replace('__BYTES__', f"{manifest['original_bytes']:,}").replace('__GZIP__', str(manifest['compressed_log_count']))
(STAGE / 'README.md').write_text(readme)

# Final content and old-input preservation checks before emitting a new index.
for record in records:
    stored = read_regular(STAGE / record['stored_path'])[0]
    assert len(stored) == record['stored_bytes'] and sha(stored) == record['stored_sha256']
    original = gzip.decompress(stored) if record['storage_encoding'] == 'gzip' else stored
    assert len(original) == record['original_bytes'] and sha(original) == record['original_sha256']
assert records[:325] == old['entries']
checksums = []
for path in sorted(STAGE.rglob('*')):
    if path.is_file() and path != STAGE / 'SHA256SUMS':
        checksums.append(f'{sha(read_regular(path)[0])}  {path.relative_to(STAGE)}')
(STAGE / 'SHA256SUMS').write_text('\n'.join(checksums) + '\n')
print(json.dumps({
    'stage': str(STAGE), 'original_inputs': len(records), 'original_bytes': manifest['original_bytes'],
    'stored_input_bytes': manifest['stored_input_bytes'], 'compressed_log_count': manifest['compressed_log_count'],
    'capture03_raw_files': raw_count, 'sha256sum_entries': len(checksums),
    'manifest_sha256': sha((STAGE / 'MANIFEST.json').read_bytes()),
    'sha256sums_sha256': sha((STAGE / 'SHA256SUMS').read_bytes()),
}))
