from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib, json, subprocess, urllib.request

root=Path('/workspace/scratch/98f315e377b2/next-tools/r7-native')
entries=json.loads((root/'receipts/runtime-package-plan.json').read_text())
started=datetime.now(timezone.utc).isoformat()
def download(e):
    p=root/'downloads'/e['url'].rsplit('/',1)[1]
    if not p.exists():
        with urllib.request.urlopen(e['url'],timeout=45) as r:
            p.write_bytes(r.read())
    data=p.read_bytes(); sha=hashlib.sha256(data).hexdigest()
    assert sha==e['expected_sha256'] and len(data)==e['expected_bytes'], e['package']
    return {**e,'path':str(p),'actual_sha256':sha,'actual_bytes':len(data)}
with ThreadPoolExecutor(max_workers=4) as pool:
    complete=list(pool.map(download,entries))
for e in complete:
    subprocess.run(['dpkg-deb','-x',e['path'],str(root/'sysroot')],check=True)
receipt={'started_at':started,'finished_at':datetime.now(timezone.utc).isoformat(),
         'system_install_performed':False,'new_r7_extraction':True,'items':complete}
(root/'receipts/runtime-packages.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'packages':len(complete),'bytes':sum(e['actual_bytes'] for e in complete)}))
