#!/usr/bin/env python3
"""Record A07's completed manual PNG review and verify its raw evidence links.

This reads existing outputs only. It never imports/runs a capture, input replay,
application, build command, or source under review.
"""
import ast
import datetime
import hashlib
import json
import pathlib
import struct
import subprocess

BASE = pathlib.Path('/workspace/scratch/98f315e377b2')
NATIVE = BASE / 'next-tools/r7-native'
CAPTURE = NATIVE / 'capture03'
INSIDE = CAPTURE / 'inside'
REPOSITORY = BASE / 'next-r7-candidate'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def file_hash(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


outer = load(CAPTURE / 'receipt.json')
inner = load(INSIDE / 'capture-receipt.json')
binding = load(INSIDE / 'input-binding.json')
assert outer['status'] == 'completed' and outer['exit_code'] == 0
assert outer['namespace_guard_armed_after'] is False
assert inner['status'] == 'completed_native_capture_requires_independent_visual_review'
assert outer['inner_receipt_sha256'] == file_hash(INSIDE / 'capture-receipt.json')
assert all(outer[k] is True for k in ('product_source_unchanged', 'harness_source_unchanged', 'executable_bytes_unchanged'))
assert len(inner['actions']) == 31 and len(inner['screenshots']) == 11
assert binding['source']['head'] == 'bc47f8024ff093927294095e27e8d20790ee1a49'
assert binding['harness']['head'] == 'c7528e1fd06e6637b8accad4d8e4e0cd8b9f92f8'
assert binding['host_desktop_bound'] is False
for name in ('original_agentd_started', 'objective_submitted', 'model_called', 'physical_input_qualified', 'IME_qualified', 'mobile_qualified', 'synthetic_egui_events_used'):
    assert inner[name] is False

# Verify immutable Git bytes, even though the parent's integration worktree has
# legitimately advanced since the completed capture.
git_inputs = []
for kind in ('source', 'harness'):
    head = binding[kind]['head']
    for path, expected in binding[kind]['files'].items():
        data = subprocess.check_output(['git', '-C', str(REPOSITORY), 'show', f'{head}:{path}'], timeout=15)
        assert sha(data) == expected, path
        git_inputs.append({'kind': kind, 'head': head, 'path': path, 'sha256': expected})

build_path = BASE / 'next-tools/r7-ui-scroll-verification/build-01/receipt.json'
assert file_hash(build_path) == binding['build_receipt_sha256']
assert load(build_path) == binding['build_receipt']
assert binding['build_receipt']['status'] == 'passed'
binary_bindings = []
later_target_observations = []
for name, record in binding['binaries'].items():
    built = binding['build_receipt']['production_binaries'][name]
    assert record == {key: built[key] for key in ('bytes', 'sha256')}
    path = pathlib.Path(built['path'])
    binary_bindings.append({'name': name, **built})
    actual_hash = file_hash(path)
    info = path.stat()
    later_target_observations.append({
        'name': name, 'path': str(path), 'bytes': info.st_size, 'sha256': actual_hash,
        'mtime_utc': datetime.datetime.fromtimestamp(info.st_mtime, datetime.timezone.utc).isoformat(),
        'matches_capture_input': info.st_size == record['bytes'] and actual_hash == record['sha256'],
    })
for name, expected in binding['native_receipts'].items():
    assert file_hash(NATIVE / 'receipts' / name) == expected

session_a, session_b, shell = (inner[k] for k in ('session_a', 'session_b', 'shell'))
assert session_a == {'namespace_pid': 8, 'instance': 'a49ed743d7118f45f390725949bcff78'}
assert session_b == {'namespace_pid': 88, 'instance': 'f1990a5300e475f96da98a2868784fb2'}
assert shell == {'xid': '4194307', 'namespace_pid': 10, 'class': 'trill-shell'}
assert inner['task_a_running']['pid'] == inner['task_a_cancelled']['pid'] == 26
assert inner['task_a_running']['id'] == inner['task_a_cancelled']['id'] == inner['task_b_running']['id'] == 1
assert inner['task_a_running']['state'] == inner['task_b_running']['state'] == 'running'
assert inner['task_a_cancelled']['state'] == 'cancelled'
assert inner['task_b_running']['pid'] == 102
assert inner['task_a_cancelled']['updated_unix_ms'] == 1792299534518
assert len(inner['cleanup']) == 4 and all(r['guard_armed_after'] is False for r in inner['cleanup'])

observations = {}
for item in inner['snapshot_observations']:
    label = item['label']
    stdout, stderr = (INSIDE / f'{label}.{kind}.log' for kind in ('stdout', 'stderr'))
    actual = load(stdout)
    assert actual == item['snapshot'] and stderr.read_bytes() == b''
    assert actual['type'] == 'snapshot'
    assert actual['session_instance'] in (session_a['instance'], session_b['instance'])
    assert actual['hepta']['connection'] == 'not_configured' and actual['hepta']['last_observation'] is None
    assert actual['resources']['sampled_unix_ms'] <= item['recorded_unix_ms']
    observations[label] = {
        'label': label, 'stdout_sha256': file_hash(stdout), 'stderr_sha256': file_hash(stderr),
        'session_instance': actual['session_instance'], 'recorded_unix_ms': item['recorded_unix_ms'],
        'sampled_unix_ms': actual['resources']['sampled_unix_ms'], 'tasks': actual['tasks'],
    }

# Parse the inert operator source as an AST; do not import it or execute its
# argv/queue logic. Its 31 requests must match the actual original queue + ACKs.
replay = NATIVE / 'capture03-operator-replay.py'
assignments = {}
for node in ast.parse(replay.read_text()).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        name = node.targets[0].id
        if name == 'TEXT':
            assignments[name] = ast.literal_eval(node.value)
        elif name == 'ACTIONS':
            actions_node = node.value
class SubstituteText(ast.NodeTransformer):
    def visit_Name(self, node):
        assert node.id == 'TEXT'
        return ast.Constant(assignments['TEXT'])
expected_actions = ast.literal_eval(SubstituteText().visit(actions_node))
assert len(expected_actions) == 31
queue_checks = []
for action, expected in zip(inner['actions'], expected_actions):
    number = action['sequence']
    assert expected == action['request']
    queue = INSIDE / f'commands/{number:03}.json'
    done = INSIDE / f'commands/{number:03}.done.json'
    assert load(queue) == expected and load(done) == action
    assert action['started_unix_ms'] <= action['completed_unix_ms']
    queue_checks.append({'sequence': number, 'request_sha256': file_hash(queue), 'ack_sha256': file_hash(done)})

property_checks = []
for label, pid, klass in (
    ('shell-properties', 10, 'trill-shell'),
    ('action-023-start-session-b-same-shell-properties', 10, 'trill-shell'),
    ('action-002-await-task-notes-properties', 26, 'trill-app-window'),
    ('action-027-await-task-notes-properties', 102, 'trill-app-window'),
):
    path = INSIDE / f'{label}.stdout.log'
    value = path.read_text()
    assert f'_NET_WM_PID(CARDINAL) = {pid}\n' in value and f'WM_CLASS(STRING) = "{klass}", "{klass}"\n' in value
    assert (INSIDE / f'{label}.stderr.log').read_bytes() == b''
    property_checks.append({'label': label, 'namespace_pid': pid, 'class': klass, 'stdout_sha256': file_hash(path)})

export_path = INSIDE / 'state/trillionnium-ui/local-context-drafts-v2.json'
export = load(export_path)
assert len(inner['exports']) == 2 and inner['exports'][0] == inner['exports'][1]
assert export == inner['exports'][0]['value']
assert file_hash(export_path) == inner['exports'][0]['sha256'] == '45c2846ab214dba0dab558938382c6c78169b213f58e6aa6548c8977e8828819'
assert export_path.stat().st_size == inner['exports'][0]['bytes'] == 362
quote = export['drafts'][0]['contexts'][0]
assert quote == {'kind': 'host_task', 'key': {'session_instance': session_a['instance'], 'task_id': 1}, 'workspace': 'personal', 'app': 'notes', 'quoted_state': 'running', 'quoted_pid': 26, 'sampled_unix_ms': 1792299492345, 'task_updated_unix_ms': 1792299441657}
cleanup_reply = load(INSIDE / 'action-031-finish-cleanup-new-notes.stdout.log')
assert cleanup_reply == inner['actions'][-1]['cleanup_cancel_response']
assert cleanup_reply['task']['state'] == 'cancel_requested'

# These are human visual findings from directly viewing all eleven files with
# view_image in this A07 turn. The assertions below only bind those findings to
# existing bytes and independent IPC; they cannot produce a pixel pass alone.
notes = {
    'initial.png': 'Personal / Chat, empty composer, 0 saved drafts and an empty current Tasks panel are visible. The Rust window labels drafts as local/not submitted; Chinese labels render.',
    'action-003-screenshot.png': 'Embedded Tasks shows actual Notes #1 Running, PID Some(26), with Quote/Details controls. The no-Wayland-at-launch qualification is visible. No claim is made that the Notes client pixels behind the raised Shell were reviewed.',
    'action-007-screenshot.png': 'The exact ASCII text is in the composer. Its attached quote retains Session A, Notes #1, PID26, Running and sample 1792299492345. A separate Current Host Observation is Running with a newer snapshot timestamp.',
    'action-009-screenshot.png': 'One saved local draft displays the same text and typed quote. The composer is empty; 1 / 127 saved drafts and local export are visible. The original quote sample is unchanged.',
    'action-013-screenshot.png': 'Open task in workspace selects Context inside the same chat workspace. Notes #1/PID26 Running is visible alongside host-only resource and Wayland qualifications. Hepta is NOT CONFIGURED and objective submission unavailable. First-frame 1792299441657 is explicitly not GPU/Wayland presentation proof.',
    'action-015-screenshot.png': 'The actual primary-pointer scrollbar action exposes Request termination. Quote, task PID/state and sample remain unchanged. Content clipped above the Context viewport is deliberate scrolling, not a Console ID collision.',
    'action-018-screenshot.png': 'The saved quoted capture remains Running/PID26/sample 1792299492345, while its separate current observation and Context both show Cancelled. Context says Observed SIGKILL termination, with lifecycle update 1792299534518.',
    'action-020-screenshot.png': 'Console shows the actual cancelled Session A process row and local notices in separate regions. No red First use/Second use ScrollArea warning or duplicate ID 72DB overlay is present. Console is explicitly read only; it is not a terminal, Hepta log or security ledger.',
    'action-022-screenshot.png': 'After Session A stops, header and Console show Offline/current state unknown. The saved quote is historical/current source state unknown, and Open task is absent. Retained cancelled process history stays qualified by the offline state. No duplicate-ID red overlays are visible.',
    'action-024-screenshot.png': 'Console displays new Session B f1990a5300e475f96da98a2868784fb2 with no host process events. The saved A quote remains PID26/sample 1792299492345 and says Session changed; reference not rebound, with no Open task. No duplicate-ID red overlays are visible.',
    'action-028-screenshot.png': 'Tasks independently shows new Session B Notes #1 Running/PID102. The left saved quote still identifies old Session A/PID26 and is historical/reference not rebound; no Open task control reappears on that old quote.',
}
images = []
for item in inner['screenshots']:
    name = item['file']
    path = INSIDE / name
    data = path.read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack('>II', data[16:24]) == (1440, 1000)
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
    assert item['shell'] == shell
    controls = []
    for direction in ('before_snapshot', 'after_snapshot'):
        label = item[direction]
        if name == 'action-022-screenshot.png':
            stdout = INSIDE / f'{label}.stdout.log'
            stderr = INSIDE / f'{label}.stderr.log'
            assert stdout.read_bytes() == b'' and b'Connection refused' in stderr.read_bytes()
            controls.append({'label': label, 'result': 'Connection refused; no current snapshot', 'stdout_sha256': file_hash(stdout), 'stderr_sha256': file_hash(stderr)})
        else:
            observed = observations[label]
            if direction == 'before_snapshot':
                assert observed['recorded_unix_ms'] <= item['captured_unix_ms']
            else:
                assert observed['recorded_unix_ms'] >= item['captured_unix_ms']
            if name in ('initial.png', 'action-024-screenshot.png'):
                assert observed['tasks'] == []
            else:
                task = observed['tasks'][0]
                expected = inner['task_b_running'] if name == 'action-028-screenshot.png' else inner['task_a_cancelled'] if name in ('action-018-screenshot.png', 'action-020-screenshot.png') else inner['task_a_running']
                assert task == expected
            assert observed['session_instance'] == (session_b['instance'] if name in ('action-024-screenshot.png', 'action-028-screenshot.png') else session_a['instance'])
            controls.append(observed)
    images.append({'file': str(path), **{k: item[k] for k in ('bytes', 'sha256', 'width', 'height', 'captured_unix_ms')}, 'review_method': 'direct view_image inspection of this actual PNG; no generated image or OCR substitution', 'visual_status': 'passed_for_observed_view', 'observed_pixels': notes[name], 'shell_identity': shell, 'raw_IPC_controls_verified': controls})
assert set(notes) == {item['file'] for item in inner['screenshots']}

review = {
    'schema': 'r7-a07-native-pixel-review-v1', 'reviewer': '/root/r6_original_session (A07)',
    'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'capture': 'capture03',
    'review_complete': True, 'overall_visual_qualification': 'PASSED_FOR_BOUNDED_LINUX_X11_SOFTWARE_WINDOW_CAPTURE',
    'overall_pixels_passed': True, 'reference_lifecycle_qualification': 'passed_for_actual_captured_host_scope',
    'input_binding_sha256': file_hash(INSIDE / 'input-binding.json'),
    'product_source_head': binding['source']['head'], 'harness_source_head': binding['harness']['head'],
    'outer_receipt': {'path': str(CAPTURE / 'receipt.json'), 'sha256': file_hash(CAPTURE / 'receipt.json'), 'value': outer},
    'inner_receipt': {'path': str(INSIDE / 'capture-receipt.json'), 'sha256': file_hash(INSIDE / 'capture-receipt.json'), 'status': inner['status']},
    'mechanical_completion_is_not_pixel_pass': True,
    'source_and_ELF_unchanged_at_capture_end_per_captured_receipt': True, 'fixed_Git_input_hash_checks': git_inputs,
    'four_ELF_build_to_capture_input_bindings': binary_bindings,
    'later_shared_target_observation': {
        'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'interpretation': 'The shared target was reused after this completed capture. These later bytes differ; this review does not claim to rehash retained capture ELFs now. The exact earlier input bindings and original pre/post receipt remain the capture evidence.',
        'files': later_target_observations,
    },
    'owned_group_cleanup_records_verified': inner['cleanup'],
    'identities': {'session_a': session_a, 'session_b': session_b, 'shell': shell, 'old_task_id': 1, 'old_task_pid': 26, 'old_task_cancelled_observed': True, 'new_task_id': 1, 'new_task_pid': 102, 'new_task_running_observed': True},
    'window_properties_verified': property_checks,
    'export': {'path': str(export_path), 'bytes': 362, 'sha256': file_hash(export_path), 'two_exports_identical': True, 'original_quote': quote},
    'operator_replay': {'path': str(replay), 'sha256': file_hash(replay), 'method': 'AST literal extraction only; not imported or executed', 'request_count': 31, 'request_and_ack_hashes': queue_checks, 'execution_provenance_from_operator': 'Requests 1..3 were manually written with the same bytes; 4..31 were supplied by this helper in phases. ACKs are coordination, not pixel proof.'},
    'image_counts': {'directly_viewed': 11, 'passed_for_observed_view': 11, 'failed': 0}, 'images': images,
    'regression': {'capture02_preserved_as_failed': True, 'baseline_review_sha256': file_hash(NATIVE / 'a07-pixel-review-capture02.json'), 'fixed_in_this_capture': 'No duplicate ScrollArea ID 72DB red overlay in Console frames 020, 022 and 024. Native screenshot inspection does not alone prove independent wheel routing; the separate source-bound RED/GREEN regression covers that.'},
    'scope': [
        'These actual private XGetImage framebuffer PNGs are 1440x1000. Shell occupies its 1360x840 area with expected black framebuffer margins.',
        'The capture used real Rust software-rendered X11 windows and XTEST ASCII/primary-pointer requests. It does not qualify physical keyboard/display/GPU, Wayland pixels, IME, Asterinas or mobile.',
        'No original Agentd, issuer, objective publication, or model execution was tested in this capture.',
        'The visible current sample comes from the Shell polling independently of the bracketing CLI RPCs; equal sample timestamps are not required. Session/task identities, lifecycle meaning and capture order were checked.',
        'The final new-task cleanup CLI response is cancel_requested. This review does not invent a later durable task outcome from that reply; owned process/namespace cleanup is independently recorded.',
        'Capture01 remains an environment failure before Rust UI startup. Capture02 remains a Console P2 pixel failure even though its mechanical capture completed.',
    ],
}
target = NATIVE / 'a07-pixel-review-capture03.json'
with target.open('x') as stream:
    stream.write(json.dumps(review, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'review_path': str(target), 'bytes': target.stat().st_size, 'sha256': file_hash(target), 'images': 11, 'raw_valid_snapshot_controls': len(observations), 'fixed_git_inputs': len(git_inputs), 'queue_actions': 31}))
