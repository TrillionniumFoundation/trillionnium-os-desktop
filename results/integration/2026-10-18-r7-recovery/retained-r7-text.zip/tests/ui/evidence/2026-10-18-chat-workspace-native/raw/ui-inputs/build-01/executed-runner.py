#!/usr/bin/env python3
"""One source-bound R7 UI verification command; no original Agentd launch."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/98f315e377b2')
TOOL = BASE / 'next-tools/rust188'
BIN = TOOL / 'rustup/toolchains/1.88.0-x86_64-unknown-linux-gnu/bin'
SYSROOT = BASE / 'next-tools/r7-native/sysroot'
TARGET = BASE / 'next-tools/r7-ui-target'
COMMANDS = {
    'test': ['test', '--offline', '--locked', '--manifest-path', 'ui/Cargo.toml', '--workspace'],
    'clippy': ['clippy', '--offline', '--locked', '--manifest-path', 'ui/Cargo.toml', '--workspace', '--all-targets', '--', '-D', 'warnings'],
    'fmt': ['fmt', '--manifest-path', 'ui/Cargo.toml', '--all', '--', '--check'],
    'build': ['build', '--offline', '--locked', '--manifest-path', 'ui/Cargo.toml', '--workspace', '--bins'],
    'fifo': ['test', '--offline', '--locked', '--manifest-path', 'ui/Cargo.toml', '-p', 'trill-shell',
             'workspace_context_tests::actual_import_refuses_fifo_without_writer_and_never_restores_legacy', '--', '--exact'],
    'font': ['test', '--offline', '--locked', '--manifest-path', 'ui/Cargo.toml', '--workspace',
             'host_fonts::tests::selected_real_font_covers_egui_proportional_and_monospace', '--', '--ignored', '--exact'],
}

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def source_binding(source):
    def git(*args):
        return subprocess.check_output(['git', '-C', str(source), *args], text=True, timeout=30).strip()
    paths = git('ls-files', '--', 'ui', 'services/hepta-os').splitlines()
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
        'status': git('status', '--porcelain=v1', '--untracked-files=all'),
        'ui_tree': git('rev-parse', 'HEAD:ui'),
        'observer_tree': git('rev-parse', 'HEAD:services/hepta-os'),
        'files': {p: digest(source / p) for p in paths if (source / p).is_file()}}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--mode', choices=COMMANDS, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    output = args.output.resolve()
    output.mkdir(mode=0o700, parents=False)
    before = source_binding(source)
    write(output / 'source-before.json', before)
    assert before['head'] == args.expected_head and before['status'] == '', 'frozen clean source required'
    assert (source / 'README.md').stat().st_size == 0, 'README empty gate'
    shutil.copyfile(__file__, output / 'executed-runner.py')
    shutil.copyfile(source / 'tests/integration/hepta/run_original_agentd.py', output / 'child-guard-source.py')
    shutil.copyfile(source / 'tests/ui/probe-original-hepta-shell.py', output / 'exec-wrapper-source.py')
    spec = importlib.util.spec_from_file_location('r7_ui_owned_guard', output / 'child-guard-source.py')
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    assert guard.child_anchor_available(), 'anchored child group required'
    env = os.environ.copy()
    for name in ['DISPLAY', 'WAYLAND_DISPLAY', 'XAUTHORITY', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'TRILL_UI_TEST_CJK_FONT',
                 'TRILL_HEPTA_AGENTD_SOCKET', 'TRILL_HEPTA_AGENT_ID', 'TRILL_HEPTA_SPAWN_GENERATION', 'TRILL_HEPTA_PEER_UID']:
        env.pop(name, None)
    selected_env = {
        'PATH': str(BIN) + ':' + env.get('PATH', ''),
        'CARGO_HOME': str(TOOL / 'cargo'), 'RUSTUP_HOME': str(TOOL / 'rustup'),
        'RUSTUP_TOOLCHAIN': '1.88.0', 'RUSTC': str(BIN / 'rustc'),
        'CARGO_TARGET_DIR': str(TARGET), 'CARGO_BUILD_JOBS': '2',
        'PKG_CONFIG': str(SYSROOT / 'usr/bin/pkgconf'), 'PKG_CONFIG_SYSROOT_DIR': str(SYSROOT),
        'PKG_CONFIG_LIBDIR': str(SYSROOT / 'usr/lib/x86_64-linux-gnu/pkgconfig') + ':' + str(SYSROOT / 'usr/share/pkgconfig'),
        'LD_LIBRARY_PATH': str(SYSROOT / 'usr/lib/x86_64-linux-gnu'), 'LC_ALL': 'C.UTF-8',
        'RUST_BACKTRACE': '0',
    }
    env.update(selected_env)
    if args.mode == 'font':
        selected_env['TRILL_UI_TEST_CJK_FONT'] = str(SYSROOT / 'usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
        env.update(selected_env)
    command = [str(BIN / 'cargo'), *COMMANDS[args.mode]]
    # Dispatch the existing fresh-wrapper function directly. argparse's
    # REMAINDER handling rejects Cargo's literal `-- -D warnings` separator;
    # raw positional forwarding preserves the exact Cargo argv.
    wrapped = [sys.executable, '-B', str(output / 'executed-runner.py'), '--bound-exec',
               str(os.getpid()), str(output / 'exec-wrapper-source.py'), *command]
    record = {'schema': 'r7-frozen-ui-verification-v1', 'mode': args.mode, 'source_root': str(source),
        'expected_head': args.expected_head, 'command': command, 'wrapped_command': wrapped,
        'cwd': str(source), 'environment': selected_env, 'started_unix_ms': int(time.time() * 1000),
        'max_seconds': 1800, 'toolchain_receipt_sha256': digest(TOOL / 'installed-receipt.json'),
        'native_dependencies_receipt_sha256': digest(BASE / 'next-tools/r7-native/receipts/native-build-packages.json'),
        'runner_sha256': digest(output / 'executed-runner.py'),
        'guard_sha256': digest(output / 'child-guard-source.py'),
        'exec_wrapper_sha256': digest(output / 'exec-wrapper-source.py'),
        'original_agentd': 'not_run', 'presented_pixels': 'not_run', 'physical_device': 'not_run'}
    if args.mode == 'font':
        record['selected_font_sha256'] = digest(Path(selected_env['TRILL_UI_TEST_CJK_FONT']))
    write(output / 'launch.json', record)
    group = None
    failure = None
    exit_code = None
    try:
        with (output / 'stdout-stderr.log').open('wb') as log:
            child = subprocess.Popen(wrapped, cwd=source, env=env, stdin=subprocess.DEVNULL,
                                     stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            group = guard.ChildGroup(child)
            record['child_pid'] = child.pid
            write(output / 'launch.json', record)
            group.wait_exit(1800)
    except BaseException as error:
        failure = repr(error)
    finally:
        if group is not None and group.armed:
            try:
                group.signal_group(signal.SIGKILL)
                group.wait_exit(5)
                exit_code = group.reap()
            except BaseException as error:
                failure = f'{failure}; cleanup: {error!r}'
        after = source_binding(source)
        write(output / 'source-after.json', after)
        record.update(completed_unix_ms=int(time.time() * 1000), source_before_equals_after=before == after,
            exit_code=exit_code, failure=failure, child_guard_armed_after=group.armed if group else False,
            stdout_stderr_sha256=digest(output / 'stdout-stderr.log'),
            source_before_sha256=digest(output / 'source-before.json'), source_after_sha256=digest(output / 'source-after.json'))
        if args.mode == 'build' and exit_code == 0:
            record['production_binaries'] = {name: {'path': str(TARGET / 'debug' / name), 'sha256': digest(TARGET / 'debug' / name), 'bytes': (TARGET / 'debug' / name).stat().st_size}
                for name in ['trill-session', 'trill-shell', 'trill-app-window', 'trill-ctl']}
        if args.mode in ('test', 'fifo', 'font'):
            binaries = {}
            for path in re.findall(r'Running[^\n]*\(([^)\n]+)\)', (output / 'stdout-stderr.log').read_text()):
                binary = Path(path).resolve(strict=True)
                assert binary.is_relative_to(TARGET / 'debug/deps'), 'unexpected test executable path'
                binaries[binary.name] = {'path': str(binary), 'sha256': digest(binary), 'bytes': binary.stat().st_size}
                if binary.name.startswith('trill_shell-'):
                    retained = output / 'retained-test-elfs'
                    retained.mkdir(exist_ok=True)
                    shutil.copyfile(binary, retained / binary.name)
            record['executed_test_binaries'] = binaries
        if args.mode == 'font':
            record['selected_font_sha256_after'] = digest(Path(selected_env['TRILL_UI_TEST_CJK_FONT']))
            if record['selected_font_sha256_after'] != record['selected_font_sha256']:
                failure = 'selected font changed during test'
                record['failure'] = failure
        record['status'] = 'passed' if exit_code == 0 and failure is None and before == after else 'failed'
        write(output / 'receipt.json', record)
    print(json.dumps({'output': str(output), 'status': record['status'], 'exit_code': exit_code, 'failure': failure}), flush=True)
    return 0 if record['status'] == 'passed' else 1

if __name__ == '__main__':
    if len(sys.argv) > 4 and sys.argv[1] == '--bound-exec':
        spec = importlib.util.spec_from_file_location('r7_ui_bound_exec', sys.argv[3])
        wrapper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(wrapper)
        wrapper.bound_exec(int(sys.argv[2]), sys.argv[4:])
    else:
        sys.exit(main())
