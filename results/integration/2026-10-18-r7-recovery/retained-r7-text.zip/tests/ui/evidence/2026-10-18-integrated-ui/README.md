# R7 final integrated UI verification

The final integration source
`560f16c26dce32b50379dbfd26ffc291b658d303` passes the complete
**105-test UI workspace**, strict all-target Clippy, formatting and the
four-binary native build. All four commands ran on the frozen clean
integration checkout with equal source before/after and disarmed owned-child
guards. This archive preserves their actual execution records.

## Why this integration run was needed

The UI tree is exactly the Console-corrected native source `bc47f802…`, but
the linked `services/hepta-os` path dependency now also contains the new,
default-disabled objective transport work. Testing only the earlier UI
checkout would not qualify that final linked source closure.

| Source component | Earlier native execution | Final integration |
| --- | --- | --- |
| Execution commit | `bc47f8024ff093927294095e27e8d20790ee1a49` | `560f16c26dce32b50379dbfd26ffc291b658d303` |
| UI tree | `5bc82eb52c42358371c1cc3725f15621d54a631e` | `5bc82eb52c42358371c1cc3725f15621d54a631e` |
| Hepta service tree | `7ebe43051e1cebb8049ba50e9da4a9fb59d1a0c7` | `85a15ad9437f4be02c48c219b0eceacf6740831a` |

The complete integration tree is
`59e925797887187b902125ea2a162f71a5eabed4`.
`integration-closure.json` and `source-identities.json` record these
relationships. Each command additionally hashes every tracked file under
both the UI and service dependency trees before and after execution. Archive
assembly verifies those recorded file hashes against their immutable Git
objects, so the integration checkout can subsequently advance without
rewriting the execution record.

## Actual command results

| Attempt | Exact scope | Result |
| --- | --- | --- |
| `test-01` | `cargo test --offline --locked --manifest-path ui/Cargo.toml --workspace` | exit 0; 105 passed / 0 failed / 2 ignored |
| `clippy-01` | `cargo clippy --offline --locked --manifest-path ui/Cargo.toml --workspace --all-targets -- -D warnings` | exit 0 |
| `fmt-01` | `cargo fmt --manifest-path ui/Cargo.toml --all -- --check` | exit 0 |
| `build-01` | `cargo build --offline --locked --manifest-path ui/Cargo.toml --workspace --bins` | exit 0; all four native binaries |

The two ignored entries are the explicit real-font tests. They are not
counted as passing in this integration run. They were already executed on
the unchanged UI source in the preceding `bc47f802…` verification. Per the
integration plan they were not repeated here. The two Console regressions
do run inside the complete 105-test suite; there is no additional focused
Console run or duplicate addition to the count.

Each `attempts/<name>/` directory contains the actual launch, receipt, raw
combined output, exact source snapshots and pre-execution runner / anchored
child-group / parent-death exec helper copies. The tests include actual
owned host IPC fixtures and in-process egui behavior checks. This UI
workspace command does not run the separate feature-on objective transport
suite; that module has its own integration record.

The verification environment remains task-private Rust 1.88.0 with the
verified native sysroot, offline locked dependencies and two Cargo jobs.
`environment/` contains the exact installed-tool and native-dependency
receipts. No original Agentd or physical/mobile device is started by these
commands, and no issuer or AI objective is submitted.

## Final production artifacts

Build receipt SHA-256:
`d48a9e6022eb51357b65b2a1edc8e061a6ace640ba66ecbc8c0833b6b366649c`.

| Binary | Bytes | SHA-256 |
| --- | ---: | --- |
| `trill-shell` | 143,661,384 | `4793abc7542c4ac4b3f0afbe1e0ad73702db5adb2a2c73954ca70baee0aaebbd` |
| `trill-session` | 19,025,752 | `2b799a88918a7b60391cd1933e0688dceeb8071de305ee191efb762c7d18a302` |
| `trill-app-window` | 139,431,384 | `e74d89ceb7e03a79cd08f8b86184f142ef6e3cbeabf7ff5ba4d870649d4b4b99` |
| `trill-ctl` | 7,974,176 | `ea563a079cd1cd5373029682775a03e41e9d0b6172571f88cd4eaab4f5eb685e` |

`production-binary-identities.json` records the actual paths and rechecks
these artifact bytes during archive assembly. The test receipt identifies
the actual executed test programs; the preserved Shell test executable is
also rehashed. Executable bytes and build caches are excluded from this
archive.

## Native capture and evidence boundary

The successful native `capture03` belongs to the earlier actual
`bc47f8024ff093927294095e27e8d20790ee1a49` source and its Shell SHA-256
`f69a0cc788e9ec71f71a93707394954f3736669ee27f10e2c47d289b3ab39b98`.
It is not relabelled as a capture of this integration source or the new
`4793abc7…` Shell. The two UI trees are identical, while the complete linked
service closure differs; this final test/lint/build record addresses that
integration boundary explicitly.

There is no new native pixel, explicit-font, IME or physical-device run in
this archive. Earlier FIFO RED/GREEN, the Console native defect baseline,
Console RED/GREEN and the corrected native images retain their original
source, artifact and review identities. `SHA256SUMS` covers the included
text records without copying runtime state or authentication material.

## Raw log storage in the published archive

Selected raw logs are stored as deterministic gzip files (`mtime=0`) to
preserve their exact output bytes through Git whitespace validation. For
each logical `.log` path listed below, `archive-manifest.json` retains the
original raw `bytes` and `sha256`; its new `stored` field identifies the
physical `.log.gz` path, encoding, stored size and stored SHA-256. Other
manifest entries are stored directly at their logical paths. The manifest
`payload_bytes` total uses physical stored bytes.

- `attempts/test-01/stdout-stderr.log` → `attempts/test-01/stdout-stderr.log.gz`

Every compressed file was decompressed and compared byte-for-byte with
the original log and the unchanged original staging archive. Receipts,
recorded raw log paths and hashes, and the initial archive-assembly script
remain unchanged. `gzip -cd <stored-path>` recovers the original output;
`SHA256SUMS` checks the actual stored files. This storage transform changes
no test result or source/ELF identity.
