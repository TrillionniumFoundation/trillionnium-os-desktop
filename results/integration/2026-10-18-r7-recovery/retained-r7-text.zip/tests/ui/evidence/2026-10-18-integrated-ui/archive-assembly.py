#!/usr/bin/env python3
"""Copy completed R7 UI records without touching the frozen source or target."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

BASE = Path('/workspace/scratch/98f315e377b2')
RUNS = BASE / 'next-tools/r7-integrated-ui-verification'
SOURCE = BASE / 'next-r7-candidate'
DEST = BASE / 'next-tools/r7-integrated-ui-archive-stage'
FINAL = '560f16c26dce32b50379dbfd26ffc291b658d303'
ATTEMPTS = [
    ('test-01', 'passed', 0, FINAL),
    ('clippy-01', 'passed', 0, FINAL),
    ('fmt-01', 'passed', 0, FINAL),
    ('build-01', 'passed', 0, FINAL),
]


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True).strip()


def copy(path, relative):
    target = DEST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    assert sha(path) == sha(target)


def main():
    # The execution freeze is released; archive the immutable recorded Git object.
    assert git('rev-parse', FINAL) == FINAL
    DEST.mkdir(mode=0o700)
    summary = []
    retained = []
    for name, status, code, head in ATTEMPTS:
        root = RUNS / name
        receipt = json.loads((root / 'receipt.json').read_text())
        before = json.loads((root / 'source-before.json').read_text())
        after = json.loads((root / 'source-after.json').read_text())
        assert receipt['status'] == status and receipt['exit_code'] == code
        assert receipt['expected_head'] == head and before == after
        assert before['head'] == head and before['status'] == ''
        for relative, expected in before['files'].items():
            raw = subprocess.check_output(['git', '-C', str(SOURCE), 'show', head + ':' + relative])
            assert hashlib.sha256(raw).hexdigest() == expected, relative
        assert receipt['source_before_equals_after'] is True
        assert receipt['child_guard_armed_after'] is False
        for field, file in [('runner_sha256', 'executed-runner.py'),
                            ('guard_sha256', 'child-guard-source.py'),
                            ('exec_wrapper_sha256', 'exec-wrapper-source.py'),
                            ('stdout_stderr_sha256', 'stdout-stderr.log'),
                            ('source_before_sha256', 'source-before.json'),
                            ('source_after_sha256', 'source-after.json')]:
            assert receipt[field] == sha(root / file), (name, file)
        for file in sorted(root.iterdir()):
            if file.is_file():
                copy(file, Path('attempts') / name / file.name)
        for file in sorted((root / 'retained-test-elfs').glob('*')):
            expected = receipt.get('executed_test_binaries', {}).get(file.name)
            if expected is None:
                separate = json.loads((root / 'test-binaries-before-fifo-build.json').read_text())
                expected = separate['executed_tests_from_raw_cargo_log'][file.name]
            assert sha(file) == expected['sha256'] and file.stat().st_size == expected['bytes']
            retained.append({'attempt': name, 'file': str(file), 'bytes': expected['bytes'],
                             'sha256': expected['sha256'], 'included_in_archive': False})
        counts = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',
                            (root / 'stdout-stderr.log').read_text())
        summary.append({'attempt': name, 'status': status, 'exit_code': code, 'source': head,
                        'command': receipt['command'], 'receipt_sha256': sha(root / 'receipt.json'),
                        'source_before_equals_after': True, 'child_guard_armed_after': False,
                        'suite_totals': {key: sum(int(x[i]) for x in counts)
                                         for i, key in [(1, 'passed'), (2, 'failed'), (3, 'ignored')]}})

    commits = []
    for head in dict.fromkeys([entry[3] for entry in ATTEMPTS] +
                              ['bc47f8024ff093927294095e27e8d20790ee1a49']):
        commits.append({'head': head, 'tree': git('rev-parse', head + '^{tree}'),
                        'parents': git('show', '-s', '--format=%P', head).split(),
                        'subject': git('show', '-s', '--format=%s', head),
                        'ui_tree': git('rev-parse', head + ':ui'),
                        'observer_tree': git('rev-parse', head + ':services/hepta-os')})
    write(DEST / 'source-identities.json', {'schema': 'r7-ui-execution-sources-v1',
           'sources': commits, 'final_execution_source': FINAL,
           'previous_native_ui_execution': 'bc47f8024ff093927294095e27e8d20790ee1a49'})
    write(DEST / 'attempt-summary.json', {'schema': 'r7-ui-attempt-summary-v1', 'attempts': summary})
    write(DEST / 'retained-test-elf-identities.json', {'schema': 'r7-retained-test-identities-v1',
           'scope': 'Archive assembly rechecked preserved test ELF bytes; binaries are excluded.',
           'test_binaries': retained})
    build = json.loads((RUNS / 'build-01/receipt.json').read_text())
    for item in build['production_binaries'].values():
        path = Path(item['path'])
        assert sha(path) == item['sha256'] and path.stat().st_size == item['bytes']
    write(DEST / 'production-binary-identities.json', {
        'schema': 'r7-ui-production-identities-v1', 'source': FINAL,
        'ui_tree': git('rev-parse', FINAL + ':ui'),
        'observer_tree': git('rev-parse', FINAL + ':services/hepta-os'),
        'build_receipt_sha256': sha(RUNS / 'build-01/receipt.json'),
        'archive_assembly_recheck_utc': datetime.now(timezone.utc).isoformat(),
        'binaries': build['production_binaries'], 'included_in_archive': False})
    copy(BASE / 'next-tools/rust188/installed-receipt.json',
         Path('environment/installed-receipt.json'))
    copy(BASE / 'next-tools/r7-native/receipts/native-build-packages.json',
         Path('environment/native-build-packages.json'))
    previous = 'bc47f8024ff093927294095e27e8d20790ee1a49'
    assert git('rev-parse', previous + ':ui') == git('rev-parse', FINAL + ':ui')
    assert git('rev-parse', previous + ':services/hepta-os') != git('rev-parse', FINAL + ':services/hepta-os')
    write(DEST / 'integration-closure.json', {
        'schema': 'r7-integrated-ui-closure-v1',
        'current_execution': FINAL,
        'current_tree': git('rev-parse', FINAL + '^{tree}'),
        'current_ui_tree': git('rev-parse', FINAL + ':ui'),
        'current_services_tree': git('rev-parse', FINAL + ':services/hepta-os'),
        'prior_native_execution': previous,
        'prior_ui_tree': git('rev-parse', previous + ':ui'),
        'prior_services_tree': git('rev-parse', previous + ':services/hepta-os'),
        'ui_tree_equal': True,
        'services_tree_changed': True,
        'prior_native_capture': 'capture03',
        'prior_native_shell_sha256': 'f69a0cc788e9ec71f71a93707394954f3736669ee27f10e2c47d289b3ab39b98',
        'current_native_capture': 'not_run',
        'current_explicit_font_tests': 'not_repeated; the two remain ignored in this final workspace run',
        'current_focused_console_tests': 'not_repeated separately; both run in the complete 105 tests',
        'claim': 'Same UI source with the newly integrated default-disabled objective transport dependency. The final four commands qualify this actual linked closure; earlier native/font receipts retain their own sources.',
    })
    copy(Path(__file__), Path('archive-assembly.py'))
    # The execution freeze is released; archive the immutable recorded Git object.
    assert git('rev-parse', FINAL) == FINAL
    print(json.dumps({'archive': str(DEST), 'attempts': len(summary),
                      'source_unchanged': True, 'binaries_copied': False}))


if __name__ == '__main__':
    main()
