# R7：原生 Rust 聊天工作区、来源引用与 ObjectiveStart 传输

本轮把 R6 的运行观察界面推进到可操作的 Rust 聊天工作区，并完成独立、默认关闭的 ObjectiveStart 传输库。代码通过 [PR #190](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/pull/190) 交付；整合基线为 main `01caff4fb3651f57ea32e648ade5a351d20df569`，保留 #187、#188、#189 的全部源码、文档和实录。

**本轮实际交付是 Linux host 原生 UI 与传输接口。** 聊天草稿没有被提交给 Hepta；原版 owner 的可信准入、模型调用、持久结果接线和设备效果仍按各自证据判定。R6 原版只读运行、R7 本地 UDS fixture、原生窗口像素、内核对象测试和 GitHub CI 分别记录。

## 1. 已实现的交互与技术决策

| 交付 | 实际行为 | 开发与技术文档 |
| --- | --- | --- |
| 原生聊天首页 | Shell 默认打开 Workspace / Chat；Personal、Research、Build 各自保留草稿、引用和选中页签；Tasks、Context、Console 嵌入工作区 | [CHAT_WORKSPACE](../../../support/ui/CHAT_WORKSPACE.md)、[运行手册](../../../support/ui/RUN.md) |
| 有来源的上下文卡 | 宿主引用绑定 `(session_instance, task_id)`；引用时的 Running/PID/采样时间与当前观测分开显示；Session 换代不绑定同编号新任务 | [typed 模型](../../../ui/core/src/conversation.rs)、[工作区实现](../../../ui/shell/src/conversation.rs) |
| 独立 Hepta 上下文 | Hepta 引用另绑定 Session、AgentId、spawn、PID 与生命周期来源；宿主 Notes 任务不是原版 objective | [观测契约](../../../services/hepta-os/CONTRACT.md)、[UI 来源规则](../../../support/ui/CHAT_WORKSPACE.md) |
| 观测失效 | 完整 Snapshot 的采样年龄和本地 receipt 年龄都必须不超过 7,000 ms；任务状态更新时间、操作回复或时钟恢复不能重新确认旧快照 | [共同纯函数](../../../ui/core/src/observation.rs)、[R6 新鲜度契约](../../../ui/shell/OBSERVATION_FRESHNESS.md) |
| 本地导出与恢复 | v2 保存工作区、文字及 typed 引用；导入数据不携带当前事实或权限；仅确实没有 v2 时允许 v1 兼容；有界、非跟随、非阻塞读取，原子替换 | [存储实现](../../../ui/shell/src/local_drafts.rs)、[实际 FIFO RED/GREEN](../../../tests/ui/evidence/2026-10-18-chat-workspace-rust/README.md) |
| Console 修复 | 两个滚动区域分别使用工作区和区域 ID，消除重复 ID 覆盖和滚动状态串扰 | [实际回归与修复](../../../tests/ui/evidence/2026-10-18-console-scroll/README.md) |
| 可选 ObjectiveStart 传输 | 显式可信 host 输入、单次连接、原始信封字节保持、严格 peer UID/PID、同一有界 deadline、typed 回复；默认关闭 | [完整 wire/API/错误契约](../../../services/hepta-os/OBJECTIVE_TRANSPORT.md)、[原版来源清单](../../../services/hepta-os/OBJECTIVE_UPSTREAM_CONTRACT.json) |

UI workspace 使用 Rust 1.88、eframe/egui 0.31.1 和原生 X11/Wayland 窗口后端；这次交付没有添加 HTML/JavaScript/WebView 产品界面。测试用 Python/XTEST 驱动真实 Rust 程序，测试驱动语言不改变产品渲染实现。完整 Asterinas 显示/输入、原生 Rust compositor 与移动端仍须独立实现、移植和验收。

设计已经采用聊天工作区组织方式；当前仍是工程原型。文件/应用内容与对话的完整接合、视觉细化、触控、无障碍和平台输入体验不由本轮有限窗口验收自动完成。

## 2. 实际执行与源码身份

执行源码、后续文档提交和远端提交分别保留。GitHub Git-data 发布逐次比较完整 tree，保留正常 merge 的有序父节点；GitHub 生成的 commit 元数据不同，因此不替换原始收据中的本地 SHA。完整对应关系见 [source-publication-map.json](source-publication-map.json)。

| 执行对象 | 本地执行 SHA | 同树远端 SHA | 结果 |
| --- | --- | --- | --- |
| A07 传输初验 | `19c2185d27c1d788354e14af27999406bc927c4f` | `73eb1aa121f9eeaaacf5e6fa6cc3487f60f6e9d3` | 35 Rust tests；14 原版文件身份；7 原声明 wire 检查组 |
| UI/FIFO 基线 | `5f6915cc8136514f8da2b636fef1ba66559ac5aa` | `bacda3cd22c4e84aa5c44301672e5e403bc9a4e2` | UI 103 passed / 2 ignored；另 2 项真实字体通过；lint/fmt/4 ELF 通过；capture02 Console 像素失败 |
| Console 负对照 | `08fb5901befc0790271b661d834b287c502a535b` | `ffca91caabc5ee35bd949ad1058f92e7cddd5588` | 2 项实际 egui 回归均失败，证明重复 ID 和双区串滚 |
| Console 修复与窗口复跑 | `bc47f8024ff093927294095e27e8d20790ee1a49` | `af1167f4d4f3ade530938c5365a24d09ccbe16e2` | 相同 2 回归通过；UI 105 passed / 2 ignored；另 2 项真实字体通过；lint/fmt/4 ELF、capture03 通过 |
| 最新 main 整合源 | `560f16c26dce32b50379dbfd26ffc291b658d303` | `c4d4224c9daf1a5b22997930000f43001525d531` | UI 105 passed / 2 ignored、严格 all-target Clippy、fmt、4 ELF 通过；实际提取的 A07 三条 CI 命令通过 |

整合源完整 tree 为 `59e925797887187b902125ea2a162f71a5eabed4`。UI tree `5bc82eb52c42358371c1cc3725f15621d54a631e` 与 capture03 产品源码相同；A07 是新的依赖闭包，因而在整合源上重新执行 UI 和 A07 检查。此处没有将 bc47 的窗口运行转记为整合源的新窗口运行。整合阶段没有重复执行那两项显式字体测试。

105 和 35 是各自测试套件的结果；A07 的 35 中包含 17 项既有 observer 回归、15 项 Objective 传输/结构测试、1 项部分写入取消测试和 2 项 compile-fail。7 项原声明检查属于另一可执行程序，不与 Rust harness 分母混算。字体的 ignored 与后来显式运行的结果分列。完整原始记录：

- [初版 UI、FIFO、两次 Clippy 失败及后续通过](../../../tests/ui/evidence/2026-10-18-chat-workspace-rust/README.md)
- [Console RED/GREEN 和修复后的完整 UI 检查](../../../tests/ui/evidence/2026-10-18-console-scroll/README.md)
- [最新 main 整合 UI 检查与构建](../../../tests/ui/evidence/2026-10-18-integrated-ui/README.md)
- [A07 初验与原版声明对照](../../../tests/integration/hepta/evidence/2026-10-18-objective-transport/README.md)
- [整合源中实际执行的三条 CI 命令](ci-objective/README.md)

## 3. 真实窗口验收：失败、修复、复跑

完整原图、操作请求、前后 Snapshot、导出、四程序构建绑定、私有显示环境、失败记录和逐图审查见[原生窗口归档](../../../tests/ui/evidence/2026-10-18-chat-workspace-native/README.md)。

| 轮次 | 实际结果 | 解释 |
| --- | --- | --- |
| capture01 | 在启动 Rust UI 之前失败 | 当前宿主不允许新 proc mount，原始 EPERM、退出及清理收据保留 |
| capture02 | 31 步协调流程完成，Console 像素失败 | 11 张实际 PNG 中 020/022/024 出现红色 ScrollArea ID 72DB 冲突；其余来源引用链通过；不能因 harness exit 0 把整轮视觉标为成功 |
| capture03 | 31 步、11 张实际 PNG、两份相同导出通过 | 使用相同已冻结 harness 和修复后新 ELF；主审与独立审查者实际逐图检查，三处 Console 冲突消失 |

capture03 实际执行时间为 **2026-10-18 04:56:50–04:59:36 UTC**。私有 Xvfb 的 1440×1000 软件帧来自真实 Rust 窗口；输入为 XTEST ASCII 和主指针。测试使用自有 mount/user/IPC/network/UTS/PID namespaces，`/proc` 是明确记录的只读宿主资源视图，用于 Linux host 指标；没有绑定用户桌面，也没有启动原版 Agentd。

同一 Shell 的 namespace PID **10**、XID **4194307** 全程保持。Session A 为 `a49ed743d7118f45f390725949bcff78`，旧 Notes 是 task **1** / PID **26**；UI 实际请求终止后，卡片同时显示引用时 Running 与当前 Cancelled。Session 停止时当前状态变为 unknown。Session B 为 `f1990a5300e475f96da98a2868784fb2`，新 Notes 仍是 task **1**，PID 为 **102**；旧卡明确显示历史引用未重新绑定，且不再显示打开当前任务按钮。

两次由真实 Shell 导出的 v2 文件各 **362 bytes**，SHA-256 均为 `45c2846ab214dba0dab558938382c6c78169b213f58e6aa6548c8977e8828819`。引用的 Session、PID 和采样时间未被新 Session 改写。第一次旧 Notes 终止来自 UI 主指针操作；最后一次新 Notes 的取消是 harness 的直接 CLI 清理，不计为第二次 UI 终止验收。

outer receipt 记录产品源码、harness 源码、四个 ELF 的前后字节均不变，所有 owned guards 均已解除。capture03 完成后，整合验证复用了构建目录并生成另一组 ELF；逐图复核依据当时的构建/input/outer 收据，不声称旧四个 ELF 仍保存在该目录，也没有为了补证而重新构建冒充原执行产物。

![同编号新任务与旧引用保持分离](../../../tests/ui/evidence/2026-10-18-chat-workspace-native/raw/capture03/inside/action-028-screenshot.png)

## 4. ObjectiveStart 的实际边界

传输库接受外部已签发的原始 ingress JSON，保留签名、source envelope、字段顺序和内部空格。结构成功不等于认证；原版 issuer、AuthBus trust/replay、authority 和 operations owners 仍是唯一事实来源。输入源不超过 32 KiB、规范 body 不超过 48 KiB、完整 LF 帧不超过 64 KiB；超出或形状不符在连接前拒绝。

一次消费式调用至多建立一次连接。写循环在每次成功写入后立即记录字节数；任何正数发送后的未决结果都保留 `SubmitUnknown`。完整回复必须具备精确请求、AgentId、spawn、run/digest 身份及一帧后的 EOF。缺帧、多帧、断连、错身份和原版可能发生在持久发布之后的通用 `request_rejected` 都不允许转换为“从未提交”。只有严格匹配的原版发布前拒绝可以确定本次拒绝，而且不能清除此前的 unknown。

当前 attempt 的保留在内存中；库没有重发、换 ID、重签或通过 `RunStatus=null` 消除 unknown 的接口，也没有实现跨进程持久恢复。原版 `Admitted`/`Conflict` 表示原版发布/冲突结果，不能显示为设备效果完成。可信 host 的持久 pending/unknown 接线与原 owner 的实际准入仍是下一条实现边界。

现有 Shell、Session IPC、观察 CLI 继续使用默认只读路径。`TrustedReadOnlyOrganV1` 不进行 I/O，不获得 endpoint 或 effect authority；传输适配器位于这个边界之外。

## 5. A06 与并行 main 的去重

本轮独立实现与执行的 `64f855512b2e78e895248ba49f908eccd7232679` 在真实 x86_64 QEMU 中完成 aster-core **157 passed / 0 failed / 0 filtered**，包含四项真实 Process/Task/cgroup 对象扣费测试及 lease 释放前后的 EBUSY 检查。第一次真实编译的借用错误和修正后的完整运行均保留；对象由 ktest 构造且没有调度，不等于完整 exit syscall、parent wait、实际 scheduler handoff 或 SMP 场景。

与此同时，[#188](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/pull/188) 已把另一份更完整的修复合入 main。其六项相关回归还覆盖未 detach zombie、旧 snapshot 和不重复扣费；已有 **159 正向通过、157 通过加 2 项预期失败的负对照**及固定 1/2 vCPU N0 probe，来源见 [#189 原始归档](../2026-10-18-audit-followthrough/README.md)。这些是主干既有执行证据，不是本轮独立 157 测试的另一个名字。

本 PR 保留 main 的完整 kernel tree，不合入重复 production patch 或第二套 factory；独立研究源码和 157 项实录单独保存。对主干 RCU getter 的检查没有发现可达的新生产缺陷，不将抽象生命周期疑问标成已证明的漏洞。[去重独立复核](reviews/a06-main-dedup-independent-review.json)记录生产路径、测试范围、主干压缩实录 CRC/原始 serial/QEMU 的交叉检查。

## 6. 全模块开发与技术文档覆盖

完整 A00–A10 映射继续由 [INDEX](../../../docs/INDEX.md)维护。R7 新增或更新 A07/A10 的具体源码模型、输入输出、构建命令、错误与恢复语义、实际失败/成功及未闭合项，不以 Agent prompt 代替开发手册。

| 模块 | 当前可依赖的工程内容 | 仍需交付的主要边界 |
| --- | --- | --- |
| A00 集成 | 全模块契约与状态入口、正常合流、执行来源和 CI 读回 | G1/G2 端到端的后续接合 |
| A01 构建/启动 | 固定 Asterinas/OSDK、构建、内核测试与来源清单 | 扩展真实目标与启动环境 |
| A02 ABI | Rust codec、独立 wire 判定器及 pinned 验收 | wire 支持不等于全部内核操作可用 |
| A03 control core | std/portable-spin、Loom、零锁内分配和 namespace receipt 绑定 | durable K/fsync、内核 IRQ/SMP 接合 |
| A04 Linux/Hepta ELF | 固定 ELF/rootfs/差分手册与 Draft #8 候选 | 合入和新内核上的实际兼容工作负载 |
| A05 内核控制 | 进程/exec 身份隔离的 QueryAbi 及实现手册 | 能力交接与其余 HOS2 操作 |
| A06 CPU | main #188 最终 quota debit 修复与限定客体验证 | 广泛迁移/退出并发、完整 Hepta/HOS2 |
| A07 Hepta 接合 | 原版只读持续观察；R7 可选单次 Objective 传输 | 可信 issuer 桌面接线、原版准入、持久结果与设备效果 |
| A08 Android | 开发/接口/内核缺口文档及 Linux host 工具回归 | Binder/seccomp/MAC、真实 Android guest/APK |
| A09 硬件/VMM | device lifecycle 技术与来源文档、宿主模型 | 真实 DMA/GPU/设备恢复 |
| A10 Rust UI | 原生聊天工作区、typed 来源引用、实际软件窗口验收 | 完整内容/应用工作流、输入体验、目标 OS 与移动端 |

因此，模块文档入口已经覆盖全部 A00–A10；A04 的实现手册仍明确指向尚未合入的固定候选。文档覆盖与模块完成度分开判断，不给项目编造一个百分比。

## 7. 发布、CI 与下一条执行边界

[初次 PR 状态读回](remote-pr-readback.json)和 [R6 合入读回](remote-pr-readback-r6.json)确认 #187/#188/#189 已合入，#8 仍为 Draft，R7 使用新的 #190；#157 不重新打开。原始 R6 `89aa8fa6` 的 G0、A10、ARM 三个精确 head runs 在 **05:08:45 UTC** 读回均为 completed/success，见[初次 CI 快照](remote-ci-readback-initial.json)。这次读回补齐旧状态，不是重跑 R6。

同一时刻 R7 整合 head `c4d4224c` 的 A10 run `39099387875` 为 queued，ARM run `39099387901` 为 in_progress。后续在 **05:30:00 UTC 之前**的[完成状态读回](remote-ci-readback-c4d-completed.json)中，同一个 ARM run 与 job `117592347821` 已 completed/success，原版 Agentd/持续 Session、五 ARM64 ELF 绑定及证据上传各步骤均成功；A10 仍 queued。原始读回保留，不改写先前状态。本地三条 CI 语句成功不等于 GitHub workflow 成功；后续最终文档 head 的状态由 PR 发布读回记录，不把 R6 或 c4d 的成功转记到另一个 head。

下一条实际开发链是：既有可信 issuer 输入 → 可信 host 的持久 pending/unknown 恢复 → 原版 ObjectiveStart 准入与 durable result owner → UI 的真实结果卡 → HOS2 CPU/撤销/确认退役闭环。UI 不创建第二个 authority 或效果账本。移动端与桌面共享 Rust 领域模型和协议，moto XT2363-4 的触控、IME、缩放旋转、生命周期与设备效果仍需独立实现和真机验证。

本归档不包含 ELF、Cargo cache、下载包、字体二进制、issuer key 或真实设备运行状态；保留的是实际输入来源、原始记录、截图和可复核的构建/执行摘要。各子归档以自己的 SHA256SUMS 验证，后续报告不改写历史失败。

## 8. 归档存储与审查

[execution-index.json](execution-index.json)按各包 SHA256SUMS 和 Git 发布清单列出六组证据。为保留原始日志末尾空行及安装日志中的空格，10 份追加日志使用 mtime=0 的 gzip 无损保存；每份均记录原始与实际存储的两组字节数和 SHA-256，解压后逐字节等于未改的原 stage，所有实际运行 receipt 保持原字节。此前原生窗口包的三份 gzip 同样保留原始映射。

本地工作区的10份重复 raw 在移出后再次出现，写入者未证实；它们与 gzip 解压逐字节相等，作为未发布副本保留。最终 Git index 明确排除这10条 raw 路径，六包的清单成员与 index 精确相等，格式检查通过；这里不声称工作区物理目录没有额外副本。见 [最终发布清单选择](reviews/r7-final-published-storage-selection.json)、[UI 日志无损包装](reviews/r7-ui-log-storage-review.json)、[CI 日志无损包装](reviews/r7-ci-log-packing.json)与[包装前独立基线](reviews/r7-final-archives-prepacking-baseline.json)。包装修订没有产生任何新的测试或运行资格。

最终[独立归档复核](reviews/r7-final-archives-independent-review.json)直接读取 Git index 的六包 890 个文件并验证 884 条 SHA，检查前后 index 相同；93 条相关 README 本地链接存在。结论针对明确的发布成员集，保留不同源码、旧运行与失败的边界。
