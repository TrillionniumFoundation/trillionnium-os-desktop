#!/usr/bin/env python3
"""Run exactly three extracted A07 CI commands on the frozen R7 candidate."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tomllib
import yaml

BASE = Path('/workspace/scratch/98f315e377b2')
SOURCE = BASE / 'next-r7-candidate'
HEAD = '560f16c26dce32b50379dbfd26ffc291b658d303'
MAIN = '01caff4fb3651f57ea32e648ade5a351d20df569'
OUT = BASE / 'next-tools/r7-ci-objective-execution-01'
KERNEL_EXEC = BASE / 'next-tools/r7-kernel/receipts/execution-02'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE, text=True).strip()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def source_binding():
    names = git('ls-files', '--', 'services/hepta-os', 'tests/ui/check-host.sh',
        '.github/workflows/a10-host.yml', 'README.md', 'docs/STATUS.md', 'docs/INDEX.md',
        'docs/DESKTOP_UX.md', 'support/upstream-lock.json', 'ui/Cargo.toml', 'ui/Cargo.lock',
        'ui/shell/Cargo.toml', 'ui/session/Cargo.toml',
        'kernel/asterinas/Cargo.toml', 'kernel/asterinas/Cargo.lock',
        'kernel/asterinas/rust-toolchain.toml',
        'kernel/asterinas/kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu.rs',
        'kernel/asterinas/kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu/final_charge_regressions.rs',
        'kernel/asterinas/kernel/core/src/process/test_util.rs',
        'kernel/asterinas/kernel/core/src/process/mod.rs',
        'kernel/asterinas/kernel/core/src/process/posix_thread/mod.rs',
        'kernel/asterinas/kernel/core/src/process/process/mod.rs',
        'tests/spec/test_a06_final_accounting_source.py').splitlines()
    files = {name: {'sha256': sha(SOURCE / name), 'bytes': (SOURCE / name).stat().st_size}
             for name in names}
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
        'status': git('status', '--porcelain=v1', '--untracked-files=all'),
        'kernel_git_tree': git('rev-parse', 'HEAD:kernel/asterinas'), 'files': files}


def main():
    OUT.mkdir(exist_ok=False)
    shutil.copy2(__file__, OUT / 'driver-source.py')
    kernel_receipt = json.loads((KERNEL_EXEC / 'receipt.json').read_text())
    assert kernel_receipt['status'] == 'passed'
    assert sha(KERNEL_EXEC / 'driver-source.py') == kernel_receipt['driver_sha256']
    assert sha(KERNEL_EXEC / 'owned-child-guard.py') == kernel_receipt['owned_child_guard_sha256']
    shutil.copy2(KERNEL_EXEC / 'driver-source.py', OUT / 'bounded-executor-source.py')
    shutil.copy2(KERNEL_EXEC / 'owned-child-guard.py', OUT / 'owned-child-guard.py')
    bound = load_module('r7_ci_bounded_executor', OUT / 'bounded-executor-source.py')
    bound.SOURCE = SOURCE
    guard = load_module('r7_ci_owned_guard', OUT / 'owned-child-guard.py')
    assert guard.child_anchor_available()
    before = source_binding()
    assert before['head'] == HEAD and before['status'] == ''
    assert before['files']['README.md']['bytes'] == 0
    assert before['kernel_git_tree'] == git('rev-parse', MAIN + ':kernel/asterinas')
    subprocess.run(['git', 'merge-base', '--is-ancestor', MAIN, HEAD], cwd=SOURCE, check=True)
    write(OUT / 'source-before.json', before)
    source_dir = OUT / 'extracted-source'
    source_dir.mkdir()
    for name in ('tests/ui/check-host.sh', '.github/workflows/a10-host.yml', 'services/hepta-os/Cargo.toml'):
        path = source_dir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(SOURCE / name, path)
    script = (SOURCE / 'tests/ui/check-host.sh').read_text()
    off = 'cargo check --manifest-path services/hepta-os/Cargo.toml --locked --offline --no-default-features --all-targets'
    on = 'cargo test --manifest-path services/hepta-os/Cargo.toml --locked --offline --features objective-transport'
    assert script.splitlines().count(off) == 1 and script.splitlines().count(on) == 1
    workflow = yaml.load((SOURCE / '.github/workflows/a10-host.yml').read_text(), Loader=yaml.BaseLoader)
    steps = workflow['jobs']['native-rust-and-wayland']['steps']
    lint = next(step for step in steps if step.get('name') == 'Enforce Rust 1.88 UI workspace and all-target Clippy warnings')
    start = lint['run'].index('cargo clippy --manifest-path services/hepta-os/Cargo.toml')
    clippy = lint['run'][start:].strip()
    expected_clippy = ('cargo clippy --manifest-path services/hepta-os/Cargo.toml --all-targets \\\n'
        '  --locked --offline --features objective-transport -- -D warnings \\\n'
        '  2>&1 | tee "$RUNNER_TEMP/a10/objective-transport-clippy.log"')
    assert clippy == expected_clippy
    assert tomllib.loads((SOURCE / 'services/hepta-os/Cargo.toml').read_text())['features']['default'] == []
    commands = [('feature-off', off), ('feature-on', on), ('strict-clippy', clippy)]
    run_temp = OUT / 'runner-temp'
    (run_temp / 'a10').mkdir(parents=True)
    for name, command in commands:
        (OUT / (name + '.sh')).write_text('#!/usr/bin/env bash\nset -euo pipefail\n' + command + '\n')
    rust = BASE / 'next-tools/rust188/rustup/toolchains/1.88.0-x86_64-unknown-linux-gnu/bin'
    env = {'PATH': str(rust) + ':/usr/bin:/bin', 'HOME': os.environ['HOME'],
        'RUSTUP_HOME': str(BASE / 'next-tools/rust188/rustup'), 'RUSTUP_TOOLCHAIN': '1.88.0',
        'CARGO_HOME': str(BASE / 'next-tools/rust188/cargo'),
        'CARGO_TARGET_DIR': str(BASE / 'next-tools/r7-objective-target'),
        'CARGO_BUILD_JOBS': '1', 'CARGO_NET_OFFLINE': 'true', 'CARGO_INCREMENTAL': '0',
        'RUSTC': str(rust / 'rustc'), 'RUSTDOC': str(rust / 'rustdoc'),
        'RUST_BACKTRACE': '0', 'LC_ALL': 'C.UTF-8', 'LANG': 'C.UTF-8',
        'RUNNER_TEMP': str(run_temp), 'PYTHONOPTIMIZE': '0'}
    receipt = {'schema': 'r7-frozen-extracted-objective-ci-execution-v1',
        'started_utc': datetime.now(timezone.utc).isoformat(), 'status': 'in_progress',
        'source_head': HEAD, 'source_tree': before['tree'], 'main_head': MAIN,
        'main_kernel_git_tree_identical': True,
        'rustc_version': subprocess.check_output([str(rust / 'rustc'), '-Vv'], env=env, text=True),
        'cargo_version': subprocess.check_output([str(rust / 'cargo'), '-Vv'], env=env, text=True),
        'driver_sha256': sha(OUT / 'driver-source.py'),
        'bounded_executor_sha256': sha(OUT / 'bounded-executor-source.py'),
        'owned_child_guard_sha256': sha(OUT / 'owned-child-guard.py'),
        'environment': env, 'exact_extracted_commands': dict(commands), 'steps': [],
        'qualification': 'actual three local CI commands on frozen combined source; not a GitHub Actions run',
        'original_agentd_or_issuer_or_objective_started': False,
        'native_window_or_physical_device_started': False}
    write(OUT / 'receipt.json', receipt)
    try:
        for name, _ in commands:
            receipt['steps'].append(bound.bounded_step(OUT, guard, name,
                ['bash', str(OUT / (name + '.sh'))], env, 1800))
            if name == 'feature-on':
                log = (OUT / 'feature-on.log').read_text()
                paths = re.findall(r'Running [^\n]*\((/[^\n)]+)\)', log)
                assert paths, 'no real feature-on Rust test binary invocation recorded'
                binaries = {path: {'bytes': Path(path).stat().st_size, 'sha256': sha(Path(path))}
                            for path in paths}
                write(OUT / 'executed-test-binaries.json', binaries)
                receipt['executed_test_binaries'] = binaries
            write(OUT / 'receipt.json', receipt)
        receipt['status'] = 'passed'
    except BaseException as error:
        receipt['status'] = 'failed'
        receipt['error'] = repr(error)
        raise
    finally:
        after = source_binding()
        write(OUT / 'source-after.json', after)
        receipt['source_before_equals_after'] = before == after
        receipt['source_before_sha256'] = sha(OUT / 'source-before.json')
        receipt['source_after_sha256'] = sha(OUT / 'source-after.json')
        receipt['completed_utc'] = datetime.now(timezone.utc).isoformat()
        if before != after:
            receipt['status'] = 'failed'
            receipt['source_error'] = 'frozen source changed during execution'
        write(OUT / 'receipt.json', receipt)
        print(json.dumps({'status': receipt['status'], 'receipt': str(OUT / 'receipt.json')}), flush=True)
    assert receipt['status'] == 'passed'


if __name__ == '__main__':
    if len(sys.argv) > 3 and sys.argv[1] == '--bound-exec':
        path = Path(__file__).parent / 'bounded-executor-source.py'
        module = load_module('r7_ci_bound_exec_child', path)
        module.bound_exec(int(sys.argv[2]), sys.argv[3:])
    else:
        main()
