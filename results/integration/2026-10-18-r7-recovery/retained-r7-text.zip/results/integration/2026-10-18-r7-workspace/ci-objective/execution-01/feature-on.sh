#!/usr/bin/env bash
set -euo pipefail
cargo test --manifest-path services/hepta-os/Cargo.toml --locked --offline --features objective-transport
