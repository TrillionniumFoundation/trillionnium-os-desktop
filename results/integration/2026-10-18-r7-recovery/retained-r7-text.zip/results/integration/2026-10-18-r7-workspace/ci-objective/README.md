# R7 exact CI statements on frozen combined source

The three A07 CI statements were extracted directly from frozen source
`560f16c26dce32b50379dbfd26ffc291b658d303`, tree
`59e925797887187b902125ea2a162f71a5eabed4`, and actually run locally on
2026-10-18 05:06:15–05:06:35 UTC. All three commands exited zero. This is a
new local execution of those statements, not a GitHub Actions completion.

| Gate | Actual result |
| --- | --- |
| `cargo check --no-default-features --all-targets --locked --offline` for services/hepta-os | Passed; feature-off remains buildable |
| `cargo test --features objective-transport --locked --offline` for services/hepta-os | 35 passed, 0 failed, 0 ignored, 0 filtered |
| `cargo clippy --all-targets --features objective-transport --locked --offline -- -D warnings` | Passed, original tee log retained |

The 35 are baseline observer17, new objective integration/structural15,
one partial-write duplex unit test, and two compile-fail ownership examples.
The raw log records an actual hepta-os-observer recompilation and the exact
executed test paths; their post-execution binary hashes are retained. These
local socket/structural fixtures do not provide original owner admission.
No original Agentd, issuer, ObjectiveStart against a real owner, native window,
physical device, or kernel guest was started by these three commands.

[The execution receipt](execution-01/receipt.json) binds source identity,
original extracted commands, the executed helper/guard source, private
Rust1.88 environment, command exits, resource observations and cleanup.
[The raw feature test log](execution-01/feature-on.log.gz) preserves every test.
[The post-check review](execution-01/post-checks/review.json) verifies all39
recorded source files against their actual Git blobs, the unchanged complete
main01c kernel tree, the main A06 test, main STATUS/INDEX/UX and upstream pin.
The actual fixed-input verifier passed118 checks. README is zero bytes,
observer default features remain empty, and UI/Session manifests do not enable
objective-transport. The nine recorded live kernel files also match main;
main's six lifecycle tests were not replaced by independent64f source.

The parent directory [source review](reviews/ci-source-at-77731c.json) retains
the earlier read-only review of the CI change: all six PR/push trigger entries
added by main#187 remain and the new strict log is uploaded by the existing
always-artifact step. Its source identity is77731c, distinct from the actual
combined560f execution; the record is not relabeled as a test run.

The executor reused the completed kernel experiment's general owned-child
and resource-guard implementation, then explicitly set the command cwd to
this frozen R7 candidate. It did not invoke that module's kernel main or
namespace runner. Each actual bash command used its original extracted
statement under pipefail and a fresh parent-death-bound exec child. All
three owned groups were reaped/disarmed. The existing private objective
Cargo target was used; no fresh compilation of every dependency is claimed.

All copied records preserve their original bytes. `MANIFEST.json` records
sizes/SHA256; `SHA256SUMS` additionally covers the manifest. Binary executables,
Cargo targets/caches and system dependencies are excluded. Absolute paths
are historical execution locations, not portable installer instructions.

The feature-on test log is stored as deterministic `gzip(mtime=0)` to preserve its original final blank line. Its raw bytes and SHA-256 remain exactly those in the execution receipt; the manifest records the separate raw and stored identities. No executed helper, source binding or test receipt was rewritten.
