#!/usr/bin/env bash
set -euo pipefail
cargo check --manifest-path services/hepta-os/Cargo.toml --locked --offline --no-default-features --all-targets
