#!/usr/bin/env bash
set -euo pipefail
cargo clippy --manifest-path services/hepta-os/Cargo.toml --all-targets \
  --locked --offline --features objective-transport -- -D warnings \
  2>&1 | tee "$RUNNER_TEMP/a10/objective-transport-clippy.log"
