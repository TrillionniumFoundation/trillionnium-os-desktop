#!/usr/bin/env python3
"""Source-bound real kernel tests with owned-child cleanup and resource guards."""
from datetime import datetime, timezone
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/98f315e377b2')
ROOT = BASE / 'next-tools/r7-kernel'
SOURCE = BASE / 'next-a06-zombie-tail'
HEAD = '64f855512b2e78e895248ba49f908eccd7232679'
NIGHTLY = 'nightly-2026-07-21'
UPSTREAM = SOURCE / 'kernel/asterinas'
STDLIB = ROOT / 'rustup/toolchains/nightly-2026-07-21-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library'
MIN_FREE_BYTES = 5 * 1024**3 // 2
MAX_NONRECLAIMABLE_BYTES = 7 * 1024**3
GUARD_SOURCE = BASE / 'next-tools/r7-ui-verification/build-01/child-guard-source.py'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def now():
    return datetime.now(timezone.utc).isoformat()


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=SOURCE, text=True).strip()


def source_binding():
    paths = git('ls-files', '--', 'kernel/asterinas', 'support/build/ktest',
                'support/build/verify-source.py', 'support/upstream-lock.json',
                'tests/spec/test_a06_final_accounting_source.py',
                'docs/ASTERINAS_CPU_BANDWIDTH_N0.md').splitlines()
    files = {}
    for name in paths:
        path = SOURCE / name
        if path.is_symlink():
            files[name] = {'symlink': os.readlink(path)}
        else:
            files[name] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain=v1', '--untracked-files=all'), 'files': files}


def resource_sample():
    stats = dict(line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())
    values = {name: int(value) for name, value in stats.items()}
    # kernel includes reclaimable slab. Do not count reclaimable filesystem
    # caches as anonymous pressure; shmem remains charged even under `file`.
    nonreclaimable = values['anon'] + values['shmem'] + max(
        0, values['kernel'] - values.get('slab_reclaimable', 0))
    return {'utc': now(), 'disk_free_bytes': shutil.disk_usage(ROOT).free,
            'memory_current_bytes': int(Path('/sys/fs/cgroup/memory.current').read_text()),
            'memory_max': Path('/sys/fs/cgroup/memory.max').read_text().strip(),
            'anon_bytes': values['anon'], 'shmem_bytes': values['shmem'],
            'kernel_bytes': values['kernel'], 'slab_reclaimable_bytes': values.get('slab_reclaimable', 0),
            'guarded_nonreclaimable_bytes': nonreclaimable}


def environment():
    env = {name: os.environ[name] for name in
           ('HOME', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY', 'SSL_CERT_FILE', 'SSL_CERT_DIR')
           if name in os.environ}
    env.update({'PATH': str(ROOT / 'cargo/bin') + ':/usr/bin:/bin',
                'RUSTUP_HOME': str(ROOT / 'rustup'), 'CARGO_HOME': str(ROOT / 'cargo'),
                'RUSTUP_TOOLCHAIN': NIGHTLY, 'CARGO_INCREMENTAL': '0',
                'CARGO_BUILD_JOBS': '1', 'CARGO_TARGET_DIR': str(ROOT / 'osdk-target'),
                'CARGO_NET_GIT_FETCH_WITH_CLI': 'true', 'RUST_BACKTRACE': '0',
                'VDSO_LIBRARY_DIR': str(ROOT / 'linux-vdso'),
                'TMPDIR': str(ROOT / 'tmp'), 'LC_ALL': 'C.UTF-8', 'LANG': 'C.UTF-8'})
    return env


def namespace(command):
    return ['bwrap', '--die-with-parent', '--unshare-user', '--unshare-ipc', '--unshare-uts',
            '--unshare-net', '--ro-bind', '/', '/', '--bind', str(ROOT), str(ROOT),
            '--bind', str(SOURCE), str(SOURCE), '--ro-bind', '/usr', str(ROOT / 'namespace/host-usr'),
            '--ro-bind', str(ROOT / 'sysroot'), str(ROOT / 'namespace/sysroot'),
            '--ro-bind', str(ROOT / 'view02/usr'), '/usr', '--tmpfs', '/tmp', '--dev', '/dev',
            '--chdir', str(SOURCE), *command]


def bound_exec(parent_pid, command):
    # Fresh single-threaded exec helper; never preexec_fn in the orchestrator.
    libc = ctypes.CDLL(None, use_errno=True)
    assert libc.prctl(1, signal.SIGKILL, 0, 0, 0) == 0, 'PR_SET_PDEATHSIG failed'
    assert os.getppid() == parent_pid, 'orchestrator died before exec helper was bound'
    os.execvpe(command[0], command, os.environ)


def bounded_step(out, guard, name, command, env, timeout_seconds):
    log = out / f'{name}.log'
    record = {'name': name, 'command': command, 'started_utc': now(),
              'timeout_seconds': timeout_seconds, 'log': str(log), 'samples': []}
    wrapped = [sys.executable, '-B', str(out / 'driver-source.py'), '--bound-exec',
               str(os.getpid()), *command]
    record['wrapped_command'] = wrapped
    write(out / f'{name}.plan.json', record)
    group = None
    failure = None
    code = None
    try:
        sample = resource_sample()
        assert sample['disk_free_bytes'] > MIN_FREE_BYTES, 'disk guard before spawn'
        assert sample['guarded_nonreclaimable_bytes'] < MAX_NONRECLAIMABLE_BYTES, 'memory guard before spawn'
        with log.open('xb') as stream:
            child = subprocess.Popen(wrapped, cwd=SOURCE, env=env, stdin=subprocess.DEVNULL,
                                     stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            group = guard.ChildGroup(child)
            record['owned_pid'] = child.pid
            write(out / f'{name}.plan.json', record)
            deadline = time.monotonic() + timeout_seconds
            next_sample = 0.0
            while group.observe_exit() is None:
                current = time.monotonic()
                if current >= deadline:
                    raise RuntimeError('bounded command deadline elapsed')
                if current >= next_sample:
                    sample = resource_sample()
                    record['samples'].append(sample)
                    with (out / f'{name}.resources.jsonl').open('a') as samples:
                        samples.write(json.dumps(sample) + '\n')
                    if sample['disk_free_bytes'] <= MIN_FREE_BYTES:
                        raise RuntimeError('disk reserve reached 2.5 GiB floor')
                    if sample['guarded_nonreclaimable_bytes'] >= MAX_NONRECLAIMABLE_BYTES:
                        raise RuntimeError('anonymous/shmem/unreclaimable-kernel memory reached 7 GiB guard')
                    next_sample = current + 0.5
                time.sleep(0.1)
    except BaseException as error:
        failure = repr(error)
    finally:
        if group is not None and group.armed:
            try:
                group.signal_group(signal.SIGKILL)
                group.wait_exit(5)
                code = group.reap()
            except BaseException as error:
                failure = f'{failure}; cleanup failed: {error!r}'
        record.update({'completed_utc': now(), 'exit_code': code, 'failure': failure,
                       'owned_guard_armed_after': group.armed if group else False,
                       'log_sha256': sha(log) if log.exists() else None})
        samples = record.pop('samples')
        record['peak_nonreclaimable_bytes'] = max((x['guarded_nonreclaimable_bytes'] for x in samples), default=0)
        record['minimum_disk_free_bytes'] = min((x['disk_free_bytes'] for x in samples), default=0)
        record['status'] = 'passed' if code == 0 and failure is None else 'failed'
        write(out / f'{name}.receipt.json', record)
    print(json.dumps({'step': name, 'status': record['status'], 'exit_code': code, 'failure': failure}), flush=True)
    if record['status'] != 'passed':
        raise RuntimeError(f'{name} failed; preserved {out / (name + ".receipt.json")}')
    return record


def main():
    out = ROOT / 'receipts/execution-02'
    out.mkdir(parents=True, exist_ok=False)
    (ROOT / 'tmp').mkdir(exist_ok=True)
    before = source_binding()
    assert before['head'] == HEAD and before['status'] == '', 'frozen clean kernel candidate required'
    write(out / 'source-before.json', before)
    shutil.copy2(__file__, out / 'driver-source.py')
    shutil.copy2(GUARD_SOURCE, out / 'owned-child-guard.py')
    spec = importlib.util.spec_from_file_location('kernel_owned_child_guard', out / 'owned-child-guard.py')
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    assert guard.child_anchor_available(), 'sole waitable child anchor required'
    receipt = {'schema': 'r7-a06-source-bound-kernel-execution-v1', 'started_utc': now(),
               'source_head': HEAD, 'source_tree': before['tree'], 'status': 'in_progress', 'steps': [],
               'guard': {'disk_floor_bytes': MIN_FREE_BYTES, 'nonreclaimable_ceiling_bytes': MAX_NONRECLAIMABLE_BYTES,
                         'memory_definition': 'anon + shmem + max(0, kernel - slab_reclaimable)',
                         'sample_period_seconds': 0.5},
               'driver_sha256': sha(out / 'driver-source.py'), 'owned_child_guard_sha256': sha(out / 'owned-child-guard.py'),
               'toolchain_receipt_sha256': sha(ROOT / 'receipts/nightly-01/receipt.json'),
               'namespace_preflight_sha256': sha(ROOT / 'receipts/namespace-preflight-03/receipt.json'),
               'stdlib_lock_before_sha256': sha(STDLIB / 'Cargo.lock'),
               'kernel_guest_profile': 'x86_64 q35 TCG max, 1 vCPU, 512 MiB, no disk/network devices',
               'scope': 'real aster-core kernel-mode test suite; test-only Process/Task/cgroup objects are unscheduled'}
    write(out / 'receipt.json', receipt)
    env = environment()
    try:
        prior = ROOT / 'receipts/execution-01'
        prior_receipt = json.loads((prior / 'receipt.json').read_text())
        prior_source = json.loads((prior / 'source-before.json').read_text())
        prior_stage = json.loads((prior / 'real-aster-core.receipt.json').read_text())
        prior_env = json.loads((prior / 'ktest/environment.json').read_text())
        assert prior_receipt['status'] == 'failed' and prior_receipt['source_before_equals_after'] is True
        assert prior_source['head'] == 'cc1f438c5bcbe863b89386a35b9fa025a32dcdb3'
        assert prior_stage['status'] == 'failed' and prior_stage['exit_code'] == 1
        assert prior_stage['failure'] is None and prior_stage['owned_guard_armed_after'] is False
        assert prior_env['osdk_install_skipped'] is False
        assert (prior / 'ktest/aster-core/osdk-exit-code.txt').read_text().strip() == '6'
        allowed_changes = {
            'kernel/asterinas/kernel/core/src/process/posix_thread/mod.rs',
            'kernel/asterinas/kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu.rs',
            'tests/spec/test_a06_final_accounting_source.py',
        }
        assert set(prior_source['files']) == set(before['files'])
        changed = {name for name in before['files'] if before['files'][name] != prior_source['files'][name]}
        assert changed == allowed_changes, 'only frozen borrow-lifetime and source-guard corrections are allowed'
        assert prior_env['osdk_sha256'] == '1d71f8da40f11d35d66002eb1ef4d3e329828e454684f8b16e27ee7a0658b4a0'
        assert sha(ROOT / 'cargo/bin/cargo-osdk') == prior_env['osdk_sha256']
        assert prior_receipt['stdlib_lock_after_sha256'] == receipt['stdlib_lock_before_sha256']
        receipt['previous_failed_execution'] = {
            'receipt_sha256': sha(prior / 'receipt.json'),
            'stage_receipt_sha256': sha(prior / 'real-aster-core.receipt.json'),
            'osdk_install_log_sha256': sha(prior / 'ktest/osdk-install.log'),
            'compiler_failure_log_sha256': sha(prior / 'ktest/aster-core/osdk-test.log'),
            'source_before_sha256': sha(prior / 'source-before.json'),
            'environment_sha256': sha(prior / 'ktest/environment.json'),
            'source_head': prior_source['head'],
            'retained_status': prior_receipt['status'],
            'changed_source_files': sorted(changed),
            'reused_source_built_osdk_sha256': prior_env['osdk_sha256'],
            'osdk_source_closure_unchanged': True,
            'reused_existing_target': str(UPSTREAM / 'target'),
        }
        write(out / 'receipt.json', receipt)
        env['CARGO_NET_OFFLINE'] = 'true'
        prepared = out / 'prepared-locks'
        receipt['steps'].append(bounded_step(out, guard, 'prepare-locks', namespace([
            'python3', '-B', str(SOURCE / 'support/build/ktest/prepare-locks.py'),
            '--crate', 'aster-core', '--output-dir', str(prepared)]), env, 300))
        expected = SOURCE / 'support/build/ktest/locks/aster-core.Cargo.lock'
        assert sha(prepared / 'aster-core.Cargo.lock') == sha(expected), 'prepared lock differs from committed fixed test-base lock'
        receipt['prepared_lock_sha256'] = sha(expected)
        write(out / 'receipt.json', receipt)
        receipt['steps'].append(bounded_step(out, guard, 'real-aster-core', namespace([
            'python3', '-B', str(SOURCE / 'support/build/ktest/run.py'), '--crate', 'aster-core',
            '--output', str(out / 'ktest'), '--skip-osdk-install']), env, 5400))
        result = json.loads((out / 'ktest/result.json').read_text())
        assert result['passed'] is True
        receipt['ktest_result'] = result
        receipt['status'] = 'passed'
    except BaseException as error:
        receipt['status'] = 'failed'
        receipt['error'] = repr(error)
        raise
    finally:
        after = source_binding()
        write(out / 'source-after.json', after)
        receipt['source_before_equals_after'] = before == after
        receipt['source_before_sha256'] = sha(out / 'source-before.json')
        receipt['source_after_sha256'] = sha(out / 'source-after.json')
        receipt['stdlib_lock_after_sha256'] = sha(STDLIB / 'Cargo.lock')
        if before != after or receipt['stdlib_lock_before_sha256'] != receipt['stdlib_lock_after_sha256']:
            receipt['status'] = 'failed'
            receipt['source_error'] = 'source or fixed standard library lock changed during execution'
        receipt['completed_utc'] = now()
        write(out / 'receipt.json', receipt)
        print(json.dumps({'status': receipt['status'], 'receipt': str(out / 'receipt.json')}), flush=True)


if __name__ == '__main__':
    if len(sys.argv) > 3 and sys.argv[1] == '--bound-exec':
        bound_exec(int(sys.argv[2]), sys.argv[3:])
    else:
        main()
