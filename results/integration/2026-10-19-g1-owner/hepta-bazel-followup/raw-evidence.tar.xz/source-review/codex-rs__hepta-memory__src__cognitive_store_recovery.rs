//! Exact current-cut witness construction and fail-closed recovery admission.
//!
//! This is not a minimum-prefix journal anchor. Any subsequent owner mutation
//! needs a fresh, independently retained host witness. Capturing a witness from
//! a suspect backup cannot authenticate that backup. No witness is auto-saved,
//! no grant is issued, and no migration, repair or unanchored fallback occurs.
//! The maximum-retained profile permits 262,144 logical rows and 128 MiB of
//! framed values, with 2 MiB per row and 1 MiB of required schema definitions.
//! This keeps recovery bounded while covering the 16,384-memory durable profile.
//! Integrity checking still scans physical
//! database pages; these logical limits are not a host latency qualification.

use codex_hepta_contracts::AgentId;
use codex_hepta_contracts::Sha256Digest;
use codex_hepta_paths::HeptaAgentLayout;
use codex_state::SqliteConfig;
use codex_state::SqliteRecoveryError;
use codex_utils_absolute_path::AbsolutePathBuf;
use serde::Deserialize;
use serde::Serialize;
use sha2::Digest;
use sha2::Sha256;
use sqlx::Row;
use sqlx::SqliteConnection;
use sqlx::TypeInfo;
use sqlx::ValueRef;

use super::CognitiveStore;
use super::CognitiveStoreError;
use super::CognitiveStoreOpenGuard;
use super::REQUIRED_SCHEMA_OBJECTS;
use super::REQUIRED_SCHEMA_ORACLE_SHA256;
use super::protect_database_file;
use super::publish_active_database;
use super::recovered_database_filename;
use super::resolve_active_database_path;
use super::unavailable;
use super::verify_store;
use crate::ProductionAuthorityLease;
use crate::ProductionAuthorityVerifier;
use crate::cognitive_path::canonical_path_without_redirection;
use crate::framing::frame_part;

#[path = "cognitive_store_recovery_read_only.rs"]
mod read_only;
pub use read_only::RecoveredCognitiveReadOnly;

const PROFILE: &str = "hepta:cognitive:exact-current-cut:v1";
const MAX_ROWS: i64 = 262_144;
const MAX_BYTES: i64 = 128 * 1024 * 1024;
const MAX_ROW_BYTES: i64 = 2 * 1024 * 1024;
const MAX_SCHEMA_BYTES: i64 = 1024 * 1024;

/// An exact logical state cut, including all registered owner tables and their
/// current tombstones/revocations. The host must independently persist and
/// authenticate this value and establish that it is CURRENT before recovery.
/// The digest is an integrity comparison, not a signature or write authority.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct CognitiveRecoveryAnchor {
    pub profile: String,
    pub owner_agent_id: AgentId,
    pub schema_digest: Sha256Digest,
    pub state_digest: Sha256Digest,
}

/// Current recovery disposition supplied by the trusted host. Revocation wins
/// before any filesystem access. An exact witness is an integrity input, not a
/// grant. Writable recovery additionally requires the externally verified
/// production authority lease supplied to `open_with_recovery`; its
/// grant-bound fencing digest is part of the recovered generation identity.
pub enum CognitiveRecoveryRequirement<'a> {
    ExactCurrentCut(&'a CognitiveRecoveryAnchor),
    Revoked,
}

/// Fail-closed recovery admission outcome.
///
/// This separate type preserves an indeterminate filesystem identity instead
/// of laundering it into ordinary storage unavailability. No variant carries
/// a recovered store or grants authority.
#[non_exhaustive]
#[derive(Debug, thiserror::Error)]
pub enum CognitiveRecoveryError {
    #[error("invalid cognitive recovery request: {0}")]
    Invalid(String),
    #[error("cognitive recovery access denied: {0}")]
    AccessDenied(String),
    #[error("cognitive recovery state is indeterminate: {0}")]
    Indeterminate(String),
    #[error("cognitive recovery is unavailable: {0}")]
    Unavailable(String),
}

impl CognitiveStore {
    /// Capture one coherent bounded owner cut. The host retains/authenticates it
    /// independently; this method does not publish an acknowledgement witness.
    pub async fn recovery_anchor(&self) -> Result<CognitiveRecoveryAnchor, CognitiveStoreError> {
        let mut transaction = self
            .pool
            .begin_with("BEGIN IMMEDIATE")
            .await
            .map_err(unavailable)?;
        let anchor = capture(&mut transaction, &self.owner_agent_id).await?;
        transaction.commit().await.map_err(unavailable)?;
        Ok(anchor)
    }

    /// Recover one exact current owner cut into a new writable generation.
    ///
    /// Source SQLite paths are never reopened by SQLite. A shared lock is held
    /// by every ordinary `CognitiveStore::open`; recovery obtains the
    /// corresponding exclusive lock, captures database/WAL/journal bytes from
    /// retained descriptors, and materializes those bytes into a fresh private
    /// generation. SQLite may recover the COPY, never the suspect source.
    ///
    /// The candidate generation becomes active only after full schema/integrity
    /// verification, exact current-cut equality, a FULL checkpoint, and
    /// independent production-authority verification. Activation is one atomic
    /// pointer rename; the predecessor database is left untouched.
    pub async fn open_with_recovery<V>(
        layout: &HeptaAgentLayout,
        requirement: CognitiveRecoveryRequirement<'_>,
        authority: &ProductionAuthorityLease,
        verifier: &V,
    ) -> Result<Self, CognitiveRecoveryError>
    where
        V: ProductionAuthorityVerifier + ?Sized,
    {
        let expected = validate_requirement(layout, requirement)?;
        verifier
            .verify(authority, layout.agent_id())
            .map_err(CognitiveRecoveryError::AccessDenied)?;
        authority
            .validate_for_agent(layout.agent_id())
            .map_err(|error| CognitiveRecoveryError::AccessDenied(error.to_string()))?;
        let writer_fence = authority
            .fencing_token_digest()
            .map_err(|error| CognitiveRecoveryError::AccessDenied(error.to_string()))?;

        let root = layout.cognitive_root();
        let canonical_root = canonical_path_without_redirection(root)
            .map_err(|error| CognitiveRecoveryError::Indeterminate(error.to_string()))?
            .ok_or_else(|| {
                CognitiveRecoveryError::Unavailable(
                    "cognitive recovery root does not exist".to_string(),
                )
            })?;
        if canonical_root != root {
            return Err(CognitiveRecoveryError::Indeterminate(
                "cognitive recovery root is redirected".to_string(),
            ));
        }
        let exclusive_guard = CognitiveStoreOpenGuard::acquire_exclusive(&canonical_root)
            .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;
        let source_path = resolve_active_database_path(&canonical_root)
            .map_err(|error| CognitiveRecoveryError::Indeterminate(error.to_string()))?;
        let sqlite_home = AbsolutePathBuf::try_from(canonical_root.clone())
            .map_err(|error| CognitiveRecoveryError::Invalid(error.to_string()))?;
        let config = SqliteConfig::from_sqlite_home(sqlite_home);
        let source_guard = config
            .bind_existing_recovery_database(&source_path)
            .map_err(recovery_error)?;

        let candidate = canonical_root.join(recovered_database_filename(expected, &writer_fence));
        config
            .materialize_identity_bound_recovery_copy(&source_guard, &candidate)
            .map_err(recovery_error)?;

        let result = async {
            let pool = config
                .open_durable_evidence_pool(&candidate)
                .await
                .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;
            let authenticated = async {
                verify_store(&pool, layout.agent_id())
                    .await
                    .map_err(|error| CognitiveRecoveryError::Indeterminate(error.to_string()))?;
                let mut transaction = pool
                    .begin_with("BEGIN IMMEDIATE")
                    .await
                    .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;
                let observed = capture(&mut transaction, layout.agent_id())
                    .await
                    .map_err(|error| CognitiveRecoveryError::Indeterminate(error.to_string()))?;
                if observed != *expected {
                    return Err(CognitiveRecoveryError::AccessDenied(
                        "recovery candidate differs from independently retained current cut"
                            .to_string(),
                    ));
                }
                let integrity: Vec<String> = sqlx::query_scalar("PRAGMA integrity_check(1)")
                    .fetch_all(&mut *transaction)
                    .await
                    .map_err(|error| CognitiveRecoveryError::Indeterminate(error.to_string()))?;
                if integrity != ["ok"] {
                    return Err(CognitiveRecoveryError::Indeterminate(
                        "recovery candidate failed SQLite integrity_check".to_string(),
                    ));
                }
                transaction
                    .commit()
                    .await
                    .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;

                Ok(())
            }
            .await;
            if let Err(error) = authenticated {
                pool.close().await;
                return Err(error);
            }
            pool.close().await;

            config
                .checkpoint_private_recovery_database(&candidate)
                .await
                .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;

            cleanup_candidate_sidecars(&candidate)?;
            protect_database_file(&candidate)
                .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;
            std::fs::File::open(&candidate)
                .and_then(|file| file.sync_all())
                .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;
            std::fs::File::open(&canonical_root)
                .and_then(|directory| directory.sync_all())
                .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;

            let pool = config
                .open_durable_evidence_pool(&candidate)
                .await
                .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;
            let final_check = async {
                verify_store(&pool, layout.agent_id())
                    .await
                    .map_err(|error| CognitiveRecoveryError::Indeterminate(error.to_string()))?;
                let mut transaction = pool
                    .begin_with("BEGIN IMMEDIATE")
                    .await
                    .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;
                let observed = capture(&mut transaction, layout.agent_id())
                    .await
                    .map_err(|error| CognitiveRecoveryError::Indeterminate(error.to_string()))?;
                transaction
                    .commit()
                    .await
                    .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;
                if observed != *expected {
                    return Err(CognitiveRecoveryError::Indeterminate(
                        "recovered generation changed during checkpoint/reopen".to_string(),
                    ));
                }
                Ok(())
            }
            .await;
            if let Err(error) = final_check {
                pool.close().await;
                return Err(error);
            }

            publish_active_database(&canonical_root, &candidate)
                .map_err(|error| CognitiveRecoveryError::Unavailable(error.to_string()))?;
            // Keep the recovery fence exclusive for this recovered writer
            // generation. Callers that need additional handles clone this
            // store; reopening by path would otherwise create a second writer
            // immediately after a security-sensitive recovery.
            Ok(CognitiveStore {
                pool,
                owner_agent_id: layout.agent_id().clone(),
                path: candidate.clone(),
                _open_guard: Some(std::sync::Arc::new(exclusive_guard)),
            })
        }
        .await;

        match result {
            Ok(store) => Ok(store),
            Err(error) => Err(reconcile_failed_recovery_candidate(
                &canonical_root,
                &candidate,
                error,
            )),
        }
    }
}

fn reconcile_failed_recovery_candidate(
    root: &std::path::Path,
    candidate: &std::path::Path,
    error: CognitiveRecoveryError,
) -> CognitiveRecoveryError {
    // A pointer rename can succeed while the following directory fsync reports
    // an error. In that state publication durability is unknown: never launder
    // it into ordinary Unavailable and never delete the possibly-active
    // generation. A later trusted recovery ceremony must reconcile it.
    let active = resolve_active_database_path(root).ok();
    if active.as_deref() == Some(candidate) {
        return CognitiveRecoveryError::Indeterminate(format!(
            "active generation publication became ambiguous after pointer rename: {error}"
        ));
    }
    cleanup_recovery_candidate(candidate);
    error
}

fn cleanup_candidate_sidecars(path: &std::path::Path) -> Result<(), CognitiveRecoveryError> {
    for suffix in ["-wal", "-shm", "-journal"] {
        let mut name = path.as_os_str().to_os_string();
        name.push(suffix);
        match std::fs::remove_file(std::path::PathBuf::from(name)) {
            Ok(()) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => {
                return Err(CognitiveRecoveryError::Unavailable(format!(
                    "cannot remove recovered SQLite sidecar: {error}"
                )));
            }
        }
    }
    Ok(())
}

fn cleanup_recovery_candidate(path: &std::path::Path) {
    let _ = cleanup_candidate_sidecars(path);
    let _ = std::fs::remove_file(path);
}

fn validate_requirement<'a>(
    layout: &HeptaAgentLayout,
    requirement: CognitiveRecoveryRequirement<'a>,
) -> Result<&'a CognitiveRecoveryAnchor, CognitiveRecoveryError> {
    let expected = match requirement {
        CognitiveRecoveryRequirement::Revoked => {
            return Err(CognitiveRecoveryError::AccessDenied(
                "cognitive recovery is revoked".to_string(),
            ));
        }
        CognitiveRecoveryRequirement::ExactCurrentCut(anchor) => anchor,
    };
    if expected.owner_agent_id != *layout.agent_id() {
        return Err(CognitiveRecoveryError::AccessDenied(
            "cognitive recovery owner mismatch".to_string(),
        ));
    }
    if expected.profile != PROFILE
        || expected.schema_digest.as_str() != REQUIRED_SCHEMA_ORACLE_SHA256
    {
        return Err(CognitiveRecoveryError::Invalid(
            "unsupported cognitive recovery profile or schema".to_string(),
        ));
    }
    Ok(expected)
}

fn recovery_error(error: SqliteRecoveryError) -> CognitiveRecoveryError {
    match error {
        SqliteRecoveryError::Unavailable => CognitiveRecoveryError::Unavailable(error.to_string()),
        SqliteRecoveryError::Indeterminate => {
            CognitiveRecoveryError::Indeterminate(error.to_string())
        }
        _ => CognitiveRecoveryError::Indeterminate(error.to_string()),
    }
}

async fn capture(
    connection: &mut SqliteConnection,
    owner: &AgentId,
) -> Result<CognitiveRecoveryAnchor, CognitiveStoreError> {
    let mut schema = REQUIRED_SCHEMA_OBJECTS.to_vec();
    schema.sort_unstable_by_key(|(name, _)| *name);
    let mut schema_hasher = Sha256::new();
    frame_part(
        &mut schema_hasher,
        b"hepta:cognitive:required-schema-oracle:v1",
    );
    frame_part(&mut schema_hasher, &(schema.len() as u64).to_be_bytes());
    let mut schema_bytes = 0_i64;
    for (name, kind) in &schema {
        let length: Option<i64> = sqlx::query_scalar(
            "SELECT length(CAST(sql AS BLOB)) FROM sqlite_schema WHERE name = ? AND type = ?",
        )
        .bind(name)
        .bind(kind)
        .fetch_optional(&mut *connection)
        .await
        .map_err(unavailable)?
        .flatten();
        let length = length.filter(|value| *value > 0).ok_or_else(|| {
            CognitiveStoreError::Corrupt("missing cognitive recovery schema object".to_string())
        })?;
        schema_bytes = schema_bytes
            .checked_add(length)
            .filter(|value| *value <= MAX_SCHEMA_BYTES)
            .ok_or_else(|| {
                CognitiveStoreError::Invalid("cognitive recovery schema exceeds bounds".to_string())
            })?;
        let sql: String = sqlx::query_scalar("SELECT sql FROM sqlite_schema WHERE name = ?")
            .bind(name)
            .fetch_one(&mut *connection)
            .await
            .map_err(unavailable)?;
        frame_part(&mut schema_hasher, name.as_bytes());
        frame_part(&mut schema_hasher, kind.as_bytes());
        frame_part(&mut schema_hasher, sql.as_bytes());
    }
    let schema_digest = Sha256Digest::from_sha256_output(schema_hasher.finalize());
    if schema_digest.as_str() != REQUIRED_SCHEMA_ORACLE_SHA256 {
        return Err(CognitiveStoreError::Corrupt(
            "cognitive recovery schema mismatch".to_string(),
        ));
    }
    let stored_owner: String = sqlx::query_scalar("SELECT owner_agent_id FROM cognitive_meta WHERE singleton = 1 AND length(owner_agent_id) = 36")
        .fetch_one(&mut *connection).await.map_err(unavailable)?;
    if stored_owner != owner.as_str() {
        return Err(CognitiveStoreError::AccessDenied(
            "cognitive recovery database owner mismatch".to_string(),
        ));
    }
    let mut tables: Vec<&str> = schema
        .iter()
        .filter_map(|(name, kind)| (*kind == "table").then_some(*name))
        .collect();
    tables.push("_sqlx_migrations");
    tables.sort_unstable();
    let actual_tables: Vec<String> = sqlx::query_scalar(
        "SELECT substr(name, 1, 129) FROM pragma_table_list
         WHERE schema = 'main' AND type IN ('table', 'virtual')
           AND name NOT LIKE 'sqlite_%' ORDER BY name LIMIT 256",
    )
    .fetch_all(&mut *connection)
    .await
    .map_err(unavailable)?;
    if actual_tables != tables {
        return Err(CognitiveStoreError::Corrupt(
            "unregistered cognitive recovery table".to_string(),
        ));
    }
    // Bind complete logical schema too, including extra triggers and indexes.
    // Physical root pages are deliberately excluded so checkpoint/backup does
    // not masquerade as an owner mutation. FTS shadows are covered through the
    // registered logical FTS tables rather than physical index pages.
    tables.push("sqlite_schema");
    let mut state = Sha256::new();
    frame_part(&mut state, PROFILE.as_bytes());
    frame_part(&mut state, owner.as_str().as_bytes());
    frame_part(&mut state, schema_digest.as_str().as_bytes());
    let mut remaining_rows = MAX_ROWS;
    let mut remaining_bytes = MAX_BYTES;
    for table in tables {
        let columns: Vec<String> = if table == "sqlite_schema" {
            ["type", "name", "tbl_name", "sql"]
                .into_iter()
                .map(str::to_string)
                .collect()
        } else {
            // Also bound metadata for the migration ledger before table_info
            // can materialize a maliciously oversized column name.
            let length: i64 = sqlx::query_scalar(
                "SELECT length(CAST(sql AS BLOB)) FROM sqlite_schema WHERE name = ?",
            )
            .bind(table)
            .fetch_one(&mut *connection)
            .await
            .map_err(unavailable)?;
            if !(1..=MAX_SCHEMA_BYTES).contains(&length) {
                return Err(CognitiveStoreError::Invalid(
                    "cognitive recovery table schema exceeds bounds".to_string(),
                ));
            }
            let columns = sqlx::query("SELECT name FROM pragma_table_info(?) ORDER BY cid")
                .bind(table)
                .fetch_all(&mut *connection)
                .await
                .map_err(unavailable)?;
            if columns.is_empty() || columns.len() > 64 {
                return Err(CognitiveStoreError::Corrupt(
                    "cognitive recovery table columns invalid".to_string(),
                ));
            }
            columns
                .iter()
                .map(|row| row.try_get("name"))
                .collect::<Result<_, _>>()
                .map_err(unavailable)?
        };
        let quoted: Vec<String> = columns
            .iter()
            .map(|column| format!("\"{}\"", column.replace('"', "\"\"")))
            .collect();
        let row_bytes = quoted.iter().map(|column| format!(
            "CASE typeof({column}) WHEN 'null' THEN 16 WHEN 'integer' THEN 32 WHEN 'real' THEN 32 ELSE 24 + length(CAST({column} AS BLOB)) END"
        )).collect::<Vec<_>>().join(" + ");
        // Check every encoded row's size and the cumulative budget inside the
        // locked snapshot BEFORE fetching any potentially large text or blob.
        // Dynamic fragments contain only fixed allowlisted table names and
        // double-quoted/escaped schema column identifiers, never input values.
        let mut bounds_query = sqlx::QueryBuilder::<sqlx::Sqlite>::new(
            "SELECT COUNT(*), COALESCE(SUM(row_size), 0), COALESCE(MAX(row_size), 0) FROM (SELECT ",
        );
        bounds_query
            .push(&row_bytes)
            .push(" AS row_size FROM \"")
            .push(table)
            .push("\" LIMIT ")
            .push_bind(remaining_rows + 1)
            .push(")");
        let (count, bytes, largest): (i64, i64, i64) = bounds_query
            .build_query_as()
            .fetch_one(&mut *connection)
            .await
            .map_err(unavailable)?;
        if count > remaining_rows || bytes > remaining_bytes || largest > MAX_ROW_BYTES {
            return Err(CognitiveStoreError::Invalid(
                "cognitive recovery state exceeds bounds".to_string(),
            ));
        }
        remaining_rows -= count;
        remaining_bytes -= bytes;
        frame_part(&mut state, table.as_bytes());
        frame_part(&mut state, &(columns.len() as u64).to_be_bytes());
        for column in &columns {
            frame_part(&mut state, column.as_bytes());
        }
        frame_part(&mut state, &count.to_be_bytes());
        let ordering = quoted
            .iter()
            .map(|column| format!("typeof({column}), {column} COLLATE BINARY"))
            .collect::<Vec<_>>()
            .join(", ");
        let selection = quoted.join(", ");
        let mut rows_query = sqlx::QueryBuilder::<sqlx::Sqlite>::new("SELECT ");
        rows_query
            .push(selection)
            .push(" FROM \"")
            .push(table)
            .push("\" ORDER BY ")
            .push(ordering);
        let rows = rows_query
            .build()
            .fetch_all(&mut *connection)
            .await
            .map_err(unavailable)?;
        for row in rows {
            for index in 0..columns.len() {
                let value = row.try_get_raw(index).map_err(unavailable)?;
                if value.is_null() {
                    frame_part(&mut state, b"null");
                    continue;
                }
                match value.type_info().name() {
                    "INTEGER" => {
                        frame_part(&mut state, b"integer");
                        frame_part(
                            &mut state,
                            &row.try_get::<i64, _>(index)
                                .map_err(unavailable)?
                                .to_be_bytes(),
                        );
                    }
                    "REAL" => {
                        frame_part(&mut state, b"real");
                        frame_part(
                            &mut state,
                            &row.try_get::<f64, _>(index)
                                .map_err(unavailable)?
                                .to_bits()
                                .to_be_bytes(),
                        );
                    }
                    "TEXT" => {
                        frame_part(&mut state, b"text");
                        frame_part(
                            &mut state,
                            row.try_get::<&str, _>(index)
                                .map_err(unavailable)?
                                .as_bytes(),
                        );
                    }
                    "BLOB" => {
                        frame_part(&mut state, b"blob");
                        frame_part(
                            &mut state,
                            row.try_get::<&[u8], _>(index).map_err(unavailable)?,
                        );
                    }
                    _ => {
                        return Err(CognitiveStoreError::Corrupt(
                            "unsupported cognitive recovery value type".to_string(),
                        ));
                    }
                }
            }
        }
    }
    // Keep both integrity gates in the same serialized snapshot. Run them only
    // after bounded logical reads, which also establish the current FTS view on
    // pooled connections; never expose the calculated digest before they pass.
    let check: String = sqlx::query_scalar("PRAGMA quick_check(1)")
        .fetch_one(&mut *connection)
        .await
        .map_err(unavailable)?;
    if check != "ok" {
        return Err(CognitiveStoreError::Corrupt(
            "cognitive recovery quick_check failed".to_string(),
        ));
    }
    if sqlx::query("SELECT 1 FROM pragma_foreign_key_check LIMIT 1")
        .fetch_optional(&mut *connection)
        .await
        .map_err(unavailable)?
        .is_some()
    {
        return Err(CognitiveStoreError::Corrupt(
            "cognitive recovery foreign-key check failed".to_string(),
        ));
    }
    Ok(CognitiveRecoveryAnchor {
        profile: PROFILE.to_string(),
        owner_agent_id: owner.clone(),
        schema_digest,
        state_digest: Sha256Digest::from_sha256_output(state.finalize()),
    })
}

#[cfg(test)]
#[path = "cognitive_store_recovery_tests.rs"]
mod tests;
