#!/usr/bin/env python3
"""Freeze the two bounded Fleet/CI evidence sets without changing old packages."""
import datetime
import hashlib
import io
import json
import lzma
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

BASE = Path('/workspace/scratch/499c7902de8e')
REMOTE = BASE / 'r10-evidence/fleet-main-remote-ci'
CANDIDATE = BASE / 'r10-evidence/hepta-scoped-disk-fix'
SOURCE = BASE / 'r10-hepta-scoped-disk-fix'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def record(path, root):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'bytes': len(data), 'sha256': sha(data)}


def write(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args]).decode().strip()


# Complete the derived observation using actual request timestamps.
final_path = REMOTE / 'final-observation.json'
final = json.loads(final_path.read_text())
requests = [json.loads(p.read_text()) for p in (REMOTE / '20261019T040945Z').glob('*.json')]
final['observation_window'] = {
    'started_at': min(r['request_started_at'] for r in requests),
    'finished_at': max(r['request_finished_at'] for r in requests),
}
final_path.write_text(json.dumps(final, indent=2, ensure_ascii=False) + '\n')

native_log_path = next((REMOTE / 'artifacts/extracted').glob('*.log'))
native_log = native_log_path.read_text()
impact = json.loads((REMOTE / 'artifacts/extracted/cargo-impact.json').read_text())
incomplete = json.loads((REMOTE / 'artifacts/extracted/impact-test.json').read_text())
assert len(impact['packages']) == 134 and incomplete['status'] == 'running'
assert incomplete['command_exit_code'] is None
assert impact['tested_sha'] == 'b34cb44f06db0a66acb3d25b183a2a05c4cebc7e'
assert '-C debuginfo=1' in native_log and '-C incremental=' in native_log
assert 'No space left on device' in native_log
assert 'test result:' not in native_log and 'tests run:' not in native_log
failed_units = re.findall(r'error: could not compile `([^`]+)` \(([^)]+)\)', native_log)
log_records = []
for path in sorted((REMOTE / 'logs').glob('*.log')):
    data = path.read_bytes()
    compressed = path.with_suffix('.log.xz')
    if not compressed.exists():
        compressed.write_bytes(lzma.compress(data, preset=6))
    assert lzma.decompress(compressed.read_bytes()) == data
    log_records.append({'decoded_utf8_log': record(path, REMOTE), 'lossless_xz': record(compressed, REMOTE)})
write(REMOTE / 'failure-analysis.json', {
    'schema': 1,
    'repository': 'TrillionniumFoundation/hepta-private-ci',
    'fleet_source': impact['tested_sha'],
    'source_tree': '15a3b89f59052368e28ce5ed4943dc2ab638844b',
    'base': impact['base_sha'],
    'run_id': 39195438433, 'job_id': 117877231475,
    'failure_step': 8, 'job_conclusion': 'failure',
    'job_started_at': '2026-10-19T03:36:31Z',
    'job_completed_at': '2026-10-19T03:52:59Z',
    'observed_compiler_enospc_at': '2026-10-19T03:52:53.2331278Z',
    'observed_runner_diagnostic_enospc_at': '2026-10-19T03:52:54.8054929Z',
    'failed_compile_units': [{'package': name, 'unit': unit} for name, unit in failed_units],
    'cause_supported_by_original_logs': 'Compiler and runner both report no space left on device.',
    'original_helper_source_or_clippy_failure_established': False,
    'timeout_failure': False,
    'artifact': record(REMOTE / 'artifacts/fleet-scoped-impact-12162530412.zip', REMOTE),
    'artifact_id': 12162530412, 'github_archive_digest_verified': True,
    'native_command_log': record(native_log_path, REMOTE),
    'actual_plan_package_count': len(impact['packages']),
    'actual_plan_full_workspace': impact['full_workspace'],
    'incomplete_execution_record': incomplete,
    'completed_successful_suite_receipt_observed': False,
    'execution_record_not_rewritten_from_job_status': True,
    'build_configuration_observation': {
        'cargo_profile_path': 'codex-rs/target/debug',
        'debuginfo_1_argument_observed': True,
        'incremental_argument_observed': True,
        'workspace_target_path_unchanged_by_workflow': True,
        'no_cache_restore_step_in_fixed_scoped_workflow': True,
        'no_sdk_cleanup_step_in_fixed_scoped_workflow': True,
        'numeric_df_du_or_sdk_inventory_in_original_logs': False,
        'runner_total_or_free_bytes': None,
        'sdk_reclaimable_bytes': None,
        'apt_additional_disk_estimate_kb_is_not_a_measurement': 3080,
        'required_v8_inputs_are_not_proposed_as_disposable_cache': True,
    },
    'log_records': log_records,
    'followup_candidate': {
        'commit': '71d9db8fd48a317fe5930392799522f186188d6a',
        'separate_evidence': '../hepta-scoped-disk-fix',
        'original_scoped_job_not_rerun': True,
        'candidate_remote_enospc_resolution_not_yet_proven': True,
    },
    'no_remote_mutation_by_this_agent': True,
})

assert git('rev-parse', 'HEAD') == '71d9db8fd48a317fe5930392799522f186188d6a'
assert git('rev-parse', 'HEAD^{tree}') == '4688d8dfc139f990b3d770c8c081050a5ace1d26'
assert git('rev-parse', 'HEAD^') == 'f8c9419df6ddeb36ff8b522a50219981fb8d9345'
assert not git('status', '--porcelain=v1', '--untracked-files=all')
receipts = []
for path in sorted(CANDIDATE.glob('*/receipt.json')):
    receipt = json.loads(path.read_text())
    assert receipt['source_unchanged']
    assert receipt['source_before'] == receipt['source_after']
    assert receipt['source_before']['commit'] == git('rev-parse', 'HEAD')
    log = path.parent / receipt['log']['path']
    assert len(log.read_bytes()) == receipt['log']['bytes']
    assert sha(log.read_bytes()) == receipt['log']['sha256']
    receipts.append({**record(path, CANDIDATE), 'name': receipt['name'],
                     'started_at': receipt['started_at'], 'completed_at': receipt['completed_at'],
                     'exit_code': receipt['exit_code'], 'source_unchanged': True})
review = json.loads((CANDIDATE / 'validation-review.json').read_text())
assert review['unique_existing_python_tests_passed'] == 102
assert review['cargo_flags_proof']['existing_library_tests_passed'] == 18
source_payload = (SOURCE / '.github/workflows/blocking-ci.yml').read_bytes()
assert source_payload == (CANDIDATE / 'publication/blocking-ci.yml').read_bytes()
write(CANDIDATE / 'final-validation.json', {
    'schema': 1, 'saved_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
    'base': git('rev-parse', 'HEAD^'), 'source_clean': True,
    'changed_paths': git('diff', '--name-only', 'HEAD^', 'HEAD').splitlines(),
    'diff_numstat': git('diff', '--numstat', 'HEAD^', 'HEAD'),
    'all_command_receipts': receipts,
    'unique_existing_python_tests_passed': 102,
    'python_count_basis': '72 passed in the first invocation plus 45 passed in original executor discovery, with 15 overlapping tests. The first invocation also retains two module-loader errors.',
    'small_existing_crate_tests_passed': 18,
    'small_existing_crate': 'codex-utils-string --lib',
    'all_original_134_package_arguments_preserved': True,
    'full_134_package_ci_run_locally_or_remotely_with_candidate': False,
    'flags_observation_scope': 'Only the recorded codex-utils-string library build and its dependency build scripts, not all 134 packages.',
    'initial_invocation_failures_preserved': ['python-contracts-01', 'cargo-flags-proof-01'],
    'standalone_workflow_change_routes_to_full_repo': True,
    'unchanged_products_locks_features_test_selection_and_failure_semantics': True,
    'sdk_deletion_or_dependency_update': False,
    'not_claimed': ['remote ENOSPC resolution', '134-package CI success', 'Fleet remote Bazel Clippy success', 'Windows boundary repair', 'security-debt resolution', 'kernel or device qualification'],
    'publication_files': [record(CANDIDATE / p, CANDIDATE) for p in ['publication/blocking-ci.yml', 'publication-manifest.json', 'PR_DESCRIPTION.md', 'change.patch']],
    'validation_summaries': [record(CANDIDATE / p, CANDIDATE) for p in ['semantic-review.json', 'validation-review.json', 'tool-manifest.json']],
    'remote_publication_status_managed_separately_by_parent': True,
})


def freeze(root, primary):
    # Packaging mechanics are retained with both raw evidence sets.
    shutil.copyfile(__file__, root / 'package-evidence.py')
    entries = []
    excluded_parts = {'.git', 'target', 'cache', 'cargo-home', 'rustup-home', 'Fleet', 'home', '__pycache__'}
    excluded_suffixes = {'.rlib', '.rmeta', '.o', '.a', '.so', '.dylib', '.exe', '.elf', '.pyc'}
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), path
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        assert not excluded_parts.intersection(relative.parts), relative
        assert path.suffix not in excluded_suffixes, relative
        data = path.read_bytes()
        if path.suffix not in {'.xz', '.zip'}:
            assert (b'oai' + b'usercontent.com') not in data, relative
        entries.append(record(path, root))
    write(root / 'files-manifest.json', {
        'schema': 1, 'member_count': len(entries), 'bytes': sum(x['bytes'] for x in entries),
        'manifest_excludes_itself': True, 'files': entries,
        'exclusions': ['all target/cache/Cargo/Rustup directories', 'native compiled artifacts', 'checkouts and Git credentials', 'transient artifact download URLs'],
        'old_frozen_packages_modified': False,
    })
    frozen = entries + [record(root / 'files-manifest.json', root)]
    frozen.sort(key=lambda x: x['path'])
    dest = root.with_name(root.name + '-package')
    temporary = dest.with_name(dest.name + '.tmp')
    assert not dest.exists() and not temporary.exists()
    temporary.mkdir()
    archive = temporary / 'raw-evidence.tar.xz'
    with tarfile.open(archive, 'w:xz', preset=6) as tar:
        for item in frozen:
            data = (root / item['path']).read_bytes()
            assert len(data) == item['bytes'] and sha(data) == item['sha256']
            info = tarfile.TarInfo(item['path'])
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            tar.addfile(info, io.BytesIO(data))
    with tarfile.open(archive, 'r:xz') as tar:
        members = tar.getmembers()
        assert [m.name for m in members] == [i['path'] for i in frozen]
        for member, expected in zip(members, frozen):
            assert member.isfile() and member.size == expected['bytes']
            assert sha(tar.extractfile(member).read()) == expected['sha256']
    for name in primary:
        target = temporary / name
        target.parent.mkdir(parents=True, exist_ok=True)
        data = (root / name).read_bytes()
        target.write_bytes(data)
        expected = next(row for row in frozen if row['path'] == name)
        assert record(target, temporary) == expected
    for item in frozen:
        assert record(root / item['path'], root) == item
    contents = [record(p, temporary) for p in sorted(temporary.rglob('*')) if p.is_file()]
    write(temporary / 'artifact-manifest.json', {
        'schema': 1, 'files': contents, 'raw_member_count': len(frozen),
        'primary_files': primary, 'raw_manifest': record(root / 'files-manifest.json', root),
        'archive_members_verified_in_order_with_size_and_sha256': True,
        'primary_bytes_match_raw_archive_entries': True,
        'archive_excludes_no_failure_receipt_or_log': True,
        'atomic_publication_after_all_verification': True,
    })
    temporary.rename(dest)
    return {'source_directory': str(root), 'package_directory': str(dest),
            'raw_members_including_manifest': len(frozen),
            'selected_files': len(entries), 'selected_bytes': sum(i['bytes'] for i in entries),
            'raw_manifest': record(root / 'files-manifest.json', root),
            'archive': record(dest / 'raw-evidence.tar.xz', dest),
            'artifact_manifest': record(dest / 'artifact-manifest.json', dest),
            'delivery_files': len(contents) + 1}


results = [
    freeze(REMOTE, ['README.md', 'final-observation.json', 'failure-analysis.json',
                    'source-and-log-records.json', 'artifacts/archive-member-review.json',
                    'artifacts/fleet-scoped-impact-12162530412.zip', 'files-manifest.json']),
    freeze(CANDIDATE, ['README.md', 'PR_DESCRIPTION.md', 'publication-manifest.json',
                       'publication/blocking-ci.yml', 'change.patch', 'final-validation.json',
                       'semantic-review.json', 'validation-review.json', 'tool-manifest.json',
                       'original-impact-plan.json', 'files-manifest.json']),
]
write(BASE / 'r10-evidence/fleet-scoped-frozen-packages.json', {
    'schema': 1, 'frozen_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'packages': results,
})
print(json.dumps(results, indent=2))
