#!/usr/bin/env python3
"""Resume archive creation after the preserved packaging scanner failure."""
import ast
import datetime
import json
from pathlib import Path
import shutil

BASE = Path('/workspace/scratch/499c7902de8e')
EVIDENCE = BASE / 'r10-evidence'
REMOTE = EVIDENCE / 'fleet-main-remote-ci'
CANDIDATE = EVIDENCE / 'hepta-scoped-disk-fix'
helper = EVIDENCE / 'freeze-fleet-scoped-evidence.py'

# Report writers already completed before the scanner rejected its own source.
# Execute only the unchanged utility/freeze definitions, never those writers.
tree = ast.parse(helper.read_text(), filename=str(helper))
definitions = [node for node in tree.body if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef))]
namespace = {
    '__file__': str(helper),
    'BASE': BASE,
    'REMOTE': REMOTE,
    'CANDIDATE': CANDIDATE,
    'SOURCE': BASE / 'r10-hepta-scoped-disk-fix',
}
exec(compile(ast.Module(body=definitions, type_ignores=[]), str(helper), 'exec'), namespace)
for root in (REMOTE, CANDIDATE):
    assert not (root / 'files-manifest.json').exists()
    assert not root.with_name(root.name + '-package').exists()
    assert not root.with_name(root.name + '-package.tmp').exists()
    shutil.copyfile(__file__, root / 'packaging-resume.py')
assert (REMOTE / 'failure-analysis.json').is_file()
assert (CANDIDATE / 'final-validation.json').is_file()

results = [
    namespace['freeze'](REMOTE, [
        'README.md', 'final-observation.json', 'failure-analysis.json',
        'source-and-log-records.json', 'artifacts/archive-member-review.json',
        'artifacts/fleet-scoped-impact-12162530412.zip', 'files-manifest.json',
    ]),
    namespace['freeze'](CANDIDATE, [
        'README.md', 'PR_DESCRIPTION.md', 'publication-manifest.json',
        'publication/blocking-ci.yml', 'change.patch', 'final-validation.json',
        'semantic-review.json', 'validation-review.json', 'tool-manifest.json',
        'original-impact-plan.json', 'files-manifest.json',
    ]),
]
namespace['write'](EVIDENCE / 'fleet-scoped-frozen-packages.json', {
    'schema': 1,
    'frozen_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'packages': results,
})
print(json.dumps(results, indent=2))
