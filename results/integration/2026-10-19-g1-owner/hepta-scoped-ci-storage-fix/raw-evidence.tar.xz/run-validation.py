#!/usr/bin/env python3
"""Record bounded host validation of the standalone CI environment candidate."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path('/workspace/scratch/499c7902de8e')
SOURCE = BASE / 'r10-hepta-scoped-disk-fix'
EVIDENCE = BASE / 'r10-evidence/hepta-scoped-disk-fix'
COMMIT = '71d9db8fd48a317fe5930392799522f186188d6a'
TOOLS = BASE / 'r10-fleet-fixture-tools'
RUST = BASE / 'r10-cargo-deny-tools/rustup-home/toolchains/1.95.0-x86_64-unknown-linux-gnu'
TARGET = BASE / 'r10-hepta-scoped-disk-target'
INPUTS = [
    'AGENTS.md', '.github/workflows/blocking-ci.yml',
    '.github/workflows/hepta-consolidated-source.yml',
    '.github/workflows/hepta-inference-maintenance.yml',
    'scripts/hepta_ci_scope.py', 'scripts/hepta_ci_dependencies.py',
    'scripts/hepta_ci_exec.py', 'scripts/run-nextest.py', 'scripts/format.py',
    'scripts/test_run_nextest.py', 'scripts/test_hepta_ci_exec.py',
    'scripts/test_hepta_ci_exec_output.py', 'scripts/test_hepta_ci_exec_deadline.py',
    'scripts/tests/test_hepta_ci_scope.py', 'scripts/tests/test_hepta_ci_dependencies.py',
    'codex-rs/Cargo.toml', 'codex-rs/Cargo.lock', 'codex-rs/.cargo/config.toml',
    'codex-rs/.config/nextest.toml', 'codex-rs/deny.toml', 'justfile',
    'codex-rs/utils/string/Cargo.toml',
]


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args]).decode().strip()


def state():
    names = sorted(set(INPUTS) | {
        p.relative_to(SOURCE).as_posix()
        for p in (SOURCE / 'codex-rs/utils/string/src').rglob('*.rs')
    })
    entries = []
    for name in names:
        data = (SOURCE / name).read_bytes()
        assert data == subprocess.check_output(['git', '-C', str(SOURCE), 'show', 'HEAD:' + name])
        entries.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    result = {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
              'parents': git('show', '-s', '--format=%P', 'HEAD').split(),
              'status_porcelain': git('status', '--porcelain=v1', '--untracked-files=all'),
              'files': entries}
    assert result['commit'] == COMMIT and not result['status_porcelain']
    return result


name, directory, *argv = sys.argv[1:]
out = EVIDENCE / name
out.mkdir(parents=True)
temporary = BASE / 'r10-hepta-scoped-disk-tmp'
temporary.mkdir(exist_ok=True)
env = os.environ.copy()
overrides = {
    'PATH': str(TOOLS / 'bin') + ':' + env.get('PATH', ''),
    'RUSTC': str(RUST / 'bin/rustc'), 'RUSTDOC': str(RUST / 'bin/rustdoc'),
    'CARGO_HOME': str(TOOLS / 'cargo-home'), 'CARGO_TARGET_DIR': str(TARGET),
    'CARGO_INCREMENTAL': '0', 'CARGO_BUILD_JOBS': '2',
    'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_NET_OFFLINE': 'true', 'CARGO_TERM_COLOR': 'never',
    'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': str(temporary),
}
env.update(overrides)
before = state()
receipt = {'schema': 1, 'name': name, 'argv': argv, 'cwd': str(SOURCE / directory),
           'started_at': utc(), 'environment_overrides': overrides, 'source_before': before,
           'scope': 'Host contract validation and at most the existing codex-utils-string library tests for Cargo flag observation; no 134-package rebuild or CI qualification.'}
with (out / 'command.log').open('wb') as log:
    result = subprocess.run(argv, cwd=SOURCE / directory, env=env,
                            stdout=log, stderr=subprocess.STDOUT)
receipt['completed_at'] = utc()
receipt['exit_code'] = result.returncode
receipt['source_after'] = state()
receipt['source_unchanged'] = before == receipt['source_after']
data = (out / 'command.log').read_bytes()
receipt['log'] = {'path': 'command.log', 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'name': name, 'started_at': receipt['started_at'],
                  'completed_at': receipt['completed_at'], 'exit_code': result.returncode,
                  'source_unchanged': receipt['source_unchanged'], 'receipt': str(out / 'receipt.json'),
                  'log_tail': [line[:1000] for line in data.decode(errors='replace').splitlines()[-12:]]}, indent=2))
raise SystemExit(result.returncode)
