#!/usr/bin/env python3
"""Execute the specified existing G0 Rust gates, without kernel/device work."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

OUT = Path('/workspace/scratch/499c7902de8e/r10-evidence/g1-ci-correction-host')
SOURCE = Path('/workspace/scratch/499c7902de8e/r10-g1-host-contract-fix')
manifest = {'abi': 'libs/os-abi/Cargo.toml', 'control': 'libs/os-control/Cargo.toml'}
commands = []
for crate in ('abi', 'control'):
    common = ['--manifest-path', manifest[crate]]
    commands.extend([
        (f'g0-{crate}-fmt', ['cargo', 'fmt', *common, '--', '--check']),
        (f'g0-{crate}-test', ['cargo', 'test', *common, '--locked', '--offline', '--verbose']),
        (f'g0-{crate}-clippy', ['cargo', 'clippy', *common, '--locked', '--offline',
                               '--all-targets', '--', '-D', 'warnings']),
    ])
portable = ['--manifest-path', manifest['control'], '--locked', '--offline',
            '--no-default-features', '--features', 'portable-spin']
commands.extend([
    ('g0-portable-test', ['cargo', 'test', *portable, '--verbose']),
    ('g0-portable-clippy', ['cargo', 'clippy', *portable, '--all-targets', '--', '-D', 'warnings']),
    ('g0-portable-rlib', ['cargo', 'build', *portable, '--lib',
                          '--target', 'x86_64-unknown-none', '--verbose']),
])
result = {'schema': 1, 'started_at': datetime.now(timezone.utc).isoformat(),
          'expected_commit': 'bc778b6b8114e5017a467c0566f5777d85abafaf',
          'expected_tree': '0218fa196b3ebb7a3f91c77906ab4ce30a67afe8',
          'plan': [{'name': name, 'argv': argv} for name, argv in commands],
          'commands': [], 'passed': False}
for name, argv in commands:
    process = subprocess.run([sys.executable, '-B', str(OUT / 'host-command.py'),
                              name, str(SOURCE), *argv])
    result['commands'].append({'name': name, 'exit_code': process.returncode})
    if process.returncode:
        result['first_failure'] = name
        break
result['completed_at'] = datetime.now(timezone.utc).isoformat()
result['passed'] = len(result['commands']) == len(commands) and all(
    row['exit_code'] == 0 for row in result['commands'])
with (OUT / 'g0-execution.json').open('x') as handle:
    handle.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': result['passed'], 'commands_executed': len(result['commands']),
                  'planned': len(commands), 'receipt': str(OUT / 'g0-execution.json')}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
