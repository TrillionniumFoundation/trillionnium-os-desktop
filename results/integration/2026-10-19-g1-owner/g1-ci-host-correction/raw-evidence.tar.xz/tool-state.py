#!/usr/bin/env python3
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

OUT = Path('/workspace/scratch/499c7902de8e/r10-evidence/g1-ci-correction-host')
commands = []
for argv in [['rustup', 'component', 'list', '--installed'], ['rustc', '-Vv'], ['cargo', '-Vv']]:
    result = subprocess.run(argv, capture_output=True, text=True)
    commands.append({'argv': argv, 'exit_code': result.returncode,
                     'stdout': result.stdout, 'stderr': result.stderr})
paths = []
for name in ['rustc', 'cargo', 'rustfmt', 'clippy-driver']:
    result = subprocess.run(['rustup', 'which', name], capture_output=True, text=True)
    if result.returncode == 0:
        paths.append(Path(result.stdout.strip()))
osdk = shutil.which('cargo-osdk')
if osdk:
    paths.append(Path(osdk))
files = []
for path in paths:
    data = path.read_bytes()
    files.append({'path': str(path), 'resolved_path': str(path.resolve()),
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
value = {'schema': 1, 'observed_at': datetime.now(timezone.utc).isoformat(),
         'rustup_toolchain': os.environ.get('RUSTUP_TOOLCHAIN'),
         'commands': commands, 'files': files}
with (OUT / sys.argv[1]).open('x') as handle:
    handle.write(json.dumps(value, indent=2) + '\n')
print(json.dumps({'record': sys.argv[1], 'toolchain': value['rustup_toolchain'],
                  'files': len(files), 'component_list': commands[0]['stdout']}))
