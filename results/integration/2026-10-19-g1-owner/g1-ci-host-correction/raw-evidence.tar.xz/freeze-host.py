#!/usr/bin/env python3
"""Verify saved host receipts and freeze evidence; no tests or builds run here."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tomllib

ROOT = Path('/workspace/scratch/499c7902de8e')
OUT = ROOT / 'r10-evidence/g1-ci-correction-host'
SOURCE = ROOT / 'r10-g1-host-contract-fix'
BASE = '4e077aef4913179a68aa0d814018ce1a9d87cafc'
INITIAL = 'bc778b6b8114e5017a467c0566f5777d85abafaf'
FINAL = 'bccb817e0d3f1987f59c1b9e7d94e939d2e6d1d3'
TREE = '65ddb50cd303f3c43a8226141c5298dca369db5d'


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def record(path, base=OUT):
    data = path.read_bytes()
    return {'path': path.relative_to(base).as_posix(), 'bytes': len(data), 'sha256': sha(data)}


def write(name, value):
    with (OUT / name).open('x', encoding='utf-8') as handle:
        handle.write(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args])


started = now()
assert git('rev-parse', 'HEAD').decode().strip() == FINAL
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
assert not git('status', '--porcelain=v1', '--untracked-files=all')
assert not (SOURCE / 'libs/os-abi/Cargo.lock').exists()
assert (SOURCE / 'README.md').read_bytes() == b''
changed = git('diff', '--name-only', BASE, FINAL).decode().splitlines()
assert changed == ['tests/control/lock_alloc/run-checks.py', 'tests/control/loom/Cargo.toml',
                   'tests/spec/test_a01_ktest_lock_preflight.py',
                   'tests/spec/test_a06_kernel_output_contract.py']
assert git('diff', '--name-only', INITIAL, FINAL).decode().splitlines() == [changed[0]]
with (OUT / 'reviewed-source.diff').open('xb') as handle:
    handle.write(git('diff', '--binary', BASE, FINAL))
git('diff', '--check', BASE, FINAL)

all_receipts = []
for path in sorted(OUT.rglob('receipt.json')):
    receipt = json.loads(path.read_text())
    assert record(path.parent / receipt['log']['path'], path.parent) == receipt['log']
    all_receipts.append({'receipt': record(path), 'name': receipt['name'],
                         'exit_code': receipt['exit_code'],
                         'started_at': receipt['started_at'], 'completed_at': receipt['completed_at'],
                         'source_commit': (receipt['source_after'] or {}).get('commit'),
                         'source_unchanged': receipt['source_unchanged']})

g0_names = ['g0-abi-fmt', 'g0-abi-test-02', 'g0-abi-clippy', 'g0-control-fmt',
            'g0-control-test', 'g0-control-clippy', 'g0-portable-test',
            'g0-portable-clippy', 'g0-portable-rlib']
passed_names = g0_names + ['loom-models-01', 'lock-alloc-02']
source_inputs = None
for name in passed_names:
    receipt = json.loads((OUT / name / 'receipt.json').read_text())
    assert receipt['exit_code'] == 0 and receipt['source_unchanged']
    if name == 'g0-abi-fmt':
        assert receipt['source_before']['commit'] == INITIAL
        assert not git('diff', INITIAL, FINAL, '--', 'libs/os-abi', 'tests/abi', 'tests/golden')
    else:
        assert receipt['source_before']['commit'] == FINAL
        assert receipt['source_before']['tree'] == TREE
        current_inputs = receipt['source_after']['inputs']
        if source_inputs is None:
            source_inputs = current_inputs
        assert current_inputs == source_inputs
assert source_inputs
for row in source_inputs:
    assert record(SOURCE / row['path'], SOURCE) == row
write('source-inputs.json', {'schema': 1, 'commit': FINAL, 'tree': TREE,
      'recorded_at': now(), 'inputs': source_inputs,
      'inputs_sha256': sha(json.dumps(source_inputs, sort_keys=True, separators=(',', ':')).encode()),
      'all_tested_final_head_inputs_identical': True,
      'prior_abi_format_reused': {'receipt': 'g0-abi-fmt/receipt.json', 'source_commit': INITIAL,
                                  'complete_tree_delta_to_final': ['tests/control/lock_alloc/run-checks.py'],
                                  'all_abi_format_inputs_unchanged': True}})

counts = {}
for name, expected in [('g0-abi-test-02', 78), ('g0-control-test', 225), ('g0-portable-test', 225)]:
    text = (OUT / name / 'command.log').read_text()
    rows = [list(map(int, match)) for match in re.findall(
        r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', text)]
    assert sum(row[0] for row in rows) == expected
    assert all(row[1:] == [0, 0, 0, 0] for row in rows)
    counts[name] = {'passed': expected, 'failed': 0, 'ignored': 0, 'filtered': 0,
                    'summary_rows': rows, 'log': record(OUT / name / 'command.log')}
for name in ['g0-abi-test-02', 'g0-abi-clippy']:
    generated = json.loads((OUT / name / 'cargo-execution.json').read_text())
    assert generated['exit_code'] == 0 and generated['generated_lock_removed_from_checkout']
    assert generated['generated_lock']['packages'] == [{'name': 'hos2-os-abi', 'version': '0.1.0'}]
    assert record(OUT / name / 'generated-Cargo.lock', OUT / name) == {
        key: generated['generated_lock'][key] for key in ['path', 'bytes', 'sha256']}

loom = json.loads((OUT / 'loom-output-01/results.json').read_text())
assert loom['exit_code'] == 0 and loom['source_unchanged'] and loom['source_inventory_unchanged']
assert loom['requested_variant'] == 'all'
assert set(loom['variants']) == {'default_shim', 'public_backend'}
assert len(loom['variants']['default_shim']['models']) == 13
assert len(loom['variants']['public_backend']['models']) == 6
assert all(isinstance(v, int) and v > 0 for v in loom['models'].values())
assert all(command['exit_code'] == 0 for command in loom['commands'])
assert loom['variants']['default_shim']['source_overrides'] == ['src/sync.rs']
assert loom['variants']['public_backend']['source_overrides'] == []
for name, expected in loom['source_hashes'].items():
    assert sha((SOURCE / name).read_bytes()) == expected
for variant, data in loom['variants'].items():
    for name, expected in data['copied_source_hashes'].items():
        path = SOURCE / ('tests/control/loom/sync.rs' if variant == 'default_shim' and name == 'sync.rs'
                         else 'libs/os-control/src/' + name)
        assert sha(path.read_bytes()) == expected

allocator = json.loads((OUT / 'lock-alloc-output-02/execution.json').read_text())
assert allocator['passed'] and allocator['current_check_executed'] and allocator['result'] == 'current_zero'
assert allocator['all_probes_used_identical_harness_bytes']
assert allocator['harness_fixtures_unchanged_during_execution']
current = allocator['probes']['current']
for flag in ['passed', 'production_sources_byte_identical', 'temporary_source_bytes_verified_after_execution',
             'worktree_source_bytes_unchanged_during_execution']:
    assert current[flag]
assert current['checks']['scenario_count'] == 19
assert all(current['checks']['summary'][field] == 0 for field in ['alloc', 'realloc', 'dealloc'])
assert current['run']['returncode'] == 0 and not current['run']['timed_out']
for name in ['build', 'format', 'clippy', 'run']:
    command = current[name]
    for stream in ['stdout', 'stderr']:
        assert sha((OUT / 'lock-alloc-output-02/current' / command[stream]).read_bytes()) == command[stream + '_sha256']
generated_manifest = tomllib.loads(current['generated_manifests']['os-control/Cargo.toml']['contents'])
assert generated_manifest['lints']['rust']['unsafe_code'] == 'forbid'
assert generated_manifest['lints']['rust']['unexpected_cfgs'] == {'level': 'warn', 'check-cfg': ['cfg(ktest)']}
assert 'ktest' not in generated_manifest['features']
for row in current['source_inventory']:
    assert record(SOURCE / 'libs/os-control/src' / row['path'], SOURCE / 'libs/os-control/src') == row
events = [json.loads(line) for line in (OUT / 'lock-alloc-output-02/current/run.stdout.log').read_text().splitlines()]
assert events == current['checks']['events']
assert len([event for event in events if event['event'] == 'scenario']) == 19
fault = next(event for event in events if event['event'] == 'failure_control')
assert fault['injected_failures'] == 2 and fault['frontier_atomic'] and fault['history_usable']

failed = json.loads((OUT / 'lock-alloc-output-01/execution.json').read_text())
assert not failed['passed'] and failed['result'] == 'failed'
assert failed['probes']['current']['clippy']['returncode'] != 0
assert 'run' not in failed['probes']['current']
assert 'unexpected `cfg` condition name: `ktest`' in (OUT / 'lock-alloc-output-01/current/clippy.stderr.log').read_text()

before = json.loads((OUT / 'toolchain-before.json').read_text())
after = json.loads((OUT / 'toolchain-after.json').read_text())
after_files = {row['path']: row for row in after['files']}
assert all(after_files[row['path']] == row for row in before['files'])
assert set(after['commands'][0]['stdout'].splitlines()) - set(before['commands'][0]['stdout'].splitlines()) == {'clippy-x86_64-unknown-linux-gnu'}
assert not (set(before['commands'][0]['stdout'].splitlines()) - set(after['commands'][0]['stdout'].splitlines()))

root_spec = ROOT / 'r10-evidence/g1-ci-correction-01'
(OUT / 'root-spec').mkdir()
for name in ['initial-validation.json', 'check-0.log', 'check-1.log']:
    (OUT / 'root-spec' / name).write_bytes((root_spec / name).read_bytes())
spec = json.loads((OUT / 'root-spec/initial-validation.json').read_text())
assert spec['source_head'] == INITIAL
for check in spec['checks']:
    assert check['exit_code'] == 0
    assert sha((OUT / 'root-spec' / check['log']).read_bytes()) == check['log_sha256']
assert 'Ran 36 tests' in (OUT / 'root-spec/check-0.log').read_text()

fleet = []
for name, expected in [('fleet-fixture-fix', 'c42b3bc1774bd150d15ea563ce8fc088dd47c23cf0b1919350d912fa495c4232'),
                       ('fleet-fixture-main-fix', '679cc06b07a26e9783ac5fde2d711383fe356763c4d6e1dac73390053d4ba868')]:
    path = ROOT / 'r10-evidence' / name
    data = (path / 'files-manifest.json').read_bytes()
    assert sha(data) == expected
    manifest = json.loads(data)
    for row in manifest['files']:
        assert record(path / row['path'], path) == row
    actual = {p.relative_to(path).as_posix() for p in path.rglob('*') if p.is_file()}
    assert actual == {row['path'] for row in manifest['files']} | {'files-manifest.json'}
    fleet.append({'directory': str(path), 'files': len(actual), 'manifest_sha256': expected,
                  'all_original_delivery_bytes_unchanged': True})

write('code-review.json', {'schema': 1, 'base': BASE, 'initial_fix': INITIAL,
      'final_fix': FINAL, 'tree': TREE, 'reviewed_paths': changed,
      'findings': [
          {'path': changed[1], 'result': 'accepted', 'reason': 'Registers cfg(ktest) as a known name at warn level; does not enable it, add an allow, or weaken -D warnings.'},
          {'path': changed[2], 'result': 'accepted_with_explicit_fixture_scope',
           'reason': 'Calls real main/original Git seed and package audits. Only Cargo execution is replaced; synthetic empty OSTD metadata is explicitly not a dependency-resolution proof. Lock mutation stops before metadata; original root lock remains unchanged.'},
          {'path': changed[3], 'result': 'accepted', 'reason': 'Separately checks the generated ELF path in hash, probe environment and artifact collection, avoiding the previous occurrence-count failure.'},
          {'path': changed[0], 'result': 'confirmed_failure_then_minimal_fix_validated',
           'reason': 'Initial copied current source failed strict Clippy at resource_state.rs:163 because the generated manifest lacked the known ktest name. Final generated manifest registers only the same known name; exact-source runtime now completes all 19 scenarios.'}],
      'unresolved_blocking_findings_within_requested_host_scope': [],
      'not_assessed_here': ['Kernel/device Cargo or QEMU execution', 'IRQ/SMP and real scheduler behavior',
                            'Desktop or mobile-device control readiness', 'Remote CI required-gate outcomes']})
write('final-validation.json', {'schema': 1, 'started_at': started, 'completed_at': now(),
      'status': 'requested_host_gates_passed',
      'source': {'commit': FINAL, 'tree': TREE, 'status_porcelain': ''},
      'reviewed_paths': changed, 'source_inputs': record(OUT / 'source-inputs.json'),
      'receipts': all_receipts, 'g0_required_operations': g0_names, 'g0_counts': counts,
      'count_scope': 'Control std and portable-spin execute overlapping cases; report each run separately.',
      'loom': {'models': len(loom['models']), 'variants': {name: {'models': len(value['models']),
                 'schedule_sum': sum(value['models'].values()), 'source_overrides': value['source_overrides']}
                 for name, value in loom['variants'].items()}, 'all_commands_passed': True,
                 'all_source_and_copy_hashes_verified': True, 'excluded': loom['excluded']},
      'allocator': {'result': 'current_zero', 'scenario_count': 19,
                    'summary': current['checks']['summary'], 'injected_failures': 2,
                    'source_and_harness_unchanged': True, 'scope': allocator['scope']},
      'retained_failures': [
          {'receipt': 'lock-alloc-01/receipt.json', 'source': INITIAL, 'kind': 'real_generated_manifest_cfg_registration_failure', 'runtime_executed': False},
          {'receipt': 'loom-fetch-01/receipt.json', 'kind': 'offline_dependency_cache_missing', 'recovery': 'fixed-lock network fetch; no dependency upgrade or lock mutation'},
          {'receipt': 'g0-abi-test/receipt.json', 'kind': 'reviewer_added_locked_flag_on_originally_lockless_crate', 'recovery': 'original workflow argument semantics; generated local-only lock archived and moved out of checkout'}],
      'root_spec': {'receipt': record(OUT / 'root-spec/initial-validation.json'), 'passed': 36,
                    'source': INITIAL, 'independently_rerun': False,
                    'scope_note': spec['root_worktree_note']},
      'tools': {'toolchain': 'nightly-2026-07-21', 'only_added_component': 'clippy',
                'previous_compiler_cargo_rustfmt_and_osdk_bytes_unchanged': True},
      'fleet_evidence': fleet,
      'limitations': ['Host validation only; portable target output is an rlib, not a kernel link or boot.',
                     'Bounded Loom schedules do not prove arbitrary histories, IRQ/SMP, Arc atomics or crash recovery.',
                     'No remote GitHub mutation, CI rerun, gate change or merge was performed.']})
assert not git('status', '--porcelain=v1', '--untracked-files=all')
files = [record(path) for path in sorted(OUT.rglob('*')) if path.is_file() and path.name != 'files-manifest.json']
write('files-manifest.json', {'schema': 1, 'created_at': now(), 'commit': FINAL, 'tree': TREE,
      'files': files, 'excluded': ['This manifest itself to avoid recursive hashing.',
                  'Build target, temporary Cargo workspaces, installed tool binaries and dependency caches.',
                  'Other frozen Fleet/security evidence packages, which remain unchanged.']})
print(json.dumps({'files': len(files) + 1, 'manifest': record(OUT / 'files-manifest.json'),
                  'validation': record(OUT / 'final-validation.json'),
                  'source_inputs': len(source_inputs), 'source': FINAL}, indent=2))
