#!/usr/bin/env python3
"""Finish the real G0 gates at the final reviewed source; retain attempt 01."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

OUT = Path('/workspace/scratch/499c7902de8e/r10-evidence/g1-ci-correction-host')
SOURCE = Path('/workspace/scratch/499c7902de8e/r10-g1-host-contract-fix')
commands = [
    ('g0-abi-test-02', [sys.executable, '-B', str(OUT / 'abi-command.py'), 'g0-abi-test-02', 'test']),
    ('g0-abi-clippy', [sys.executable, '-B', str(OUT / 'abi-command.py'), 'g0-abi-clippy', 'clippy']),
    ('g0-control-fmt', ['cargo', 'fmt', '--manifest-path', 'libs/os-control/Cargo.toml', '--', '--check']),
    ('g0-control-test', ['cargo', 'test', '--manifest-path', 'libs/os-control/Cargo.toml',
                          '--locked', '--offline', '--verbose']),
    ('g0-control-clippy', ['cargo', 'clippy', '--manifest-path', 'libs/os-control/Cargo.toml',
                            '--locked', '--offline', '--all-targets', '--', '-D', 'warnings']),
]
portable = ['--manifest-path', 'libs/os-control/Cargo.toml', '--locked', '--offline',
            '--no-default-features', '--features', 'portable-spin']
commands.extend([
    ('g0-portable-test', ['cargo', 'test', *portable, '--verbose']),
    ('g0-portable-clippy', ['cargo', 'clippy', *portable, '--all-targets', '--', '-D', 'warnings']),
    ('g0-portable-rlib', ['cargo', 'build', *portable, '--lib',
                          '--target', 'x86_64-unknown-none', '--verbose']),
])
result = {'schema': 1, 'started_at': datetime.now(timezone.utc).isoformat(),
          'expected_commit': 'bccb817e0d3f1987f59c1b9e7d94e939d2e6d1d3',
          'expected_tree': '65ddb50cd303f3c43a8226141c5298dca369db5d',
          'prior_pass_retained': 'g0-abi-fmt/receipt.json: unchanged ABI inputs at bc778b6',
          'plan': [{'name': name, 'argv': argv} for name, argv in commands],
          'commands': [], 'passed': False}
for name, argv in commands:
    process = subprocess.run([sys.executable, '-B', str(OUT / 'host-command-final.py'),
                              name, str(SOURCE), *argv])
    result['commands'].append({'name': name, 'exit_code': process.returncode})
    if process.returncode:
        result['first_failure'] = name
        break
result['completed_at'] = datetime.now(timezone.utc).isoformat()
result['passed'] = len(result['commands']) == len(commands) and all(
    row['exit_code'] == 0 for row in result['commands'])
with (OUT / 'g0-final-execution.json').open('x') as handle:
    handle.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': result['passed'], 'new_commands_executed': len(result['commands']),
                  'new_planned': len(commands), 'prior_format_pass': 1,
                  'receipt': str(OUT / 'g0-final-execution.json')}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
