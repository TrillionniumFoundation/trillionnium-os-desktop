#!/usr/bin/env python3
"""Run the original lockless ABI gate and preserve its generated local-only lock."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tomllib

ROOT = Path('/workspace/scratch/499c7902de8e')
SOURCE = ROOT / 'r10-g1-host-contract-fix'
OUT = ROOT / 'r10-evidence/g1-ci-correction-host'
stage, subcommand = sys.argv[1:]
assert subcommand in ('test', 'clippy')
lock = SOURCE / 'libs/os-abi/Cargo.lock'
assert not lock.exists(), 'Never remove or replace a pre-existing lock file'
argv = ['cargo', subcommand, '--manifest-path', 'libs/os-abi/Cargo.toml', '--offline']
argv += ['--verbose'] if subcommand == 'test' else ['--all-targets', '--', '-D', 'warnings']
receipt = {'schema': 1, 'argv': argv, 'cwd': str(SOURCE),
           'started_at': datetime.now(timezone.utc).isoformat(),
           'tracked_lock_existed_before': False,
           'reason': 'The G0 ABI workflow uses no --locked flag, and this dependency-free crate has no tracked Cargo.lock. Preserve Cargo-generated output separately.'}
process = subprocess.run(argv, cwd=SOURCE)
receipt['completed_at'] = datetime.now(timezone.utc).isoformat()
receipt['exit_code'] = process.returncode
if lock.exists():
    data = lock.read_bytes()
    parsed = tomllib.loads(data.decode())
    receipt['generated_lock'] = {'path': 'generated-Cargo.lock', 'bytes': len(data),
                                'sha256': hashlib.sha256(data).hexdigest(),
                                'packages': parsed.get('package')}
    destination = OUT / stage / 'generated-Cargo.lock'
    assert not destination.exists()
    os.rename(lock, destination)
    receipt['generated_lock_removed_from_checkout'] = not lock.exists()
    assert parsed.get('package') == [{'name': 'hos2-os-abi', 'version': '0.1.0'}], parsed
with (OUT / stage / 'cargo-execution.json').open('x') as handle:
    handle.write(json.dumps(receipt, indent=2) + '\n')
raise SystemExit(process.returncode)
