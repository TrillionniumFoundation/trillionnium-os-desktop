#!/usr/bin/env python3
"""Package immutable host evidence with ordered-member byte verification."""
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

ROOT = Path('/workspace/scratch/499c7902de8e/r10-evidence')
SOURCE = ROOT / 'g1-ci-correction-host'
STAGE = ROOT / 'g1-ci-correction-host-package.tmp'
DEST = ROOT / 'g1-ci-correction-host-package'


def record(path, base=SOURCE):
    data = path.read_bytes()
    return {'path': path.relative_to(base).as_posix(), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


started = datetime.now(timezone.utc).isoformat()
assert not STAGE.exists() and not DEST.exists()
manifest = json.loads((SOURCE / 'files-manifest.json').read_text())
entries = manifest['files'] + [record(SOURCE / 'files-manifest.json')]
entries.sort(key=lambda row: row['path'])
assert {p.relative_to(SOURCE).as_posix() for p in SOURCE.rglob('*') if p.is_file()} == {row['path'] for row in entries}
for row in entries:
    path = SOURCE / row['path']
    assert not path.is_symlink()
    assert not ({'.git', 'target', 'cache', 'cargo-home', 'rustup-home'} & set(Path(row['path']).parts))
    assert path.suffix not in ('.rlib', '.rmeta', '.o', '.elf')
    assert record(path) == row
STAGE.mkdir()
archive = STAGE / 'raw-evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as handle:
    for row in entries:
        data = (SOURCE / row['path']).read_bytes()
        info = tarfile.TarInfo(row['path'])
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        handle.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as handle:
    members = handle.getmembers()
    assert [member.name for member in members] == [row['path'] for row in entries]
    for member, row in zip(members, entries):
        assert member.isfile() and member.size == row['bytes']
        data = handle.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest() == row['sha256']
primary = ['README.md', 'final-validation.json', 'code-review.json', 'source-inputs.json',
           'reviewed-source.diff', 'g0-final-execution.json', 'loom-output-01/results.json',
           'lock-alloc-output-01/execution.json', 'lock-alloc-output-02/execution.json',
           'root-spec/initial-validation.json', 'toolchain-before.json', 'toolchain-after.json',
           'files-manifest.json']
copies = []
by_name = {row['path']: row for row in entries}
for name in primary:
    path = STAGE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((SOURCE / name).read_bytes())
    assert record(path, STAGE) == by_name[name]
    copies.append(dict(record(path, STAGE), archive_entry=name))
for row in entries:
    assert record(SOURCE / row['path']) == row
result = {'schema': 1, 'status': 'verified', 'started_at': started,
          'completed_at': datetime.now(timezone.utc).isoformat(),
          'source_commit': manifest['commit'], 'source_tree': manifest['tree'],
          'raw_entries': len(entries), 'archive': record(archive, STAGE),
          'primary_copies': copies, 'failures_retained': True,
          'ordered_member_size_sha256_verification': True, 'source_files_unchanged': True}
(STAGE / 'artifact-manifest.json').write_text(json.dumps(result, indent=2) + '\n')
os.rename(STAGE, DEST)
print(json.dumps({'directory': str(DEST), 'delivery_files': len(primary) + 2,
                  'raw_entries': len(entries), 'archive': result['archive'],
                  'artifact_manifest': record(DEST / 'artifact-manifest.json', DEST)}, indent=2))
