#!/usr/bin/env python3
"""Capture one authorized host-only gate against a fixed read-only checkout."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/499c7902de8e')
SOURCE = ROOT / 'r10-g1-host-contract-fix'
OUT = ROOT / 'r10-evidence/g1-ci-correction-host'
HEAD = 'bccb817e0d3f1987f59c1b9e7d94e939d2e6d1d3'
TREE = '65ddb50cd303f3c43a8226141c5298dca369db5d'
PATHS = ['libs/os-abi', 'libs/os-control', 'tests/abi', 'tests/golden',
         'tests/control', 'tests/spec', 'support/build/ktest',
         'support/upstream-lock.json', 'docs/agents/PLAN.md', 'README.md',
         '.github/workflows/g0-contracts.yml', '.github/workflows/a03-native-models.yml',
         '.github/workflows/a06-kernel.yml']


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args])


def state():
    if not SOURCE.exists():
        return None
    commit = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    status = git('status', '--porcelain=v1', '--untracked-files=all').decode()
    assert (commit, tree, status) == (HEAD, TREE, ''), (commit, tree, status)
    entries = []
    for name in git('ls-files', '-z', '--', *PATHS).decode().split('\0'):
        if name:
            path = SOURCE / name
            data = path.read_bytes()
            entries.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    entries.sort(key=lambda row: row['path'])
    return {'commit': commit, 'tree': tree, 'status_porcelain': status,
            'inputs': entries,
            'inputs_sha256': sha(json.dumps(entries, sort_keys=True, separators=(',', ':')).encode())}


name, cwd, *argv = sys.argv[1:]
out = OUT / name
out.mkdir(parents=True)
env = os.environ.copy()
if name != 'worktree-add':
    assert env.get('RUSTUP_TOOLCHAIN') == 'nightly-2026-07-21'
overrides = {'CARGO_TARGET_DIR': str(ROOT / 'g1-ci-correction-host-target/g0'),
             'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0',
             'CARGO_NET_OFFLINE': 'true', 'CARGO_TERM_COLOR': 'never',
             'TMPDIR': str(ROOT / 'g1-ci-correction-host-tmp')}
Path(overrides['TMPDIR']).mkdir(exist_ok=True)
env.update(overrides)
keys = ['PATH', 'CARGO_HOME', 'RUSTUP_HOME', 'RUSTUP_TOOLCHAIN', 'CARGO', 'RUSTC',
        'RUSTDOC', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER',
        'RUSTC_WORKSPACE_WRAPPER', 'CARGO_NET_GIT_FETCH_WITH_CLI',
        'OSDK_LOCAL_DEV', 'VDSO_LIBRARY_DIR', *overrides]
before = state()
receipt = {'schema': 1, 'name': name, 'argv': argv, 'cwd': cwd,
           'started_at': now(), 'source_before': before,
           'environment': {key: env.get(key) for key in dict.fromkeys(keys)},
           'scope': 'Existing G0 host/portable rlib and A03 bounded host harness gates only; no kernel or device Cargo/QEMU execution.'}
(out / 'started.json').write_text(json.dumps(receipt, indent=2) + '\n')
with (out / 'command.log').open('xb') as log:
    process = subprocess.run(argv, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
receipt['completed_at'] = now()
receipt['exit_code'] = process.returncode
receipt['source_after'] = state()
receipt['source_unchanged'] = before == receipt['source_after']
data = (out / 'command.log').read_bytes()
receipt['log'] = {'path': 'command.log', 'bytes': len(data), 'sha256': sha(data)}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'name': name, 'started_at': receipt['started_at'],
                  'completed_at': receipt['completed_at'], 'exit_code': process.returncode,
                  'source_unchanged': receipt['source_unchanged'],
                  'receipt': str(out / 'receipt.json'),
                  'tail': data.decode(errors='replace').splitlines()[-14:]}, indent=2))
raise SystemExit(process.returncode)
