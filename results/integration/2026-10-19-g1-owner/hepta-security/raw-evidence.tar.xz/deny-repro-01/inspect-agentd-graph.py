#!/usr/bin/env python3
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT=Path('/workspace/scratch/499c7902de8e')
SOURCE=ROOT/'r10-cargo-deny-repro'
TOOLS=ROOT/'r10-cargo-deny-tools'
EVIDENCE=ROOT/'r10-evidence/owner-ci/new-head/deny-repro-01'

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity():
    return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=SOURCE,text=True).strip(),'cargo_lock_sha256':hashlib.sha256((SOURCE/'codex-rs/Cargo.lock').read_bytes()).hexdigest(),'deny_policy_sha256':hashlib.sha256((SOURCE/'codex-rs/deny.toml').read_bytes()).hexdigest()}

env=os.environ.copy()
env.update({'CARGO_HOME':str(TOOLS/'cargo-home'),'RUSTUP_HOME':str(TOOLS/'rustup-home'),'RUSTUP_TOOLCHAIN':'1.95.0-x86_64-unknown-linux-gnu','PATH':str(TOOLS/'cargo-home/bin')+os.pathsep+os.environ['PATH'],'CARGO_TERM_COLOR':'never','CARGO_NET_OFFLINE':'true','RUSTUP_NO_UPDATE_CHECK':'1'})
record={'schema':1,'kind':'locked_offline_dependency_and_feature_graph_not_execution_trace','started_at':now(),'before':identity(),'commands':[],'product_build_performed':False}
for target in ['x86_64-unknown-linux-gnu','aarch64-unknown-linux-gnu']:
    name='agentd-no-default-normal-'+target
    argv=[str(TOOLS/'cargo-home/bin/rustup'),'run','1.95.0','cargo','tree','--locked','--offline','--manifest-path','./codex-rs/Cargo.toml','-p','codex-hepta-agentd','--no-default-features','--edges','normal','--target',target,'--prefix','depth','--format','{p} features=[{f}]','--charset','ascii']
    began=now()
    result=subprocess.run(argv,cwd=SOURCE,env=env,capture_output=True,timeout=60)
    out=EVIDENCE/(name+'.txt');err=EVIDENCE/(name+'.stderr.log')
    out.write_bytes(result.stdout);err.write_bytes(result.stderr)
    record['commands'].append({'argv':argv,'cwd':str(SOURCE),'started_at':began,'completed_at':now(),'exit_code':result.returncode,'target':target,'stdout':{'path':str(out),'bytes':len(result.stdout),'sha256':hashlib.sha256(result.stdout).hexdigest()},'stderr':{'path':str(err),'bytes':len(result.stderr),'sha256':hashlib.sha256(result.stderr).hexdigest()}})
    if result.returncode:break
record['after']=identity();record['source_unchanged']=record['before']==record['after'];record['completed_at']=now()
(EVIDENCE/'agentd-graph-execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'source_unchanged':record['source_unchanged'],'commands':[{'target':c['target'],'exit_code':c['exit_code'],'bytes':c['stdout']['bytes']} for c in record['commands']]}))
