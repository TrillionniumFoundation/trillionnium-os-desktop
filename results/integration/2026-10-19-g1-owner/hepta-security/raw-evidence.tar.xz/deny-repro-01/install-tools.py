#!/usr/bin/env python3
"""Install isolated official binaries for a new diagnostic; never build product code."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import tarfile
import time
import urllib.request

ROOT = Path('/workspace/scratch/499c7902de8e')
EVIDENCE = ROOT / 'r10-evidence/owner-ci/new-head/deny-repro-01'
TOOLS = ROOT / 'r10-cargo-deny-tools'
SOURCE = ROOT / 'r10-cargo-deny-repro'
LIMIT = 4_000_000_000

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def size():
    return sum(p.stat().st_size for root in [TOOLS, SOURCE] for p in root.rglob('*') if p.is_file() and not p.is_symlink())

def download(url, destination, expected=None, max_bytes=40_000_000):
    with urllib.request.urlopen(url, timeout=60) as response:
        data = response.read(max_bytes + 1)
        final_url = response.url
    if len(data) > max_bytes:
        raise RuntimeError('download size limit exceeded')
    digest = sha(data)
    if expected and digest != expected:
        raise RuntimeError('official digest mismatch')
    destination.write_bytes(data)
    record['downloads'].append({'url': url, 'final_host': urllib.request.urlparse(final_url).netloc if hasattr(urllib.request, 'urlparse') else final_url.split('/')[2], 'path': str(destination), 'bytes': len(data), 'sha256': digest, 'expected_sha256': expected})
    return data

TOOLS.mkdir(exist_ok=True)
(TOOLS / 'bin').mkdir(exist_ok=True)
(TOOLS / 'downloads').mkdir(exist_ok=True)
record = {'schema': 1, 'started_at': now(), 'status': 'running', 'budget_bytes': LIMIT, 'downloads': [], 'commands': [], 'diagnostic_only': True, 'product_build_performed': False}
try:
    archive = TOOLS / 'downloads/cargo-deny-0.19.0-x86_64-unknown-linux-musl.tar.gz'
    checksum = download('https://github.com/EmbarkStudios/cargo-deny/releases/download/0.19.0/' + archive.name + '.sha256', archive.with_suffix(archive.suffix + '.sha256'), '0ae3ac071bfd45a87d1786df23b4847929de8c6d1891d3346826107fd4632b9d').decode().strip()
    if checksum != '0e8c2aa59128612c90d9e09c02204e912f29a5b8d9a64671b94608cbe09e064f':
        raise RuntimeError('asset digest and checksum disagree')
    download('https://github.com/EmbarkStudios/cargo-deny/releases/download/0.19.0/' + archive.name, archive, checksum)
    with tarfile.open(archive) as bundle:
        candidates = [m for m in bundle.getmembers() if m.isfile() and Path(m.name).name == 'cargo-deny']
        if len(candidates) != 1:
            raise RuntimeError('ambiguous official binary member')
        member = candidates[0]
        if member.size > 100_000_000:
            raise RuntimeError('unexpected binary size')
        data = bundle.extractfile(member).read()
    binary = TOOLS / 'bin/cargo-deny'
    binary.write_bytes(data)
    binary.chmod(0o755)
    record['cargo_deny_binary'] = {'path': str(binary), 'bytes': len(data), 'sha256': sha(data)}
    rustup_version = '1.28.2'
    rustup_url = f'https://static.rust-lang.org/rustup/archive/{rustup_version}/x86_64-unknown-linux-gnu/rustup-init'
    rustup_checksum = download(rustup_url + '.sha256', TOOLS / 'downloads/rustup-init.sha256').decode().split()[0]
    if len(rustup_checksum) != 64 or any(c not in '0123456789abcdef' for c in rustup_checksum):
        raise RuntimeError('invalid official rustup checksum')
    initializer = TOOLS / 'downloads/rustup-init'
    download(rustup_url, initializer, rustup_checksum)
    initializer.chmod(0o755)
    env = os.environ.copy()
    env.update({'CARGO_HOME': str(TOOLS / 'cargo-home'), 'RUSTUP_HOME': str(TOOLS / 'rustup-home'), 'RUSTUP_INIT_SKIP_PATH_CHECK': 'yes', 'RUSTUP_NO_UPDATE_CHECK': '1'})
    argv = [str(initializer), '-y', '--no-modify-path', '--profile', 'minimal', '--default-toolchain', '1.95.0-x86_64-unknown-linux-gnu']
    command = {'argv': argv, 'started_at': now(), 'log': str(EVIDENCE / 'rustup-install.log'), 'environment_overrides': {k:env[k] for k in ['CARGO_HOME','RUSTUP_HOME','RUSTUP_INIT_SKIP_PATH_CHECK','RUSTUP_NO_UPDATE_CHECK']}}
    start = time.monotonic()
    with open(command['log'], 'wb') as log:
        proc = subprocess.Popen(argv, cwd=SOURCE, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        while proc.poll() is None:
            time.sleep(2)
            usage = size()
            if usage > LIMIT - 200_000_000 or time.monotonic() - start > 600:
                command['stop_reason'] = 'budget_or_600_second_install_bound'
                os.killpg(proc.pid, signal.SIGKILL)
                break
        command['exit_code'] = proc.wait()
    command['completed_at'] = now()
    record['commands'].append(command)
    if command['exit_code']:
        raise RuntimeError('toolchain installation failed; inspect retained log')
    for name, argv in [('cargo-deny', [str(binary), '--version']), ('rustup', [str(TOOLS/'cargo-home/bin/rustup'), '--version']), ('rustc', [str(TOOLS/'cargo-home/bin/rustup'), 'run', '1.95.0', 'rustc', '-vV']), ('cargo', [str(TOOLS/'cargo-home/bin/rustup'), 'run', '1.95.0', 'cargo', '-V'])]:
        result = subprocess.run(argv, cwd=SOURCE, env=env, capture_output=True, timeout=30)
        record.setdefault('versions', {})[name] = {'argv': argv, 'exit_code': result.returncode, 'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()}
        if result.returncode:
            raise RuntimeError('version check failed')
    record['status'] = 'installed'
except BaseException as exc:
    record['status'] = 'failed'
    record['error'] = str(exc)
    raise
finally:
    record['completed_at'] = now()
    record['local_bytes_including_source'] = size()
    (EVIDENCE / 'tools-installation.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'status': record['status'], 'local_bytes_including_source': record['local_bytes_including_source'], 'receipt': str(EVIDENCE/'tools-installation.json')}), flush=True)
