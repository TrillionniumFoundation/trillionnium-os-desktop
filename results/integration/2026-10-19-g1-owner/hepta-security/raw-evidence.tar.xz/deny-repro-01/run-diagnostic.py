#!/usr/bin/env python3
"""New locked dependency-check diagnostic; does not recover an original CI log."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path('/workspace/scratch/499c7902de8e')
EVIDENCE = ROOT / 'r10-evidence/owner-ci/new-head/deny-repro-01'
SOURCE = ROOT / 'r10-cargo-deny-repro'
TOOLS = ROOT / 'r10-cargo-deny-tools'
EXPECTED_HEAD = '1b0fedb8c2b510106848f6feaf530c9b3698399d'
EXPECTED_TREE = 'a3e718280a7e17b8c4a226a0232bf18c23fd3586'
REMOTE_HEAD = 'd32e795f0d24df89fc57745f6fae70fbd0642eba'
LIMIT = 4_000_000_000

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def file_record(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def git(*args, cwd=SOURCE):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()

def identity():
    paths = ['codex-rs/Cargo.lock', 'codex-rs/Cargo.toml', 'codex-rs/deny.toml', '.github/workflows/cargo-deny.yml', '.github/workflows/blocking-ci.yml']
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status_porcelain': git('status', '--porcelain', '--untracked-files=all'), 'files': [file_record(SOURCE/p) for p in paths]}

def usage():
    return sum(p.stat().st_size for root in [TOOLS, SOURCE, EVIDENCE] for p in root.rglob('*') if p.is_file() and not p.is_symlink())

env = os.environ.copy()
env.update({'CARGO_HOME': str(TOOLS/'cargo-home'), 'RUSTUP_HOME': str(TOOLS/'rustup-home'), 'RUSTUP_TOOLCHAIN': '1.95.0-x86_64-unknown-linux-gnu', 'PATH': str(TOOLS/'cargo-home/bin') + os.pathsep + str(TOOLS/'bin') + os.pathsep + os.environ['PATH'], 'CARGO_NET_GIT_FETCH_WITH_CLI': 'false', 'CARGO_TERM_COLOR': 'always', 'RUSTUP_NO_UPDATE_CHECK': '1'})
record = {'schema': 1, 'kind': 'new_local_diagnostic_not_original_job_log', 'remote_head': REMOTE_HEAD, 'local_equivalent_commit': EXPECTED_HEAD, 'expected_tree': EXPECTED_TREE, 'original_run_id': 39185139893, 'original_job_id': 117846024659, 'started_at': now(), 'status': 'running', 'budget_bytes': LIMIT, 'environment_overrides': {k: env[k] for k in ['CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','CARGO_NET_GIT_FETCH_WITH_CLI','CARGO_TERM_COLOR','RUSTUP_NO_UPDATE_CHECK']}, 'differences_from_original_action': ['Host GNU Linux rather than the pinned Alpine/musl container', 'Explicit --locked asserts an unchanged lockfile; same action --all-features/check selection', 'New execution time and freshly fetched remote registry/advisory state', 'No optional Git credentials or SSH inputs; no CI setup action or container'], 'commands': [], 'product_build_performed': False}

def run(name, argv, timeout=600, stdout_name=None):
    command = {'name': name, 'argv': argv, 'cwd': str(SOURCE), 'started_at': now(), 'timeout_seconds': timeout, 'before': identity()}
    stdout = EVIDENCE/(stdout_name or f'{name}.log')
    stderr = EVIDENCE/f'{name}.stderr.log' if stdout_name else stdout
    started = time.monotonic()
    with stdout.open('wb') as output:
        err = stderr.open('wb') if stderr != stdout else output
        try:
            proc = subprocess.Popen(argv, cwd=SOURCE, env=env, stdout=output, stderr=err, start_new_session=True)
            while proc.poll() is None:
                time.sleep(2)
                current = usage()
                if current > LIMIT - 200_000_000:
                    command['stop_reason'] = 'dedicated_4GB_budget_margin'
                    os.killpg(proc.pid, signal.SIGKILL)
                    break
                if stdout.stat().st_size > 128_000_000 or stderr.stat().st_size > 128_000_000:
                    command['stop_reason'] = 'diagnostic_log_limit'
                    os.killpg(proc.pid, signal.SIGKILL)
                    break
                if time.monotonic() - started > timeout:
                    command['stop_reason'] = 'bounded_diagnostic_timeout'
                    os.killpg(proc.pid, signal.SIGKILL)
                    break
            command['exit_code'] = proc.wait()
        finally:
            if err is not output:
                err.close()
    command.update({'completed_at': now(), 'elapsed_seconds': time.monotonic() - started, 'stdout': file_record(stdout), 'stderr': file_record(stderr), 'after': identity(), 'local_bytes': usage()})
    command['source_unchanged'] = command['before'] == command['after']
    record['commands'].append(command)
    (EVIDENCE/'execution-progress.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'name': name, 'exit_code': command['exit_code'], 'source_unchanged': command['source_unchanged'], 'local_bytes': command['local_bytes'], 'completed_at': command['completed_at']}), flush=True)
    if not command['source_unchanged']:
        raise RuntimeError('source identity changed; stop diagnostic')
    return command

try:
    record['source_before'] = identity()
    if record['source_before']['commit'] != EXPECTED_HEAD or record['source_before']['tree'] != EXPECTED_TREE or record['source_before']['status_porcelain']:
        raise RuntimeError('expected clean source identity not present')
    meta = run('locked-metadata', [str(TOOLS/'cargo-home/bin/rustup'), 'run', '1.95.0', 'cargo', 'metadata', '--format-version', '1', '--locked', '--all-features', '--manifest-path', './codex-rs/Cargo.toml'], stdout_name='locked-metadata.json')
    if meta['exit_code']:
        record['status'] = 'metadata_failed'
    else:
        deny = run('cargo-deny', [str(TOOLS/'bin/cargo-deny'), '--log-level', 'warn', '--manifest-path', './codex-rs/Cargo.toml', '--all-features', '--locked', 'check'])
        record['status'] = 'deny_success' if deny['exit_code'] == 0 else 'deny_failed'
    record['advisory_databases'] = []
    dbroot = TOOLS/'cargo-home/advisory-dbs'
    if dbroot.exists():
        for database in dbroot.iterdir():
            if (database/'.git').exists():
                record['advisory_databases'].append({'path': str(database), 'commit': git('rev-parse','HEAD',cwd=database), 'tree': git('rev-parse','HEAD^{tree}',cwd=database)})
except BaseException as exc:
    record['status'] = 'exception'
    record['error'] = str(exc)
    raise
finally:
    record['source_after'] = identity()
    record['source_unchanged'] = record.get('source_before') == record['source_after']
    record['completed_at'] = now()
    record['local_bytes'] = usage()
    (EVIDENCE/'execution.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'status': record['status'], 'completed_at': record['completed_at'], 'source_unchanged': record['source_unchanged'], 'receipt': str(EVIDENCE/'execution.json')}), flush=True)
