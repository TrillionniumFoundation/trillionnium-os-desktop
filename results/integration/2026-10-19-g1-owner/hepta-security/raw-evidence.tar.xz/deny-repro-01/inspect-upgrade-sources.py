#!/usr/bin/env python3
"""Fetch small official metadata/source archives only; do not resolve or install upgrades."""
from pathlib import Path
import datetime,hashlib,json,tarfile,urllib.request

ROOT=Path('/workspace/scratch/499c7902de8e')
OUT=ROOT/'r10-evidence/owner-ci/new-head/deny-repro-01/upstream-sources'
OUT.mkdir(exist_ok=True)
record={'schema':1,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'read_only_upstream_metadata_and_source_inspection','downloads':[],'selected_registry_entries':{},'source_files':[],'dependencies_modified':False,'product_build_performed':False}
def digest(data):return hashlib.sha256(data).hexdigest()
def fetch(url,path,max_bytes=8_000_000):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    req=urllib.request.Request(url,headers={'User-Agent':'Hepta-CI-dependency-audit/1.0'})
    with urllib.request.urlopen(req,timeout=45) as r:data=r.read(max_bytes+1)
    if len(data)>max_bytes:raise RuntimeError('metadata/source size cap')
    path.write_bytes(data)
    record['downloads'].append({'url':url,'path':str(path),'bytes':len(data),'sha256':digest(data),'started_at':started,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    return data
names=['matrix-sdk','matrix-sdk-crypto','matrix-sdk-sqlite','anymap3','serde-saphyr','keyring','keyring-core','zbus-secret-service-keyring-store','dbus-secret-service-keyring-store','secret-service','zbus','zip','rustls']
try:
    for name in names:
        shard=('1/'+name if len(name)==1 else '2/'+name if len(name)==2 else '3/'+name[0]+'/'+name if len(name)==3 else name[:2]+'/'+name[2:4]+'/'+name)
        data=fetch('https://index.crates.io/'+shard,OUT/(name+'-index.jsonl'))
        rows=[json.loads(line) for line in data.splitlines()]
        stable=[r for r in rows if not r.get('yanked') and '-' not in r['vers']]
        stable.sort(key=lambda r:tuple(map(int,r['vers'].split('.'))))
        selected=stable[-2:]
        for exact in {'matrix-sdk':'0.19.0','matrix-sdk-crypto':'0.19.0','zip':'9.0.0','rustls':'0.23.46'}.get(name,'').split():
            match=next((r for r in rows if r['vers']==exact),None)
            if match and match not in selected:selected.append(match)
        record['selected_registry_entries'][name]=selected
    for name,version in [('matrix-sdk','0.19.1'),('zip','9.0.5'),('keyring','4.2.0')]:
        selected=next(r for r in record['selected_registry_entries'][name] if r['vers']==version)
        archive=OUT/(name+'-'+version+'.crate')
        data=fetch(f'https://static.crates.io/crates/{name}/{name}-{version}.crate',archive)
        if digest(data)!=selected['cksum']:raise RuntimeError('crate checksum mismatch')
        with tarfile.open(archive) as tar:
            wanted={'Cargo.toml','Cargo.toml.orig','README.md','CHANGELOG.md','CHANGELOG','src/lib.rs','src/read.rs'}
            for member in tar.getmembers():
                if not member.isfile():continue
                pieces=Path(member.name).parts
                relative='/'.join(pieces[1:])
                if relative not in wanted:continue
                if member.size>3_000_000:raise RuntimeError('source member cap')
                content=tar.extractfile(member).read()
                destination=OUT/(name+'-'+version+'-'+relative.replace('/','__'))
                destination.write_bytes(content)
                record['source_files'].append({'crate':name,'version':version,'member':member.name,'path':str(destination),'bytes':len(content),'sha256':digest(content),'archive_sha256':digest(data)})
    record['status']='inspected'
except BaseException as exc:
    record['status']='failed';record['error']=str(exc);raise
finally:
    record['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'status':record['status'],'metadata_crates':len(record['selected_registry_entries']),'source_files':len(record['source_files'])}),flush=True)
