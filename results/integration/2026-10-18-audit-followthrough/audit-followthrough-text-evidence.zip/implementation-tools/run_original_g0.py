#!/usr/bin/env python3
"""Execute unmodified G0 run blocks and bind narrowly reused local evidence."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

import yaml


ROOT = Path('/workspace/scratch/499c7902de8e')
REPO = ROOT / 'implementation-integration'
OUT = ROOT / 'implementation-g0-evidence'
BASE = '3551e1e0e017e2973da7e2b8ab811ece25c258c0'
HEAD = 'a0adc97b35264510fb2056bed93d46c155ffe5ff'
TREE = '2f391cae63211e7d607d188205cf91b997077b3e'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def input_match(mapping):
    records = []
    for name, expected in mapping.items():
        path = REPO / name
        actual = sha(path.read_bytes()) if path.is_file() and not path.is_symlink() else None
        records.append({'path': name, 'expected_sha256': expected,
                        'actual_sha256': actual, 'matched': actual == expected})
    return {'matched': all(x['matched'] for x in records), 'files': records}


def rust_counts(text):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text)
    return {key: sum(int(row[i]) for row in rows)
            for i, key in enumerate(('passed', 'failed', 'ignored', 'measured', 'filtered'))}


def main():
    if git('rev-parse', 'HEAD') != HEAD or git('rev-parse', 'HEAD^{tree}') != TREE:
        raise RuntimeError('unexpected integration checkout')
    if git('status', '--porcelain', '--untracked-files=no'):
        raise RuntimeError('tracked input modifications at start')
    git('cat-file', '-e', BASE + '^{commit}')
    OUT.mkdir()
    for name in ('steps', 'logs', 'reused', 'runner-temp'):
        (OUT / name).mkdir()
    workflow_path = REPO / '.github/workflows/g0-contracts.yml'
    workflow_bytes = workflow_path.read_bytes()
    workflow = yaml.safe_load(workflow_bytes)
    (OUT / 'g0-contracts.yml').write_bytes(workflow_bytes)
    before_pyc = set((REPO / 'tests').rglob('*.pyc'))
    before_cache_dirs = set((REPO / 'tests').rglob('__pycache__'))
    env = os.environ.copy()
    env.update({
        'RUSTUP_HOME': str(ROOT / 'implementation-tools/rustup'),
        'CARGO_HOME': str(ROOT / 'implementation-tools/cargo'),
        'PATH': str(ROOT / 'implementation-tools/cargo/bin') + os.pathsep + env['PATH'],
        'RUSTUP_TOOLCHAIN': '1.99.0',
        'EVENT_BASE_SHA': BASE,
        'RUNNER_TEMP': str(OUT / 'runner-temp'),
        'PYTHONDONTWRITEBYTECODE': '1',
    })
    report = {
        'schema': 'local-g0-original-workflow-v1',
        'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'repo': str(REPO), 'head': HEAD, 'tree': TREE, 'event_base': BASE,
        'workflow_sha256': sha(workflow_bytes),
        'scope': 'Local host execution plus explicitly reused same-input evidence; not a GitHub Actions run, kernel guest execution or native-device qualification.',
        'execution_toolchain': '1.99.0', 'steps': [], 'success': False,
    }

    def save():
        (OUT / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')

    a02_path = ROOT / 'implementation-a02-acceptance/report.json'
    a02 = json.loads(a02_path.read_text())
    a02_match = input_match(a02['input_sha256'])
    if not (a02.get('success') is True and a02.get('original_inputs_unchanged') is True
            and a02.get('not_executed') == [] and a02_match['matched']):
        raise RuntimeError('A02 reuse lacks successful identical inputs')
    shutil.copyfile(a02_path, OUT / 'reused/a02-report.json')
    report['a02_reuse_input_match'] = a02_match
    a02_checks = {c['name']: c for c in a02['checks']}
    reuse = {
        'Host Rust no_std ABI crate': {
            'record': 'reused/a02-report.json', 'checks': ['rust'],
            'toolchain': a02['toolchain'],
            'equivalence': 'Same ABI files, fixtures and tests; cargo test adds --offline and omits diagnostic --verbose. Original workflow has no fixed Rust version.',
        },
        'Host Rust ABI strict rustfmt and Clippy': {
            'record': 'reused/a02-report.json', 'checks': ['rustfmt', 'clippy'],
            'toolchain': a02['toolchain'],
            'equivalence': 'Same ABI inputs; fmt --check and clippy --all-targets -D warnings match the workflow; Clippy adds --offline.',
        },
    }
    for value in reuse.values():
        for name in value['checks']:
            if a02_checks[name].get('passed') is not True or a02_checks[name].get('returncode') != 0:
                raise RuntimeError('nonpassing reused ABI check ' + name)
    std_path = ROOT / 'implementation-tools/integration-control.log'
    std_text = std_path.read_text()
    std_counts = rust_counts(std_text)
    if std_counts != {'passed': 225, 'failed': 0, 'ignored': 0, 'measured': 0, 'filtered': 0}:
        raise RuntimeError('unexpected previously executed integrated std test counts')
    shutil.copyfile(std_path, OUT / 'reused/integration-control.log')
    reuse['Host Rust control model'] = {
        'record': 'reused/integration-control.log', 'sha256': sha(std_path.read_bytes()),
        'test_counts': std_counts, 'toolchain': '1.99.0',
        'binding': 'Root previously executed this log on this exact integration checkout/tree and explicitly authorized reuse; the raw cargo log itself does not encode a Git SHA.',
    }

    loom_path = ROOT / 'implementation-receipt-evidence/loom/results.json'
    loom = json.loads(loom_path.read_text())
    loom_match = input_match(loom['source_hashes'])
    alloc_path = ROOT / 'implementation-receipt-evidence/lock-alloc/execution.json'
    alloc = json.loads(alloc_path.read_text())
    current = alloc['probes']['current']
    alloc_mapping = {'libs/os-control/src/' + row['path']: row['sha256']
                     for row in current['source_inventory']}
    alloc_mapping.update({'tests/control/lock_alloc/' + row['path']: row['sha256']
                          for row in alloc['fixtures']})
    alloc_match = input_match(alloc_mapping)
    if not (loom_match['matched'] and loom['exit_code'] == 0 and loom['source_unchanged']
            and alloc_match['matched'] and alloc['passed']
            and alloc['result'] == 'current_zero' and alloc['current_check_executed']):
        raise RuntimeError('A03 supplemental evidence no longer matches integration inputs')
    shutil.copyfile(loom_path, OUT / 'reused/loom-results.json')
    shutil.copyfile(alloc_path, OUT / 'reused/lock-alloc-execution.json')
    report['supplemental_a03'] = {
        'scope': 'Original A03 gates reused by input hashes; not rerun and not separate G0 steps.',
        'loom': {'record': 'reused/loom-results.json', 'input_match': loom_match,
                 'models': len(loom['models']), 'schedules': sum(loom['models'].values())},
        'lock_alloc': {'record': 'reused/lock-alloc-execution.json', 'input_match': alloc_match,
                       'scenarios': current['checks']['scenario_count'],
                       'summary': current['checks']['summary']},
    }
    save()

    for index, step in enumerate(workflow['jobs']['host-contracts']['steps']):
        if 'run' not in step:
            continue
        name = step['name']
        run = step['run']
        script = OUT / 'steps' / f'{index:02d}.sh'
        script.write_text(run)
        row = {'workflow_step_index': index, 'name': name,
               'original_run_sha256': sha(run.encode()), 'script': str(script.relative_to(OUT))}
        if step.get('if'):
            if step['if'] != "hashFiles('tests/kernel/control/queryabi_guest.c') != ''":
                raise RuntimeError('unsupported workflow conditional')
            enabled = (REPO / 'tests/kernel/control/queryabi_guest.c').is_file()
            row['condition'] = {'expression': step['if'], 'result': enabled}
            if not enabled:
                raise RuntimeError('expected guest probe is absent')
        if name in reuse:
            row.update({'status': 'passed_reused', 'evidence': reuse[name]})
            report['steps'].append(row)
            print(json.dumps({'step': index, 'status': row['status'], 'name': name}), flush=True)
            save()
            continue
        argv = (['bash', '--noprofile', '--norc', '-e', '-o', 'pipefail']
                if step.get('shell') == 'bash' else ['bash', '-e']) + [str(script)]
        row.update({'status': 'running', 'argv': argv, 'cwd': str(REPO)})
        report['steps'].append(row)
        save()
        print(json.dumps({'step': index, 'status': 'running', 'name': name}), flush=True)
        started = time.monotonic()
        log = OUT / 'logs' / f'{index:02d}.log'
        try:
            with log.open('wb') as output:
                result = subprocess.run(argv, cwd=REPO, env=env, stdout=output,
                                        stderr=subprocess.STDOUT, timeout=600)
            row['returncode'] = result.returncode
            row['timed_out'] = False
            row['status'] = 'passed_executed' if result.returncode == 0 else 'failed'
        except subprocess.TimeoutExpired:
            row.update({'returncode': None, 'timed_out': True, 'status': 'failed'})
        row.update({'elapsed_seconds': round(time.monotonic() - started, 3),
                    'log': str(log.relative_to(OUT)), 'log_sha256': sha(log.read_bytes())})
        text = log.read_text(errors='replace')
        row['python_suite_counts'] = [int(x) for x in re.findall(r'^Ran (\d+) tests? in ', text, re.M)]
        row['rust_test_counts'] = rust_counts(text)
        print(json.dumps({'step': index, 'status': row['status'], 'name': name,
                          'returncode': row['returncode']}), flush=True)
        save()
        if row['status'] == 'failed':
            print(text[-5000:], flush=True)
            break

    for path in set((REPO / 'tests').rglob('*.pyc')) - before_pyc:
        path.unlink()
    for path in set((REPO / 'tests').rglob('__pycache__')) - before_cache_dirs:
        if not any(path.iterdir()):
            path.rmdir()
    report['head_after'] = git('rev-parse', 'HEAD')
    report['tracked_status_after'] = git('status', '--porcelain', '--untracked-files=no')
    report['source_unchanged'] = (report['head_after'] == HEAD
                                  and not report['tracked_status_after']
                                  and workflow_path.read_bytes() == workflow_bytes)
    expected_steps = sum('run' in s for s in workflow['jobs']['host-contracts']['steps'])
    report['success'] = (report['source_unchanged'] and len(report['steps']) == expected_steps
                         and all(s['status'].startswith('passed_') for s in report['steps']))
    report['executed_step_count'] = sum(s['status'] == 'passed_executed' for s in report['steps'])
    report['reused_step_count'] = sum(s['status'] == 'passed_reused' for s in report['steps'])
    report['completed_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({'success': report['success'], 'summary': str(OUT / 'summary.json'),
                      'executed': report['executed_step_count'], 'reused': report['reused_step_count']}), flush=True)
    return 0 if report['success'] else 1


if __name__ == '__main__':
    sys.exit(main())
