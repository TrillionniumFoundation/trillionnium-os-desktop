set -euo pipefail
cargo fmt --manifest-path libs/os-abi/Cargo.toml -- --check
cargo clippy --manifest-path libs/os-abi/Cargo.toml --all-targets -- -D warnings
