set -euo pipefail
cargo fmt --manifest-path libs/os-control/Cargo.toml -- --check
cargo clippy --manifest-path libs/os-control/Cargo.toml --all-targets -- -D warnings
