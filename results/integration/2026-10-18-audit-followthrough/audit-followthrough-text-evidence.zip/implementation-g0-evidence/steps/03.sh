set -euo pipefail
for fixture in tests/golden/generate_transport32.py tests/golden/transport32.hex; do
  if [[ ! -f "$fixture" || -L "$fixture" ]]; then
    echo "Missing or symlinked independent ioctl transport fixture: $fixture" >&2
    exit 1
  fi
done
python3 -I tests/golden/generate_transport32.py --check
