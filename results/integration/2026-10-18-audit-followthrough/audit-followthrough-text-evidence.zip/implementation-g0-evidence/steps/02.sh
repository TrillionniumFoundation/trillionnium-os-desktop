set -euo pipefail
for fixture in \
  tests/golden/generate_hos2_edges.py \
  tests/golden/hos2_edges.json \
  tests/abi/test_semantic_edges_contract.py \
  libs/os-abi/tests/semantic_edges.rs; do
  if [[ ! -f "$fixture" || -L "$fixture" ]]; then
    echo "Missing or symlinked mandatory HOS2 semantic oracle: $fixture" >&2
    exit 1
  fi
done
# This generator intentionally imports sibling generate_hos2.py;
# it checks 24 independently generated HOS2 edge frames.
python3 tests/golden/generate_hos2_edges.py --check
