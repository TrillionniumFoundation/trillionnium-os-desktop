set -euo pipefail
test -f libs/os-abi/Cargo.toml
test -f libs/os-control/Cargo.toml
