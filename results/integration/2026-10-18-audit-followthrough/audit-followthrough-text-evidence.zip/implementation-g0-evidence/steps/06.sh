test -f tests/kernel/control/hos2_queryabi_probe.c
test -f tests/kernel/control/run-host-smoke.sh
test -f tests/kernel/control/fake-ioctl-efault.c
sh tests/kernel/control/run-host-smoke.sh
