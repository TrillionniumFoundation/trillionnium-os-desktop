set -euo pipefail
dir=tests/kernel/control
# A pair absent from BOTH base and head may bootstrap once. Once
# tracked, deleting its source AND test together must be a failure.
if [[ -z "${EVENT_BASE_SHA:-}" || "$EVENT_BASE_SHA" =~ ^0+$ ]] ||
   ! git cat-file -e "$EVENT_BASE_SHA^{commit}" 2>/dev/null; then
  echo 'Cannot identify exact A05 regression event base' >&2
  exit 1
fi
any=0
for pair in \
  'run_queryabi_guest.py test_queryabi_guest_runner.py' \
  'pinned_memfd.py test_pinned_memfd.py' \
  'serial_limit.py test_serial_limit.py'; do
  read -r source testfile <<< "$pair"
  for name in "$source" "$testfile"; do
    path="$dir/$name"
    # The event-base *tree* is authoritative, not only the head.
    if git cat-file -e "$EVENT_BASE_SHA:$path" 2>/dev/null; then
      if [[ ! -f "$path" || -L "$path" ]]; then
        echo "A05 required regression vanished since base: $path" >&2
        exit 1
      fi
    fi
    if [[ -e "$path" || -L "$path" ]]; then
      if [[ ! -f "$path" || -L "$path" ]]; then
        echo "A05 replay source/test is not regular: $path" >&2
        exit 1
      fi
      any=1
    fi
  done
  if [[ -e "$dir/$source" || -L "$dir/$source" ||
        -e "$dir/$testfile" || -L "$dir/$testfile" ]]; then
    if [[ ! -f "$dir/$source" || -L "$dir/$source" ||
          ! -f "$dir/$testfile" || -L "$dir/$testfile" ]]; then
      echo "A05 replay source/test pair incomplete: $pair" >&2
      exit 1
    fi
  fi
done
if [[ "$any" -eq 0 ]]; then
  echo 'BOOTSTRAP ONLY: all three A05 replay pairs absent in base and head'
else
  for mode in normal optimized; do
    args=()
    if [[ "$mode" == optimized ]]; then args=(-O); fi
    logfile="$RUNNER_TEMP/a05-replay-${mode}.log"
    python3 -I "${args[@]}" -m unittest discover -s "$dir" \
      -p 'test_*.py' -v 2>&1 | tee "$logfile"
    if ! grep -Eq '^Ran [1-9][0-9]* tests? in ' "$logfile"; then
      echo 'A05 replay suite yielded zero tests; fail closed' >&2
      exit 1
    fi
  done
fi
