set -euo pipefail
test -s libs/os-control/Cargo.lock
cargo test --locked --manifest-path libs/os-control/Cargo.toml \
  --no-default-features --features portable-spin --verbose
cargo clippy --locked --manifest-path libs/os-control/Cargo.toml \
  --no-default-features --features portable-spin --all-targets -- -D warnings
