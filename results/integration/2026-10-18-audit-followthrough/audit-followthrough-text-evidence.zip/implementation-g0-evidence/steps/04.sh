python3 -m unittest discover -s tests/abi -p 'test_*.py' -v
python3 -m unittest discover -s tests/spec -p 'test_*.py' -v
