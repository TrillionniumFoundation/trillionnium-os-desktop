set -euo pipefail
rustup target add x86_64-unknown-none
cargo build --locked --manifest-path libs/os-control/Cargo.toml \
  --no-default-features --features portable-spin \
  --lib --target x86_64-unknown-none --verbose
