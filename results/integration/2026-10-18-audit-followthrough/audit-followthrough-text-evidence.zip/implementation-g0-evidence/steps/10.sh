set -euo pipefail
rustc -Vv
cargo -Vv
rustup component add rustfmt clippy
