#!/usr/bin/env python3
"""Independent archived-byte and source-object review; starts no product process."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path('/workspace/scratch/499c7902de8e/implementation-hepta-shell')
OUT = Path(__file__).resolve().parent
ARCHIVE = ROOT / 'tests/ui/evidence/2026-10-17-original-hepta-shell'
HEAD = '89aa8fa62d30b00259cb33174260c134edf1a70b'
MAIN = '3551e1e0e017e2973da7e2b8ab811ece25c258c0'
MERGED_TREE = '2f9a0d5a96b7260c42782b39a3de1c100b5015e4'
VISUAL_SAMPLES = {
    '02': [1792277794233, 1792277797242, 1792277800252, 1792277801255, 1792277809180, 1792277809180],
    '03': [1792277987357, 1792277990368, 1792277993377, 1792277993377, 1792278000290, 1792278002303],
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], stderr=subprocess.PIPE).decode().strip()

def verify(path, record):
    assert sha(path) == record['sha256'], str(path)
    if 'bytes' in record:
        assert path.stat().st_size == record['bytes'], str(path)

def checksum_manifest(path):
    count = 0
    for line in path.read_text().splitlines():
        digest, filename = line.split('  ', 1)
        file = path.parent / filename
        assert file.is_relative_to(path.parent) and not file.is_symlink()
        assert sha(file) == digest, str(file)
        count += 1
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(path), 'files_verified': count}

spec = importlib.util.spec_from_file_location('m0_capture_contract', ROOT / 'tests/ui/probe-original-hepta-shell.py')
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
bindings = read(ARCHIVE / 'source-bindings.json')
maps = read(ROOT / 'tests/integration/hepta/evidence/2026-10-17-r6/publication-source-map.json')['mappings']
mapping = {item['local_commit']: item for item in maps}
report = {
    'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root/original_hepta_shell', 'head': HEAD,
    'method': 'Public Git fetch; independently read 12 original PNGs with view_image; hash archived bytes; replay phase and before/after snapshot semantics; verify immutable published source objects and prospective main merge.',
    'new_product_runtime_or_build_started': False,
    'actual_elf_bytes_available_to_this_reviewer': False,
    'claims_from_original_runtime_receipts_are_not_a_new_execution': True,
    'archives': [], 'runs': [], 'production_closure': [],
}
for relative in [
    'tests/ui/evidence/2026-10-17-original-hepta-shell',
    'tests/integration/hepta/evidence/2026-10-17-r6',
    'tests/integration/hepta/evidence/2026-10-17-original-session-build',
    'tests/integration/hepta/evidence/2026-10-17-original-session-runtime',
    'tests/ui/evidence/2026-10-17-original-shell-ci',
]:
    path = ROOT / relative / 'SHA256SUMS'
    if path.is_file():
        report['archives'].append(checksum_manifest(path))

for run in bindings['runs']:
    if run['run'] not in VISUAL_SAMPLES:
        continue
    folder = ARCHIVE / run['archive_directory']
    capture = read(folder / 'capture-receipt.json')
    runtime = read(folder / 'paired-runtime-receipt.json')
    verify(folder / 'paired-runtime-receipt.json', run['paired_runtime_receipt'])
    source = capture['source_provenance']
    published = run['root_reported_published_same_tree_object']
    assert git('rev-parse', published + '^{tree}') == source['harness_tree'] == runtime['desktop']['tree']
    assert runtime['desktop'] == runtime['desktop_after']
    assert runtime['original_build'] == runtime['original_after']
    assert runtime['binaries_before'] == runtime['binaries_after'] == run['original_owner_binaries']
    assert runtime['helper_sha256'] == runtime['helper_sha256_after']
    assert runtime['original_build']['original']['commit'] == bindings['original_hepta_pin']
    assert runtime['status'] == runtime['live_agentd_acceptance'] == runtime['persistent_session_acceptance'] == 'passed'
    assert runtime['private_state_cleanup_complete'] is True
    assert read(folder / 'namespace.json')['returncode'] == 0
    assert capture['capture_passed'] and capture['shell_processes_started'] == 1
    assert capture['same_shell_pid_all_phases'] and capture['same_shell_window_all_phases']
    assert capture['visual_review_required'] and not capture['visual_review_completed_by_capture']
    assert not any(capture[key] for key in ['synthetic_agentd_fixture_used', 'renderer_memory_injected', 'objective_submitted', 'model_called', 'device_effect_tested'])
    assert len(capture['phases']) == 6
    assert len(runtime['steps']) == 1 and runtime['steps'][0]['exit_code'] == 0
    assert runtime['steps'][0]['child_guard_armed_after_completion'] is False
    assert {item['label'] for item in capture['cleanup']} == {'rust-shell', 'xvfb'}
    assert all(isinstance(item['observed_returncode'], int) for item in capture['cleanup'])
    build = read(folder / 'rust-build-receipt.json')
    assert sha(folder / 'rust-build-receipt.json') == runtime['ui_build']['build_receipt_sha256']
    for name, info in source['binaries'].items():
        assert info['sha256'] == build['binaries'][name]['sha256']
    for label, name in [('trill-session', 'session'), ('trill-ctl', 'ctl')]:
        assert source['binaries'][label]['sha256'] == runtime['binaries_before'][name]['sha256']
    for label, filename in [('harness', 'capture-source.py'), ('pixels', 'x11-capture-source.py'), ('guard', 'child-guard-source.py')]:
        info = source['tracked_sources'][label]
        verify(folder / filename, info)
        assert git('rev-parse', published + ':' + info['path']) == info['git_blob']
        assert sha(ROOT / info['path']) == info['sha256']
    assert git('rev-parse', published + ':ui') == source['unchanged_ui_subtree']
    for relative, expected in source['unchanged_session_path_dependency'].items():
        assert git('rev-parse', published + ':' + relative) == expected
        assert git('rev-parse', HEAD + ':' + relative) == expected
    images, previous, runtime_path, identities = [], None, None, []
    records = runtime['runtime_records']
    acceptance = [item for item in records if item.get('event') in ('acceptance_pass', 'session_acceptance_pass')]
    assert len(acceptance) == 2 and all(len(item['checks']) == 8 for item in acceptance)
    assert all(not item[key] for item in acceptance for key in ('objective_submission', 'model_turn', 'device_effect'))
    for i, (phase, sample) in enumerate(zip(capture['phases'], VISUAL_SAMPLES[run['run']]), 1):
        held_path = folder / phase['phase_file']
        held = read(held_path)
        assert sha(held_path) == phase['phase_sha256']
        assert held in records
        assert held['capture_ack_is_coordination_only'] is True
        runtime_path = oracle.validate_phase(held, i, runtime_path, previous)
        ack = read(folder / 'coordination' / f'ack-{i}.json')
        assert ack == held['ack']
        assert any(item.get('event') == 'session_phase_acknowledged' and item['ack'] == ack for item in records)
        assert phase['shell_pid'] == capture['shell_pid'] and phase['shell_window_xid'] == capture['shell_window']['xid']
        ids = (held['session_pid'], held['session_instance'], held['worker_tid'])
        identities.append(ids)
        before = read(folder / phase['before']['file'])
        after = read(folder / phase['after']['file'])
        for label, data in [('before', before), ('after', after)]:
            info = phase[label]
            verify(folder / info['file'], info)
            assert info['hepta'] == data['hepta']
            assert info['peer_pid'] == held['session_pid'] and info['peer_uid'] == info['peer_gid'] == 0
            assert data['session_instance'] == held['session_instance']
        oracle.compare_snapshot(before, held, phase['before']['finished_unix_ms'])
        oracle.compare_snapshot(after, held, phase['after']['finished_unix_ms'], before['hepta'])
        ob, oa = before['hepta']['last_observation'], after['hepta']['last_observation']
        assert ob['sampled_unix_ms'] <= sample <= oa['sampled_unix_ms']
        image = folder / phase['screenshot']['file']
        verify(image, phase['screenshot'])
        header = image.read_bytes()[:24]
        assert header[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack('>II', header[16:24]) == (1440,1000)
        if i in (4,6):
            assert ob == oa == held['stale_verification']['first_stale_snapshot']['hepta']['last_observation']
            assert sample == oa['sampled_unix_ms']
        images.append({'sequence': i, 'phase': phase['phase'], 'file': str(image.relative_to(ROOT)), 'sha256': sha(image), 'visual_review': 'passed', 'visible_sample_unix_ms': sample, 'agent_id': oa['agent_id'], 'spawn_generation': oa['spawn_generation'], 'current_generation': oa['current_generation'], 'health': oa['health'], 'connection': after['hepta']['connection'], 'session_pid': ids[0], 'session_instance': ids[1], 'worker_tid': ids[2]})
        previous = held
    assert len(set(identities[:4])) == len(set(identities[4:])) == 1 and identities[0] != identities[4]
    report['runs'].append({'run':run['run'], 'published_harness_commit':published, 'actual_execution_commit':source['harness_commit'], 'actual_execution_tree':source['harness_tree'], 'shell_pid':capture['shell_pid'], 'shell_window':capture['shell_window'], 'original_agentd_sha256':runtime['binaries_before']['agentd']['sha256'], 'shell_sha256':source['binaries']['trill-shell']['sha256'], 'images':images})

closure = read(ROOT / 'tests/integration/hepta/evidence/2026-10-17-r6/source-closure-review.json')['source_closure']
for item in closure:
    actual = git('rev-parse', HEAD + ':' + item['path'])
    merged = git('rev-parse', MERGED_TREE + ':' + item['path'])
    assert actual == merged == item['actual_runtime_source_object']
    report['production_closure'].append({'path': item['path'], 'git_object': actual, 'head_and_prospective_merge_match_executed_source': True})
assert git('diff', '--name-only', MAIN, MERGED_TREE, '--', 'libs', 'kernel') == ''
for ancestor in [MAIN, '45552fbd8f79ea713509908ac4b08a3fd44a95bc']:
    if ancestor != MAIN:
        assert subprocess.run(['git','-C',str(ROOT),'merge-base','--is-ancestor',ancestor,HEAD]).returncode == 0
report['prospective_merge'] = {'main':MAIN, 'ui_owner_head':HEAD, 'tree':MERGED_TREE, 'conflicts':False, 'main_kernel_and_libs_unchanged':True, 'a10_owner_ancestry_preserved':True}
report['status'] = 'passed'
report['m0_qualification'] = 'Original pinned Hepta → persistent Session → one native Rust Shell across six visible lifecycle phases; Linux x86_64 Xvfb read-only only.'
report['exclusions'] = ['No new runtime execution by this reviewer.', 'ELF bytes not included in archival repo; runtime/build receipts and prior byte inspection form executed binary provenance.', 'No ObjectiveStart/model turn/effect, physical display, target kernel, Android/iOS or input qualification.']
(OUT / 'm0-independent-review.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status':report['status'],'verified_archives':report['archives'],'images':sum(len(r['images']) for r in report['runs']),'source_objects':len(closure),'prospective_merge':report['prospective_merge'],'report':str(OUT/'m0-independent-review.json')},indent=2))
