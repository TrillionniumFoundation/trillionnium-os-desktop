
import fcntl,hashlib,importlib.util,json,os,signal,subprocess,sys,traceback
from pathlib import Path
root=Path(sys.argv[1]); source=Path(sys.argv[2]); inject=sys.argv[3]
spec=importlib.util.spec_from_file_location('runner_under_audit',source)
runner=importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
real_popen=runner.subprocess.Popen
real_signal=runner.signal.signal
fired=False
def owned_popen(*args,**kwargs):
    process=real_popen(*args,**kwargs)
    (root/'leader-popen.json').write_text(json.dumps({'pid':process.pid,'argv':args[0],'start_new_session':kwargs.get('start_new_session')}))
    return process
real_stop=runner.OwnedSession.stop
real_killpg=runner.os.killpg

def inject_term(location):
    global fired
    fired=True
    (root/'signal-seam.json').write_text(json.dumps({'old_repro_label':inject,'actual_patched_seam':location,'injected_signal':'SIGTERM','stack':traceback.format_stack()}))
    os.kill(os.getpid(),signal.SIGTERM)

def stop_entry(self,*args,**kwargs):
    if inject=='before-int-ignore' and not fired:
        inject_term('OwnedSession.stop entry; former handler-masking entry removed')
    return real_stop(self,*args,**kwargs)

def killpg_seam(pid,number):
    result=real_killpg(pid,number)
    if inject=='between-int-term-ignore' and not fired and number==signal.SIGTERM:
        inject_term('after owned group TERM, before KILL; no temporary signal masking')
    return result
runner.subprocess.Popen=owned_popen
runner.OwnedSession.stop=stop_entry
runner.os.killpg=killpg_seam
status=0
try:
    with runner.interruption_handlers():
        with runner.locked_output(root/'runner.lock',root/'output'):
            runner.command([sys.executable,'-I',str(root.parent.parent/'leader.py'),str(root)],root,os.environ.copy(),root/'output/child.log',20)
except runner.RunnerInterrupted as error:
    status=128+error.signum
    (root/'worker-result.json').write_text(json.dumps({'exit':status,'signal':signal.Signals(error.signum).name,'seam_fired':fired}))
    traceback.print_exc()
finally:
    (root/'worker-source.json').write_text(json.dumps({'entry':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}))
raise SystemExit(status)
