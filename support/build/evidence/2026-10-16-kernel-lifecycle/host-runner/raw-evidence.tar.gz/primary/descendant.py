
import json,signal,socket,sys,time
from pathlib import Path
root=Path(sys.argv[1])
signal.signal(signal.SIGTERM,signal.SIG_IGN)
listener=socket.socket(); listener.bind(('127.0.0.1',0)); listener.listen(1)
(root/'listener.json').write_text(json.dumps({'address':listener.getsockname()}))
time.sleep(60)
