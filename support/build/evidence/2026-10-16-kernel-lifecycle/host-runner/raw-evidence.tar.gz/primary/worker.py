
import fcntl,hashlib,importlib.util,json,os,signal,subprocess,sys,traceback
from pathlib import Path
root=Path(sys.argv[1]); source=Path(sys.argv[2]); inject=sys.argv[3]
spec=importlib.util.spec_from_file_location('runner_under_audit',source)
runner=importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
real_popen=runner.subprocess.Popen
real_signal=runner.signal.signal
fired=False

def owned_popen(*args,**kwargs):
    process=real_popen(*args,**kwargs)
    (root/'leader-popen.json').write_text(json.dumps({'pid':process.pid,'argv':args[0],'start_new_session':kwargs.get('start_new_session')}))
    return process

def signal_seam(number,handler):
    global fired
    target=signal.SIGINT if inject=='before-int-ignore' else signal.SIGTERM
    if inject!='control' and not fired and number==target and handler==signal.SIG_IGN:
        fired=True
        (root/'signal-seam.json').write_text(json.dumps({'target':signal.Signals(number).name,'injected_signal':'SIGTERM','before_real_signal_call':True,'stack':traceback.format_stack()}))
        # A real signal runs the actual previously installed Python handler.
        os.kill(os.getpid(),signal.SIGTERM)
    return real_signal(number,handler)
runner.subprocess.Popen=owned_popen
runner.signal.signal=signal_seam
status=0
try:
    with runner.interruption_handlers():
        with runner.locked_output(root/'runner.lock',root/'output'):
            runner.command([sys.executable,'-I',str(root.parent.parent/'leader.py'),str(root)],root,os.environ.copy(),root/'output/child.log',20)
except runner.RunnerInterrupted as error:
    status=128+error.signum
    (root/'worker-result.json').write_text(json.dumps({'exit':status,'signal':signal.Signals(error.signum).name,'seam_fired':fired}))
    traceback.print_exc()
finally:
    (root/'worker-source.json').write_text(json.dumps({'entry':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}))
raise SystemExit(status)
