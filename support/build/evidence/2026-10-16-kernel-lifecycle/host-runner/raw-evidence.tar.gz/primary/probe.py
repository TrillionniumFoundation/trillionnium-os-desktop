#!/usr/bin/env python3
"""Read-only signal-seam reproduction against the actual imported runner."""
import argparse,errno,fcntl,hashlib,json,os,select,signal,socket,subprocess,sys,time
from pathlib import Path

WORKER=r'''
import fcntl,hashlib,importlib.util,json,os,signal,subprocess,sys,traceback
from pathlib import Path
root=Path(sys.argv[1]); source=Path(sys.argv[2]); inject=sys.argv[3]
spec=importlib.util.spec_from_file_location('runner_under_audit',source)
runner=importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
real_popen=runner.subprocess.Popen
real_signal=runner.signal.signal
fired=False

def owned_popen(*args,**kwargs):
    process=real_popen(*args,**kwargs)
    (root/'leader-popen.json').write_text(json.dumps({'pid':process.pid,'argv':args[0],'start_new_session':kwargs.get('start_new_session')}))
    return process

def signal_seam(number,handler):
    global fired
    target=signal.SIGINT if inject=='before-int-ignore' else signal.SIGTERM
    if inject!='control' and not fired and number==target and handler==signal.SIG_IGN:
        fired=True
        (root/'signal-seam.json').write_text(json.dumps({'target':signal.Signals(number).name,'injected_signal':'SIGTERM','before_real_signal_call':True,'stack':traceback.format_stack()}))
        # A real signal runs the actual previously installed Python handler.
        os.kill(os.getpid(),signal.SIGTERM)
    return real_signal(number,handler)
runner.subprocess.Popen=owned_popen
runner.signal.signal=signal_seam
status=0
try:
    with runner.interruption_handlers():
        with runner.locked_output(root/'runner.lock',root/'output'):
            runner.command([sys.executable,'-I',str(root.parent.parent/'leader.py'),str(root)],root,os.environ.copy(),root/'output/child.log',20)
except runner.RunnerInterrupted as error:
    status=128+error.signum
    (root/'worker-result.json').write_text(json.dumps({'exit':status,'signal':signal.Signals(error.signum).name,'seam_fired':fired}))
    traceback.print_exc()
finally:
    (root/'worker-source.json').write_text(json.dumps({'entry':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}))
raise SystemExit(status)
'''
LEADER=r'''
import json,subprocess,sys,time
from pathlib import Path
root=Path(sys.argv[1])
p=subprocess.Popen([sys.executable,'-I',str(root.parent.parent/'descendant.py'),str(root)])
(root/'descendant-popen.json').write_text(json.dumps({'pid':p.pid,'argv':p.args}))
while not (root/'listener.json').is_file(): time.sleep(.01)
print('OWNED_RUNNER_CHILDREN_READY',flush=True)
time.sleep(60)
'''
DESCENDANT=r'''
import json,signal,socket,sys,time
from pathlib import Path
root=Path(sys.argv[1])
signal.signal(signal.SIGTERM,signal.SIG_IGN)
listener=socket.socket(); listener.bind(('127.0.0.1',0)); listener.listen(1)
(root/'listener.json').write_text(json.dumps({'address':listener.getsockname()}))
time.sleep(60)
'''

def dump(path,value): path.write_text(json.dumps(value,indent=2)+'\n')
def exited(descriptor,timeout=0):
    poll=select.poll(); poll.register(descriptor,select.POLLIN)
    return bool(poll.poll(timeout))
def port_free(address):
    with socket.socket() as listener:
        try: listener.bind(tuple(address))
        except OSError as error:
            if error.errno!=errno.EADDRINUSE: raise
            return False
    return True

parser=argparse.ArgumentParser(); parser.add_argument('--out',type=Path,required=True); args=parser.parse_args()
source=Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop/support/build/osdk-integration/run.py')
base=Path(__file__).resolve().parent
for name,data in [('worker.py',WORKER),('leader.py',LEADER),('descendant.py',DESCENDANT)]:
    path=base/name
    if path.exists() and path.read_text()!=data: raise RuntimeError('fixture changed')
    path.write_text(data)
args.out.mkdir(parents=True,exist_ok=False)
records=[]
for mode in ['control','before-int-ignore','between-int-term-ignore']:
    root=args.out/mode; root.mkdir()
    argv=[sys.executable,'-I',str(base/'worker.py'),str(root),str(source),mode]
    record={'mode':mode,'argv':argv,'cwd':str(root),'entry_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
    fds={}; worker=None
    try:
        with (root/'worker.log').open('xb') as log:
            worker=subprocess.Popen(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
            deadline=time.monotonic()+5
            while True:
                if worker.poll() is not None: raise RuntimeError('worker exited before fixture readiness')
                if (root/'listener.json').exists() and (root/'descendant-popen.json').exists() and (root/'leader-popen.json').exists() and (root/'output/child.log').exists() and 'OWNED_RUNNER_CHILDREN_READY' in (root/'output/child.log').read_text(): break
                if time.monotonic()>=deadline: raise TimeoutError('fixture readiness')
                time.sleep(.01)
            for role in ['leader','descendant']:
                pid=json.loads((root/(role+'-popen.json')).read_text())['pid']
                fds[role]=os.pidfd_open(pid)
            address=json.loads((root/'listener.json').read_text())['address']
            record['before']={'leader_exited':exited(fds['leader']),'descendant_exited':exited(fds['descendant']),'listener_free':port_free(address)}
            if any(record['before'].values()): raise RuntimeError('fixture was not live before signal')
            began=time.monotonic(); worker.send_signal(signal.SIGINT)
            record['worker_exit']=worker.wait(timeout=5)
            record['worker_exit_seconds']=time.monotonic()-began
            if mode=='control':
                exited(fds['descendant'],2000)
            else:
                # Distinguish leaked ownership from asynchronous SIGKILL exit.
                exited(fds['descendant'],1000)
            with (root/'runner.lock').open('a') as lock:
                try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB); free=True
                except BlockingIOError: free=False
            record['after_worker']={'leader_exited':exited(fds['leader']),'descendant_exited':exited(fds['descendant']),'listener_free':port_free(address),'runner_lock_free':free}
            record['command_record']=json.loads((root/'output/child.command.json').read_text())
            record['seam_fired']=(root/'signal-seam.json').exists()
            record['leak_reproduced']=mode!='control' and record['worker_exit']==143 and record['seam_fired'] and not record['after_worker']['leader_exited'] and not record['after_worker']['descendant_exited'] and not record['after_worker']['listener_free'] and record['after_worker']['runner_lock_free']
            record['control_passed']=mode=='control' and record['worker_exit']==130 and record['after_worker']['leader_exited'] and record['after_worker']['descendant_exited'] and record['after_worker']['listener_free'] and record['command_record'].get('group_cleanup',{}).get('leader_reaped') is True
    finally:
        if worker is not None and worker.poll() is None: worker.kill(); worker.wait()
        cleanup={}
        for role,descriptor in fds.items():
            try:
                if not exited(descriptor): signal.pidfd_send_signal(descriptor,signal.SIGKILL)
                cleanup[role]=exited(descriptor,2000)
            finally: os.close(descriptor)
        record['fixture_owned_pidfd_cleanup']=cleanup
        dump(root/'probe-result.json',record)
    records.append(record)
    print(json.dumps({key:record[key] for key in ['mode','worker_exit','after_worker','leak_reproduced','control_passed']}),flush=True)
report={'schema':1,'scope':'host-only controlled real-signal seam, actual owned children and TCP lease; no VM, no product source changes, no /proc or post-reap PGID signal',
 'entry_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'baseline_commit':'2eee2c3df5a837e89ae7557510008ce1de37a1ca','records':records,
 'confirmed':records[0]['control_passed'] and all(r['leak_reproduced'] for r in records[1:])}
dump(args.out/'report.json',report)
raise SystemExit(not report['confirmed'])
