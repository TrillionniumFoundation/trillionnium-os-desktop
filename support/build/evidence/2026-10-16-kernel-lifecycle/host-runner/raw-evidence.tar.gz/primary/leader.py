
import json,subprocess,sys,time
from pathlib import Path
root=Path(sys.argv[1])
p=subprocess.Popen([sys.executable,'-I',str(root.parent.parent/'descendant.py'),str(root)])
(root/'descendant-popen.json').write_text(json.dumps({'pid':p.pid,'argv':p.args}))
while not (root/'listener.json').is_file(): time.sleep(.01)
print('OWNED_RUNNER_CHILDREN_READY',flush=True)
time.sleep(60)
