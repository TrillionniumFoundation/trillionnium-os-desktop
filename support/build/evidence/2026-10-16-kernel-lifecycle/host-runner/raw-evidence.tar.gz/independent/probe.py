import importlib.util,json,os,signal,sys,time
from pathlib import Path
spec=importlib.util.spec_from_file_location('reviewed_runner','/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop/support/build/osdk-integration/run.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
original_signal=signal.signal
original_init=runner.OwnedSession.__init__
owners=[]
def init(self,*args,**kwargs):
 original_init(self,*args,**kwargs)
 owners.append(self)
runner.OwnedSession.__init__=init
injected=False
def install(number,handler):
 global injected
 result=original_signal(number,handler)
 if number==signal.SIGINT and handler==signal.SIG_IGN and not injected:
  injected=True
  Path('injection.json').write_text(json.dumps({'phase':'finish_cleanup installed SIGINT ignore but SIGTERM still raises','sigterm_handler':str(signal.getsignal(signal.SIGTERM))}))
  os.kill(os.getpid(),signal.SIGTERM)
 return result
signal.signal=install
try:
 with runner.interruption_handlers():
  runner.command([sys.executable,'-I','-c',"import json,os,signal,socket,time;from pathlib import Path;signal.signal(signal.SIGTERM,signal.SIG_IGN);lease=socket.socket();lease.bind(('127.0.0.1',0));lease.listen(1);Path('ready.json').write_text(json.dumps({'pid':os.getpid(),'group':os.getpgrp(),'address':lease.getsockname()}));time.sleep(60)"],Path.cwd(),os.environ.copy(),Path('case.log'),30)
except BaseException as error:
 Path('error.json').write_text(json.dumps({'type':type(error).__name__,'message':str(error),'signum':getattr(error,'signum',None)}))
finally:
 while not Path('parent-cleaned').exists():time.sleep(.01)
 for owned in owners:owned.process.wait(timeout=3)
