import importlib.util,os,signal,subprocess,sys,time
from pathlib import Path
spec=importlib.util.spec_from_file_location('debug_fixture','/workspace/scratch/ae1a8cf05419/next6-debug-patched-02-final/spawn-publication/fixture-project/support/build/debug/run.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=subprocess.Popen
def spawn(*args,**kwargs):
 child=original(*args,**kwargs)
 if any(str(value).endswith('/kernel.sh') for value in args[0]):
  ready=Path('/workspace/scratch/ae1a8cf05419/next6-debug-patched-02-final/spawn-publication/ready.json')
  deadline=time.monotonic()+5
  while not ready.exists():
   assert time.monotonic()<deadline
   time.sleep(.01)
  os.kill(os.getpid(),signal.SIGTERM)
 return child
subprocess.Popen=spawn
sys.argv=['/workspace/scratch/ae1a8cf05419/next6-debug-patched-02-final/spawn-publication/fixture-project/support/build/debug/run.py', '--output', '/workspace/scratch/ae1a8cf05419/next6-debug-patched-02-final/spawn-publication/debug-output', '--gdb', '/workspace/scratch/ae1a8cf05419/next6-debug-patched-02-final/spawn-publication/tools/gdb', '--nm', '/workspace/scratch/ae1a8cf05419/next6-debug-patched-02-final/spawn-publication/tools/nm', '--ready-timeout', '30']
raise SystemExit(module.main())
