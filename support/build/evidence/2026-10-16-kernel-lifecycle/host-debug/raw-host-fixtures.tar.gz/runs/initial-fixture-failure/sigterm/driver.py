import fcntl,json,os,signal,socket,subprocess,sys,time
from pathlib import Path
root=Path(os.environ['A01_DEBUG_FIXTURE_ROOT'])
held=(root/'held.lock').open('w');fcntl.flock(held,fcntl.LOCK_EX)
signal.signal(signal.SIGTERM,signal.SIG_IGN)
lease=socket.socket();lease.bind(('127.0.0.1',0));lease.listen(1)
child=subprocess.Popen([sys.executable,'-I','-c',"import json,os,signal,socket,time;from pathlib import Path;signal.signal(signal.SIGTERM,signal.SIG_IGN);lease=socket.socket();lease.bind(('127.0.0.1',0));lease.listen(1);Path(os.environ['A01_DEBUG_FIXTURE_ROOT'],'descendant.json').write_text(json.dumps({'pid':os.getpid(),'group':os.getpgrp(),'address':lease.getsockname()}));time.sleep(60)"],pass_fds=(held.fileno(),))
while not (root/'descendant.json').exists():time.sleep(.01)
(root/'ready.json').write_text(json.dumps({'pid':os.getpid(),'group':os.getpgrp(),'address':lease.getsockname(),'descendant':json.loads((root/'descendant.json').read_text())}))
time.sleep(60)
