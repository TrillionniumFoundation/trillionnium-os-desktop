host lifecycle fixture; not kernel source
