#!/usr/bin/env python3
"""Capture one unchanged-source invocation of the existing A02 owner gate."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

REPO = Path('/workspace/scratch/d7da9e7650f0/trillionnium-os-desktop')
OUTPUT = Path('/workspace/scratch/d7da9e7650f0/a01-runtime/review/a02-after-main-4339')
OUTER = Path('/tmp/a01-main4339-abi/outer')
ENV_SCRIPT = Path('/workspace/scratch/d7da9e7650f0/a01-runtime/env.sh')
EXPECTED_HEAD = 'd9ccc523141ec46baef2a0dfe0afe49e4f97f523'
EXPECTED_TREE = '315b2b84319a88442fb054f434ccc2fdc436e47e'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def utc() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def capture() -> dict:
    head = git('rev-parse', 'HEAD')
    tree = git('rev-parse', 'HEAD^{tree}')
    status = git('status', '--porcelain=v1', '--untracked-files=no')
    sys.path.insert(0, str(REPO / 'tests/abi'))
    import run_acceptance
    inputs = run_acceptance.selected_inputs(REPO)
    manifest = {}
    for name, data in inputs.items():
        blob = subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=REPO)
        manifest[name] = {
            'size': len(data),
            'sha256': sha(data),
            'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(blob)).encode() + b'\0' + blob).hexdigest(),
            'git_blob_sha256': sha(blob),
            'matches_recorded_head_blob': data == blob,
        }
    canonical = json.dumps(manifest, separators=(',', ':'), sort_keys=True).encode()
    return {
        'captured_at_utc': utc(),
        'repository': str(REPO),
        'head': head,
        'tree': tree,
        'tracked_status_porcelain': status,
        'tracked_clean': status == '',
        'source_selection': 'existing tests/abi/run_acceptance.py:selected_inputs; imported with Python -B',
        'input_count': len(manifest),
        'input_manifest_sha256': sha(canonical),
        'all_inputs_match_recorded_head': all(value['matches_recorded_head_blob'] for value in manifest.values()),
        'inputs': manifest,
    }


def main() -> int:
    OUTER.mkdir(parents=True, exist_ok=False)
    if OUTPUT.exists():
        raise SystemExit(f'gate output must not exist before execution: {OUTPUT}')
    before = capture()
    write_json(OUTER / 'source-before.json', before)
    if not (before['head'] == EXPECTED_HEAD and before['tree'] == EXPECTED_TREE
            and before['tracked_clean'] and before['all_inputs_match_recorded_head']):
        raise SystemExit('source preconditions failed; owner gate not started')
    argv = ['python3', '-B', 'tests/abi/run_acceptance.py', '--repo-root', str(REPO),
            '--toolchain', 'nightly-2026-07-21', '--output-dir', str(OUTPUT),
            '--timeout', '60', '--mutation-timeout', '900']
    started = utc()
    command = {
        'argv': argv, 'cwd': str(REPO), 'started_at_utc': started,
        'fixed_toolchain': 'nightly-2026-07-21',
        'shell_setup': f'source {ENV_SCRIPT}',
        'environment_script': {'path': str(ENV_SCRIPT), 'size': ENV_SCRIPT.stat().st_size,
                               'sha256': sha(ENV_SCRIPT.read_bytes())},
        'effective_selected_environment': {key: os.environ.get(key) for key in (
            'CARGO_BUILD_JOBS', 'CARGO_HOME', 'RUSTUP_HOME', 'RUSTUP_TOOLCHAIN',
            'CARGO_TARGET_DIR', 'RUSTC', 'RUSTDOC', 'PATH')},
        'tool_sandbox_permissions': 'require_escalated',
        'authorization_scope': 'user-authorized existing owner gate; private loopback/network dependencies; no policy changes',
        'output_directory_absent_before_start': True,
    }
    write_json(OUTER / 'command.json', command)
    (OUTER / 'command.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        + f'cd {shlex.quote(str(REPO))}\nsource {shlex.quote(str(ENV_SCRIPT))}\n'
        + 'CARGO_BUILD_JOBS=2 ' + shlex.join(argv) + '\n')
    print(json.dumps({'event': 'owner_gate_started', 'head': before['head'],
                      'input_count': before['input_count'], 'output': str(OUTPUT),
                      'log': str(OUTER / 'owner-gate.log')}), flush=True)
    clock = time.monotonic()
    with (OUTER / 'owner-gate.log').open('wb') as log:
        result = subprocess.run(argv, cwd=REPO, stdout=log, stderr=subprocess.STDOUT, check=False)
    finished = utc()
    elapsed = time.monotonic() - clock
    after = capture()
    write_json(OUTER / 'source-after.json', after)
    report_file = OUTPUT / 'report.json'
    report = json.loads(report_file.read_text()) if report_file.is_file() else {}
    unchanged = (before['head'] == after['head'] and before['tree'] == after['tree']
                 and before['inputs'] == after['inputs'] and after['tracked_clean'])
    report_matches = (report.get('input_sha256') == {name: value['sha256'] for name, value in before['inputs'].items()}
                      and report.get('original_input_sha256_after') == {name: value['sha256'] for name, value in after['inputs'].items()})
    receipt = {
        'started_at_utc': started, 'finished_at_utc': finished,
        'elapsed_seconds': round(elapsed, 6), 'returncode': result.returncode,
        'owner_report_path': str(report_file),
        'owner_report_success': report.get('success'),
        'owner_report_errors': report.get('errors'),
        'owner_report_not_executed': report.get('not_executed'),
        'recorded_source_head': before['head'], 'recorded_source_tree': before['tree'],
        'head_tree_selected_inputs_and_clean_state_unchanged': unchanged,
        'owner_report_inputs_match_outer_capture': report_matches,
        'log_sha256': sha((OUTER / 'owner-gate.log').read_bytes()),
        'successful_gate_and_source_binding': result.returncode == 0 and report.get('success') is True and unchanged and report_matches,
    }
    write_json(OUTER / 'result.json', receipt)
    print(json.dumps(receipt), flush=True)
    return 0 if receipt['successful_gate_and_source_binding'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
