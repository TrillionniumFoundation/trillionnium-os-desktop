#!/usr/bin/env python3
"""Package existing A02 host evidence; no test execution or source copies."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/tmp/a01-main4339-abi')
GATE = Path('/workspace/scratch/d7da9e7650f0/a01-runtime/review/a02-after-main-4339')
REPO = Path('/workspace/scratch/d7da9e7650f0/trillionnium-os-desktop')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


report = read(GATE / 'report.json')
mutation = read(GATE / 'mutations.json')
before = read(ROOT / 'outer/source-before.json')
after = read(ROOT / 'outer/source-after.json')
receipt = read(ROOT / 'outer/result.json')
command = read(ROOT / 'outer/command.json')
previous = read(Path('/tmp/a01-main355-abi/outer/source-before.json'))
checks = {c['name']: c for c in report['checks']}
if not receipt['successful_gate_and_source_binding']:
    raise ValueError('recorded gate or source binding did not pass')
for relative, value in before['inputs'].items():
    if digest((GATE / 'snapshot' / relative).read_bytes()) != value['sha256']:
        raise ValueError('snapshot changed after execution: ' + relative)

runtime_relative = 'support/build/evidence/2026-10-18-current-main/runtime.tar.gz'
runtime = REPO / runtime_relative
summary = {
    'schema': 'a01-a02-main4339-owner-gate-evidence-v1',
    'scope': 'Existing A02 host codec gate after main 4339 merge; no new kernel or A03 matrix execution.',
    'success': True,
    'source': {
        'head': before['head'], 'tree': before['tree'],
        'input_count': before['input_count'],
        'input_manifest_sha256': before['input_manifest_sha256'],
        'all_inputs_equal_recorded_head_blobs': before['all_inputs_match_recorded_head'] and after['all_inputs_match_recorded_head'],
        'head_tree_and_28_input_hashes_unchanged': receipt['head_tree_selected_inputs_and_clean_state_unchanged'],
        'tracked_clean_before_and_after': before['tracked_clean'] and after['tracked_clean'],
        'status_scope': 'Source receipts record tracked-only porcelain, not complete-worktree status.',
        'snapshot_inputs_verified_at_packaging': True,
        'root_readme_bytes': report['readme_bytes'],
    },
    'execution': {k: receipt[k] for k in ('started_at_utc', 'finished_at_utc', 'elapsed_seconds', 'returncode')},
    'toolchain': report['toolchain'],
    'command': command,
    'check_count': len(checks),
    'checks_passed': sum(c['passed'] for c in checks.values()),
    'checks': {name: {k: c[k] for k in ('passed', 'returncode', 'elapsed_seconds')} for name, c in checks.items()},
    'golden_vectors': {name: checks[name]['vectors'] for name in ('golden_hos2', 'golden_edges', 'golden_transport')},
    'python': {name: {k: v for k, v in checks[name]['tests'].items() if k != 'cases'} for name in ('python', 'python_optimized', 'python_mutations')},
    'rust': {k: v for k, v in checks['rust']['tests'].items() if k != 'cases'},
    'compiled_source_mutations': {
        'schema': mutation['schema'], 'expected_mutants': mutation['expected_mutants'],
        'mutants_killed': mutation['mutants_killed'],
        'all_compiled': all(m['compiled'] for m in mutation['mutants']),
        'all_expected_test_failures_observed': all(m['expected_test_failed'] for m in mutation['mutants']),
        'expected_tests_by_suite': mutation['expected_tests_by_suite'],
        'success': mutation['success'], 'errors': mutation['errors'],
    },
    'errors': report['errors'], 'not_executed': report['not_executed'],
    'counting_notes': [
        'Ordinary Python has 62 cases; optimized mode repeats those 62 and is reported separately.',
        'The separately executed 9-case Python mutation subset is already included in the ordinary 62.',
        'Rust has 78 cases including one doctest. Discovery, mutation baselines and mutant executions are not additive.',
    ],
    'reused_runtime_archive': {
        'repository_relative_path': runtime_relative,
        'immutable_github_url': f'https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/{before["head"]}/{runtime_relative}',
        'size': runtime.stat().st_size, 'sha256': digest(runtime.read_bytes()),
        'copied_into_this_archive': False,
    },
    'exclusions': ['Source snapshot text is bound by all 28 SHA256 and Git blob identities but is not duplicated.',
                   'Cargo target, binaries, caches, temporary mutation worktrees and existing runtime archive are not copied.'],
}

names = sorted(set(before['inputs']) | set(previous['inputs']))
comparison = {
    'scope': 'Only the 28 selected A02 gate inputs; not an assertion about the whole repository.',
    'previous_source_head': previous['head'], 'current_source_head': before['head'],
    'previous_python_cases': 60, 'current_python_cases': checks['python']['tests']['actual'],
    'changed_inputs': {name: {'previous_sha256': previous['inputs'].get(name, {}).get('sha256'),
                             'current_sha256': before['inputs'].get(name, {}).get('sha256')}
                       for name in names if previous['inputs'].get(name, {}).get('sha256') != before['inputs'].get(name, {}).get('sha256')},
}

members = {}
origins = []


def add(path, member, kind):
    if path.is_symlink() or not path.is_file():
        raise ValueError('nonregular source: ' + str(path))
    data = path.read_bytes()
    data.decode('utf-8')
    if b'\0' in data:
        raise ValueError('binary outside archive scope: ' + str(path))
    members[member] = data
    origins.append({'original_absolute_path': str(path), 'archive_member': member,
                    'kind': kind, 'size': len(data), 'sha256': digest(data)})


for name in ('report.json', 'mutations.json'):
    add(GATE / name, 'gate/' + name, 'original report including complete raw stdout/stderr and commands')
for path in sorted((ROOT / 'outer').iterdir()):
    add(path, 'outer/' + path.name, 'original command/log/source binding/receipt')
for name in ('run-owner-gate.py', 'package-owner-evidence.py'):
    add(ROOT / name, 'scripts/' + name, 'evidence recording or packaging script')
origin_map = {'schema': 'a01-evidence-original-path-map-v1', 'source_head': before['head'],
              'files': origins, 'omitted_input_snapshot': str(GATE / 'snapshot'),
              'snapshot_binding_members': ['outer/source-before.json', 'outer/source-after.json'],
              'exclusions': summary['exclusions']}
members['metadata/summary.json'] = encode(summary)
members['metadata/original-paths.json'] = encode(origin_map)
members['metadata/input-comparison-to-main355.json'] = encode(comparison)
members['SHA256SUMS'] = ''.join(f'{digest(data)}  {name}\n' for name, data in sorted(members.items())).encode()
archive = ROOT / 'a02-owner-gate-main4339.tar.gz'
with archive.open('xb') as destination:
    with gzip.GzipFile(filename='', mode='wb', fileobj=destination, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, mode='r:gz') as tar:
    entries = tar.getmembers()
    if len(entries) != len(members) or {entry.name for entry in entries} != set(members):
        raise ValueError('archive member set mismatch')
    for entry in entries:
        stream = tar.extractfile(entry)
        if not entry.isfile() or stream is None or stream.read() != members[entry.name]:
            raise ValueError('archive readback byte mismatch: ' + entry.name)
manifest = {
    'schema': 'a01-evidence-archive-manifest-v1',
    'archive_absolute_path': str(archive), 'archive_size': archive.stat().st_size,
    'archive_sha256': digest(archive.read_bytes()),
    'source_head': before['head'], 'source_tree': before['tree'],
    'original_file_count': len(origins), 'archive_member_count': len(members),
    'original_files': origins,
    'members': [{'archive_member': name, 'size': len(data), 'sha256': digest(data)} for name, data in sorted(members.items())],
    'archive_readback_verified': True,
    'checksum_scope': 'In-archive SHA256SUMS excludes itself; this external manifest includes every member including SHA256SUMS.',
}
for name, value in [('summary.json', summary), ('original-paths.json', origin_map),
                    ('input-comparison-to-main355.json', comparison), ('archive-manifest.json', manifest)]:
    (ROOT / name).write_bytes(encode(value))
(ROOT / 'SHA256SUMS').write_text(''.join(f'{digest((ROOT / name).read_bytes())}  {name}\n' for name in (
    archive.name, 'summary.json', 'original-paths.json', 'input-comparison-to-main355.json', 'archive-manifest.json')))
print(json.dumps({key: manifest[key] for key in ('archive_absolute_path', 'archive_size', 'archive_sha256',
    'source_head', 'source_tree', 'original_file_count', 'archive_member_count', 'archive_readback_verified')}, indent=2))
print(json.dumps(comparison, indent=2))
