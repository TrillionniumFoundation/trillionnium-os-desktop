#!/usr/bin/env python3
"""Freeze only the completed next7 actual cancellation, no kernel/source writes."""
import gzip,hashlib,io,json,shutil,subprocess,tarfile
from pathlib import Path
BASE=Path('/workspace/scratch/ae1a8cf05419')
REPO=BASE/'trillionnium-os-desktop'
WORK=BASE/'a01-next6-build'
PLAN=BASE/'next7-ktest-cancel-plan'
CONTROL=BASE/'next7-real-ktest-cancel-controller-01'
OUT=WORK/'support/build/out/next7-real-ktest-cancel-01'
DEST=REPO/'support/build/evidence/2026-10-16-ktest-lifecycle/real-ktest-cancel'
COMMIT='efb02440ad6fff3b7a1a5d5019f660743d74ab32'
TREE='bfae38050e0b6473df7a46a6e02669166cf3055f'
def digest(b):return hashlib.sha256(b).hexdigest()
def readj(p):return json.loads(p.read_text())
def writej(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def require(c,m):
 if not c:raise RuntimeError(m)
require(not DEST.exists(),'archive path must be new')
result=readj(CONTROL/'result.json');inv=readj(CONTROL/'invocation.json')
env=readj(OUT/'environment.json');source=readj(OUT/'source-inputs.json')
require(result['passed'] is True and result['boot_pass'] is False,'unexpected controller result')
require(inv['git_tree']==TREE and inv['git_head']==COMMIT and not inv['git_status'],'source binding differs')
require(git('rev-parse',f'{COMMIT}^{{tree}}').decode().strip()==TREE,'immutable tree differs')
require(result['cli_returncode']==143 and result['stable_lock_reacquired'] is True,'cancellation cleanup failed')
qemu=readj(OUT/'ostd/guests/guest-001/qemu.json')
serial=(OUT/'ostd/guests/guest-001/serial.log').read_bytes()
require(qemu['raw_exit_code'] is None and qemu['timed_out'] is False and not serial,'unfinalized record boundary changed')
kernel_gz=(CONTROL/'kernel.elf.gz').read_bytes();kernel=gzip.decompress(kernel_gz)
require(digest(kernel)==result['native_launch']['kernel']['sha256'],'saved actual kernel differs')
require(len(kernel)==result['native_launch']['kernel']['size'],'saved actual kernel size differs')
launch=result['native_launch']
require(launch['actual_argv']==['/usr/bin/qemu-system-x86_64',*launch['requested_argv'][1:],'-S'],'native adapter changes more than executable and -S')
require(digest((PLAN/'controller.py').read_bytes())==inv['controller']['sha256'],'controller changed after launch')
require(digest((CONTROL/'tools/qemu-system-x86_64').read_bytes())==inv['shim']['sha256'],'shim changed after launch')
source_hashes=dict(env['build_inputs_sha256'])
for path,h in source['input_sha256'].items():source_hashes['kernel/asterinas/'+path]=h
for path,r in inv['source'].items():
 require(path not in source_hashes or source_hashes[path]==r['sha256'],'conflicting source hashes')
 source_hashes[path]=r['sha256']
source_hashes['support/upstream-lock.json']=digest(git('show',COMMIT+':support/upstream-lock.json'))
members={}
source_records=[]
for path,h in sorted(source_hashes.items()):
 data=git('show',COMMIT+':'+path)
 require(digest(data)==h,'recorded source differs from immutable published blob: '+path)
 members['source/'+path]=data
 source_records.append({'path':path,'size':len(data),'sha256':h,'origin':COMMIT+':'+path})
for prefix,directory in [('controller',CONTROL),('output',OUT),('plan',PLAN)]:
 for file in sorted(directory.rglob('*')):
  if not file.is_file() or '__pycache__' in file.parts:continue
  require(not file.is_symlink(),'refusing symlink in raw record')
  members[prefix+'/'+str(file.relative_to(directory))]=file.read_bytes()
DEST.mkdir(parents=True)
for original,name in [(CONTROL/'result.json','result.json'),(CONTROL/'invocation.json','invocation.json'),(PLAN/'controller.py','controller.py'),(CONTROL/'tools/qemu-system-x86_64','qemu-hold.py'),(CONTROL/'kernel.elf.gz','kernel.elf.gz'),(OUT/'result.json','ktest-result.json'),(OUT/'environment.json','environment.json'),(OUT/'source-inputs.json','source-inputs.json'),(OUT/'ostd/osdk-test.log.command.json','cancelled-command.json'),(OUT/'ostd/guests/guest-001/qemu.json','qemu.json'),(OUT/'ostd/guests/guest-001/serial.log','serial.log')]:
 shutil.copyfile(original,DEST/name)
shutil.copyfile(REPO/'support/build/evidence/2026-10-16-ktest-lifecycle/host-ktest/publication-receipt.json',DEST/'publication-receipt.json')
writej(DEST/'source-binding.json',{'runtime_commit':COMMIT,'runtime_tree':TREE,'runtime_git_status':inv['git_status'],'source_origin':'immutable git show of recorded runtime commit, after the completed run; not the worktree current files','source_files':source_records,'source_hashes_match_runtime_records':True,'upstream_source_verification':source,'full_kernel_source_archived_here':False,'source_mutated_for_test':False,'target_reused_from':'root actual full two-crate out/next7-ktest-01; cache reused explicitly','OSDK_install_skipped':True})
writej(DEST/'commands.json',{'launch_command':['python3','-I',str(PLAN/'controller.py'),'--launch','--expected-tree',TREE,'--published-commit',COMMIT],'stdout_stderr_redirect':str(PLAN/'actual-launch.log'),'actual_tool_session':50773,'actual_tool_session_exit_code':0,'session_receipt_origin':'observed exec_command then write_stdin completion in this agent session; no separately saved raw tool transcript','production_cli':inv['argv'],'production_cwd':inv['cwd'],'test_native_qemu_argv':launch['actual_argv'],'archive_command':['python3','-I',str(PLAN/'archive.py')],'execution_attempt_count':1,'failed_execution_attempts':0})
writej(DEST/'artifact-binding.json',{'kernel':{'gzip_path':'kernel.elf.gz','gzip_size':len(kernel_gz),'gzip_sha256':digest(kernel_gz),'raw_size':len(kernel),'raw_sha256':digest(kernel),'matches_native_exec_receipt_and_production_recorder':True,'captured_before_cancel_and_target_reuse':True},'native_qemu':inv['real_qemu'],'test_adapter':inv['shim'],'recorded_qemu_sha_identifies_adapter_not_native_binary':True,'adaptation':'test-only PATH executable delegates --version directly and execs recorded native QEMU with original production argv plus only -S; source, kernel ELF and production serial argv unchanged','not_executed':{'rust_entry':True,'guest_test':True,'complete_boot':True},'serial':{'path':'serial.log','size':len(serial),'sha256':digest(serial),'empty':True},'qemu_record':{'raw_exit_code':qemu['raw_exit_code'],'timed_out':qemu['timed_out'],'finalized':False,'native_exit_code_known':False,'limitation':'wrapper was killed during cancellation before final rewrite; native pidfd proves exit but gives no wait/reap status for this non-direct child'},'no_TCP_lease_existed':'profile has no GDB/server/monitor TCP endpoint; no TCP port-release claim for this case'})
index=[]
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o755 if name.endswith('.py') or name.endswith('/qemu-system-x86_64') else 0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(data));index.append({'name':name,'size':len(data),'sha256':digest(data)})
(DEST/'raw-evidence.tar.gz').write_bytes(gzip.compress(buf.getvalue(),mtime=0))
writej(DEST/'raw-members.json',index)
(DEST/'RAW_MEMBER_SHA256SUMS').write_text(''.join(r['sha256']+'  '+r['name']+'\n' for r in index))
with tarfile.open(DEST/'raw-evidence.tar.gz','r:gz') as tar:
 actual=tar.getmembers();require(len(actual)==len(index),'member count changed')
 for member,expected in zip(actual,index):
  require(member.isfile() and member.name==expected['name'],'unsafe/different tar member')
  data=tar.extractfile(member).read()
  require(len(data)==expected['size'] and digest(data)==expected['sha256'],'tar readback bytes differ')
verification={'regular_tar_members':len(index),'all_member_bytes_read_back_and_sha256_checked':True,'saved_kernel_gzip_readback_sha256_and_size_checked':True,'immutable_source_files_checked':len(source_records),'source_files_match_recorded_runtime_and_published_tree':True,'actual_runtime_tool_session':50773,'actual_runtime_tool_exit_code':0,'claim_scope':'one actual paused native QEMU cancellation case; no guest execution or kernel boot/regression pass','production_source_modified':False,'VM_or_Cargo_invoked_during_archiving':False}
writej(DEST/'archive-verification.json',verification)
(DEST/'README.md').write_text('''# Actual ktest CLI cancellation, 2026-10-16\n\nOne real `ktest/run.py --crate ostd --skip-osdk-install` process launched the source-built OSTD ELF through native QEMU 8.2.2, then received SIGTERM through the controller-owned CLI pidfd. Tool session 50773 completed with exit 0; that is the cancellation controller result. The ktest CLI itself returned 143 and its aggregate result remains `passed:false`, `interrupted_by:SIGTERM`, `exit_code:143`.\n\nThe test-only PATH executable forwards `--version` to native QEMU and executes the recorded production argv with only `-S` appended. It records its own PID immediately before `execv`; the controller retains that same native QEMU pidfd and its direct CLI Popen/pidfd in the same fork/exec namespace. No `/proc` PID interpretation or late numeric-PID signal was used. The virtual CPU remains paused before guest execution: this is neither a Rust-entry assertion, a kernel boot pass, nor a guest regression pass.\n\nThe CLI and native QEMU pidfds were live before CLI-only SIGTERM, and both signaled exit afterward. The stable workspace-lock inode was busy before cancellation and could be reacquired after CLI exit. All six direct command leaders have successful WNOWAIT-anchor cleanup/reap receipts; this does not claim adoption or reaping of grandchildren. The cancelled Cargo/OSDK command actually returned raw 13, with effective cancellation exit 143; both values are preserved. Controller final cleanup found both pidfds already exited and sent no extra signal. Exactly one native VM launch occurred. No GDB or other TCP listener was configured, so this case makes no TCP-release assertion.\n\nThe launch source is published commit `efb02440ad6fff3b7a1a5d5019f660743d74ab32`, tree `bfae38050e0b6473df7a46a6e02669166cf3055f`; runtime git status was empty. The environment and immutable source snapshot bind the exact runner SHA `e18d02adb932ba213f9f78cdad9457a439465779edb46542eec8ecf590514b1e`. The existing target from the preceding full two-crate run was explicitly reused, OSDK installation was skipped, and the actual log records an incremental release build in 8.27 seconds. This archive makes no fresh full-compile claim. The controller saved and SHA-checked the real 2,004,424-byte executed ELF before cancellation and target reuse. No production source or ELF was adapted.\n\nThe recorder was terminated before finalizing `qemu.json`: its raw exit remains null, `timed_out:false`, and the actual serial file is empty. The native pidfd proves termination, not a native exit status; raw 33 is not claimed. The whole completed output is preserved, including that empty serial file. `manifest-preservation.json` reports that no project manifest existed when the controller held the stable lock, so no manifest was renamed in this attempt. The preservation lock was released before the new CLI took the same lock; root had serialized kernel activity.\n\nThere was one launch attempt and it passed the cancellation checks, with no failed launch to omit. `controller.py`, `qemu-hold.py`, `commands.json`, raw plan/preflight/controller files, every completed production output file, and the exact immutable source files are retained. `raw-members.json` and `RAW_MEMBER_SHA256SUMS` index every regular file in `raw-evidence.tar.gz`; all members were decompressed and SHA-checked after creation. `source-binding.json` distinguishes this source binding from a full source-tree archive. No VM, Cargo command, or source check-out was run during archiving.\n''')
files=sorted(p for p in DEST.rglob('*') if p.is_file())
(DEST/'SHA256SUMS').write_text(''.join(digest(p.read_bytes())+'  '+str(p.relative_to(DEST))+'\n' for p in files))
for line in (DEST/'SHA256SUMS').read_text().splitlines():
 h,name=line.split('  ',1);require(digest((DEST/name).read_bytes())==h,'final archive SHA differs')
print(json.dumps({'directory':str(DEST),'files_including_manifest':len(files)+1,'raw_members':len(index),'source_files':len(source_records),'sha256sums_sha256':digest((DEST/'SHA256SUMS').read_bytes()),'bytes':sum(p.stat().st_size for p in DEST.rglob('*') if p.is_file())},indent=2))
