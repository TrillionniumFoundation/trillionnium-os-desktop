import fcntl, hashlib, json, os, select, signal, socket, subprocess, sys, time
from pathlib import Path
root = Path(__file__).resolve().parent
project = root / 'baseline-project'
here = project / 'support/build/ktest'
here.mkdir(parents=True)
(here/'run.py').write_bytes((root/'run-before.py').read_bytes())
verify = project/'support/build/verify-source.py'
verify.write_text('''import json, os, signal, socket, subprocess, sys, time\nfrom pathlib import Path\nsignal.signal(signal.SIGTERM, signal.SIG_IGN)\nchild=subprocess.Popen([sys.executable, '-I', '-c', "import signal,time; signal.signal(signal.SIGTERM,signal.SIG_IGN); time.sleep(60)"])\nlease=socket.socket(); lease.bind(('127.0.0.1',0)); lease.listen()\nPath(os.environ['FIXTURE_READY']).write_text(json.dumps({'leader':os.getpid(),'descendant':child.pid,'address':lease.getsockname()}))\ntime.sleep(60)\n''')
ready = root/'baseline-ready.json'
env = os.environ | {'FIXTURE_READY':str(ready)}
argv = [sys.executable,'-I',str(here/'run.py'),'--output',str(root/'baseline-output')]
record = {'argv':argv,'source_sha256':hashlib.sha256((here/'run.py').read_bytes()).hexdigest(),'namespace_evidence':'all fixtures fork/exec from this controller; no namespace switch or /proc inspection','commands':['SIGTERM sent only to retained CLI Popen','pidfd observation of both same-namespace fixture PIDs before cleanup','fresh TCP bind and flock tests']}
fds=[]
p=None
try:
 with (root/'baseline-console.log').open('wb') as log:
  p=subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  deadline=time.monotonic()+5
  while not ready.exists():
   if time.monotonic()>deadline: raise RuntimeError('fixture did not become ready')
   time.sleep(.01)
  info=json.loads(ready.read_text()); record['fixture']=info
  fds=[os.pidfd_open(info[k]) for k in ('leader','descendant')]
  lockpath=project/'support/build/out-kernel.lock'
  def lock_available():
   with lockpath.open('a') as f:
    try: fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:return False
    return True
  record['lock_available_before']=lock_available()
  p.send_signal(signal.SIGTERM); record['cli_exit']=p.wait(timeout=5)
  record['live_pidfds_after_cli']=[not bool(select.select([fd],[],[],.1)[0]) for fd in fds]
  record['lock_available_after']=lock_available()
  with socket.socket() as lease:
   try: lease.bind(tuple(info['address'])); record['lease_free_after_cli']=True
   except OSError: record['lease_free_after_cli']=False
  record['success_result_exists']=(root/'baseline-output/result.json').exists()
  record['finding_reproduced']=(record['cli_exit']==-signal.SIGTERM and all(record['live_pidfds_after_cli']) and not record['lease_free_after_cli'] and record['lock_available_after'] and not record['lock_available_before'])
finally:
 for fd in fds:
  try:signal.pidfd_send_signal(fd,signal.SIGKILL)
  except ProcessLookupError:pass
 for fd in fds:
  record.setdefault('cleanup_exited',[]).append(bool(select.select([fd],[],[],3)[0]));os.close(fd)
 if p is not None and p.returncode is None:p.kill();p.wait(timeout=5)
 (root/'baseline-observation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
if not record.get('finding_reproduced'):raise SystemExit(1)
