import hashlib,importlib.util,json,os,subprocess,sys,tempfile
from pathlib import Path
sys.dont_write_bytecode=True
repo=Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop');scratch=Path('/workspace/scratch/ae1a8cf05419');tempfile.tempdir=str(scratch)
spec=importlib.util.spec_from_file_location('manifest_audit_fixture',repo/'support/build/tests/test_kernel_runner.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
fixture=module.KernelRunnerTests('test_owned_manifest_removed_after_success');fixture.setUp()
try:
 stat_script='''#!/usr/bin/python3
import json,os,subprocess,sys
from pathlib import Path
result=subprocess.run(['/usr/bin/stat', *sys.argv[1:]], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
path=Path(sys.argv[-1])
root=Path(os.environ['MOCK_PROJECT'])
if result.returncode==0 and path==root/'kernel/asterinas/kernel/OSDK.toml':
    owned_identity=result.stdout.decode().strip()
    replacement=path.with_name('foreign-manifest-stage')
    replacement.write_text('foreign manifest installed after identity was checked\\n')
    foreign_identity='%s:%s' % (replacement.stat().st_dev,replacement.stat().st_ino)
    os.replace(replacement,path)
    (root/'race-proof.json').write_text(json.dumps({'owned_identity_checked':owned_identity,'foreign_identity_installed':foreign_identity,'foreign_bytes':path.read_text()}))
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
raise SystemExit(result.returncode)
'''
 fixture.write_tool('stat',stat_script)
 result=fixture.run_runner()
 proof=json.loads((fixture.root/'race-proof.json').read_text());manifest=fixture.kernel/'OSDK.toml'
 assert proof['owned_identity_checked']!=proof['foreign_identity_installed']
 assert result.returncode==0 and not manifest.exists()
 report={'schema':1,'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source':'support/build/kernel.sh','source_sha256':hashlib.sha256((repo/'support/build/kernel.sh').read_bytes()).hexdigest(),'issue':'cleanup identity stat followed by pathname unlink permits foreign replacement deletion','code_lines':[45,46,47],'fixture_scope':'Unmodified copied shell runner and supervisor/checker from project; disposable mock project and host tools only; no production manifest, Cargo, kernel build or QEMU','trigger':'stat wrapper returns the actual owned inode identity while atomically replacing the disposable manifest with a different foreign inode before shell rm','probe_stat_wrapper':stat_script,'result':{'runner_exit_code':result.returncode,'runner_stdout':result.stdout,'foreign_manifest_deleted':not manifest.exists(),**proof},'reproduction':'Load KernelRunnerTests fixture read-only, setUp(), override only mock-bin/stat with recorded wrapper, run_runner(), inspect race-proof.json and fixture manifest. Existing test_manifest_replaced_during_build_is_preserved covers replacement before the stat, not this stat/unlink interval.'}
 destination=scratch/'next7-manifest-cleanup-probe.json';destination.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'head':report['git_head'],'runner_exit_code':result.returncode,'foreign_manifest_deleted':not manifest.exists(),**proof,'report':str(destination),'report_sha256':hashlib.sha256(destination.read_bytes()).hexdigest()},indent=2))
finally:
 fixture.doCleanups()
