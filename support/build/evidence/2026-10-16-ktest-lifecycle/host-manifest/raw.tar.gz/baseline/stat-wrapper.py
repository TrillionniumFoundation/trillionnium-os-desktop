#!/usr/bin/python3
import json,os,subprocess,sys
from pathlib import Path
result=subprocess.run(['/usr/bin/stat', *sys.argv[1:]], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
path=Path(sys.argv[-1])
root=Path(os.environ['MOCK_PROJECT'])
if result.returncode==0 and path==root/'kernel/asterinas/kernel/OSDK.toml':
    owned_identity=result.stdout.decode().strip()
    replacement=path.with_name('foreign-manifest-stage')
    replacement.write_text('foreign manifest installed after identity was checked\n')
    foreign_identity='%s:%s' % (replacement.stat().st_dev,replacement.stat().st_ino)
    os.replace(replacement,path)
    (root/'race-proof.json').write_text(json.dumps({'owned_identity_checked':owned_identity,'foreign_identity_installed':foreign_identity,'foreign_bytes':path.read_text()}))
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
raise SystemExit(result.returncode)
