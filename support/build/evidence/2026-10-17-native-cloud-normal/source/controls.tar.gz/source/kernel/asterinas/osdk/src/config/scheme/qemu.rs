// SPDX-License-Identifier: MPL-2.0

//! A module about QEMU settings and arguments.

use std::{path::PathBuf, process};

use clap::ValueEnum;

use crate::{
    arch::{Arch, get_default_arch},
    config::unix_args::{apply_kv_array, get_key, split_to_kv_array},
    error::Errno,
    error_msg,
};

#[derive(Clone, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
pub struct QemuScheme {
    /// The additional arguments for running QEMU, in the form of raw
    /// command line arguments.
    pub args: Option<String>,
    /// The additional qemu argument after the `-drive` option for the
    /// boot device, in the form of raw command line arguments, comma
    /// included. For example, `",if=virtio,media=disk,index=2"`.
    /// The `format` and the `file` options are not allowed to set.
    ///
    /// This option only works with [`super::BootMethod::GrubQcow2`] and
    /// [`super::BootMethod::GrubRescueIso`].
    ///
    /// This option exist because different firmwares may need
    /// different interface types for the boot drive.
    ///
    /// See <https://www.qemu.org/docs/master/system/invocation.html>
    /// for details about `-drive` option.
    pub bootdev_append_options: Option<String>,
    /// The path of qemu
    pub path: Option<PathBuf>,
    /// Whether to run QEMU as daemon and connect to it in monitor mode.
    pub with_monitor: Option<bool>,
    /// The transport used by OSDK's managed QEMU monitor.
    pub monitor_transport: Option<MonitorTransport>,
    /// The QEMU output log used for panic translation and coverage collection.
    /// Relative paths are resolved from the OSDK working directory.
    pub log_file: Option<PathBuf>,
    /// Host daemons and their arguments to run for the duration of QEMU.
    pub with_daemons: Option<Vec<DaemonScheme>>,
}

#[derive(Clone, Debug, Deserialize, Eq, Serialize)]
pub struct Qemu {
    pub args: String,
    /// This finalized config has a unorthodox `Option` because
    /// we cannot provide a default value for it. The default
    /// value is determined by the final running routine
    /// [`crate::bundle::Bundle::run`].
    pub bootdev_append_options: Option<String>,
    pub path: PathBuf,
    /// Whether to run QEMU as daemon and connect to it in monitor mode.
    pub with_monitor: bool,
    /// The transport used by OSDK's managed QEMU monitor.
    #[serde(default)]
    pub monitor_transport: MonitorTransport,
    /// The QEMU output log used for panic translation and coverage collection.
    pub log_file: Option<PathBuf>,
    /// Host daemons and their arguments to run for the duration of QEMU.
    #[serde(default)]
    pub with_daemons: Vec<DaemonScheme>,
}

impl Default for Qemu {
    fn default() -> Self {
        Qemu {
            args: String::new(),
            bootdev_append_options: None,
            path: PathBuf::from(get_default_arch().system_qemu()),
            with_monitor: false,
            monitor_transport: MonitorTransport::default(),
            log_file: None,
            with_daemons: Vec::new(),
        }
    }
}

// Implements `PartialEq` for `Qemu`, comparing `args` while ignoring numeric characters
// (random ports), and comparing the remaining settings normally.
impl PartialEq for Qemu {
    fn eq(&self, other: &Self) -> bool {
        fn strip_numbers(input: &str) -> String {
            input.chars().filter(|c| !c.is_numeric()).collect()
        }

        strip_numbers(&self.args) == strip_numbers(&other.args)
            && self.bootdev_append_options == other.bootdev_append_options
            && self.path == other.path
            && self.with_monitor == other.with_monitor
            && self.monitor_transport == other.monitor_transport
            && self.log_file == other.log_file
            && self.with_daemons == other.with_daemons
    }
}

impl Qemu {
    pub fn apply_qemu_args(&mut self, args: &Vec<String>) {
        let mut joined = split_to_kv_array(&self.args);

        // Check the soundness of qemu arguments
        for arg in joined.iter() {
            check_qemu_arg(arg);
        }

        apply_kv_array(&mut joined, args, " ", MULTI_VALUE_KEYS);

        self.args = joined.join(" ");
    }
}

impl QemuScheme {
    pub fn inherit(&mut self, from: &Self) {
        if self.args.is_none() {
            self.args.clone_from(&from.args);
        }
        if self.path.is_none() {
            self.path.clone_from(&from.path);
        }
        if self.with_monitor.is_none() {
            self.with_monitor.clone_from(&from.with_monitor);
        }
        if self.monitor_transport.is_none() {
            self.monitor_transport = from.monitor_transport;
        }
        if self.log_file.is_none() {
            self.log_file.clone_from(&from.log_file);
        }
        if self.with_daemons.is_none() {
            self.with_daemons.clone_from(&from.with_daemons);
        }
    }

    pub fn finalize(self, arch: Arch) -> Qemu {
        Qemu {
            args: self.args.unwrap_or_default(),
            bootdev_append_options: self.bootdev_append_options,
            path: self.path.unwrap_or(PathBuf::from(arch.system_qemu())),
            with_monitor: self.with_monitor.unwrap_or(false),
            monitor_transport: self.monitor_transport.unwrap_or_default(),
            log_file: self.log_file,
            with_daemons: self.with_daemons.unwrap_or_default(),
        }
    }
}

/// The connection used to control QEMU's managed monitor.
#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, PartialEq, Serialize, ValueEnum)]
#[serde(rename_all = "lowercase")]
pub enum MonitorTransport {
    /// A temporary UNIX socket served by QEMU.
    #[default]
    Unix,
    /// A private preconnected IPv4 loopback socket inherited by QEMU.
    Tcp,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub(crate) struct DaemonScheme {
    pub(crate) path: PathBuf,
    #[serde(default)]
    pub(crate) args: Vec<String>,
}

// Below are checked keys in qemu arguments. The key list is non-exhaustive.

/// Keys with multiple values
const MULTI_VALUE_KEYS: &[&str] = &[
    "-device", "-chardev", "-object", "-netdev", "-drive", "-cdrom",
];
/// Keys with only single value
const SINGLE_VALUE_KEYS: &[&str] = &["-cpu", "-machine", "-m", "-serial", "-monitor", "-display"];
/// Keys with no value
const NO_VALUE_KEYS: &[&str] = &["--no-reboot", "-nographic", "-enable-kvm"];
/// Keys are not allowed to set in configuration files and command line
const NOT_ALLOWED_TO_SET_KEYS: &[&str] = &["-kernel", "-append", "-initrd"];

fn check_qemu_arg(arg: &str) {
    let key = if let Some(key) = get_key(arg, " ") {
        key
    } else {
        arg.to_string()
    };

    if NOT_ALLOWED_TO_SET_KEYS.contains(&key.as_str()) {
        error_msg!("`{}` is not allowed to set", arg);
        process::exit(Errno::ParseMetadata as _);
    }

    if NO_VALUE_KEYS.contains(&key.as_str()) && key.as_str() != arg {
        error_msg!("`{}` cannot have value", arg);
        process::exit(Errno::ParseMetadata as _);
    }

    if (SINGLE_VALUE_KEYS.contains(&key.as_str()) || MULTI_VALUE_KEYS.contains(&key.as_str()))
        && key.as_str() == arg
    {
        error_msg!("`{}` should have value", arg);
        process::exit(Errno::ParseMetadata as _);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn monitor_transport_defaults_to_unix_for_old_configs() {
        let qemu = QemuScheme::default().finalize(Arch::X86_64);
        assert_eq!(qemu.monitor_transport, MonitorTransport::Unix);
        let mut old_config = toml::Value::try_from(&qemu).unwrap();
        old_config
            .as_table_mut()
            .unwrap()
            .remove("monitor_transport");
        let restored: Qemu = old_config.try_into().unwrap();
        assert_eq!(restored.monitor_transport, MonitorTransport::Unix);
        assert_eq!(qemu, restored);
    }

    #[test]
    fn monitor_transport_inherits_and_can_be_overridden() {
        let parent: QemuScheme = toml::from_str("monitor_transport = 'tcp'").unwrap();
        let mut inherited = QemuScheme::default();
        inherited.inherit(&parent);
        assert_eq!(
            inherited.finalize(Arch::X86_64).monitor_transport,
            MonitorTransport::Tcp
        );
        let mut overridden: QemuScheme = toml::from_str("monitor_transport = 'unix'").unwrap();
        overridden.inherit(&parent);
        assert_eq!(
            overridden.finalize(Arch::X86_64).monitor_transport,
            MonitorTransport::Unix
        );
        assert!(toml::from_str::<QemuScheme>("monitor_transport = 'udp'").is_err());
    }
}
