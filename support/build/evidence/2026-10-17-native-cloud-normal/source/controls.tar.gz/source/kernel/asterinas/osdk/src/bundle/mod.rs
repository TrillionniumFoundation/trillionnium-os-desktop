// SPDX-License-Identifier: MPL-2.0

pub mod bin;
pub mod file;
mod monitor;
pub mod vm_image;

use bin::{AsterBin, AsterBinType};
use file::{BundleFile, Initramfs};
use monitor::{MonitorEndpoint, MonitorStream};
use std::{
    io::{BufRead, BufReader, Write},
    process::{self, ExitStatus},
    time::{Duration, Instant},
};
use vm_image::{AsterVmImage, AsterVmImageType};

use std::{
    path::{Path, PathBuf},
    time::SystemTime,
};

use crate::{
    arch::Arch,
    config::{
        Config,
        scheme::{Action, ActionChoice, BootMethod, BootProtocol},
    },
    daemon::{DaemonSupervisor, SignalGuard},
    error::Errno,
    error_msg,
    util::{DirGuard, new_command_checked_exists},
};

/// Timeout for monitor reads; this is intentionally longer than the daemon
/// supervision poll interval because monitor responses are socket-based.
const MONITOR_POLL_INTERVAL: Duration = Duration::from_millis(100);
const MONITOR_CONNECT_TIMEOUT: Duration = Duration::from_secs(5);

/// The osdk bundle artifact that stores as `bundle` directory.
///
/// This `Bundle` struct is used to track a bundle on a filesystem. Every modification to the bundle
/// would result in file system writes. But the bundle will not be removed from the file system when
/// the `Bundle` is dropped.
pub struct Bundle {
    manifest: BundleManifest,
    path: PathBuf,
}

/// The osdk bundle artifact manifest that stores as `bundle.toml`.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct BundleManifest {
    pub initramfs: Option<Initramfs>,
    pub aster_bin: Option<AsterBin>,
    pub vm_image: Option<AsterVmImage>,
    pub config: Config,
    pub action: ActionChoice,
    pub last_modified: SystemTime,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum QemuExit {
    Success,
    Failed,
    Unknown,
}

pub(crate) fn classify_qemu_exit_status(exit_status: ExitStatus) -> QemuExit {
    if exit_status.success() {
        return QemuExit::Success;
    }

    let Some(qemu_exit_code) = exit_status.code() else {
        return QemuExit::Unknown;
    };

    // For x86 QEMU with `isa-debug-exit`, the guest exit code is encoded as
    // `(code << 1) | 1`. Do not decode QEMU's own failure exit code `1`.
    if qemu_exit_code == 1 {
        return QemuExit::Unknown;
    }

    let kernel_exit_code = qemu_exit_code >> 1;
    match kernel_exit_code {
        // Corresponds to `ostd::QemuExitCode::Success`.
        0x10 => QemuExit::Success,
        // Corresponds to `ostd::QemuExitCode::Failed`.
        0x20 => QemuExit::Failed,
        // Unknown exit code, e.g., a triple fault.
        _ => QemuExit::Unknown,
    }
}

impl Bundle {
    /// This function creates a new `Bundle` without adding any files.
    pub fn new(path: impl AsRef<Path>, config: &Config, action: ActionChoice) -> Self {
        std::fs::create_dir_all(path.as_ref()).unwrap();
        let config_initramfs = match action {
            ActionChoice::Run => config.run.boot.initramfs.as_ref(),
            ActionChoice::Test => config.test.boot.initramfs.as_ref(),
        };
        let initramfs = if let Some(ref initramfs) = config_initramfs {
            if !initramfs.exists() {
                error_msg!("initramfs file not found: {}", initramfs.display());
                process::exit(Errno::BuildCrate as _);
            }
            Some(Initramfs::new(initramfs).copy_to(&path))
        } else {
            None
        };
        let mut created = Self {
            manifest: BundleManifest {
                initramfs,
                aster_bin: None,
                vm_image: None,
                config: config.clone(),
                action,
                last_modified: SystemTime::now(),
            },
            path: path.as_ref().to_path_buf(),
        };
        created.write_manifest_to_fs();
        created
    }

    // Load the bundle from the file system. If the bundle does not exist or have inconsistencies,
    // it will return `None`.
    pub fn load(path: impl AsRef<Path>) -> Option<Self> {
        let manifest_file_path = path.as_ref().join("bundle.toml");
        let manifest_file_content = std::fs::read_to_string(manifest_file_path).ok()?;
        let manifest: BundleManifest = toml::from_str(&manifest_file_content).ok()?;

        let _dir_guard = DirGuard::change_dir(&path);

        if let Some(aster_bin) = &manifest.aster_bin
            && !aster_bin.validate()
        {
            return None;
        }
        if let Some(vm_image) = &manifest.vm_image
            && !vm_image.validate()
        {
            return None;
        }
        if let Some(initramfs) = &manifest.initramfs
            && !initramfs.validate()
        {
            return None;
        }

        Some(Self {
            manifest,
            path: path.as_ref().to_path_buf(),
        })
    }

    pub fn can_run_with_config(&self, config: &Config, action: ActionChoice) -> Result<(), String> {
        // If built for testing, better not to run it. Vice versa.
        if self.manifest.action != action {
            return Err(format!(
                "The bundle is built for {:?}",
                self.manifest.action
            ));
        }

        let self_action = match self.manifest.action {
            ActionChoice::Run => &self.manifest.config.run,
            ActionChoice::Test => &self.manifest.config.test,
        };
        let config_action = match action {
            ActionChoice::Run => &config.run,
            ActionChoice::Test => &config.test,
        };

        // Compare the manifest with the run configuration except the initramfs and the boot method.
        if self_action.grub != config_action.grub
            || self_action.qemu != config_action.qemu
            || self_action.build != config_action.build
            || self_action.boot.kcmdline != config_action.boot.kcmdline
        {
            return Err("The bundle is not compatible with the run configuration".to_owned());
        }

        // Checkout if the files on disk supports the boot method
        match config_action.boot.method {
            BootMethod::VmmDirect => {
                if self.manifest.aster_bin.is_none() {
                    return Err("Kernel ELF is required for direct ELF booting".to_owned());
                };

                // Validate the kernel binary type against the configured boot protocol.
                // This prevents reusing an incompatible binary (e.g. ELF vs. `bzImage`) when
                // switching boot methods (for example, from a Grub ISO to `vmm-direct`),
                // which would otherwise cause boot failures.
                let aster_bin_type = self.manifest.aster_bin.as_ref().unwrap().typ();
                let expects_linux = matches!(aster_bin_type, AsterBinType::BzImage(_));
                let actual_linux = config_action.grub.boot_protocol == BootProtocol::Linux;
                if expects_linux != actual_linux {
                    return Err(
                        "The boot protocol is not compatible with the kernel binary".to_owned()
                    );
                }
            }
            BootMethod::GrubRescueIso => {
                let Some(ref vm_image) = self.manifest.vm_image else {
                    return Err("VM image is required for QEMU booting".to_owned());
                };
                if !matches!(vm_image.typ(), AsterVmImageType::GrubIso(_)) {
                    return Err("VM image in the bundle is not a Grub ISO image".to_owned());
                }
            }
            BootMethod::GrubQcow2 => {
                let Some(ref vm_image) = self.manifest.vm_image else {
                    return Err("VM image is required for QEMU booting".to_owned());
                };
                if !matches!(vm_image.typ(), AsterVmImageType::Qcow2(_)) {
                    return Err("VM image in the bundle is not a Qcow2 image".to_owned());
                }
            }
        }

        // Compare the initramfs.
        let initramfs_err =
            "The initramfs in the bundle is different from the one in the run configuration"
                .to_owned();
        match (&self.manifest.initramfs, &config_action.boot.initramfs) {
            (Some(initramfs), Some(initramfs_path)) => {
                let config_initramfs = Initramfs::new(initramfs_path);
                if initramfs.size() != config_initramfs.size()
                    || initramfs.modified_time() < config_initramfs.modified_time()
                {
                    return Err(initramfs_err);
                }
            }
            (None, None) => {}
            _ => {
                return Err(initramfs_err);
            }
        };

        Ok(())
    }

    pub fn last_modified_time(&self) -> SystemTime {
        self.manifest.last_modified
    }

    pub fn run(&self, config: &Config, action: ActionChoice) {
        let exit_status = self.run_qemu_and_wait(config, action);
        // FIXME: When panicking it sometimes returns success, why?
        match classify_qemu_exit_status(exit_status) {
            QemuExit::Success => {}
            QemuExit::Failed => std::process::exit(1),
            QemuExit::Unknown => std::process::exit(2),
        }
    }

    pub(crate) fn run_qemu_and_wait(&self, config: &Config, action: ActionChoice) -> ExitStatus {
        match self.can_run_with_config(config, action) {
            Ok(()) => {}
            Err(msg) => {
                error_msg!("{}", msg);
                std::process::exit(Errno::RunBundle as _);
            }
        }
        let action = match action {
            ActionChoice::Run => &config.run,
            ActionChoice::Test => &config.test,
        };

        let signal_guard = match SignalGuard::install() {
            Ok(guard) => guard,
            Err(errno) => process::exit(errno as _),
        };
        let mut qemu_cmd = new_command_checked_exists(&action.qemu.path);
        qemu_cmd.current_dir(&config.work_dir);

        match action.boot.method {
            BootMethod::VmmDirect => {
                let aster_bin = self.manifest.aster_bin.as_ref().unwrap();
                qemu_cmd
                    .arg("-kernel")
                    .arg(self.path.join(aster_bin.path()));
                if let Some(ref initramfs) = action.boot.initramfs {
                    qemu_cmd.arg("-initrd").arg(initramfs);
                } else {
                    info!("No initramfs specified");
                };
                qemu_cmd.arg("-append").arg(action.boot.kcmdline.join(" "));
            }
            BootMethod::GrubRescueIso => {
                let vm_image = self.manifest.vm_image.as_ref().unwrap();
                assert!(matches!(vm_image.typ(), AsterVmImageType::GrubIso(_)));
                let bootdev_opts = action
                    .qemu
                    .bootdev_append_options
                    .as_deref()
                    .unwrap_or(",index=2,media=cdrom");
                qemu_cmd.arg("-drive").arg(format!(
                    "file={},format=raw{}",
                    self.path.join(vm_image.path()).to_string_lossy(),
                    bootdev_opts,
                ));
            }
            BootMethod::GrubQcow2 => {
                let vm_image = self.manifest.vm_image.as_ref().unwrap();
                assert!(matches!(vm_image.typ(), AsterVmImageType::Qcow2(_)));
                // FIXME: this doesn't work for regular QEMU, but may work for TDX.
                let bootdev_opts = action
                    .qemu
                    .bootdev_append_options
                    .as_deref()
                    .unwrap_or(",if=virtio");
                qemu_cmd.arg("-drive").arg(format!(
                    "file={},format=qcow2{}",
                    self.path.join(vm_image.path()).to_string_lossy(),
                    bootdev_opts,
                ));
            }
        };

        match shlex::split(&action.qemu.args) {
            Some(args) => {
                for arg in args {
                    qemu_cmd.arg(arg);
                }
            }
            None => {
                error_msg!("Failed to parse qemu args: {:#?}", &action.qemu.args);
                process::exit(Errno::ParseMetadata as _);
            }
        }

        let mut daemon_supervisor = match DaemonSupervisor::start(
            &action.qemu.with_daemons,
            &config.work_dir,
            &signal_guard,
        ) {
            Ok(supervisor) => supervisor,
            Err(errno) => process::exit(errno as _),
        };

        let exit_status = if action.qemu.with_monitor
            && let Some(qemu_log_file) = &action.qemu.log_file
        {
            let qemu_log_path = config.work_dir.join(qemu_log_file);
            let (mut qemu_child, endpoint) =
                MonitorEndpoint::spawn(action.qemu.monitor_transport, qemu_cmd).unwrap_or_else(
                    |error| {
                        error_msg!("failed to spawn QEMU with its managed monitor: {error}");
                        daemon_supervisor.abort(None, Errno::ExecuteCommand);
                    },
                );
            let mut qemu_monitor_stream = match connect_monitor(
                &endpoint,
                &mut qemu_child,
                &signal_guard,
                &mut daemon_supervisor,
            ) {
                Ok(stream) => stream,
                Err(errno) => daemon_supervisor.abort(Some(&mut qemu_child), errno),
            };
            wait_until_guest_kernel_shutdown(
                config,
                &qemu_log_path,
                &mut qemu_monitor_stream,
                &mut qemu_child,
                &signal_guard,
                &mut daemon_supervisor,
            );
            info!("QEMU monitor wait ended; inspecting guest output");

            self.post_run_action(config, action, Some(&mut qemu_monitor_stream));

            let _ = qemu_monitor_stream.write_all(b"quit\n");
            match daemon_supervisor.wait_for_qemu(&mut qemu_child) {
                Ok(status) => status,
                Err(errno) => daemon_supervisor.abort(Some(&mut qemu_child), errno),
            }
        } else {
            info!("Running QEMU: {qemu_cmd:#?}");
            let Ok(mut qemu_child) = qemu_cmd.spawn() else {
                daemon_supervisor.abort(None, Errno::ExecuteCommand);
            };
            let exit_status = match daemon_supervisor.wait_for_qemu(&mut qemu_child) {
                Ok(status) => status,
                Err(errno) => daemon_supervisor.abort(Some(&mut qemu_child), errno),
            };
            self.post_run_action(config, action, None);
            exit_status
        };

        fn connect_monitor(
            endpoint: &MonitorEndpoint,
            qemu_child: &mut process::Child,
            signal: &SignalGuard,
            daemon_supervisor: &mut DaemonSupervisor<'_>,
        ) -> Result<MonitorStream, Errno> {
            if matches!(endpoint, MonitorEndpoint::Unix(_)) {
                // Preserve the existing UNIX monitor startup delay.
                std::thread::sleep(Duration::from_secs(1));
            }
            let deadline = Instant::now() + MONITOR_CONNECT_TIMEOUT;
            loop {
                if signal.received_signal().is_some() {
                    return Err(Errno::Interrupted);
                }
                daemon_supervisor.reap_exited_daemons()?;
                match qemu_child.try_wait() {
                    Ok(Some(status)) => {
                        error_msg!("QEMU exited before connecting its monitor: {status}");
                        return Err(Errno::ExecuteCommand);
                    }
                    Ok(None) => {}
                    Err(error) => {
                        error_msg!("failed to inspect QEMU monitor startup: {error}");
                        return Err(Errno::ExecuteCommand);
                    }
                }
                match endpoint.try_connect() {
                    Ok(stream) => {
                        stream
                            .set_write_timeout(Some(MONITOR_POLL_INTERVAL))
                            .map_err(|error| {
                                error_msg!("failed to set QEMU monitor write timeout: {error}");
                                Errno::ExecuteCommand
                            })?;
                        return Ok(stream);
                    }
                    Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => {
                        if Instant::now() >= deadline {
                            error_msg!("timed out connecting to QEMU monitor");
                            return Err(Errno::ExecuteCommand);
                        }
                        std::thread::sleep(MONITOR_POLL_INTERVAL);
                    }
                    Err(error) => {
                        error_msg!("failed to connect to QEMU monitor: {error}");
                        return Err(Errno::ExecuteCommand);
                    }
                }
            }
        }

        fn wait_until_guest_kernel_shutdown(
            config: &Config,
            qemu_log_path: &Path,
            qemu_monitor_stream: &mut MonitorStream,
            qemu_child: &mut process::Child,
            signal: &SignalGuard,
            daemon_supervisor: &mut DaemonSupervisor<'_>,
        ) {
            qemu_monitor_stream
                .set_read_timeout(Some(MONITOR_POLL_INTERVAL))
                .unwrap_or_else(|err| {
                    error_msg!("Failed to set read timeout: {:?}", err);
                    daemon_supervisor.abort(Some(qemu_child), Errno::ExecuteCommand);
                });
            let mut monitor_reader = BufReader::new(&mut *qemu_monitor_stream);
            let mut line = String::new();

            // Check VM status every 0.1 seconds and break the loop if the VM is stopped or hanging.
            while monitor_reader.get_mut().write_all(b"info status\n").is_ok() {
                if signal.received_signal().is_some() {
                    daemon_supervisor.abort(Some(qemu_child), Errno::Interrupted);
                }
                if let Err(errno) = daemon_supervisor.reap_exited_daemons() {
                    daemon_supervisor.abort(Some(qemu_child), errno);
                }
                let Ok(qemu_status) = qemu_child.try_wait() else {
                    daemon_supervisor.abort(Some(qemu_child), Errno::ExecuteCommand);
                };
                if qemu_status.is_some() {
                    break;
                }

                let guest_shutdown = loop {
                    line.clear();
                    let Ok(bytes_read) = monitor_reader.read_line(&mut line) else {
                        break false;
                    };
                    if bytes_read == 0 {
                        break false;
                    }
                    if line.starts_with("VM status:") {
                        break line.trim_end() == "VM status: paused (shutdown)";
                    }
                };

                if guest_shutdown {
                    break;
                }

                if config.target_arch == Arch::RiscV64
                    && let Ok(log_file) = std::fs::File::open(qemu_log_path)
                {
                    let log = rev_buf_reader::RevBufReader::new(&log_file);
                    if log.lines().next().is_some_and(|line| {
                        line.as_ref().is_ok_and(|s| {
                            s.contains("SBI system_reset cannot shut down the underlying machine")
                        })
                    }) {
                        break;
                    }
                }
                std::thread::sleep(MONITOR_POLL_INTERVAL);
            }
        }

        daemon_supervisor.stop_all();
        exit_status
    }

    /// Move the vm_image into the bundle.
    pub fn consume_vm_image(&mut self, vm_image: AsterVmImage) {
        if self.manifest.vm_image.is_some() {
            panic!("vm_image already exists");
        }
        self.manifest.vm_image = Some(vm_image.copy_to(&self.path));
        self.write_manifest_to_fs();
    }

    /// Move the aster_bin into the bundle.
    pub fn consume_aster_bin(&mut self, aster_bin: AsterBin) {
        if self.manifest.aster_bin.is_some() {
            panic!("aster_bin already exists");
        }
        self.manifest.aster_bin = Some(aster_bin.copy_to(&self.path));
        self.write_manifest_to_fs();
    }

    fn write_manifest_to_fs(&mut self) {
        self.manifest.last_modified = SystemTime::now();
        let manifest_file_content = toml::to_string(&self.manifest).unwrap();
        let manifest_file_path = self.path.join("bundle.toml");
        std::fs::write(manifest_file_path, manifest_file_content).unwrap();
    }

    fn post_run_action(
        &self,
        config: &Config,
        action: &Action,
        qemu_monitor_stream: Option<&mut MonitorStream>,
    ) {
        let Some(qemu_log_file) = &action.qemu.log_file else {
            return;
        };

        // Read the configured QEMU output and check if it failed with a panic.
        // Setting a QEMU log is required for source line stack trace because piping the output
        // is less desirable when running QEMU with serial redirected to standard I/O.
        let qemu_log_path = config.work_dir.join(qemu_log_file);
        if let Ok(file) = std::fs::File::open(&qemu_log_path)
            && let Some(aster_bin) = &self.manifest.aster_bin
        {
            crate::util::trace_panic_from_log(file, self.path.join(aster_bin.path()));
        }

        // Find the coverage data information in the QEMU log, and dump it if found.
        if let Some(qemu_monitor_stream) = qemu_monitor_stream
            && let Ok(file) = std::fs::File::open(&qemu_log_path)
        {
            crate::util::dump_coverage_from_qemu(file, qemu_monitor_stream);
        }
    }
}
