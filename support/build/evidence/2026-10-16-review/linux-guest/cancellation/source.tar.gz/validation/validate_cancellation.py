#!/usr/bin/env python3
"""Actual SCM guest cancellation check using owned Popen/pidfd identities."""
from pathlib import Path
import hashlib
import json
import os
import select
import signal
import subprocess
import time

B=Path(__file__).resolve().parent
P=Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop')
ENTRY=P/'support/build/linux-guest/isolate.py'
for sig in [signal.SIGTERM,signal.SIGINT]:
    out=B/('cancel-real-'+signal.Signals(sig).name.lower())
    out.mkdir(mode=0o700)
    runner=out/'runner'
    argv=['python3','-I',str(ENTRY),'--a04-source-root',str(B),'--rootfs',str(B/'current-rootfs'),'--a01-kernel-gz',str(P/'support/build/evidence/2026-10-16/artifacts/kernel.elf.gz'),'--a01-initramfs',str(P/'support/build/evidence/2026-10-16/artifacts/initramfs.cpio.gz'),'--firmware','/usr/share/seabios/bios-256k.bin','--qemu','/usr/bin/qemu-system-x86_64','--out-dir',str(runner),'--jobs','1','--timeout','30','--case','dynamic.scm_rights','--case','static.scm_rights']
    proc=None;pidfd=None;record={'profile':'actual-Asterinas-SCM-guest-cancellation','argv':argv,'entry_sha256':hashlib.sha256(ENTRY.read_bytes()).hexdigest(),'signal':signal.Signals(sig).name}
    try:
        with (out/'console.log').open('xb') as log:
            proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT)
            deadline=time.monotonic()+15
            started=runner/'dynamic.scm_rights/qemu-process.json'
            serial=runner/'dynamic.scm_rights/serial.log'
            while time.monotonic()<deadline and proc.poll() is None:
                if started.exists() and serial.exists() and b'unsupported flags: MSG_CMSG_CLOEXEC' in serial.read_bytes():break
                time.sleep(.02)
            else:raise RuntimeError('real SCM guest did not reach fixed failing path')
            qemu_pid=json.loads(started.read_text())['qemu_pid']
            pidfd=os.pidfd_open(qemu_pid)
            poll=select.poll();poll.register(pidfd,select.POLLIN)
            record['qemu_pid_from_owned_Popen_receipt']=qemu_pid
            record['pidfd_ready_before_signal']=bool(poll.poll(0))
            before=time.monotonic();proc.send_signal(sig);record['cli_exit_code']=proc.wait(timeout=8)
            record['cleanup_seconds']=time.monotonic()-before
            record['qemu_pidfd_exited_after_cli']=bool(poll.poll(1000))
            summary=json.loads((runner/'summary.json').read_text())
            result=summary['results'][0]
            record['summary']=summary
            record['passed']=not record['pidfd_ready_before_signal'] and record['qemu_pidfd_exited_after_cli'] and record['cli_exit_code']==128+sig and summary['aborted'] and summary['matched']==0 and summary['skipped_cases']==1 and result['aborted'] and result['qemu_reaped_exit_code'] is not None and not (runner/'static.scm_rights/qemu-process.json').exists()
    finally:
        if proc is not None and proc.poll() is None:
            proc.kill();proc.wait()
        if pidfd is not None:
            check=select.poll();check.register(pidfd,select.POLLIN)
            if not check.poll(0):
                signal.pidfd_send_signal(pidfd,signal.SIGKILL)
                record['emergency_owned_pidfd_cleanup']=True
            os.close(pidfd)
        (out/'result.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in record.items() if k not in ['summary','argv']}),flush=True)
    if not record.get('passed'):raise SystemExit('cancellation validation failed')
