#!/usr/bin/python3
"""Host-only cancellation fixture. This does not boot any guest."""
import json
import os
from pathlib import Path
import sys
import time

if sys.argv[1:] == ["-version"]:
    print("QEMU emulator version HOST-CANCELLATION-FIXTURE")
    raise SystemExit(0)
import signal
signal.signal(signal.SIGTERM, signal.SIG_IGN)
record = {"pid": os.getpid(), "ppid": os.getppid(), "argv": sys.argv,
          "start_ticks": Path("/proc/self/stat").read_text().split()[21]}
with open(os.environ["A01_CANCEL_FIXTURE_PIDFILE"], "a") as stream:
    stream.write(json.dumps(record) + "\n")
    stream.flush()
while True:
    time.sleep(0.05)
