#!/usr/bin/env python3
"""Independent A01 diagnostic profile; does not replace the original A04 suite.

Uses unmodified PR8 guest.py/replay_qemu.py pack/parser/command APIs and the
same four manifest-pinned ELF. Each reference case runs in a fresh guest so
one ABI deadlock cannot conceal later cases. Full-W1 qualification is false.
"""
import argparse
import concurrent.futures
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import time

BASE=Path(__file__).resolve().parent
def imported(name,path):
 spec=importlib.util.spec_from_file_location(name,path)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 return module
q=imported('a04_isolated_qemu',BASE/'tests/workloads/linux/replay_qemu.py')
g=q.guest

def dump(path,obj):
 with path.open('x') as stream:stream.write(json.dumps(obj,indent=2,sort_keys=True)+'\n')

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--out-dir',type=Path,required=True)
 ap.add_argument('--timeout',type=int,default=30)
 ap.add_argument('--jobs',type=int,default=2)
 ap.add_argument('--case',action='append')
 a=ap.parse_args()
 if not 1<=a.timeout<=180 or not 1<=a.jobs<=2:ap.error('bounded timeout/jobs required')
 a.out_dir.mkdir(mode=0o700,parents=False,exist_ok=False)
 repo=Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop')
 kernel_gz=repo/'support/build/evidence/2026-10-16/artifacts/kernel.elf.gz'
 initramfs=repo/'support/build/evidence/2026-10-16/artifacts/initramfs.cpio.gz'
 firmware=Path('/usr/share/seabios/bios-256k.bin')
 qemu=Path('/usr/bin/qemu-system-x86_64')
 kernel_data,qemu_version=q.preflight(kernel_gz,initramfs,firmware,qemu)
 reference_path=BASE/'tests/workloads/linux/baselines/linux-debian13-x86_64.json'
 reference=json.loads(reference_path.read_text())
 rootfs_manifest=BASE/'support/rootfs/manifest-debian13-x86_64.json'
 cases=g.reference_elf_cases(reference)
 if a.case:
  selected=set(a.case)
  if not selected <= {name for name,_,_ in cases}:ap.error('unknown case')
  cases=[item for item in cases if item[0] in selected]
 source={}
 for r in json.loads((BASE/'source-origin.json').read_text())['files']:
  p=BASE/r['path'];b=p.read_bytes();identity=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
  if identity!=r['git_blob']:raise ValueError('fixed PR8 source changed: '+r['path'])
  source[r['path']]={'sha256':hashlib.sha256(b).hexdigest(),'git_blob':identity}
 dump(a.out_dir/'environment.json',{'profile':'a01-a04-isolated-case-v1','a04_source_commit':'16d672881909a5a9197d82126032b7d962db7d76','source':source,'original_reference_sha256':g.sha_file(reference_path),'qemu_version':qemu_version,'qemu_sha256':g.sha_file(qemu),'firmware_sha256':g.sha_file(firmware),'kernel_sha256':hashlib.sha256(kernel_data).hexdigest(),'original_a01_initramfs_sha256':g.sha_file(initramfs),'rootfs_manifest_sha256':g.sha_file(rootfs_manifest),'full_original_suite_passed':False,'full_w1_passed':False,'jobs':a.jobs,'per_guest_timeout_seconds':a.timeout})
 def run(item):
  name,_,_=item;out=a.out_dir/name;out.mkdir(mode=0o700)
  subset=copy.deepcopy(reference);subset['cases']={name:reference['cases'][name]}
  image=out/'initramfs.cpio.gz'
  manifest=g.pack(initramfs,BASE/'current-rootfs',rootfs_manifest,subset,image,out/'inputs.json')
  kernel=out/'kernel.elf';kernel.write_bytes(kernel_data)
  cmd=q.command_for_qemu(qemu,firmware,kernel,image)
  dump(out/'invocation.json',{'argv':cmd,'timeout_seconds':a.timeout,'subset_of_original_reference':[name],'original_reference_sha256':g.sha_file(reference_path)})
  started=time.time();timed_out=False
  with (out/'serial.log').open('xb') as log:
   try:raw_exit=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=a.timeout,check=False).returncode
   except subprocess.TimeoutExpired:raw_exit=None;timed_out=True
  serial=out/'serial.log'
  result=g.parse_serial(serial.read_text(errors='replace'),reference,manifest,qemu_exit=raw_exit,kernel_sha=g.sha_file(kernel),image_sha=g.sha_file(image))
  dump(out/'guest-result.json',result)
  observed=result['cases'][name]
  record={'case':name,'elapsed_seconds':time.time()-started,'raw_qemu_exit_code':raw_exit,'timed_out':timed_out,'guest_execution_verified':result['guest_execution_verified'],'case_result':observed,'exact_match':not timed_out and result['guest_execution_verified'] and result['guest_compatibility_passed'] and observed.get('status')=='pass','serial_sha256':g.sha_file(serial),'initramfs_sha256':g.sha_file(image),'kernel_sha256':g.sha_file(kernel),'original_suite_qualification':False}
  dump(out/'result.json',record)
  print(json.dumps({'case':name,'exact_match':record['exact_match'],'timed_out':timed_out,'raw_qemu_exit_code':raw_exit}),flush=True)
  return record
 results=list(concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs).map(run,cases))
 summary={'profile':'a01-a04-isolated-case-v1','case_count':len(results),'matched':sum(x['exact_match'] for x in results),'timed_out':sum(x['timed_out'] for x in results),'failed_completed':sum(not x['exact_match'] and not x['timed_out'] for x in results),'original_unmodified_suite_passed':False,'full_w1_passed':False,'results':results}
 dump(a.out_dir/'summary.json',summary)
 print(json.dumps({k:v for k,v in summary.items() if k!='results'}),flush=True)
 return 0 if summary['matched']==len(results) else 2

if __name__=='__main__':raise SystemExit(main())
