import subprocess,sys
raise SystemExit(subprocess.call([sys.executable,'-I','/workspace/scratch/ae1a8cf05419/integration-private-tools/full/I/capture-fixtures/sigint/recorder-driver.py']))
