set pagination off
set confirm off
set tcp auto-retry on
set tcp connect-timeout 15
set remotetimeout 10
set architecture i386:x86-64
python
import gdb, json, os, re, time
settings = json.loads('{"endpoint": "127.0.0.1:12345", "symbol": "ostd::arch::power::try_poweroff", "address": "0xffffffff88001000", "serial": "/workspace/scratch/ae1a8cf05419/integration-private-tools/full/IO/capture-fixtures/sigint/serial.log", "raw": "/workspace/scratch/ae1a8cf05419/integration-private-tools/full/IO/capture-fixtures/sigint/coverage.profraw", "observations": "/workspace/scratch/ae1a8cf05419/integration-private-tools/full/IO/capture-fixtures/sigint/capture-gdb-observations.json", "prefix": "/workspace/scratch/ae1a8cf05419/integration-private-tools/full/IO/capture-fixtures/sigint/capture-serial-prefix.log"}')
result = {"passed": False, "breakpoint": {"symbol": settings["symbol"], "resolved_address": settings["address"]}}
def persist():
    with open(settings["observations"], "w") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
persist()
try:
    gdb.execute("target remote " + settings["endpoint"])
    breakpoint = gdb.Breakpoint("*" + settings["address"], type=gdb.BP_HARDWARE_BREAKPOINT, internal=True)
    gdb.execute("continue")
    pc = int(gdb.parse_and_eval("$pc"))
    result["breakpoint"]["actual_pc"] = hex(pc)
    if pc != int(settings["address"], 16):
        raise gdb.GdbError("guest stopped at an unexpected instruction pointer")
    deadline = time.monotonic() + 5
    while True:
        try:
            with open(settings["serial"], "rb") as source:
                serial = source.read()
        except FileNotFoundError:
            serial = b""
        announcements = re.findall(rb"^#### Coverage: (0x[0-9a-fA-F]+) (\d+)\r?$", serial, re.MULTILINE)
        if len(announcements) == 1:
            break
        if len(announcements) > 1 or time.monotonic() >= deadline:
            raise gdb.GdbError("expected one complete live coverage announcement")
        time.sleep(.02)
    address, length = announcements[0]
    address, length = int(address, 16), int(length)
    if address == 0 or not 0 < length <= 512 * 1024 * 1024:
        raise gdb.GdbError("coverage pointer or size is invalid")
    result["announcement"] = {"address": hex(address), "size": length}
    if os.path.lexists(settings["raw"]):
        raise gdb.GdbError("refusing to overwrite an existing coverage profile")
    command = "monitor memsave 0x%x %d %s" % (address, length, json.dumps(settings["raw"]))
    result["memsave_command"] = command
    gdb.execute(command)
    deadline = time.monotonic() + 5
    while not os.path.isfile(settings["raw"]) or os.path.getsize(settings["raw"]) != length:
        if time.monotonic() >= deadline:
            raise gdb.GdbError("monitor dump did not produce the announced number of bytes")
        time.sleep(.02)
    with open(settings["prefix"], "wb") as prefix:
        prefix.write(serial)
    breakpoint.enabled = False
    breakpoint.delete()
    gdb.execute("detach")
    result["resumed_by_detach"] = True
    result["passed"] = True
    persist()
except Exception as error:
    result["error"] = str(error)
    persist()
    raise gdb.GdbError(str(error))
end
quit
