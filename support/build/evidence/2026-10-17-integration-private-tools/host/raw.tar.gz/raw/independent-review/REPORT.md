# Integration private tools 独立只读审阅

状态：已冻结。未发现本次私有工具路径修复引入的阻塞性回归。

`static-observation.json` 记录实际读取的 baseline/current 文件 SHA256、大小和 AST 比较；`report.json` 记录逐项判断。没有生成或冒充测试执行日志。

- recorder 原有顶层 helper 除 `main` 外 AST 全部不变；唯一新增 helper 为 `select_private_inputs`。原 parser、device 限制、TCP/GDB/monitor handoff、coverage 和 `run_capture` 未放宽。
- 共享 parent recorder 与保存的 baseline 逐字节相同。新 helper 读取一次 raw bytes，用 `compile(raw)` 执行同一内容，再记录其 SHA；模块名不触发其 `main`。
- 默认行为保留 integration 的 `FIRMWARE`：先执行 `transform_args`，unset 的共享选择器原样保留该参数，因此既有 FIRMWARE monkeypatch 不会被共享模块默认值覆盖。
- BIOS 产物哈希读取选定 argv 路径；固定参数在选择前另存，两个 selection 与 exact source SHA 一并记录。
- runner 输入哈希表补充 parent recorder。capture lifecycle fixture 与新 CLI fixture 都复制 integration recorder、capture（按需要）及上一层共享 recorder，目录关系完整。
- 静态检查了六个新增 CLI 测试方法；执行工作由 parent 负责，本 reviewer 未跑完整 suite、fake QEMU、真实 VM 或 Cargo，未修改仓库、旧阶段或创建 commit。

范围边界：integration 的 `file_record` 仍为既有路径读取；这次没有引入普通 recorder 的 artifact snapshots，不能声称闭合同用户 writer 的产物变更 race。parser 仍与 baseline 相同，对未知 QEMU 参数或替代拼写没有新增完备性证明。
