# A01 最终只读复核与剩余事项

本包只写 scratch，未修改仓库、锁、README、旧证据、Git 或远端状态；没有编译、安装、原生探测、VM 或全局 SDK 操作。原文档和所用冻结报告的精确字节保存在 local-source/、frozen-phase-readback/，哈希和时点见 local-readback-index.json。具体更新字段见 review-report.json。

GitHub 只读窗口为 **2026-10-17 01:52:52.607–01:53:47.412 UTC**，之后可能继续推进。

| 事项 | 本次实际看到的状态 | 报告边界 |
| --- | --- | --- |
| A01 #22 | open、非 Draft，head d879a9d2、base main40ca002；run38992415807/job117277478013 queued，conclusion null | 当前 host CI 尚未完成；历史170次绿色宿主执行属于另一精确源码。不能用空 statuses 列表当绿灯。 |
| A05 #87 | open Draft，head25cbffe6；关联 G0 run38988938901/job117266736845 success，步骤均为 host contracts | 本次未重新绑定 checkout 日志/merge parents，不把该关联状态升级为新精确树的内核验收。QueryAbi 真实历史 guest4/4及core141是另有来源的 owner 结果。 |
| A06 #18 / #63 | open Draft57b23ede；关联G0失败；#63 open、0 comments | dead Weak Process 最终运行时间可能漏计仍是未闭合源码问题，不是本次已证明的 QEMU quota exploit。 |
| A04 #8 | open Draftda4107f8；本次接口未返回其 PR workflow runs | owner 新13例报告11通过、两失败；空run列表不构成失败或成功结论。 |
| A07 | 当前A07-title和A07-head查询各0结果 | 不能杜撰“A07 Draft”，不能证明外部 owner 不存在。旧冻结的71分支扫描属于早前窗口。 |
| A05 replay #93 | open Draftecdd6275 | 新 runner/测试的 PR 正文仍说明未执行；不可用此前 guest 结果替它放行。 |

A05 #87 的正文仍残留“仅编译、未 guest 运行”，但 docs/STATUS 顶部及冻结 owner receipt 已记录后来的实际 guest。最终报告应按具体源码和机器结果分层，不能采用过时正文覆盖已验证历史。A04 正文内 Asterinas SHA 有拼写错误，固定 pin 始终以 upstream-lock 的 c4b7ed575b7b32773475b194d2ad41fb6d03765b 为准。

| 分类 | 可闭合或已成立 | 仍待实际证据 |
| --- | --- | --- |
| A01 构建/启动 | 完整固定源码已导入。最新冻结A4从空target实际编译279行、正常进入Rust/小initramfs，raw33，内核SHA8c540288c6af2a1a97121031643c1af4c4db395d7e8b4082d6edc4604449849a | A4只接受一个schema4案例；不把它写成已完成跨路径比较。 |
| 路径重现 | opt-in macro/编译参数/Cargo盐/完成producer单job机制有独立来源；A2/B2均真实boot但字节不同的失败已保留 | 最终不同真实root的完整两次构建、启动及直接字节比较须单独冻结。尚无独立跨主机或完整不可变环境验收。 |
| 快照/隔离/矩阵 | 原普通recorder快照、archive custody、per-case target与前置cache检查有真实host验证；最终integration快照源码9f51c0有152×2 host通过 | final包明确 pending post-publication real full22；必须保全所有实际private kernel/initrd/BIOS和EM62 symbol，不能用host fake raw33替代。旧20/22及已丢旧boot字节不可追补为通过。 |
| 环境限制 | 私有57包签名索引/下载/解包与固定nightly恢复、显式BIOS/-L路径已记录 | default host AF_UNIX EPERM、无/dev/kvm、VMX/EPT skips、未授权/未验证的第二host仍开放；TCG/TCP成功不关闭它们。 |
| 历史未知writer | 目录隔离和输入复制限制共享路径影响，失败/不同inode已保留 | writer仍未知；无归因、无任意特权写者不可变保证。 |
| A05 / A06 | QueryAbi guest与CPU配额样本按各自owner来源成立 | 可信CapSpace/启动授权/exec_epoch、四项剩余公开操作、规范errno、最终CPU借记/生命周期/权限和严格窗口要求仍未闭合。 |
| A04 / A07 | A04 owner选定guest11/13、历史Linux/Hepta调查各自保留 | MSG_CMSG_CLOEXEC、RLIMIT_NOFILE；四个ELF重建不匹配manifest，需要精确原输入；现有唯一持久owner的真实K↔D、确认/查询/退役/撤销/故障和认证effect仍无G2放行。 |

A01 的历史内核分母是362 reported、3 soft skip、359 exercised lower bound；A06 owner另有374/3/371的不同源码结果，不能互相替换。已合main的ABI/控制模型与host Clippy成功也不等于G1/G2。Linux全面兼容、Android/GPU/UI目标内核运行及裸机均不由这轮建立。

需要 root 更新的 A01 自有位置：

- support/build/README.md:9–54：补本轮来源与当前状态；A02 owner修复已经合main，不再把旧“候选待采纳/strict nightly失败”列为当前阻塞。保留其历史失败。
- 同文件67–86：补 A01_QEMU_BIOS、A01_QEMU_DATA_DIR 和私有工具路径；指向实验恢复证据，不把其restore.py包装为production installer。
- 同文件188–220：默认UNIX历史20/22、旧TCP/GDB22/22、最终快照host152×2与后续真实full22分列。完整矩阵结果未冻结前不提前改pass。
- 同文件245–277：链接新的opt-in schema4入口，明确normal build未变；不同path同host与不同host分开。
- 同文件310–324：A05/A06已经开始且仍独占core接口；历史13/14诊断继续保留，不把它当作最新状态。
- upstream-lock 的 native_build_environment 指向本轮环境；latest_native_boot及history按实际最后完成的source/profile/artifact/serial更新。原 artifact_sha256 已明确为首个基线，不能静默换角色。
- kernel.host_regression.explicit_tcp_gdb_capture 追加真实新矩阵来源；default UNIX记录保留。kernel.cloud_main_sync 的bc294/181/partial属历史，另加 exact8f ABI13/13、exact40ca control129+129与lint/no_std结果。不要声称其完整tree相同。
- reproducible_kernel_build_note 记录最后真实pair的限定结果；reproducible_kernel_build_ready在完整环境尚未建立时保留false，build_container_digest维持null，native最小构建不以Docker/Nix/ISO为前提。
- 追加本轮archive/private selectors/case targets/snapshots/repro/owner-CI指针，保留all_project_blockers_closed、default_unix_blocker_closed、native_resource_control_accepted等false。固定Asterinas/Hepta/nightly/Cargo locks不动。
- PR22正文仍写head01a344/mainbc294，与本次metadata headd879/base40ca不符；root在最终冻结后重写，当前排队CI继续按时点报告。

需要由 A00 协调的文档更新：

- docs/STATUS.md:3前追加本轮A01/owner/CI快照，不覆盖QueryAbi历史客体记录。189已有历史总标题；205/213/219/235的同级标题可进一步标明历史，防止“无.rs/not_executed”脱离日期被误读。
- docs/ARCHITECTURE.md:60–66 将“未来导入上游”更新为现有单目录来源；区分main codec、A05 Draft只读QueryAbi与仍缺的可信效果权限。
- docs/ROADMAP.md:24–29、58、62 标注已完成的源码/构建/codec与下一步；把main NOT_ENFORCED反例同A06 Draft后来实测限额分开。容器digest不是最小native启动必要条件。
- PROJECT、NATIVE_ABI与PLAN的目标/所有权仍有效；不要改低CapSpace、errno、固定窗口或G0/G1/G2契约以配合当前部分实现。尤其NATIVE_ABI:38的errno差异应由A05实现修正，不能改规格掩盖。

这是一份有界回读。尚在运行或之后完成的B4/最终matrix不在本包里；root应使用其之后冻结的真实结果更新总报告，而不是把本包pending记录当永久状态。
