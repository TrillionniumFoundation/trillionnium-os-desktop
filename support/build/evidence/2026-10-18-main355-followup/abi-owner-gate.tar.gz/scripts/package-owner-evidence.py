#!/usr/bin/env python3
"""Package existing A02 gate evidence without executing any tests."""
from __future__ import annotations

import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

ROOT = Path('/tmp/a01-main355-abi')
GATE = Path('/workspace/scratch/d7da9e7650f0/a01-runtime/review/a02-after-main-3551e1e')
OUTER = ROOT / 'outer'
ENV = Path('/workspace/scratch/d7da9e7650f0/a01-runtime/env.sh')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encoded(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text())


def main() -> None:
    report = read_json(GATE / 'report.json')
    mutations = read_json(GATE / 'mutations.json')
    before = read_json(OUTER / 'source-before.json')
    after = read_json(OUTER / 'source-after.json')
    receipt = read_json(OUTER / 'result.json')
    command = read_json(OUTER / 'command.json')
    full_status_observation = read_json(OUTER / 'postgate-untracked-observation.json')
    if not receipt['successful_gate_and_source_binding']:
        raise ValueError('this packager expects the recorded successful gate')
    if sha(ENV.read_bytes()) != command['environment_script']['sha256']:
        raise ValueError('environment script changed after the captured invocation')
    for name, value in before['inputs'].items():
        if sha((GATE / 'snapshot' / name).read_bytes()) != value['sha256']:
            raise ValueError(f'gate snapshot changed: {name}')

    checks = {check['name']: check for check in report['checks']}
    summary = {
        'schema': 'a01-a02-main355-owner-gate-evidence-v1',
        'scope': 'Existing A02 host ABI codec acceptance gate on the merged published A01 source; no kernel or driver validation in this gate.',
        'success': receipt['successful_gate_and_source_binding'],
        'source': {
            'head': before['head'], 'tree': before['tree'],
            'input_count': before['input_count'],
            'input_manifest_sha256': before['input_manifest_sha256'],
            'before_and_after_inputs_equal': before['inputs'] == after['inputs'],
            'before_and_after_head_tree_equal': before['head'] == after['head'] and before['tree'] == after['tree'],
            'before_and_after_tracked_clean': before['tracked_clean'] and after['tracked_clean'],
            'all_inputs_equal_recorded_git_blobs': before['all_inputs_match_recorded_head'] and after['all_inputs_match_recorded_head'],
            'snapshot_inputs_verified_again_at_packaging': True,
            'root_readme_bytes': report['readme_bytes'],
            'abi_lib_rs_sha256': before['inputs']['libs/os-abi/src/lib.rs']['sha256'],
            'status_scope': 'Before/after source receipts use --untracked-files=no; they certify tracked-clean state only.',
        },
        'invocation': command,
        'execution': {key: receipt[key] for key in (
            'started_at_utc', 'finished_at_utc', 'elapsed_seconds', 'returncode')},
        'toolchain': report['toolchain'],
        'check_count': len(checks),
        'checks_passed': sum(check['passed'] for check in checks.values()),
        'check_results': {name: {'passed': check['passed'], 'returncode': check['returncode'],
                                  'elapsed_seconds': check['elapsed_seconds']}
                          for name, check in checks.items()},
        'golden_vectors': {name: checks[name]['vectors'] for name in (
            'golden_hos2', 'golden_edges', 'golden_transport')},
        'python': {name: {key: value for key, value in checks[name]['tests'].items() if key != 'cases'}
                   for name in ('python', 'python_optimized', 'python_mutations')},
        'rust': {key: value for key, value in checks['rust']['tests'].items() if key != 'cases'},
        'compiled_source_mutations': {
            'schema': mutations['schema'], 'success': mutations['success'],
            'expected_mutants': mutations['expected_mutants'],
            'mutants_killed': mutations['mutants_killed'],
            'all_compiled': all(mutant['compiled'] for mutant in mutations['mutants']),
            'all_expected_test_failures_observed': all(mutant['expected_test_failed'] for mutant in mutations['mutants']),
            'expected_tests_by_suite': mutations['expected_tests_by_suite'],
            'errors': mutations['errors'],
        },
        'owner_report_errors': report['errors'],
        'owner_report_not_executed': report['not_executed'],
        'post_gate_environment_observation': {
            'captured_at_utc': full_status_observation['captured_at_utc'],
            'full_status_porcelain': full_status_observation['full_status_porcelain'],
            'matching_live_gate_processes': full_status_observation['matching_processes'],
            'unknown_entry_path': full_status_observation['unknown_entry_path'],
            'unknown_entry_sha256': full_status_observation.get('unknown_entry_sha256'),
            'observation_member': 'outer/postgate-untracked-observation.json',
            'note': 'An untracked kernel/asterinas/kernel/OSDK.toml was observed after the gate. The A02 reviewer neither created nor changed it; its recorded mtime/ctime precede this gate. No claim of complete-worktree cleanliness is made.',
        },
        'counting_notes': [
            'The 60-case optimized Python execution repeats the ordinary Python suite and is reported separately.',
            'The 9-case Python mutation subset is included in the ordinary 60; it is not additive.',
            'The 78 Rust cases include one doctest. Discovery, mutation baselines, and mutant executions repeat cases and are not added to that denominator.',
            'All 20 source mutants compiled; their expected regression failures were validated by the existing owner gate, rather than counting compilation failures as kills.',
        ],
        'exclusions': [
            {'path': str(GATE / 'target'), 'reason': 'Cargo target binaries, metadata and build cache are outside this text-evidence archive.'},
            {'pattern': '**/__pycache__/**, **/.pytest_cache/**', 'reason': 'Interpreter/test caches are outside text evidence.'},
            {'scope': 'Unrelated temporary worktrees and parent kernel build/runtime outputs', 'reason': 'No scope expansion; parent preserves kernel evidence separately.'},
        ],
    }

    members: dict[str, bytes] = {}
    originals = []

    def add_original(path: Path, member: str, kind: str) -> None:
        metadata = path.lstat()
        if not stat.S_ISREG(metadata.st_mode):
            raise ValueError(f'nonregular evidence path: {path}')
        data = path.read_bytes()
        data.decode('utf-8')
        if b'\0' in data:
            raise ValueError(f'binary evidence excluded by policy: {path}')
        if member in members:
            raise ValueError(f'duplicate member: {member}')
        members[member] = data
        record = {'original_absolute_path': str(path), 'archive_member': member,
                  'kind': kind, 'size': len(data), 'sha256': sha(data),
                  'original_mode': oct(stat.S_IMODE(metadata.st_mode))}
        snapshot_relative = str(path.relative_to(GATE / 'snapshot')) if path.is_relative_to(GATE / 'snapshot') else None
        if snapshot_relative in before['inputs']:
            binding = before['inputs'][snapshot_relative]
            record.update(repository_relative_source_path=snapshot_relative,
                          repository_source_head=before['head'],
                          repository_source_git_blob_sha1=binding['git_blob_sha1'],
                          original_repository_absolute_path=str(Path(before['repository']) / snapshot_relative))
        originals.append(record)

    for current, directories, files in os.walk(GATE):
        directories[:] = sorted(name for name in directories if name not in ('target', '__pycache__', '.pytest_cache'))
        for name in sorted(files):
            path = Path(current) / name
            add_original(path, 'gate/' + path.relative_to(GATE).as_posix(),
                         'original_gate_snapshot_input_or_generated_lock' if path.is_relative_to(GATE / 'snapshot') else 'original_gate_report_with_raw_command_output')
    for path in sorted(OUTER.iterdir()):
        add_original(path, 'outer/' + path.name, 'original_outer_invocation_receipt')
    add_original(ROOT / 'run-owner-gate.py', 'scripts/run-owner-gate.py', 'original_recording_wrapper_source')
    add_original(ROOT / 'package-owner-evidence.py', 'scripts/package-owner-evidence.py', 'packaging_script_source')
    add_original(ENV, 'environment/env.sh', 'original_environment_setup_script')

    origins = {
        'schema': 'a01-evidence-original-path-map-v1',
        'original_gate_output_directory': str(GATE),
        'original_outer_evidence_directory': str(OUTER),
        'source_head': before['head'],
        'files': sorted(originals, key=lambda item: item['archive_member']),
        'exclusions': summary['exclusions'],
    }
    members['metadata/summary.json'] = encoded(summary)
    members['metadata/original-paths.json'] = encoded(origins)
    members['SHA256SUMS'] = ''.join(f'{sha(data)}  {name}\n' for name, data in sorted(members.items())).encode()
    archive = ROOT / 'a02-owner-gate-main355.tar.gz'
    with archive.open('xb') as destination:
        with gzip.GzipFile(filename='', mode='wb', fileobj=destination, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
                for name, data in sorted(members.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    tar.addfile(info, io.BytesIO(data))
    manifest = {
        'schema': 'a01-evidence-archive-manifest-v1',
        'archive_absolute_path': str(archive),
        'archive_size': archive.stat().st_size,
        'archive_sha256': sha(archive.read_bytes()),
        'source_head': before['head'], 'source_tree': before['tree'],
        'original_file_count': len(originals), 'archive_member_count': len(members),
        'original_files': origins['files'],
        'members': [{'archive_member': name, 'size': len(data), 'sha256': sha(data)}
                    for name, data in sorted(members.items())],
        'checksum_scope': 'In-archive SHA256SUMS covers all other members; this external manifest also records the SHA256SUMS member hash.',
        'archive_readback_verified': False,
    }
    with tarfile.open(archive, mode='r:gz') as tar:
        actual = tar.getmembers()
        if len(actual) != len(members) or {entry.name for entry in actual} != set(members):
            raise ValueError('archive readback member mismatch')
        for entry in actual:
            handle = tar.extractfile(entry)
            if not entry.isfile() or handle is None or handle.read() != members[entry.name]:
                raise ValueError(f'archive readback byte mismatch: {entry.name}')
    manifest['archive_readback_verified'] = True
    (ROOT / 'summary.json').write_bytes(encoded(summary))
    (ROOT / 'original-paths.json').write_bytes(encoded(origins))
    (ROOT / 'archive-manifest.json').write_bytes(encoded(manifest))
    (ROOT / 'SHA256SUMS').write_text(''.join(
        f'{sha((ROOT / name).read_bytes())}  {name}\n' for name in (
            archive.name, 'summary.json', 'original-paths.json', 'archive-manifest.json')))
    print(json.dumps({key: manifest[key] for key in (
        'archive_absolute_path', 'archive_size', 'archive_sha256', 'source_head',
        'source_tree', 'original_file_count', 'archive_member_count', 'archive_readback_verified')}, indent=2))


if __name__ == '__main__':
    main()
