#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/d7da9e7650f0/trillionnium-os-desktop
source /workspace/scratch/d7da9e7650f0/a01-runtime/env.sh
CARGO_BUILD_JOBS=2 python3 -B tests/abi/run_acceptance.py --repo-root /workspace/scratch/d7da9e7650f0/trillionnium-os-desktop --toolchain nightly-2026-07-21 --output-dir /workspace/scratch/d7da9e7650f0/a01-runtime/review/a02-after-main-3551e1e --timeout 60 --mutation-timeout 900
