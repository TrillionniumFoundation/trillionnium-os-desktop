# A01 已安装运行环境的本轮核验

本收据记录 **2026-10-18 14:29:45–14:29:46 UTC** 对已有隔离运行环境的当前核验。原环境在当天 08:34–08:36 UTC 安装；本轮没有再次下载或安装依赖，没有运行内核构建，没有创建 QEMU machine，也没有读取或写入项目公共 OSDK.toml。

环境入口：`/workspace/scratch/d7da9e7650f0/a01-current-runtime/env.sh`。

## 实际结果

| 项目 | 结果 |
|---|---|
| 工具版本、组件、目标和只读配置命令 | 24/24 退出 0 |
| 已保留原生依赖包的当前哈希 | 57/57 与原签名索引记录一致 |
| 实际二进制与动态库当前哈希 | 70/70 与原收据一致 |
| 本轮 QEMU 动态依赖路径和哈希 | 48/48 一致，未缺库 |
| SeaBIOS、静态 BusyBox、vDSO、initramfs | 4/4 大小和 SHA256 一致 |
| Rust 固定 manifest | 文件哈希一致，9/9 组件项一致 |
| 已有安装收据及原归档 | 核验前后内容保持一致 |

工具版本为 nightly-2026-07-21，rustc `87e5904f5eb6398af6b22eac2802c78934260c48`，Cargo `3efb1f477e99b42974b982d939fd100303cdf7db`，cargo-binutils 0.4.0，LLVM 工具 22.1.8，QEMU 8.2.2 Ubuntu `1:8.2.2+ds-0ubuntu1.18`，Clang/LLD 18.1.3，GDB 15.1，BusyBox 1.36.1，GNU Make 4.3。固定 `x86_64-unknown-none` 目标已安装。

vDSO commit `8af571775a3d3a1df3e84fc9709b9d6b160c771a`，tree `8e0a300d78c2a020ccc79f1253bc27a8301416e6`，工作树干净。内核启动所需关键文件和版本的完整原始输出、路径、大小与哈希位于 `runtime-current-check.json` 和 `comparisons.json`。

Docker、Nix 和 nix-build 在本轮 PATH 中未找到；`/dev/kvm` 不存在。现有 QEMU 原生 TCG 依赖检查通过，但工具 `--version` 和库检查本身不构成新的客体启动验收。

## 运行中任务观察

最初沙箱中的 `ps` 报 `fatal library error, lookup self`。随后在 **14:31:01 UTC** 进行了只读 host-visible `ps` 与 `/proc` 检查：`ps` 退出 0，可见 17 个 PID，无不可读条目；排除本检查自身的祖先进程后，没有观察到本项目相关构建或 QEMU guest。快照仅证明观察时的可见状态。未读取进程环境文件，也未发送任何进程信号。完整快照见 `processes-host.json`。

## 证据范围与复查

`check-runtime.py` 是本轮实际运行脚本；它使用独立输出路径和排他创建方式，原样重跑前应选择新的输出目录。历史 `prepare_initramfs` 步骤会写文件，本轮刻意不重跑它，仅复核现有镜像。`check-processes.py` 是后续进程快照的实际脚本。

Rust 原始组件压缩包在历史 rustup 安装后未保留。本轮验证保留的官方 manifest、组件条目以及已安装程序哈希；不把历史 rustup 下载验证表述为本轮重新下载验证。部分实际工具与库来自已记录的宿主文件，因此本收据不宣称完整不可变宿主依赖锁或跨宿主逐字节复现。

`SHA256SUMS` 覆盖本归档中除其自身之外的文件。沙箱初始进程输出中的执行容器参数保留在临时检查目录供调查，归档采用随后完整成功的 host-visible 快照。
