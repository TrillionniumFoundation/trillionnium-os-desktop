#!/usr/bin/env python3
"""Read-only verification of A01's previously installed isolated runtime."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shlex
import shutil
import stat
import subprocess
import sys
import time
import tomllib

ROOT = Path('/workspace/scratch/d7da9e7650f0/a01-current-runtime')
OUT = Path('/tmp/a01-round2-runtime')

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def write(name, value):
    p = OUT / name
    with p.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')

def hash_file(path):
    p = Path(path)
    r = {'path': str(p)}
    try:
        resolved = p.resolve(strict=True)
        with p.open('rb') as f:
            before = os.fstat(f.fileno())
            if not stat.S_ISREG(before.st_mode):
                raise ValueError('not a regular file')
            h = hashlib.file_digest(f, 'sha256').hexdigest()
            after = os.fstat(f.fileno())
        public = p.stat()
        fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        r.update(resolved_path=str(resolved), size=before.st_size,
                 mode=oct(stat.S_IMODE(before.st_mode)), sha256=h,
                 stable_fd_and_path=all(getattr(before, k) == getattr(after, k)
                    == getattr(public, k) for k in fields))
    except (OSError, ValueError) as e:
        r['error'] = f'{type(e).__name__}: {e}'
    return r

def compare(expected):
    actual = hash_file(expected['path'])
    checks = {k: actual.get(k) == expected[k]
              for k in ('resolved_path', 'size', 'sha256') if k in expected}
    checks['stable_fd_and_path'] = actual.get('stable_fd_and_path', False)
    return {'expected': expected, 'actual': actual, 'checks': checks,
            'pass': all(checks.values())}

def run(name, argv, prior=None):
    start = now()
    tick = time.monotonic()
    executable = shutil.which(argv[0]) if not os.path.isabs(argv[0]) else argv[0]
    r = {'name': name, 'argv': argv, 'shell_command': shlex.join(argv),
         'start_utc': start, 'cwd': str(OUT),
         'executable': hash_file(executable) if executable else None}
    try:
        c = subprocess.run(argv, cwd=OUT, capture_output=True, text=True,
                           timeout=30, check=False)
        r.update(exit_code=c.returncode, stdout=c.stdout, stderr=c.stderr,
                 timed_out=False)
    except (OSError, subprocess.TimeoutExpired) as e:
        r.update(exit_code=None, error=f'{type(e).__name__}: {e}',
                 timed_out=isinstance(e, subprocess.TimeoutExpired))
    r['end_utc'] = now()
    r['duration_seconds'] = time.monotonic() - tick
    r['pass'] = r.get('exit_code') == 0
    if prior:
        r['prior_exit_code'] = prior.get('exit_code')
        r['stdout_identical_to_prior'] = r.get('stdout') == prior.get('stdout')
        r['stderr_identical_to_prior'] = r.get('stderr') == prior.get('stderr')
        r['executable_hash_identical_to_prior'] = (
            bool(r['executable']) and r['executable'].get('sha256') ==
            prior.get('executable', {}).get('sha256'))
    return r

def process_snapshot():
    result = {'recorded_at_utc': now(), 'method': 'read-only /proc observation',
              'self_pid': os.getpid(), 'self_proc_visible': Path('/proc/self/stat').exists(),
              'related': [], 'unreadable': [], 'visible_process_count': 0,
              'no_processes_signalled': True,
              'scope_note': 'Snapshot of visible PID namespace only; unavailable entries are retained as observation limits.'}
    try:
        pids = sorted(int(p.name) for p in Path('/proc').iterdir() if p.name.isdigit())
    except OSError as e:
        result['enumeration_error'] = str(e)
        return result
    result['visible_process_count'] = len(pids)
    for pid in pids:
        if pid == os.getpid():
            continue
        base = Path('/proc') / str(pid)
        try:
            argv = [x.decode(errors='replace') for x in (base/'cmdline').read_bytes().split(b'\0') if x]
            if not argv:
                continue
            # Do not collect unrelated process command lines or environments.
            is_project = any('a01-current' in x or 'trillionnium-os-desktop' in x
                             or 'support/build/ktest' in x for x in argv)
            is_build_or_guest = any(re.search(r'(^|/)(qemu-system[^/ ]*|cargo-osdk|rustc|cargo)$', x)
                                    for x in argv[:1])
            if not (is_project or is_build_or_guest):
                continue
            entry = {'pid': pid, 'argv': argv, 'project_path_match': is_project,
                     'build_or_guest_executable_match': is_build_or_guest}
            try:
                entry['cwd'] = os.readlink(base/'cwd')
                entry['executable'] = os.readlink(base/'exe')
                entry['stat_raw'] = (base/'stat').read_text().strip()
            except OSError as e:
                entry['metadata_error'] = str(e)
            result['related'].append(entry)
        except OSError as e:
            result['unreadable'].append({'pid': pid, 'error': str(e)})
    return result

started = now()
OUT.mkdir(parents=True, exist_ok=True)
prior_names = ['env.sh', 'summary.json', 'runtime-receipt.json', 'native-inputs.json',
               'rust-inputs.json', 'effective-binary-inputs.json', 'initramfs-manifest.json',
               'archive-receipt.json', 'runtime-current.tar.gz']
prior_files_before = {name: hash_file(ROOT/name) for name in prior_names}
prior = json.loads((ROOT/'runtime-receipt.json').read_text())
native = json.loads((ROOT/'native-inputs.json').read_text())
rust = json.loads((ROOT/'rust-inputs.json').read_text())
effective = json.loads((ROOT/'effective-binary-inputs.json').read_text())
process_before = process_snapshot()

checks = {}
for name, old in prior['checks'].items():
    if name == 'prepare_initramfs':
        continue  # This historical step writes files and is intentionally not rerun.
    checks[name] = run(name, old['argv'], old)

for name, argv in {
    'rustup_which_rustc': ['rustup', 'which', 'rustc'],
    'rustup_which_cargo': ['rustup', 'which', 'cargo'],
    'cargo_installed_tools': ['cargo', 'install', '--list'],
    'rust_objcopy': ['rust-objcopy', '--version'],
    'rust_objdump': ['rust-objdump', '--version'],
    'make': ['make', '--version'],
    'vdso_identity': ['git', '-C', str(ROOT/'linux-vdso'), 'rev-parse', 'HEAD', 'HEAD^{tree}'],
    'vdso_status': ['git', '--no-optional-locks', '-C', str(ROOT/'linux-vdso'), 'status', '--porcelain=v1'],
}.items():
    checks[name] = run(name, argv)

comparisons = {
    'native_packages': [compare(x) for x in native],
    'effective_binaries_and_libraries': [compare(x) for x in effective],
    'artifacts': {name: compare(x) for name, x in prior['artifacts'].items()},
    'rust_manifest': compare(rust['manifest']),
}

manifest = tomllib.loads((ROOT/'downloads/channel-rust-nightly-2026-07-21.toml').read_text())
component_checks = []
for c in rust['components']:
    actual = manifest['pkg'][c['component']]
    target = actual['target'][c['target']]
    tests = {'version': actual['version'] == c['version'],
             'source_url': target['xz_url'] == c['source_url'],
             'sha256': target['xz_hash'] == c['sha256']}
    component_checks.append({'component': c['component'], 'target': c['target'],
                             'checks': tests, 'pass': all(tests.values())})
comparisons['rust_component_manifest_entries'] = component_checks
comparisons['rust_archives_rehashed'] = False
comparisons['rust_archives_note'] = 'The original installation verified component downloads with rustup; component archives were not retained. This check verifies the preserved manifest and installed executable hashes, and does not relabel historical archive verification as a new download/install.'

ldd = checks['qemu_dynamic_libraries'].get('stdout', '')
ldd_paths = sorted(set(re.findall(r'=> (/\S+)', ldd) + re.findall(r'^\s*(/\S+) \(', ldd, re.M)))
effective_by_path = {x['path']: x for x in effective}
qemu_deps = []
for p in ldd_paths:
    if p in effective_by_path:
        qemu_deps.append(compare(effective_by_path[p]))
    else:
        qemu_deps.append({'actual': hash_file(p), 'pass': False,
                          'error': 'New dependency path absent from historical effective-binary-inputs.json'})
comparisons['qemu_current_dynamic_dependencies'] = qemu_deps
comparisons['qemu_missing_dynamic_libraries'] = 'not found' in ldd

prior_files_after = {name: hash_file(ROOT/name) for name in prior_names}
historical_receipts_unchanged = all(
    prior_files_before[n].get('sha256') == prior_files_after[n].get('sha256')
    and prior_files_before[n].get('size') == prior_files_after[n].get('size')
    for n in prior_names)
process_after = process_snapshot()
runtime = {
    'started_at_utc': started, 'completed_at_utc': now(),
    'scope': 'Current verification of the existing previously installed A01 runtime; no dependency installation was performed in this task.',
    'platform': platform.platform(), 'python': sys.executable,
    'environment_entry': str(ROOT/'env.sh'),
    'environment': {k: os.environ.get(k) for k in ['A01_RUNTIME_ROOT','CARGO_HOME','RUSTUP_HOME',
      'RUSTUP_TOOLCHAIN','A01_BUSYBOX','A01_QEMU_BIOS','A01_QEMU_DATA_DIR','QEMU_MODULE_DIR','VDSO_LIBRARY_DIR']},
    'availability': {k: shutil.which(k) for k in ['docker','nix','nix-build','qemu-system-x86_64']},
    'kvm': {'device_exists': Path('/dev/kvm').exists(),
            'read_write_access': os.access('/dev/kvm', os.R_OK | os.W_OK)},
    'historical_receipts_before': prior_files_before, 'historical_receipts_after': prior_files_after,
    'historical_receipts_unchanged': historical_receipts_unchanged,
    'commands': checks, 'no_installation_performed': True,
    'no_qemu_machine_created': True, 'no_kernel_build_or_boot_performed': True,
    'no_project_checkout_manifest_accessed': True,
}
write('runtime-current-check.json', runtime)
write('comparisons.json', comparisons)
write('processes.json', {'before': process_before, 'after': process_after,
    'preliminary_ps_attempt': {'argv': ['ps','-eo','pid,ppid,lstart,stat,args'],
         'stderr_observed': 'fatal library error, lookup self',
         'full_pipeline_exit_code': 1, 'ps_exit_code_individually_recorded': False}})

def group(a):
    a = list(a.values()) if isinstance(a, dict) else a
    return {'total': len(a), 'passed': sum(x['pass'] for x in a),
            'failed': [x for x in a if not x['pass']]}

summary = {
    'started_at_utc': started, 'completed_at_utc': now(),
    'scope': runtime['scope'], 'installation_performed': False,
    'version_and_read_only_commands': group(checks),
    'native_package_hashes': group(comparisons['native_packages']),
    'effective_binary_and_library_hashes': group(comparisons['effective_binaries_and_libraries']),
    'artifacts': group(comparisons['artifacts']),
    'rust_manifest_verified': comparisons['rust_manifest']['pass'],
    'rust_component_manifest_entries': group(component_checks),
    'qemu_current_dynamic_dependency_hashes': group(qemu_deps),
    'qemu_missing_dynamic_libraries': comparisons['qemu_missing_dynamic_libraries'],
    'historical_receipts_unchanged': historical_receipts_unchanged,
    'availability': runtime['availability'], 'kvm': runtime['kvm'],
    'process_observation': {'visible_before': process_before['visible_process_count'],
      'visible_after': process_after['visible_process_count'],
      'related_before': process_before['related'], 'related_after': process_after['related'],
      'unreadable_before': len(process_before['unreadable']),
      'unreadable_after': len(process_after['unreadable']),
      'self_proc_visible_before': process_before['self_proc_visible'],
      'self_proc_visible_after': process_after['self_proc_visible']},
    'complete_immutable_host_dependency_lock': False,
    'cross_host_bit_reproducibility_claimed': False,
    'new_kernel_build_or_boot_claimed': False,
}
write('summary.json', summary)
print(json.dumps(summary, indent=2, sort_keys=True))
