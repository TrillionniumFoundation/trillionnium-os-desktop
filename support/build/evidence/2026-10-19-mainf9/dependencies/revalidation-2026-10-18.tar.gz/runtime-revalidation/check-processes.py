#!/usr/bin/env python3
"""Read-only host-visible process snapshot; no signals and no environment reads."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

OUT = Path('/tmp/a01-round2-runtime/processes-host.json')
PROJECTS = ('/a01-current', '/a01-round2', '/trillionnium-os-desktop', '/support/build/')
record = {'recorded_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
          'method': 'read-only host-visible /proc and ps with default process metadata',
          'self_pid': os.getpid(), 'signals_sent': 0,
          'environment_files_read': False, 'related': [], 'unreadable': []}
ps = subprocess.run(['ps', '-eo', 'pid,ppid,lstart,stat,comm'], capture_output=True, text=True)
record['ps'] = {'argv': ['ps', '-eo', 'pid,ppid,lstart,stat,comm'], 'exit_code': ps.returncode,
                'stdout': ps.stdout, 'stderr': ps.stderr}
try:
    entries = sorted(int(p.name) for p in Path('/proc').iterdir() if p.name.isdigit())
except OSError as e:
    entries = []
    record['enumeration_error'] = str(e)
record['visible_process_count'] = len(entries)
ancestors = {os.getpid()}
cur = os.getpid()
while cur > 1:
    try:
        raw = (Path('/proc')/str(cur)/'stat').read_text()
        cur = int(raw.rsplit(')', 1)[1].split()[1])
    except (OSError, ValueError, IndexError):
        break
    if cur in ancestors:
        break
    ancestors.add(cur)
record['own_ancestor_pids_excluded'] = sorted(ancestors)
for pid in entries:
    if pid in ancestors:
        continue
    base = Path('/proc')/str(pid)
    try:
        args = [x.decode(errors='replace') for x in (base/'cmdline').read_bytes().split(b'\0') if x]
        if not args:
            continue
        comm = (base/'comm').read_text().strip()
        executable_name = Path(args[0]).name
        build_guest = bool(re.fullmatch(r'qemu-system.*|cargo-osdk|rustc|cargo|make|ninja', executable_name))
        project = any(any(marker in x for marker in PROJECTS) for x in args)
        if not (build_guest or project):
            continue
        # Container orchestration arguments can include an entire task program;
        # record their classification, but do not duplicate internal policy data.
        wrapper = executable_name in {'codex-linux-sandbox', 'bwrap', 'codex'}
        entry = {'pid': pid, 'comm': comm, 'project_path_match': project,
                 'build_or_guest_executable_match': build_guest,
                 'orchestration_wrapper': wrapper}
        if wrapper:
            entry['argv0'] = args[0]
            entry['command_line_sha256'] = hashlib.sha256((base/'cmdline').read_bytes()).hexdigest()
        else:
            entry['argv'] = args
        for key in ['cwd', 'exe']:
            try:
                entry[key] = os.readlink(base/key)
            except OSError as e:
                entry[key+'_error'] = str(e)
        entry['stat_raw'] = (base/'stat').read_text().strip()
        record['related'].append(entry)
    except OSError as e:
        record['unreadable'].append({'pid': pid, 'error': str(e)})
record['observed_build_or_guest_count'] = sum(x['build_or_guest_executable_match'] for x in record['related'])
with OUT.open('x') as f:
    json.dump(record, f, indent=2, sort_keys=True)
    f.write('\n')
print(json.dumps({'recorded_at_utc': record['recorded_at_utc'], 'ps_exit_code': ps.returncode,
                  'visible_process_count': record['visible_process_count'],
                  'observed_build_or_guest_count': record['observed_build_or_guest_count'],
                  'related': record['related'], 'unreadable': record['unreadable']}, indent=2))
