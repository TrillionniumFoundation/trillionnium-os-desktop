#!/usr/bin/env python3
"""Small read-only runtime recheck after host-session restoration."""
import datetime as dt
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import re
import shlex
import shutil
import stat
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/d7da9e7650f0/a01-current-runtime')
OUT = Path('/tmp/a01-round2-runtime-resume')

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def write(name, value):
    with (OUT/name).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')

def fingerprint(path):
    p = Path(path)
    result = {'path': str(p)}
    try:
        with p.open('rb') as f:
            a = os.fstat(f.fileno())
            digest = hashlib.file_digest(f, 'sha256').hexdigest()
            b = os.fstat(f.fileno())
        c = p.stat()
        fields = ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')
        result.update(resolved_path=str(p.resolve()), size=a.st_size, sha256=digest,
                      stable=all(getattr(a,k)==getattr(b,k)==getattr(c,k) for k in fields))
    except OSError as e:
        result['error'] = f'{type(e).__name__}: {e}'
    return result

def compare(old):
    new = fingerprint(old['path'])
    checks = {k:new.get(k)==old[k] for k in ['resolved_path','size','sha256'] if k in old}
    checks['stable'] = new.get('stable',False)
    return {'expected':old, 'actual':new, 'checks':checks, 'pass':all(checks.values())}

started = now()
prior = json.loads((ROOT/'runtime-receipt.json').read_text())
effective = json.loads((ROOT/'effective-binary-inputs.json').read_text())
receipts_before = {n:fingerprint(ROOT/n) for n in ['env.sh','runtime-receipt.json','effective-binary-inputs.json']}
commands = {}
names = ['rustc','cargo','rust_strip','clang','lld','gcc','gdb','busybox','busybox_elf','cpio','pkgconfig','qemu','qemu_dynamic_libraries']
for name in names:
    old = prior['checks'][name]
    argv = old['argv']
    result = {'argv':argv, 'shell_command':shlex.join(argv), 'cwd':str(OUT), 'started_at_utc':now()}
    try:
        completed = subprocess.run(argv,cwd=OUT,capture_output=True,text=True,timeout=20,check=False)
        result.update(exit_code=completed.returncode, stdout=completed.stdout, stderr=completed.stderr,
                      stdout_identical_to_prior=completed.stdout==old['stdout'],
                      stderr_identical_to_prior=completed.stderr==old['stderr'])
    except (OSError, subprocess.TimeoutExpired) as e:
        result.update(exit_code=None,error=f'{type(e).__name__}: {e}')
    result['completed_at_utc'] = now()
    result['pass'] = result.get('exit_code')==0
    commands[name] = result

effective_checks = [compare(x) for x in effective]
artifact_checks = {n:compare(v) for n,v in prior['artifacts'].items()}
ldd = commands['qemu_dynamic_libraries'].get('stdout','')
paths = sorted(set(re.findall(r'=> (/\S+)',ldd)+re.findall(r'^\s*(/\S+) \(',ldd,re.M)))
old_paths = {x['path']:x for x in effective}
current_paths = {x['actual']['path']:x for x in effective_checks}
libraries = [{'path':p,'pass':p in current_paths and current_paths[p]['pass']} for p in paths]
receipts_after = {n:fingerprint(ROOT/n) for n in receipts_before}
receipts_unchanged = all(receipts_before[n].get('sha256')==receipts_after[n].get('sha256') for n in receipts_before)

raw = {
    'schema':1,'started_at_utc':started,'completed_at_utc':now(),
    'scope':'Current verification of previously installed runtime after host session restoration; no installation or build.',
    'environment_entry':str(ROOT/'env.sh'),'platform':platform.platform(),
    'environment':{k:os.environ.get(k) for k in ['A01_RUNTIME_ROOT','CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTUP_AUTO_INSTALL','A01_BUSYBOX','A01_QEMU_BIOS','A01_QEMU_DATA_DIR','QEMU_MODULE_DIR','VDSO_LIBRARY_DIR']},
    'commands':commands,'effective_binary_and_library_checks':effective_checks,
    'artifact_checks':artifact_checks,'qemu_current_library_checks':libraries,
    'receipt_files_before':receipts_before,'receipt_files_after':receipts_after,
    'historical_receipts_unchanged':receipts_unchanged,
    'no_installation_performed':True,'no_kernel_build_or_qemu_machine_created':True,
    'no_project_manifest_or_target_accessed':True,
}
write('raw-checks.json',raw)
summary = {
    'schema':1,'started_at_utc':started,'completed_at_utc':raw['completed_at_utc'],
    'scope':raw['scope'],'environment_entry':raw['environment_entry'],
    'commands':{'passed':sum(x['pass'] for x in commands.values()),'total':len(commands),'failed':[n for n,x in commands.items() if not x['pass']]},
    'effective_binaries_and_libraries':{'passed':sum(x['pass'] for x in effective_checks),'total':len(effective_checks),'failed':[x for x in effective_checks if not x['pass']]},
    'artifacts':{'passed':sum(x['pass'] for x in artifact_checks.values()),'total':len(artifact_checks),'failed':[n for n,x in artifact_checks.items() if not x['pass']]},
    'qemu_current_libraries':{'passed':sum(x['pass'] for x in libraries),'total':len(libraries),'missing': 'not found' in ldd,'failed':[x for x in libraries if not x['pass']]},
    'versions':{n:commands[n].get('stdout','').splitlines()[:1] for n in ['rustc','cargo','rust_strip','clang','lld','gcc','gdb','busybox','cpio','pkgconfig','qemu']},
    'rust_toolchain':os.environ.get('RUSTUP_TOOLCHAIN'),
    'unavailable':{n:shutil.which(n) for n in ['docker','nix','nix-build']},
    'kvm_device_exists':Path('/dev/kvm').exists(),
    'historical_receipts_unchanged':receipts_unchanged,
    'no_installation_performed':True,'no_kernel_build_or_qemu_machine_created':True,
    'no_project_manifest_or_target_accessed':True,
    'complete_immutable_host_dependency_lock':False,'cross_host_bit_reproducibility_claimed':False,
}
write('summary.json',summary)
files = ['check-runtime-resume.py','raw-checks.json','summary.json']
with (OUT/'SHA256SUMS').open('x') as f:
    for name in files:
        f.write(hashlib.sha256((OUT/name).read_bytes()).hexdigest()+'  '+name+'\n')
files.append('SHA256SUMS')
archive = OUT/'runtime-resume-check.tar.gz'
with archive.open('xb') as a:
    with gzip.GzipFile(fileobj=a,mode='wb',filename='',mtime=0) as g:
        with tarfile.open(fileobj=g,mode='w',format=tarfile.PAX_FORMAT) as t:
            for name in files:
                data=(OUT/name).read_bytes()
                info=tarfile.TarInfo('runtime-resume/'+name)
                info.size=len(data);info.mode=0o644;info.mtime=0
                t.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as t:
    for member in t.getmembers():
        name=member.name.removeprefix('runtime-resume/')
        assert t.extractfile(member).read()==(OUT/name).read_bytes()
receipt={'created_at_utc':now(),'path':str(archive),'size':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'all_members_byte_verified':True}
write('archive-receipt.json',receipt)
print(json.dumps({'summary':summary,'archive':receipt},indent=2,sort_keys=True))
