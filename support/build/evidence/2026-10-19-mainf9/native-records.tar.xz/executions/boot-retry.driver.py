#!/usr/bin/env python3
"""Actual A01 current-source command receipts; no synthetic guest results."""
import argparse, datetime, hashlib, json, os, pathlib, shutil, subprocess, sys, time

REPO = pathlib.Path('/workspace/scratch/d7da9e7650f0/a01-mainf9')
OUT = REPO / 'support/build/out/2026-10-19-mainf9'
ENV = pathlib.Path('/workspace/scratch/d7da9e7650f0/a01-current-runtime/env.sh')
CAPTURE = pathlib.Path('/workspace/scratch/d7da9e7650f0/a01-current/support/build/evidence/2026-10-18-current-main/source/capture-source.py')
PRODUCER = '7758ffe294bb0e1eab46e20cba60e8af9d8bcd61'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def write(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def git(*parts): return subprocess.check_output(['git','-C',str(REPO),*parts],text=True).strip()
def file_info(path):
    if not path.exists() and not path.is_symlink(): return {'path':str(path),'exists':False}
    s=path.lstat()
    result={'path':str(path),'exists':True,'mode':oct(s.st_mode),'device':s.st_dev,'inode':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
    if path.is_file() and not path.is_symlink(): result['sha256']=sha(path.read_bytes())
    return result
def capture(name, compare=None):
    dest=OUT/'source'/f'{name}.json'
    argv=[sys.executable,'-B','-I',str(CAPTURE),'--repo',str(REPO)]
    if compare: argv += ['--compare',str(compare)]
    with dest.open('wb') as log:
        p=subprocess.run(argv,stdout=log,stderr=subprocess.PIPE)
    write(dest.with_suffix('.command.json'),{'argv':argv,'exit':p.returncode,'stderr':p.stderr.decode(),'captured_at':now()})
    if p.returncode: raise RuntimeError('source capture rejected: '+str(dest))
    return dest
def freeze(source,dest):
    before=source.stat()
    with source.open('rb') as f:
        opened=os.fstat(f.fileno());raw=f.read();after=os.fstat(f.fileno())
    fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    if not fields(before)==fields(opened)==fields(after)==fields(source.stat()): raise RuntimeError('artifact changed during capture')
    dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('xb') as f: f.write(raw)
    return {'source':file_info(source),'frozen':file_info(dest),'stable_during_capture':True,'bytes_equal':source.read_bytes()==dest.read_bytes(),'captured_at':now()}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['kernel','boot','boot-retry','ktest']);args=parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    for name in ['executions','source','artifacts']: (OUT/name).mkdir(exist_ok=True)
    if not (OUT/'executions/execute.py').exists(): shutil.copyfile(__file__,OUT/'executions/execute.py')
    stage_script=OUT/'executions'/f'{args.stage}.driver.py'
    if not stage_script.exists(): shutil.copyfile(__file__,stage_script)
    if not (OUT/'source/capture-source.py').exists(): shutil.copyfile(CAPTURE,OUT/'source/capture-source.py')
    if git('rev-parse','HEAD')!=PRODUCER: raise RuntimeError('wrong producer')
    receipt=OUT/'executions'/f'{args.stage}.json'
    if receipt.exists(): raise RuntimeError('existing execution receipt')
    before=capture(args.stage+'-before',OUT/'source/kernel-before.json' if args.stage!='kernel' else None)
    stage_output=OUT/args.stage
    env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['A01_SMP']='1'
    if args.stage in ['kernel','boot','boot-retry']:
        env['A01_RUN_DIR']=str(stage_output)
        command=['support/build/kernel.sh','kernel' if args.stage=='kernel' else 'run_kernel']
    else: command=['python3','-B','-I','support/build/ktest/run.py','--output',str(stage_output)]
    argv=['bash','--noprofile','--norc','-c','source "$1"; shift; exec "$@"','bash',str(ENV),*command]
    record={'producer':PRODUCER,'project_tree':git('rev-parse','HEAD^{tree}'),'kernel_tree':git('rev-parse','HEAD:kernel/asterinas'),'stage':args.stage,'cwd':str(REPO),'argv':argv,'selected_environment':{k:env.get(k) for k in ['CARGO_BUILD_JOBS','A01_SMP','A01_RUN_DIR','CARGO_TARGET_DIR','CARGO_ENCODED_RUSTFLAGS']},'runtime_env':file_info(ENV),'started_at':now(),'disk_free_before':shutil.disk_usage(REPO).free,'target_before':file_info(REPO/'kernel/asterinas/target'),'osdk_target_before':file_info(REPO/'kernel/asterinas/osdk/target'),'public_manifest_before':file_info(REPO/'kernel/asterinas/kernel/OSDK.toml'),'source_before':str(before),'git_status_before':git('status','--porcelain=v1','--untracked-files=all')}
    write(receipt,record)
    print('START '+args.stage+' '+record['started_at'],flush=True)
    started=time.monotonic()
    with (OUT/'executions'/f'{args.stage}.stdout-stderr.log').open('xb') as log:
        p=subprocess.run(argv,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
    record.update(finished_at=now(),elapsed_seconds=time.monotonic()-started,exit_code=p.returncode,disk_free_after=shutil.disk_usage(REPO).free,public_manifest_after=file_info(REPO/'kernel/asterinas/kernel/OSDK.toml'),git_status_after=git('status','--porcelain=v1','--untracked-files=all'))
    write(receipt,record)
    if p.returncode==0 and args.stage=='kernel':
        binding=freeze(REPO/'kernel/asterinas/target/osdk/asterinas/asterinas-osdk-bin.elf',OUT/'artifacts/first-kernel.elf')
        write(OUT/'artifacts/first-kernel.json',binding)
    if p.returncode==0 and args.stage=='ktest':
        for crate in ['ostd','aster-core']:
            binding=freeze(REPO/f'kernel/asterinas/target/osdk/{crate}/{crate}-osdk-bin.elf',OUT/f'artifacts/{crate}.elf')
            write(OUT/f'artifacts/{crate}.json',binding)
    record['source_after']=str(capture(args.stage+'-after',OUT/'source/kernel-before.json'))
    write(receipt,record)
    print(json.dumps({k:record[k] for k in ['stage','producer','started_at','finished_at','elapsed_seconds','exit_code','disk_free_after','public_manifest_after','git_status_after']},indent=2),flush=True)
    return p.returncode
if __name__=='__main__': raise SystemExit(main())
