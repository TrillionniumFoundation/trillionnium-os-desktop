import datetime, json, pathlib, subprocess
old = pathlib.Path('/workspace/scratch/d7da9e7650f0/a01-current')
new = old.parent / 'a01-mainf9'
out = pathlib.Path('/tmp/a01-round2-acquisition')
producer = '7758ffe294bb0e1eab46e20cba60e8af9d8bcd61'
previous = '71524be19383e2ff98f6abc90668c48988e7c8e2'
main = 'f9e306f76154590e096a42f70ce9de0a7c859e60'
records = []
def run(repo, *args):
    p = subprocess.run(['git','-C',str(repo),*args], capture_output=True, text=True)
    records.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(repo),'argv':['git',*args],'stdout':p.stdout,'stderr':p.stderr,'exit':p.returncode})
    (out/'align-producer.json').write_text(json.dumps(records,indent=2)+'\n')
    if p.returncode: raise SystemExit(p.stderr)
    return p.stdout.strip()
assert run(new,'rev-parse','origin/agents/A01-asterinas-boot') == producer
assert run(new,'write-tree') == run(new,'rev-parse',producer+'^{tree}')
assert run(new,'rev-list','--parents','-n','1',producer).split() == [producer,main,previous]
assert run(old,'status','--porcelain=v1') == ''
assert run(old,'rev-parse','HEAD') == previous
run(old,'switch','--detach',previous)
run(new,'merge','--quit')
run(new,'update-ref','--no-deref','HEAD',producer,main)
run(new,'merge-base','--is-ancestor',previous,producer)
run(new,'update-ref','refs/heads/agents/A01-asterinas-boot',producer,previous)
run(new,'switch','agents/A01-asterinas-boot')
assert run(new,'status','--porcelain=v1') == ''
assert run(new,'rev-parse','HEAD') == producer
assert (new/'README.md').stat().st_size == 0
assert not (new/'kernel/asterinas/target').exists()
assert not (new/'kernel/asterinas/kernel/OSDK.toml').exists()
print(json.dumps({'producer':producer,'branch':'agents/A01-asterinas-boot','tree':run(new,'rev-parse','HEAD^{tree}'),'kernel_tree':run(new,'rev-parse','HEAD:kernel/asterinas'),'clean':True,'target_absent':True,'manifest_absent':True},indent=2))
