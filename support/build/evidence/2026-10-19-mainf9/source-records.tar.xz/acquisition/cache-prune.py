import datetime, fcntl, hashlib, json, os, pathlib, shutil, stat, subprocess, tarfile

repo = pathlib.Path('/workspace/scratch/d7da9e7650f0/a01-current')
receipt = pathlib.Path('/tmp/a01-round2-acquisition/cache-prune.json')
target = repo / 'kernel/asterinas/target'
archive = repo / 'support/build/evidence/2026-10-18-main012-current/guest-artifacts.tar.xz'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()
record = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'repo': str(repo), 'target': str(target), 'reason': 'Remove only archived, regenerable A01 compilation cache to permit a new isolated current-main build.', 'head': git('rev-parse', 'HEAD'), 'free_before': shutil.disk_usage(repo).free, 'archive': str(archive)}
assert record['head'] == '71524be19383e2ff98f6abc90668c48988e7c8e2'
assert git('status', '--porcelain=v1') == ''
assert target.is_dir() and not target.is_symlink()
assert not git('ls-files', '--', 'kernel/asterinas/target')
assert git('check-ignore', 'kernel/asterinas/target') == 'kernel/asterinas/target'
assert not (repo / 'kernel/asterinas/kernel/OSDK.toml').exists()
assert sha(archive.read_bytes()) == 'dbf024d66dc6e5d31702a9d8fed0826cb470784cf315a15fd7a73d16c853b22d'
record['archive_sha256'] = sha(archive.read_bytes())
record['archive_git_blob'] = git('hash-object', str(archive))
assert record['archive_git_blob'] == git('rev-parse', 'HEAD:support/build/evidence/2026-10-18-main012-current/guest-artifacts.tar.xz')
lock_path = repo / 'support/build/out-kernel.lock'
with open(lock_path, 'a+b') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    record['lock'] = {'path': str(lock_path), 'inode': os.fstat(lock.fileno()).st_ino, 'exclusive_nonblocking_acquired': True}
    bindings = [('boot/kernel.elf', 'osdk/asterinas/asterinas-osdk-bin.elf'), ('ktest/ostd.elf', 'osdk/ostd/ostd-osdk-bin.elf'), ('ktest/aster-core.elf', 'osdk/aster-core/aster-core-osdk-bin.elf')]
    record['preserved_artifacts'] = []
    with tarfile.open(archive, 'r:xz') as tf:
        for member, relative in bindings:
            live = target / relative
            assert live.is_file() and not live.is_symlink()
            archived = tf.extractfile(member).read()
            original = live.read_bytes()
            assert archived == original
            record['preserved_artifacts'].append({'archive_member': member, 'cache_path': str(live), 'size': len(original), 'sha256': sha(original), 'bytes_equal': True})
    before = target.lstat()
    record['cache_inode'] = before.st_ino
    record['action'] = 'delete-only-ignored-target-after-verifying-published-artifact-copies'
    receipt.write_text(json.dumps(record, indent=2) + '\n')
    assert stat.S_ISDIR(before.st_mode) and target.lstat().st_ino == before.st_ino
    shutil.rmtree(target)
    record['target_absent_after'] = not target.exists()
    record['git_status_after'] = git('status', '--porcelain=v1')
    record['free_after'] = shutil.disk_usage(repo).free
    record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
