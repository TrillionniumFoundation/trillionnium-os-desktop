import datetime, json, pathlib, subprocess, shutil

old = pathlib.Path('/workspace/scratch/d7da9e7650f0/a01-current')
new = old.parent / 'a01-mainf9'
out = pathlib.Path('/tmp/a01-round2-acquisition')
main = 'f9e306f76154590e096a42f70ce9de0a7c859e60'
prior = '71524be19383e2ff98f6abc90668c48988e7c8e2'
records = []
def run(cwd, *args):
    began = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(['git', '-C', str(cwd), *args], text=True, capture_output=True)
    records.append({'started_at': began, 'cwd': str(cwd), 'argv': ['git', *args], 'stdout': result.stdout, 'stderr': result.stderr, 'returncode': result.returncode})
    (out / 'worktree-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    if result.returncode: raise SystemExit(result.stderr)
    return result.stdout.strip()

assert not new.exists()
assert run(old, 'rev-parse', 'origin/main') == main
assert run(old, 'rev-parse', 'origin/agents/A01-asterinas-boot') == prior
run(old, 'worktree', 'add', '--no-checkout', '--detach', str(new), main)
selected = ['docs', 'libs', 'kernel/asterinas', 'tests/organ_backend'] + ['support/build/' + n for n in ['minimal', 'ktest', 'debug', 'tests', 'osdk-integration', 'repro', 'linux-guest']]
run(new, 'sparse-checkout', 'set', '--cone', *selected)
assert run(new, 'rev-parse', 'HEAD') == main
run(new, 'merge', '--no-commit', '--no-ff', prior)
assert not run(new, 'ls-files', '-u')
tree = run(new, 'write-tree')
assert (new / 'README.md').stat().st_size == 0
assert not (new / 'kernel/asterinas/target').exists()
assert not (new / 'kernel/asterinas/kernel/OSDK.toml').exists()
summary = {'captured_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'repo': str(new), 'main_first_parent': main, 'a01_second_parent': prior, 'merged_tree': tree, 'selected_sparse_directories': selected, 'kernel_complete': True, 'root_readme_bytes': 0, 'target_absent': True, 'public_manifest_absent': True, 'free_bytes': shutil.disk_usage(new).free, 'changes_against_main': run(new, 'diff', '--cached', '--name-status'), 'changes_against_prior': run(new, 'diff', '--cached', prior, '--name-status')}
(out / 'worktree.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
