import datetime, json, pathlib, subprocess, shutil
new = pathlib.Path('/workspace/scratch/d7da9e7650f0/a01-mainf9')
out = pathlib.Path('/tmp/a01-round2-acquisition')
main = 'f9e306f76154590e096a42f70ce9de0a7c859e60'
prior = '71524be19383e2ff98f6abc90668c48988e7c8e2'
records = []
def run(*args):
    began = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(['git', '-C', str(new), *args], text=True, capture_output=True)
    records.append({'started_at': began, 'cwd': str(new), 'argv': ['git', *args], 'stdout': result.stdout, 'stderr': result.stderr, 'returncode': result.returncode})
    (out / 'worktree-recovery-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    if result.returncode: raise SystemExit(result.stderr)
    return result.stdout.strip()
assert run('rev-parse', 'HEAD') == main
assert run('ls-files') == ''
run('read-tree', '-m', '-u', 'HEAD')
assert run('status', '--porcelain=v1') == ''
run('merge', '--no-commit', '--no-ff', prior)
assert not run('ls-files', '-u')
tree = run('write-tree')
assert (new / 'README.md').stat().st_size == 0
assert not (new / 'kernel/asterinas/target').exists()
assert not (new / 'kernel/asterinas/kernel/OSDK.toml').exists()
summary = {'captured_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'repo': str(new), 'main_first_parent': main, 'a01_second_parent': prior, 'merged_tree': tree, 'selected_sparse_directories': run('sparse-checkout', 'list').splitlines(), 'kernel_complete': True, 'root_readme_bytes': 0, 'target_absent': True, 'public_manifest_absent': True, 'free_bytes': shutil.disk_usage(new).free, 'changes_against_main': run('diff', '--cached', '--name-status'), 'changes_against_prior': run('diff', '--cached', prior, '--name-status')}
(out / 'worktree.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k:v for k,v in summary.items() if k != 'changes_against_main'}, indent=2))
