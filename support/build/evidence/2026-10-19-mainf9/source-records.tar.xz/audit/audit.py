#!/usr/bin/env python3
"""Read immutable Git objects and write only this audit's /tmp directory."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import subprocess

REPO = Path('/workspace/scratch/d7da9e7650f0/a01-current')
OUT = Path('/tmp/a01-round2-source-audit')
BASE = '01225ab0a20a9f25dd8313a7fad7652dd9154e30'
MAIN = 'f9e306f76154590e096a42f70ce9de0a7c859e60'
UPSTREAM = 'c4b7ed575b7b32773475b194d2ad41fb6d03765b'
TREE = '96605cf64aeae2d34f29b97e85eff9315fe10a8e'
PREVIOUS_A01 = '71524be19383e2ff98f6abc90668c48988e7c8e2'
PREFIX = 'kernel/asterinas/'
DOCS = [
    'docs/agents/PLAN.md', 'docs/PROJECT.md', 'docs/ARCHITECTURE.md',
    'docs/NATIVE_ABI.md', 'docs/ROADMAP.md', 'docs/STATUS.md',
    'support/upstream-lock.json', 'kernel/asterinas/AGENTS.md',
]


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def tree(ref: str) -> dict:
    result = {}
    for entry in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if not entry:
            continue
        metadata, path = entry.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        result[path.decode()] = {'mode': mode, 'type': kind, 'git_blob': oid}
    return result


def describe(ref: str, path: str) -> dict:
    content = git('show', ref + ':' + path)
    metadata = git('ls-tree', ref, '--', path).decode().split('\t', 1)[0].split()
    return {
        'path': path, 'git_blob': metadata[2], 'mode': metadata[0],
        'bytes': len(content), 'lines': len(content.splitlines()),
        'sha256': hashlib.sha256(content).hexdigest(),
    }


def text(ref: str, path: str) -> str:
    return git('show', ref + ':' + path).decode()


def same_paths(ref1: str, ref2: str, paths: list[str]) -> dict:
    return {path: git('rev-parse', ref1 + ':' + path) == git('rev-parse', ref2 + ':' + path)
            for path in paths}


def symbols(path: str, names: list[str], ref: str = MAIN) -> dict:
    lines = text(ref, path).splitlines()
    return {
        'source': describe(ref, path),
        'symbols': {name: [i + 1 for i, line in enumerate(lines)
                           if re.search(r'\b(?:fn|struct|trait)\s+' + re.escape(name) + r'\b', line)]
                    for name in names},
    }


def main() -> None:
    OUT.mkdir(exist_ok=True, parents=True)
    original = tree(UPSTREAM)
    current = tree(MAIN + ':' + PREFIX.rstrip('/'))
    missing = sorted(set(original) - set(current))
    added = sorted(set(current) - set(original))
    modified = [path for path in original.keys() & current.keys()
                if original[path] != current[path]]
    protected = [path for path in original
                 if (Path(path).name.startswith(('LICENSE', 'COPYING', 'NOTICE', 'README'))
                     or Path(path).name == 'AGENTS.md'
                     or path in ('.licenserc.yaml', '.github/workflows/check_licenses.yml'))]
    protected_changed = [path for path in protected if current.get(path) != original[path]]
    document_records = [describe(MAIN, path) | {
        'read_in_full': True,
        'identical_to_previous_main': git('show', MAIN + ':' + path) == git('show', BASE + ':' + path),
    } for path in DOCS]
    lock = json.loads(text(MAIN, 'support/upstream-lock.json'))
    changes = []
    for row in git('diff', '--name-status', BASE, MAIN).decode().splitlines():
        status, path = row.split('\t', 1)
        changes.append({'status': status, 'path': path,
                        'before': None if status == 'A' else describe(BASE, path),
                        'after': None if status == 'D' else describe(MAIN, path)})
    cpu_path = PREFIX + 'kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu.rs'
    cpu_before, cpu_after = text(BASE, cpu_path), text(MAIN, cpu_path)
    # Compare unchanged implementation sections, not line numbers shifted by the parser extraction.
    max_impl_before = cpu_before.split('impl CpuMax {', 1)[1].split('impl super::SubControl for CpuController', 1)[0]
    max_impl_after = cpu_after.split('impl CpuMax {', 1)[1].split('impl super::SubControl for CpuController', 1)[0]
    runtime_before = cpu_before.split('impl super::SubControlStatic for CpuController', 1)[1].split('#[cfg(ktest)]', 1)[0]
    runtime_after = cpu_after.split('impl super::SubControlStatic for CpuController', 1)[1].split('#[cfg(ktest)]', 1)[0]
    parser_path = PREFIX + 'kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu/max_config.rs'
    controller_tests_path = PREFIX + 'kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu/config_regressions.rs'
    parser_tests = re.findall(r'#\[cfg_attr\(ktest, ktest\)\]\s*#\[cfg_attr\(not\(ktest\), test\)\]\s*fn\s+(\w+)', text(MAIN, parser_path))
    controller_tests = re.findall(r'#\[ktest\]\s*fn\s+(\w+)', text(MAIN, controller_tests_path))
    retained_scopes = same_paths(BASE, MAIN, [
        'support/build', 'support/upstream-lock.json',
        PREFIX + 'osdk', PREFIX + 'ostd', PREFIX + 'Cargo.lock',
        PREFIX + 'rust-toolchain.toml', PREFIX + 'Makefile', PREFIX + 'OSDK.toml',
        PREFIX + 'kernel/core/src/process', PREFIX + 'kernel/core/src/syscall/ioctl.rs',
        PREFIX + 'kernel/core/src/device/misc/hepta_control.rs',
        PREFIX + 'kernel/core/src/sched', 'libs/os-abi', 'libs/os-control',
    ])
    pin_inputs = [describe(MAIN, p) for p in [
        PREFIX + 'Cargo.lock', PREFIX + 'osdk/Cargo.lock', PREFIX + 'rust-toolchain.toml',
        PREFIX + 'Makefile', PREFIX + 'OSDK.toml',
        'support/build/minimal/Cargo.lock', 'support/build/minimal/OSDK.toml',
        'support/build/ktest/locks/ostd.Cargo.lock',
        'support/build/ktest/locks/aster-core.Cargo.lock', 'libs/os-abi/src/lib.rs',
    ]]
    interfaces = {
        'A05_process': symbols(PREFIX + 'kernel/core/src/process/process/mod.rs', [
            'Process', 'hepta_exec_epoch', 'hepta_capspace_session',
            'advance_hepta_exec_epoch', 'cgroup', 'set_cgroup', 'set_cpu_cgroup_for_tasks']),
        'A05_exec': symbols(PREFIX + 'kernel/core/src/process/execve.rs', ['do_execve', 'do_execve_no_return']),
        'A05_init': symbols(PREFIX + 'kernel/core/src/process/process/init_proc.rs', [
            'spawn_init_process', 'create_init_process', 'create_init_task']),
        'A05_ioctl': symbols(PREFIX + 'kernel/core/src/syscall/ioctl.rs', ['sys_ioctl']),
        'A05_device': symbols(PREFIX + 'kernel/core/src/device/misc/hepta_control.rs', [
            'HeptaControlDevice', 'HeptaControlFile', 'open', 'check_session', 'ioctl']),
        'A06_scheduler': symbols(PREFIX + 'kernel/core/src/sched/sched_class/mod.rs', [
            'ClassScheduler', 'PerCpuClassRqSet', 'replenish_throttled', 'pick_next_entity',
            'try_pick_next', 'update_current', 'dequeue_current']),
        'A06_cpu_controller': symbols(cpu_path, ['CpuController', 'CpuMax', 'write_attr',
            'charge_bandwidth_hierarchy', 'bandwidth_available_hierarchy', 'task_cpu_eligible',
            'charge_task_cpu', 'charge_cpu_time']),
        'A06_cpu_parser': symbols(parser_path, ['CpuMaxConfig', 'parse']),
        'A05_A06_thread_lease': symbols(PREFIX + 'kernel/core/src/process/posix_thread/mod.rs', [
            'cpu_cgroup', 'set_cpu_cgroup', 'CpuCgroupLease']),
        'A06_cgroup_lease': symbols(PREFIX + 'kernel/core/src/fs/fs_impls/cgroupfs/systree_node.rs', [
            'retain_cpu_charge_lease', 'release_cpu_charge_lease']),
    }
    checks = {
        'upstream_commit_object_exists': git('cat-file', '-t', UPSTREAM).strip() == b'commit',
        'upstream_tree_matches_pin': git('rev-parse', UPSTREAM + '^{tree}').decode().strip() == TREE,
        'main_pin_commit_matches': lock['kernel']['commit'] == UPSTREAM,
        'main_pin_tree_matches': lock['kernel']['tree'] == TREE,
        'main_pin_toolchain_matches': lock['kernel']['toolchain'] == 'nightly-2026-07-21',
        'main_full_kernel_single_root': lock['kernel']['reuse'] == 'full_kernel_derived' and lock['kernel']['source_directory'] == 'kernel/asterinas',
        'root_readme_zero_bytes': git('show', MAIN + ':README.md') == b'',
        'all_original_paths_retained': not missing,
        'protected_upstream_documents_unchanged': not protected_changed,
        'required_documents_identical_to_main012': all(d['identical_to_previous_main'] for d in document_records),
        'non_cpu_parser_scopes_unchanged': all(retained_scopes.values()),
        'cpu_max_accounting_impl_unchanged': max_impl_before == max_impl_after,
        'cpu_resource_runtime_and_final_charge_unchanged': runtime_before == runtime_after,
        'exactly_seven_new_parser_regressions': len(parser_tests) == 7,
        'exactly_two_new_controller_regressions': len(controller_tests) == 2,
    }
    if not all(checks.values()):
        raise SystemExit('source checks failed: ' + repr(checks))
    result = {
        'schema': 1,
        'completed_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'agent': '/root/main_audit',
        'scope': 'read-only immutable main Git objects; no Cargo, rustc, QEMU, target or manifest operations',
        'repository': 'TrillionniumFoundation/trillionnium-os-desktop',
        'object_store': str(REPO),
        'main_commit': MAIN, 'main_tree': git('rev-parse', MAIN + '^{tree}').decode().strip(),
        'main_parents': git('show', '-s', '--format=%P', MAIN).decode().split(),
        'comparison_base': BASE, 'previous_published_A01': PREVIOUS_A01,
        'producer_commit': None,
        'producer_note': 'Parent will bind a separate merged build producer; these main facts are not a build receipt.',
        'kernel_subtree': git('rev-parse', MAIN + ':kernel/asterinas').decode().strip(),
        'core_subtree': git('rev-parse', MAIN + ':kernel/asterinas/kernel/core').decode().strip(),
        'documents': document_records, 'pin_inputs': pin_inputs,
        'changes_main012_to_mainf9': changes,
        'diff_stat': git('diff', '--stat', BASE, MAIN).decode(),
        'unchanged_scopes': retained_scopes,
        'upstream_retention': {
            'commit': UPSTREAM, 'tree': TREE, 'upstream_files': len(original),
            'main_kernel_files': len(current), 'missing_original_paths': missing,
            'modified_original_paths': sorted(modified), 'added_derived_paths': added,
            'unchanged_original_files': len(original) - len(modified) - len(missing),
            'protected_document_files': len(protected), 'protected_changed_paths': protected_changed,
            'note': 'Tree-level blob/mode identity. The later A01 merged producer may contain one additional OSDK file.',
        },
        'fix_scope': {
            'owner': 'A06; process interfaces remain A05; shared changes coordinated by A00',
            'malformed_explicit_period': 'reject before owner mutation, formerly treated as omitted',
            'overflowing_explicit_period': 'reject before owner mutation, formerly treated as omitted',
            'extra_fields': 'reject rather than accepting a valid prefix',
            'valid_single_quota': 'preserve the owner period under the existing budget lock',
            'valid_quota_period': 'reuse existing quota/period bounds and CpuMax::reconfigure',
            'mutation_lock': 'SpinLock<CpuMax, LocalIrqDisabled>',
            'linux_equivalence': 'The owner documentation explicitly calls malformed-input strictness a project choice, not exact Linux parser equivalence.',
            'core_accounting_unchanged': max_impl_before == max_impl_after and runtime_before == runtime_after,
            'hos2_operations_added': 0,
        },
        'new_tests_source_inventory': {
            'parser_file': parser_path, 'parser_names': parser_tests,
            'controller_file': controller_tests_path, 'controller_names': controller_tests,
            'controller_fields_asserted_unchanged': [
                'quota_usec', 'period_usec', 'window_start', 'used_clocks', 'carry_debt_clocks',
                'nr_periods', 'nr_throttled', 'throttled_since', 'throttled_clocks'],
            'host_entry': 'tests/organ_backend/cpu_max_config_host.rs',
            'userspace_regression': PREFIX + 'test/initramfs/src/regression/process/cgroup.sh',
            'expected_aster_core_reported': 169,
            'expected_ostd_reported_from_unchanged_source': 221,
            'expected_ostd_soft_skips_if_same_TCG_capabilities': 3,
            'expectation_basis': 'Previous b39 native core 160 plus 9 newly compiled ktests. Counts are expectations, not current execution results.',
            'executed_by_this_audit': False,
        },
        'interfaces': interfaces,
        'source_checks': checks,
        'source_checks_true': sum(checks.values()),
        'native_execution_result': None,
        'historical_state_note': 'STATUS top R8 includes Linux-host trusted ObjectiveStart and real Rust Shell projection; earlier unresolved statements are historical. Native HOS2 four effects and durable K-D/G1/G2 remain outside this parser fix.',
        'retrieval_note': 'Initial default-sandbox Git diff could not lazily fetch a promisor blob due proxy connectivity. The authorized require_escalated read succeeded; no source/branch/index mutation was performed by this audit.',
    }
    (OUT / 'main-source-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'main012-to-mainf9.diff').write_bytes(git('diff', BASE, MAIN))
    print(json.dumps({'source_checks_true': sum(checks.values()), 'source_checks_total': len(checks),
                      'documents_read': len(document_records), 'status_lines': next(d['lines'] for d in document_records if d['path'] == 'docs/STATUS.md'),
                      'main_kernel_files': len(current), 'expected_core': 169,
                      'output': str(OUT / 'main-source-audit.json')}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
