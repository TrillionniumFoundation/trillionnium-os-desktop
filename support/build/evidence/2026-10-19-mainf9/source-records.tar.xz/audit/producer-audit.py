#!/usr/bin/env python3
"""Audit a frozen producer; only /tmp receives output, no build or temp manifest access."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tomllib

REPO = Path('/workspace/scratch/d7da9e7650f0/a01-mainf9')
OUT = Path('/tmp/a01-round2-source-audit')
PRODUCER = '7758ffe294bb0e1eab46e20cba60e8af9d8bcd61'
EXPECTED_TREE = '98c7b099ff280f0804041dca13d691d431a8caf6'
EXPECTED_KERNEL_TREE = '9b400ccf16c275935736e6e2b0b08aecbe20c40e'
MAIN = 'f9e306f76154590e096a42f70ce9de0a7c859e60'
A01 = '71524be19383e2ff98f6abc90668c48988e7c8e2'
UPSTREAM = 'c4b7ed575b7b32773475b194d2ad41fb6d03765b'
UPSTREAM_TREE = '96605cf64aeae2d34f29b97e85eff9315fe10a8e'
PREFIX = 'kernel/asterinas/'
EPHEMERAL_MANIFEST = PREFIX + 'kernel/OSDK.toml'


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def oid(spec):
    return git('rev-parse', spec).decode().strip()


def read_blob(ref, path):
    return git('show', ref + ':' + path)


def entries(ref):
    found = {}
    for raw in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if not raw:
            continue
        meta, path = raw.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        found[path.decode()] = {'mode': mode, 'type': kind, 'git_blob': blob}
    return found


def describe(ref, path):
    data = read_blob(ref, path)
    return {'path': path, 'git_blob': oid(ref + ':' + path),
            'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def fingerprint(st):
    return (st.st_dev, st.st_ino, st.st_mode, st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def check_tracked(path, expected):
    # The only on-disk checks are exact tracked inputs, never an ignored target
    # or the ephemeral kernel/OSDK.toml. Other manifest contents are read as
    # immutable Git objects below; avoid accessing on-disk *.toml / *manifest*.
    assert path != EPHEMERAL_MANIFEST
    assert 'target' not in Path(path).parts
    absolute = REPO / path
    before = absolute.lstat()
    if expected['mode'] == '120000':
        if not stat.S_ISLNK(before.st_mode):
            return {'path': path, 'match': False, 'reason': 'expected_tracked_symlink'}
        # Hash the stored link bytes; never follow or open the link's target.
        data = os.fsencode(os.readlink(absolute))
        after = absolute.lstat()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        stable = fingerprint(before) == fingerprint(after)
        return {'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                'git_blob': blob, 'mode': '120000', 'symlink_target_not_followed': True,
                'stable_symlink_metadata': stable, 'match': stable and blob == expected['git_blob']}
    if not stat.S_ISREG(before.st_mode):
        return {'path': path, 'match': False, 'reason': 'not_regular'}
    fd = os.open(absolute, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd)
        chunks = []
        while chunk := os.read(fd, 1 << 20):
            chunks.append(chunk)
        after = os.fstat(fd)
        last = absolute.lstat()
    finally:
        os.close(fd)
    data = b''.join(chunks)
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    mode = '100755' if (after.st_mode & 0o111) else '100644'
    stable = fingerprint(before) == fingerprint(opened) == fingerprint(after) == fingerprint(last)
    return {'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': blob, 'mode': mode, 'stable_fd_and_path': stable,
            'match': stable and blob == expected['git_blob'] and mode == expected['mode']}


def package_identity(package):
    return (package['name'], package['version'], package.get('source'), package.get('checksum'))


def main():
    began = now()
    head_before = oid('HEAD')
    project = entries(PRODUCER)
    upstream = entries(UPSTREAM)
    kernel = {p[len(PREFIX):]: entry for p, entry in project.items() if p.startswith(PREFIX)}
    missing = sorted(set(upstream) - set(kernel))
    added = sorted(set(kernel) - set(upstream))
    modified = sorted(p for p in upstream.keys() & kernel.keys() if upstream[p] != kernel[p])
    mode_changes = sorted(p for p in upstream.keys() & kernel.keys()
                          if upstream[p]['mode'] != kernel[p]['mode'] or upstream[p]['type'] != kernel[p]['type'])
    protected = sorted(p for p in upstream
                       if (Path(p).name.startswith(('LICENSE', 'COPYING', 'NOTICE', 'README'))
                           or Path(p).name == 'AGENTS.md'
                           or p in ('.licenserc.yaml', '.github/workflows/check_licenses.yml')))
    protected_changes = [p for p in protected if kernel.get(p) != upstream[p]]
    core_scopes = [PREFIX + 'kernel', PREFIX + 'ostd', PREFIX + 'test',
                   'libs/os-abi', 'libs/os-control', 'docs', 'tests/organ_backend']
    owner_identity = {p: {'producer': oid(PRODUCER + ':' + p), 'main': oid(MAIN + ':' + p),
                          'equal': oid(PRODUCER + ':' + p) == oid(MAIN + ':' + p)} for p in core_scopes}
    build_scopes = ['support/build', 'support/upstream-lock.json', PREFIX + 'osdk']
    build_identity = {p: {'producer': oid(PRODUCER + ':' + p), 'previous_A01': oid(A01 + ':' + p),
                          'equal': oid(PRODUCER + ':' + p) == oid(A01 + ':' + p)} for p in build_scopes}
    pin_paths = [PREFIX + 'Cargo.lock', PREFIX + 'rust-toolchain.toml', PREFIX + 'Cargo.toml',
                 PREFIX + 'Makefile', PREFIX + 'OSDK.toml', PREFIX + 'osdk/Cargo.lock',
                 PREFIX + 'osdk/Cargo.toml', 'support/build/minimal/Cargo.lock',
                 'support/build/minimal/OSDK.toml', 'support/build/ktest/locks/ostd.Cargo.lock',
                 'support/build/ktest/locks/aster-core.Cargo.lock', 'libs/os-abi/src/lib.rs']
    pin_inputs = {p: describe(PRODUCER, p) for p in pin_paths}
    lock = json.loads(read_blob(PRODUCER, 'support/upstream-lock.json'))
    approved = lock['kernel']['approved_host_osdk_inputs']
    package_sets = {}
    for path in pin_paths:
        if not path.endswith('Cargo.lock'):
            continue
        packages = tomllib.loads(read_blob(PRODUCER, path).decode()).get('package', [])
        git_packages = [v for v in packages if v.get('source', '').startswith('git+')]
        registry = [v for v in packages if v.get('source', '').startswith('registry+')]
        package_sets[path] = {
            'packages': len(packages), 'git_packages': len(git_packages), 'registry_packages': len(registry),
            'git_revisions_full_sha': all(re.search(r'#[0-9a-f]{40}$', v['source']) for v in git_packages),
            'registry_checksums_present': all(re.fullmatch(r'[0-9a-f]{64}', v.get('checksum', '')) for v in registry),
        }
    up_osdk = tomllib.loads(read_blob(UPSTREAM, 'osdk/Cargo.lock').decode())['package']
    derived_osdk = tomllib.loads(read_blob(PRODUCER, PREFIX + 'osdk/Cargo.lock').decode())['package']
    source_docs = json.loads((OUT / 'main-source-audit.json').read_text())['documents']
    documents = []
    for d in source_docs:
        path = d['path']
        actual = describe(PRODUCER, path)
        actual['lines'] = len(read_blob(PRODUCER, path).splitlines())
        actual['equal_to_read_main_document'] = actual['sha256'] == d['sha256']
        actual['note'] = ('A01 report history and approved host OSDK inputs retained from previous A01; immutable pin fields unchanged'
                          if path == 'support/upstream-lock.json' else 'Matches fully read main document')
        documents.append(actual)

    # Exclude all on-disk manifests/TOML; their identity is checked from Git only.
    # Historical sparse evidence is irrelevant to the operational source check.
    selected = []
    omitted_manifests = []
    for path in sorted(project):
        if not (path.startswith(PREFIX) or path.startswith('support/build/')
                or path in ('README.md', 'support/upstream-lock.json', 'libs/os-abi/src/lib.rs')):
            continue
        if path.startswith(('support/build/evidence/', 'support/build/handoffs/')):
            continue
        if path == EPHEMERAL_MANIFEST or 'target' in Path(path).parts:
            raise RuntimeError('A forbidden temporary path is unexpectedly tracked: ' + path)
        if path.endswith('.toml') or 'manifest' in Path(path).name.lower():
            omitted_manifests.append(describe(PRODUCER, path))
            continue
        selected.append(path)
    workspace_checks = [check_tracked(path, project[path]) for path in selected]
    failures = [row for row in workspace_checks if not row['match']]
    index_listing = git('ls-files', '-v', '--', 'kernel/asterinas').decode().splitlines()
    skipped_kernel_paths = [line[2:] for line in index_listing if line.startswith('S ')]
    index_paths = [line[2:] for line in index_listing]
    head_after = oid('HEAD')
    producers_delta = git('diff', '--name-status', A01, PRODUCER).decode().splitlines()
    checks = {
        'exact_head_before_after': head_before == PRODUCER == head_after,
        'exact_project_tree': oid(PRODUCER + '^{tree}') == EXPECTED_TREE,
        'exact_kernel_tree': oid(PRODUCER + ':kernel/asterinas') == EXPECTED_KERNEL_TREE,
        'ordered_parents_main_then_A01': git('show', '-s', '--format=%P', PRODUCER).decode().split() == [MAIN, A01],
        'upstream_commit_type': git('cat-file', '-t', UPSTREAM).strip() == b'commit',
        'upstream_git_tree': oid(UPSTREAM + '^{tree}') == UPSTREAM_TREE,
        'pinned_commit_tree_toolchain': (lock['kernel']['commit'], lock['kernel']['tree'], lock['kernel']['toolchain']) == (UPSTREAM, UPSTREAM_TREE, 'nightly-2026-07-21'),
        'full_kernel_single_directory': lock['kernel']['reuse'] == 'full_kernel_derived' and lock['kernel']['source_directory'] == 'kernel/asterinas',
        'main_owner_scopes_identical': all(row['equal'] for row in owner_identity.values()),
        'previous_A01_build_scopes_identical': all(row['equal'] for row in build_identity.values()),
        'all_original_upstream_paths_retained': not missing,
        'upstream_modes_types_unchanged': not mode_changes,
        'protected_upstream_documents_unchanged': not protected_changes,
        'sparse_does_not_skip_any_kernel_path': not skipped_kernel_paths,
        'kernel_index_lists_entire_committed_subtree': set(index_paths) == {PREFIX + p for p in kernel},
        'selected_worktree_files_match_git_and_stable': not failures,
        'root_readme_zero': read_blob(PRODUCER, 'README.md') == b'',
        'kernel_lock_matches_fixed_hash': pin_inputs[PREFIX + 'Cargo.lock']['sha256'] == lock['kernel']['cargo_lock_sha256'],
        'toolchain_file_matches_fixed_hash': pin_inputs[PREFIX + 'rust-toolchain.toml']['sha256'] == lock['kernel']['toolchain_file_sha256'],
        'approved_host_OSDK_lock_matches': pin_inputs[PREFIX + 'osdk/Cargo.lock']['sha256'] == approved['derived_lock_sha256'],
        'approved_host_OSDK_manifest_matches': pin_inputs[PREFIX + 'osdk/Cargo.toml']['sha256'] == approved['derived_manifest_sha256'],
        'upstream_OSDK_packages_preserved': set(map(package_identity, up_osdk)).issubset(set(map(package_identity, derived_osdk))),
        'Cargo_registry_and_git_pins_complete': all(v['git_revisions_full_sha'] and v['registry_checksums_present'] for v in package_sets.values()),
        'seven_narrative_required_docs_identical_to_main': all(d['equal_to_read_main_document'] for d in documents if d['path'] != 'support/upstream-lock.json'),
        'six_file_delta_from_previous_A01': len(producers_delta) == 6,
    }
    result = {
        'schema': 1, 'started_at_utc': began, 'completed_at_utc': now(),
        'agent': '/root/main_audit', 'repository': 'TrillionniumFoundation/trillionnium-os-desktop',
        'worktree': str(REPO), 'producer_commit': PRODUCER,
        'producer_tree': oid(PRODUCER + '^{tree}'), 'producer_kernel_tree': oid(PRODUCER + ':kernel/asterinas'),
        'producer_core_tree': oid(PRODUCER + ':kernel/asterinas/kernel/core'),
        'parents': [MAIN, A01], 'main_baseline': MAIN, 'previous_published_A01': A01,
        'checks': checks, 'checks_true': sum(checks.values()), 'checks_total': len(checks),
        'owner_identity': owner_identity, 'build_identity': build_identity, 'pin_inputs': pin_inputs,
        'lock_package_summary': package_sets,
        'upstream_OSDK_packages': len(up_osdk), 'derived_OSDK_packages': len(derived_osdk),
        'approved_host_OSDK_note': 'Historical kernel.osdk_cargo_lock_sha256 is not the current derived lock. Current approved_host_osdk_inputs hashes match the actual producer blobs.',
        'upstream_retention': {
            'original_files': len(upstream), 'producer_kernel_files': len(kernel),
            'unchanged_original_files': len(upstream) - len(missing) - len(modified),
            'modified_original_paths': modified, 'added_derived_paths': added,
            'missing_original_paths': missing, 'mode_type_changes': mode_changes,
            'protected_documents': protected, 'protected_changed_paths': protected_changes,
        },
        'documents': documents, 'producer_delta_from_previous_A01': producers_delta,
        'worktree_check': {
            'scope': 'Tracked kernel files and operational A01 build inputs, excluding all on-disk TOML/manifest files and historical support/build/evidence and support/build/handoffs. Excluded manifests were inspected only as immutable Git blobs. No target or ephemeral kernel/OSDK.toml access.',
            'selected_count': len(workspace_checks), 'matched_count': sum(v['match'] for v in workspace_checks),
            'git_only_manifest_count': len(omitted_manifests), 'git_only_manifests': omitted_manifests,
            'failures': failures, 'files': workspace_checks,
            'kernel_index_entries': len(index_paths), 'skipped_kernel_paths': skipped_kernel_paths,
            'not_a_full_worktree_cleanliness_claim': True,
        },
        'expected_tests_only': {'aster_core': 169, 'ostd_reported_if_same_profile': 221,
                                'ostd_soft_skips_if_same_capabilities': 3,
                                'basis': 'Main source delta: 160 prior core + 7 parser + 2 controller ktests; OSTD unchanged.',
                                'executed_by_this_audit': False},
        'native_results': None, 'runtime_or_build_commands_executed': [],
        'repo_source_index_refs_modified': False,
        'permissions_note': 'Only audit files under /tmp are written; Git object reads, stable-FD reads of explicitly selected tracked regular files, and lstat/readlink of tracked symlink bytes without dereference.',
        'reappearance_observation': 'No target, temporary manifest, or ELF was examined. This audit cannot attribute any reappearance event.',
        'prior_audit_attempt': {'exit_code': 1, 'scope_issue': 'The first audit selection included sparse-omitted historical support/build/handoffs/a02-nightly-clippy/README.md; an uncaught FileNotFoundError stopped that attempt before the final JSON. Selection now excludes the declared historical handoff area. No build or QEMU was run.', 'record': 'producer-audit-first-attempt.log'},
        'prior_audit_attempt02': {'exit_code': 1, 'scope_issue': 'The regular-only checker reported the retained upstream tracked .claude/skills/aster-code-review symlink as not_regular. The audit now checks mode 120000 using lstat/readlink without following its target. No repository file was changed.', 'record': 'producer-source-audit-attempt02.json'},
    }
    (OUT / 'producer-source-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['started_at_utc', 'completed_at_utc', 'producer_commit', 'checks_true', 'checks_total']}
                     | {'selected_worktree_count': len(workspace_checks), 'git_only_manifests': len(omitted_manifests),
                        'producer_kernel_files': len(kernel), 'modified_original_files': len(modified),
                        'new_derived_files': len(added), 'protected_documents': len(protected),
                        'worktree_failures': failures, 'failed_checks': [k for k, v in checks.items() if not v]},
                     ensure_ascii=False, indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
