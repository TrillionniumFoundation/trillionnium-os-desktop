# A01 第二轮只读 main 审计与交接

审计对象：`f9e306f76154590e096a42f70ce9de0a7c859e60`，tree `70c6f2b365baa9c3ef8561d7c9882dc24ba6ca2b`。比较基线：`01225ab0a20a9f25dd8313a7fad7652dd9154e30`。这份审计只读取固定 Git 对象，没有运行 Cargo、rustc、make、QEMU，也没有访问 target、临时 OSDK manifest 或 ELF。第一次审计仅固定 main；新 producer 的身份已在下方 2026-10-19 补充节核验。

## 当前源码结论

main012 到 mainf9 只有 6 个文件变化，共 311 行增加、43 行删除，来自合入 PR #195 的 CPU 配置解析修复。固定 Asterinas c4 commit 对象实际指向 tree 96605cf64aeae2d34f29b97e85eff9315fe10a8e；v0.19.0、nightly-2026-07-21、完整派生方式和唯一 kernel/asterinas 根均保持。

本 main 内核目录有 2944 个 tracked 文件；完整上游 2938 个原始文件全部保留，其中 2917 个 blob/mode/type 未变。许可、README、AGENTS 及许可证检查配置的保护集合没有差异。A01 合并其已有 OSDK 分支后，最终 producer 的文件数可能不同，不能把 main 的计数直接写成 producer 的计数。项目根 README 为 0 字节。

15 项源码身份/范围检查均成立；该数字是静态审计检查数，不是内核回归结果。

## 最新修复的实际边界

[`CpuController::write_attr`](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/f9e306f76154590e096a42f70ce9de0a7c859e60/kernel/asterinas/kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu.rs) 在复制并转换 `cpu.max` 输入后，先调用新 [`CpuMaxConfig::parse`](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/f9e306f76154590e096a42f70ce9de0a7c859e60/kernel/asterinas/kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu/max_config.rs)，成功才取得现有 `SpinLock<CpuMax, LocalIrqDisabled>` 并调用 `CpuMax::reconfigure`。

- 显式非数字 period（如 `1000 nope`）和溢出 period 现在拒绝；之前会被误当作省略 period，仍改变 quota。
- 多余字段（如 `1000 100000 junk`）现在拒绝；之前会接受有效前缀。
- 单独合法 quota 仍在预算锁内继承当前 owner period。合法 quota+period、`max` 及既有数值范围保留。
- CpuMax 计费实现、层级资格/计费和 final-charge 路径的实际字节段未变。process、ioctl、scheduler、OSTD、A01 构建工具、A02/A03 和固定 Cargo/toolchain 输入没有该次 main 差异。
- 这是项目对畸形输入的明确严格选择；owner 文档没有承诺 Linux parser 的逐字节同等行为。没有新增 HOS2 操作或权限授予。

实际用户态 `cgroup.sh` 已改为期待畸形 period 拒绝，且读取 quota/period 保持原值；最小 boot initramfs 不自动运行整套用户态 regression。

## 回归源码与待执行数量

[`max_config.rs`](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/f9e306f76154590e096a42f70ce9de0a7c859e60/kernel/asterinas/kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu/max_config.rs) 有 7 个同源 host/ktest 测试；[`config_regressions.rs`](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/f9e306f76154590e096a42f70ce9de0a7c859e60/kernel/asterinas/kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu/config_regressions.rs) 有 2 个真实 `CpuController::write_attr` + `VmReader` 内核测试。后者检查畸形输入保持 quota、period、window_start、used_clocks、carry_debt_clocks、nr_periods、nr_throttled、throttled_since、throttled_clocks 全部不变，并检查合法单 quota 保留 owner period。

根据前一轮 b39 的实际 core 160，加上这 9 个新增注册，**本轮 core 预期 169**。OSTD 源码不变，若使用相同 TCG 能力，预期仍报告 221，其中 3 个 VMX/EPT soft skip。**这些数值是源码预期；本审计没有执行任何 Rust 或 QEMU 测试，也没有新的 PASS 收据。**

可执行入口：

```bash
# 在最终 producer 根、固定运行环境激活后
support/build/kernel.sh kernel
support/build/kernel.sh run_kernel
python3 -B -I support/build/ktest/run.py

# 仅 CPU production-parser 的独立宿主入口
rustc --edition=2024 --test -Dwarnings \
  --check-cfg 'cfg(test)' --check-cfg 'cfg(ktest)' \
  tests/organ_backend/cpu_max_config_host.rs -o /tmp/cpu-max-config-tests
/tmp/cpu-max-config-tests --nocapture
```

A01 wrapper 的根入口仍为上游 `make kernel` / `make run_kernel`，upstream Makefile 进入 `kernel` 子目录调用 `cargo osdk build/run`。精确 argv、环境、ELF 和串口必须由本轮实际 producer 的执行收据给出。

## A05 交接

| 源码路径（相对 kernel/asterinas） | 具体接口及约束 |
| --- | --- |
| `kernel/core/src/process/process/mod.rs` | `Process`；`hepta_capspace_session()` 在进程锁内返回一致 exec_epoch/nonce；`hepta_exec_epoch()`；`advance_hepta_exec_epoch()` 使用 checked increment 并使旧身份失效 |
| `kernel/core/src/process/execve.rs` | `do_execve()` 在 `do_execve_no_return()` 成功后推进 epoch；耗尽时终止进程 |
| `kernel/core/src/process/process/init_proc.rs` | `spawn_init_process()`、`create_init_process()`、`create_init_task()`；最后 `process.run()` 是现有启动接合位置，不意味着可信 grant 已实现 |
| `kernel/core/src/syscall/ioctl.rs` | `sys_ioctl()` 将 file 引用转成 owned，释放 file-table borrow 后再调用真实 `FileLike::ioctl` |
| `kernel/core/src/device/misc/hepta_control.rs` | `HeptaControlDevice::open()`、`HeptaControlFile::check_session()` 和 `PerOpenFileOps::ioctl()`；实际 Process `Arc::ptr_eq` 与 exec_epoch 检查 |
| `kernel/core/src/lib.rs` | 通过 path 引入仓库唯一 `libs/os-abi/src/lib.rs`；没有第二份 wire codec |

设备为 `/dev/hepta-control`，实验 ioctl `0xC0204802`，当前只返回 QueryAbi、支持位只开放 QueryAbi。ReadUsage、InstallBudget、QueryDelivery、RetireThrough 仍返回 EOPNOTSUPP。该次 CPU parser fix 没有改变这些内容。实际只读 guest probe 和 future effect 权限验收必须分别记录，不能由通用 boot 自动推定。

## A06 交接

| 源码路径（相对 kernel/asterinas） | 具体接口及约束 |
| --- | --- |
| `kernel/core/src/sched/sched_class/mod.rs` | `ClassScheduler` / `PerCpuClassRqSet`；`LocalRunQueue::try_pick_next`、`update_current`、`dequeue_current`，以及 `pick_next_entity`、`replenish_throttled` |
| `kernel/core/src/sched/sched_class/{stop,real_time,fair,idle,time}.rs` | 现有调度类与 runtime 时间基础，沿同一 scheduler 接合 |
| `kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu.rs` | `CpuController`、`CpuMax`、`task_cpu_eligible`、`charge_task_cpu`、层级 bandwidth 计费；quota 与 cpu.stat tick usage 是各自现有字段 |
| `kernel/core/src/fs/fs_impls/cgroupfs/controller/cpu/max_config.rs` | 新 `pub(super)` 的 `CpuMaxConfig::parse` 是内部 cgroup 配置解析器，不是新增 public native ABI |
| `kernel/core/src/process/posix_thread/mod.rs` | `cpu_cgroup`、`set_cpu_cgroup`、`CpuCgroupLease`；进程文件归 A05，共享接合需沿既有约定 |
| `kernel/core/src/process/process/mod.rs` | `cgroup`、`set_cgroup`、`set_cpu_cgroup_for_tasks`；已有注释要求在 cgroup/membership 约束内使用 |
| `kernel/core/src/fs/fs_impls/cgroupfs/systree_node.rs`、`inode.rs` | `retain_cpu_charge_lease` / `release_cpu_charge_lease` 与删除/membership 边界 |

`charge_task_cpu` 保留实际存活 process 绑定；仅 detached zombie 或弱引用失效才使用线程 lease 完成尾段计费。该既有修复字节保持，但本次 parser 样本不扩大退出/reap、迁移、SMP 或严格逐窗口资格。`cpu.weight` 仍有未执行的明确 warning，不能把 bandwidth 能力等同完整 weight 调度。

## 所有权和当前产品边界

A01 继续负责 support/build、upstream-lock 和初始/构建配置；不得借此次 latest-main 同步改 A05/A06 核心。共享 OSTD、固定版本和跨 owner 变更由 A00 协调。Root 将另行绑定 merged producer 中的 A05/A06 路径与 main f9 是否完全相同。

STATUS 的顶部 R8 已包含 Linux host 上的可信 ObjectiveStart 准入与原版 run → Rust Shell 可见投影；不能引用历史段落声称这整项完全未实现。生产 issuer、durable K↔D、最终 grant、四个 native HOS2 effect 操作、G1/G2、显示/输入和移动资格仍未被本 parser fix 闭合。

## 已完整阅读的文档

| 路径 | 行数 | SHA256 |
| --- | ---: | --- |
| `docs/agents/PLAN.md` | 62 | `b5f4f8f4940c7d53632f6090a143b6ec61ff6b8c0277c2fa02dd7dee92f0dfda` |
| `docs/PROJECT.md` | 40 | `f7061998bbc30192153c2e0c8e77dcbd9ffb6a6ae9208e44299203e55609ffa4` |
| `docs/ARCHITECTURE.md` | 66 | `0a28073b9e3036f669c887ea80052a9aa6149f5ba7a4029de6c1720613485a4b` |
| `docs/NATIVE_ABI.md` | 132 | `796ed1f10d2b51067d9b386d29288235656fc91deaef5febcea52c786a7cdd93` |
| `docs/ROADMAP.md` | 64 | `09812263974d5160486fa9abcf7bac4c17c007f671b8c092dac2f8436e9b6a25` |
| `docs/STATUS.md` | 510 | `2f2087f9a7c8052c234df0b09ea7c4089c2768397ac774678044b09af3c70380` |
| `support/upstream-lock.json` | 102 | `beb48f48a77101e5456ca78aa98d3c0f4c3a3f11ca29f422e2d576ff837cc592` |
| `kernel/asterinas/AGENTS.md` | 104 | `e5d9f65c769df1846a48ec4709ed14d55043ecf9fdbcd5a0292a7ec03a867d10` |

全部 8 份与 main012 字节相同。STATUS 全部 510 行已逐段读取，历史结果保持其原始 source identity；未将其转记为本轮执行。

详细 blob/mode、全部差异、函数位置、上游保留清单与静态核验项见 `main-source-audit.json`。初次读取差异时默认沙箱无法补取 promisor blob，正常授权的网络读取后成功；这只影响 Git 对象读取，没有发生构建或目标目录操作。

## 2026-10-19：新 producer 身份补充

本次检查窗口为 `2026-10-19T00:56:26.521806+00:00` 至 `2026-10-19T00:56:27.410456+00:00`。实际独立工作树为 `/workspace/scratch/d7da9e7650f0/a01-mainf9`。

```text
Producer:    7758ffe294bb0e1eab46e20cba60e8af9d8bcd61
Project tree:98c7b099ff280f0804041dca13d691d431a8caf6
Kernel tree: 9b400ccf16c275935736e6e2b0b08aecbe20c40e
Parent 1:    f9e306f76154590e096a42f70ce9de0a7c859e60
Parent 2:    71524be19383e2ff98f6abc90668c48988e7c8e2
```

25 项静态身份、所有权和输入检查均成立。kernel/asterinas/kernel、OSTD、上游 test、libs/os-abi、libs/os-control、docs、tests/organ_backend 与 main f9 子树相同。support/build、support/upstream-lock.json 和 kernel/asterinas/osdk 与已有 A01 71524 子树相同。producer 相对前一 A01 仅多出本节前述 6 文件的 main 修复，没有本轮新的 A01 核心改动。

producer 内核总数为 **2,945**：2,938 个原始上游路径全部保留，2,906 个原始文件未改，32 个原始文件有派生差异，新增 7 个派生文件；没有模式/类型差异。84 项明确列举的许可证、README、AGENTS 及许可证检查配置均保留原 blob/mode。所有内核路径都存在于 Git index，未被 sparse skip-worktree 标记省略。

对 2,875 个选定工作文件核对了实际字节及 Git 模式，其中上游 tracked symlink 用 lstat/readlink 校验原始链接字节且不解引用；结果全部匹配、检查前后 HEAD 不变。另有 **139 个 TOML/manifest 文件只读取不可变 Git 对象**，遵守本任务不触碰工作目录 manifest 的约束；不把它们冒称为已读取实际工作文件字节。历史 support/build/evidence 和 support/build/handoffs 按 sparse 范围省略。本审计不声明整个工作树没有临时文件，也没有检查 target、临时 kernel/OSDK.toml 或 ELF。

内核 Cargo.lock 与固定工具链文件哈希匹配。当前 OSDK 派生 Cargo.lock 的 SHA256 为 `1011e26a7070708d37f2062a84b309d2c228c177a9e5434bfe63917203c17a18`，manifest 为 `39b9fa3d5cc822eb718bd3b14d872f50b48b285998f77ca5ebde38561a69c9ce`，均匹配已有 `approved_host_osdk_inputs`；全部 154 个上游 OSDK package identity/checksum 保留，派生有 159 个 package。历史 `kernel.osdk_cargo_lock_sha256` 保留原上游锁值，不能误当当前派生值。所有检查的 Cargo.lock registry checksum 和 Git 完整 SHA 引用均存在。

第一次审计执行因纳入 sparse 省略的历史 handoff 而退出 1；第二次因审计器只支持 regular 文件，将上游原有 symlink 标为 not_regular。两项都是本审计程序的范围/类型处理问题，分别保留 `producer-audit-first-attempt.log` 与 `producer-source-audit-attempt02.json`；没有改动仓库文件。修正后重新核验 25/25 成立。

本补充没有运行 Cargo、rustc、make 或 QEMU；core 169 / OSTD 221 仍是源代码预期。实际构建、guest 数量、ELF 哈希和串口结果由父 Agent 的独立执行收据提供。函数路径、A05/A06 边界及前述未完成产品能力继续适用。
