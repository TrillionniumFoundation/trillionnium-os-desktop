#!/usr/bin/env python3
"""Offline final index consistency check. Never access runtime targets or execute captured commands."""
import hashlib,json,pathlib,sys
BASE=pathlib.Path(__file__).resolve().parent
def need(ok,message):
 if not ok:raise ValueError(message)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def reference(r):
 p=pathlib.PurePosixPath(r['path']);need(not p.is_absolute() and '..' not in p.parts,'unsafe index reference')
 f=BASE.joinpath(*p.parts);need(f.is_file() and not f.is_symlink(),'missing reference '+r['path'])
 need(f.stat().st_size==r['bytes'] and sha(f)==r['sha256'],'reference changed '+r['path']);return f
try:
 d=load(BASE/'final-index.json');need(d['primary_phase_count']==30 and d['complete_nested_review_packages']==3,'phase count differs')
 accepted=d['final_accepted_validation'];need(accepted['executions']==len(accepted['receipts'])==98,'accepted check count differs')
 need(accepted['generic']==60 and accepted['shipped_or_scratch_closure']==38,'check kinds differ')
 keys=set()
 for r in accepted['receipts']:
  e=load(reference(r['receipt']));need(e['exit_code']==0,'accepted check failed');need(e['stdout_sha256'] and e['stderr_sha256'],'missing output binding')
  parent=BASE/r['receipt']['path'];parent=parent.parent
  need(sha(parent/'stdout.log')==e['stdout_sha256'] and sha(parent/'stderr.log')==e['stderr_sha256'],'execution log differs')
  key=(r['phase'],r['kind'],r['mode']);need(key not in keys,'duplicate accepted check');keys.add(key)
 attempts=d['all_executed_verification_attempts'];need(attempts['executions']==110 and attempts['exit_zero']==108 and attempts['exit_nonzero']==2,'all attempt counts differ')
 need(len(attempts['retained_original_attempts'])==12,'retained attempt count differs')
 for r in attempts['retained_original_attempts']:
  e=load(reference(r['receipt']));need(e['exit_code']==r['exit_code'],'original attempt exit differs')
  directory=(BASE/r['receipt']['path']).parent
  need(sha(directory/'stdout.log')==e['stdout_sha256'] and sha(directory/'stderr.log')==e['stderr_sha256'],'retained log differs')
 for key in ['source_indexes','classification_sources']:
  for r in d[key]:reference(r)
 reference(attempts['generic_scope_correction']);reference(attempts['native_unpublished_freeze_supersession'])
 rows=d['phase_inventory'];need(len(rows)==30 and len({r['phase'] for r in rows})==30,'duplicate/missing phase')
 need(sum(r['outer_regular_files'] for r in rows)==1247 and sum(r['outer_bytes'] for r in rows)==288729204,'physical totals differ')
 need(d['root_README_bytes']==0 and d['new_Cargo_kernel_build_VM_or_workload_runs']==0 and not d['unlisted_or_missing'] and not d['physical_files_over_2MiB'],'recorded audit scope differs')
 native={r['phase']:r['manifest_sha256'] for r in rows if r['phase'] in ['native-cloud-before','native-cloud-final']}
 need(native=={'native-cloud-before':'98a5b38fcb2c15dc59047056715153d466f8ebdc5bc53660f3d553eaad6387d8','native-cloud-final':'1def7ab5712a1c6e5c9a68461ca4e7cc57506f51a60d482ab7fed77946dca221'},'accepted native freeze differs')
 outer=None
 if (BASE/'SHA256SUMS').exists():
  expected={}
  for line in (BASE/'SHA256SUMS').read_text().splitlines():
   h,n=line.split('  ',1);p=pathlib.PurePosixPath(n);need(not p.is_absolute() and '..' not in p.parts and n not in expected,'unsafe duplicate outer path');expected[n]=h
  files={str(p.relative_to(BASE)) for p in BASE.rglob('*') if p.is_file() and p!=BASE/'SHA256SUMS'}
  need(files==set(expected),'outer index file coverage differs')
  for n,h in expected.items():need(sha(BASE/n)==h,'outer index checksum differs '+n)
  need(not any(p.is_symlink() for p in BASE.rglob('*')),'outer index symlink')
  outer={'entries':len(expected),'sha256':sha(BASE/'SHA256SUMS')}
 print(json.dumps({'passed':True,'primary_phases':30,'nested_review_packages':3,'final_accepted_checks':98,'all_actual_verification_attempts':110,'retained_nonzero_generic_scope_errors':2,'retained_superseded_native_checks':8,'physical_phase_files':1247,'physical_phase_bytes':288729204,'outer_index_manifest':outer,'python_optimized':not __debug__,'new_Cargo_kernel_VM_workloads':0,'scope':'Read only saved receipts/classification and optional outer index manifest; no phase controller or actual runtime target read.'},sort_keys=True))
except (OSError,ValueError,KeyError) as e:
 print('index verification failed: '+str(e),file=sys.stderr);sys.exit(1)
