# A01 2026-10-17 evidence index — combined draft through batch02

As of 2026-10-17T02:07:59.083121+00:00: **27 frozen primary phases +3 complete nested review packages**. Final accepted offline validation: **54 generic +32 package/source-closure executions =86**, all exit0 in isolated ordinary/optimized Python. Every phase SHA256SUMS is unchanged; no missing/unlisted files or physical file >2 MiB. Project root README remains0 bytes.

**All attempted checks are retained:** 90 actual executions,88 exit0 and2 initial generic scope errors. Those two failures and the original two shipped successes remain under append-batch02/2026-10-17-repro-cross-path/. The scratch auditor v2 corrected interpretation of one partial historical readable manifest; it did not repair package bytes. Final comparison and owner-final checks are under append-batch02/validated/.

This index adds **zero Cargo builds, kernel builds, VMs or workloads**. Its 1076physical files /104,933,933bytes are storage totals, never an acceptance denominator. Unique successful named kernel cases in this authorized set are A2,B2,A4,B4; the successful cross-path comparison adds no guests. Native/full22 and ordinary N1 evidence are excluded until separately frozen.

| Phase | SUM SHA256 | entries / physical files | Bytes | Tar regular / hardlink | Generic I/IO | Shipped exits |
| --- | --- | ---: | ---: | ---: | --- | --- |
| a02-owner-nightly | edc5cd771ac8bc4a643ece6d683b53e95e6413cebc001325766eb784cb894cb3 | 11/12 | 570715 | 75/0 | 0/0 | not shipped |
| archive-custody | 806c7c31c781164caaa974e45a2081818e1cadee414e6f56a801935c037b7b56 | 11/12 | 232699 | 126/0 | 0/0 | not shipped |
| cloud-native | d56359f0e137d7100effd727d8f97b009768b5faa7b84f91a5be74055adc5942 | 51/52 | 4114594 | 60/0 | 0/0 | 0,0 |
| integration-case-targets | c376e8472c9a28c0b7c47c25e3b6827cee4760abb16722ea7a3ffc2a7748ed2b | 31/32 | 1547770 | 1377/4 | 0/0 | not shipped |
| integration-input-snapshots | 6131edf8f387f3ef854cc33df4cd05e05ad5ea1d7776a5632c2486757879e7ce | 20/21 | 2349345 | 1207/0 | 0/0 | not shipped |
| integration-input-snapshots-final | 7497e665c4ac7777f89d5f0e94cea1a8190acabbbd8721de5c68508ab07bdae4 | 31/32 | 3201809 | 1605/0 | 0/0 | not shipped |
| integration-private-tools/host | 978532e6ef57846bbd1b9732a5b817c8fa83324baeb9f282aece3bd498c4ac6e | 19/20 | 1035243 | 637/0 | 0/0 | not shipped |
| ktest-private-inputs | 3b4f6a86682e03925acc2f69bcfe579f18720d91fbf950cb06d7f9a6dcc63a62 | 21/22 | 181101 | 161/0 | 0/0 | not shipped |
| latest-main | 35946c6e2f06dd14eb56ef083fc53c8100fbeec89de94ef3bc0812d868c69f0e | 26/27 | 745827 | 108/0 | 0/0 | not shipped |
| owner-ci | 94cefd6c7a7086d415fed7e8a1ba0dd0a0f75093e87bea5e5c25f3cdf724c046 | 39/40 | 839557 | 0/0 | 0/0 | not shipped |
| owner-refresh | f8189352e96affdcc732303cb1a6aa38bb77fdfe15402ee50fc531c4278dfaf3 | 171/172 | 7046033 | 12/0 | 0/0 | 0,0 |
| private-bios | ee73f3e7b913e35fe6074cc470c13f748727b73a4cf90de4b1526115f7441807 | 15/16 | 465201 | 341/0 | 0/0 | not shipped |
| private-qemu-data | d67643093c6722890012ccff7cde4e667802974cd11d867ba41964d70ec6254c | 14/15 | 802039 | 624/0 | 0/0 | not shipped |
| private-toolchain | 638b3c5e0a1534a4c9c0656af5390374ace6f97ffd92a985cb01f2db4949da00 | 271/272 | 22799668 | 0/0 | 0/0 | 0,0 |
| repro-cargo-disambiguator | 96794ae2826734683c834b998f8b157ba03c25c925ecbdb5ecd93c856b919f10 | 9/10 | 3725635 | 0/0 | 0/0 | 0,0 |
| repro-compiler-flags | 7fa8188b76c2c068f2e94dcb8f130ff5b07f5302afe749ebc4b63a4b2fcbeaed | 9/10 | 2508995 | 0/0 | 0/0 | 0,0 |
| repro-cross-path-before | 18750895bf9c03ed247bc62f123370bdfaef6f34ceeb4a3b044308d5f9c7f1e2 | 37/38 | 8803051 | 194/0 | 0/0 | 0,0 |
| repro-kernel-a2 | f9d4594bba1e1c8451ff70c46d878491a262e7410ff83ae1863cb35273203025 | 34/35 | 5700424 | 142/0 | 0/0 | 0,0 |
| repro-kernel-a3-before | 47d552667a3cbfacd9dfa4415ac3a0bf74d9157d1a5018559dc5ad654765b4a5 | 32/33 | 1764220 | 118/0 | 0/0 | 0,0 |
| repro-kernel-a4 | 84c4110dc73515afc7a3be4f0bf27d5850b170be2a7c250af46b3b2dd9b62f6a | 36/37 | 5746258 | 143/0 | 0/0 | 0,0 |
| repro-kernel-b2 | 2626f550815d3301e0dfaf7d82302514c7764b02246e704058d43bd4654be990 | 34/35 | 5698147 | 142/0 | 0/0 | 0,0 |
| repro-kernel-before | a39f591ab4abf675ccc17b99c247b0cc55b317f264b23725697b5e06a83da726 | 27/28 | 5137416 | 137/0 | 0/0 | 0,0 |
| repro-mechanism | a59db5884010b9b3eafa4e41da0c8b91b6913ed38660f1b3c9867c6b40b059a3 | 19/20 | 6634044 | 0/0 | 0/0 | 0,0 |
| repro-producer-order | 4f6c4162af6c62b034c47c89dda93864acac5139818a940d1711ed6f4bc2f72f | 7/8 | 507990 | 0/0 | 0/0 | 0,0 |
| repro-kernel-b4 | f24be56fc3e9da87c8e1fdecd4227f288eb01d0e7b5e19e077d00bf7ced846a9 | 36/37 | 5745980 | 143/0 | 0/0 | 0,0 |
| repro-cross-path | b940afa3098a50249390419271efc9e4b21efcf012d90ccb2deef06a8966c9a2 | 29/30 | 6883299 | 86/0 | 0/0 | 0,0 |
| owner-final-refresh | 5d14476d3c577bbfe852cb50df45bf8367432785466e13783f71a254f405d3aa | 9/10 | 146873 | 39/0 | 0/0 | 0,0 |

Classification and source-bound limits are retained separately for every package. Comparison is same-host full-byte equality for A4/B4 under the opt-in schema4 profile; it does not establish default-build or cross-host reproducibility. Owner-final-refresh records only the18 GitHub requests observed at01:52:52.607–01:53:47.412UTC; its pending states cannot override later independently frozen results.

Complete exact argv/cwd/start/end/exit/stdout/stderr remain in the original executions/ and appended receipt directories. combined-index.json binds every accepted execution receipt and the retained original errors. inventory.json/audit-results.json remain the original first25-phase records; immutable sibling final-round-evidence-index-batch01 is unchanged.

Historical B2 report.verification command strings name A2; actual execution receipts select B2/verify.py. This index records the erratum and leaves frozen evidence untouched. Archive members were inspected in memory, not extracted. Physical package limit2MiB does not restrict reconstructed logical ELF sizes.
