#!/usr/bin/env python3
"""Read-only outer manifest, file size and tar member audit; never extract."""
import collections,hashlib,json,os,pathlib,re,stat,sys,tarfile
def need(ok,message):
 if not ok: raise ValueError(message)
def relative(name):
 p=pathlib.PurePosixPath(name)
 need(bool(name) and not p.is_absolute() and str(p)==name and all(x not in (".","..","") for x in p.parts) and "\\" not in name and "\0" not in name,"unsafe relative name "+repr(name))
 return p
def read(path):
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
 try:
  a=os.fstat(fd);need(stat.S_ISREG(a.st_mode),"not regular "+str(path))
  with os.fdopen(fd,"rb",closefd=False) as f:data=f.read()
  z=os.fstat(fd)
  need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns),"changed during read "+str(path))
  need(len(data)==a.st_size,"short read "+str(path));return data
 finally:os.close(fd)
def sha(data):return hashlib.sha256(data).hexdigest()
def one_manifest(root,manifest):
 data=read(manifest);declared={}
 for line in data.decode().splitlines():
  digest,name=line.split("  ",1);relative(name)
  need(re.fullmatch("[0-9a-f]{64}",digest) is not None and name not in declared,"bad/duplicate manifest record "+name)
  declared[name]=digest
 actual={}
 links=[]
 for directory,dirs,files in os.walk(root,followlinks=False):
  here=pathlib.Path(directory)
  for name in list(dirs):
   p=here/name
   if p.is_symlink():links.append(str(p.relative_to(root)));dirs.remove(name)
  for name in files:
   p=here/name
   if p==manifest:continue
   if p.is_symlink():links.append(str(p.relative_to(root)));continue
   raw=read(p);actual[str(p.relative_to(root))]={"size":len(raw),"sha256":sha(raw)}
 missing=sorted(set(declared)-set(actual));unlisted=sorted(set(actual)-set(declared))
 mismatches=[name for name in declared if name in actual and declared[name]!=actual[name]["sha256"]]
 need(not links,"outer filesystem symlinks "+repr(links))
 need(not missing and not unlisted and not mismatches,"manifest coverage/hash failure "+json.dumps({"missing":missing,"unlisted":unlisted,"mismatches":mismatches}))
 over=[{"path":k,**v} for k,v in actual.items() if v["size"]>2*1024*1024]
 need(not over,"outer physical file exceeds2MiB "+repr(over))
 return {"manifest":str(manifest),"sha256":sha(data),"entries":len(declared),"physical_regular_files_including_this_manifest":len(actual)+1,"bytes_including_this_manifest":sum(x["size"] for x in actual.values())+len(data),"largest_content_file":max(({"path":k,**v} for k,v in actual.items()),key=lambda r:r["size"],default=None),"missing":[],"unlisted":[],"mismatches":[],"over2MiB":[],"filesystem_symlinks":[]}
def archive(path):
 raw=read(path);counts=collections.Counter();logical_bytes=0;header_regular_bytes=0;links=[];symlinks=[]
 with tarfile.open(path,"r:*") as tf:
  ms=tf.getmembers();byname={}
  for i,m in enumerate(ms):
   relative(m.name);need(m.name not in byname,"duplicate tar member "+m.name);byname[m.name]=(i,m)
  for i,m in enumerate(ms):
   if m.isreg():
    counts["regular"]+=1;data=tf.extractfile(m).read();need(len(data)==m.size,"tar member short read");header_regular_bytes+=len(data);logical_bytes+=len(data)
   elif m.islnk():
    counts["hardlink"]+=1;relative(m.linkname);need(m.linkname in byname,"external hardlink target "+m.linkname);index,target=byname[m.linkname];need(target.isreg(),"hardlink chain/nonregular target");data=tf.extractfile(target).read();logical_bytes+=len(data);links.append({"name":m.name,"target":m.linkname,"target_index":index,"payload_size":len(data),"payload_sha256":sha(data)})
   elif m.issym():
    counts["symlink"]+=1;symlinks.append({"name":m.name,"target":m.linkname})
   elif m.isdir():counts["directory"]+=1
   else:counts["other"]+=1
 return {"path":str(path),"size":len(raw),"sha256":sha(raw),"tar_member_count":len(ms),"member_types":dict(counts),"header_regular_bytes":header_regular_bytes,"logical_payload_bytes":logical_bytes,"internal_hardlinks":links,"symlinks_metadata_only":symlinks,"scope":"Parsed tar members; no filesystem extraction. This general audit does not infer original runtime success."}
def main():
 root=pathlib.Path(sys.argv[1]).absolute()
 need(root.is_dir() and not root.is_symlink(),"phase root missing/non-directory/symlink")
 top=one_manifest(root,root/"SHA256SUMS")
 sub=[];captured=[]
 for p in sorted(root.rglob("SHA256SUMS")):
  if p==root/"SHA256SUMS":continue
  location=p.relative_to(root)
  if len(location.parts)==2 and location.parts[0] in ("independent-review","host-entry-review"):
   sub.append(one_manifest(p.parent,p));continue
  # A captured original manifest inside readable is an evidence payload, not
  # a declaration that its original directory was copied here in full.
  need(location.parts[0]=="readable","unclassified nested manifest scope "+str(location))
  raw=read(p);present=[];absent=[]
  for line in raw.decode().splitlines():
   digest,name=line.split("  ",1);relative(name)
   need(re.fullmatch("[0-9a-f]{64}",digest) is not None,"bad recorded manifest digest")
   target=p.parent/name
   if target.is_file():
    need(sha(read(target))==digest,"recorded present-entry mismatch "+str(target));present.append(name)
   else:absent.append(name)
  captured.append({"path":str(location),"sha256":sha(raw),"present_entries":present,"not_present_in_captured_subset":absent,"authoritative_current_subpackage":False,"scope":"Historical manifest is retained and outer-hashed; original siblings may live in source/archive controls rather than this readable subset. Package-local verifier checks the selected capture closure."})
 archives=[]
 for p in sorted(root.rglob("*")):
  if p.is_file() and not p.is_symlink() and (p.name.endswith(".tar.gz") or p.suffix==".tar"):archives.append(archive(p))
 print(json.dumps({"pass":True,"phase":str(root),"outer_manifest":top,"nested_manifests":sub,"captured_historical_manifests":captured,"archives":archives,"python_optimized":not __debug__,"new_Cargo_VM_tests":0,"code_sha256":sha(read(pathlib.Path(__file__)))},indent=2))
if __name__=="__main__":
 try:main()
 except (OSError,ValueError,KeyError,tarfile.TarError,EOFError) as e:
  print(json.dumps({"pass":False,"error":str(e)}));raise SystemExit(1)

