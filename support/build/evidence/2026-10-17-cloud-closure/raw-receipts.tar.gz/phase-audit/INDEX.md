# A01 2026-10-17 evidence index — first frozen batch

As of 2026-10-17T02:00:15.378592+00:00: 25 primary phases and 3 nested review manifests. All **50 generic + 28 package/source-blob verifier executions** returned 0 under ordinary/optimized isolated Python. Every phase checksum remained unchanged; no missing/unlisted file or physical repository file larger than 2 MiB was found. Root README is 0 bytes.

This is offline verification of retained evidence. It adds zero Cargo builds, kernel builds, workloads, live checks or VMs. Original result scopes are in classification/classification.json; the parent final report must keep host-only, actual boot, true failed attempt and candidate history separate. Future comparison/native/normal phases are not inferred.

| Phase | SUM SHA256 prefix | SUM entries / physical files | Physical bytes | Tar regular / hardlink | Generic I / IO | Package verifier exits |
| --- | --- | --- | ---: | --- | --- | --- |
| a02-owner-nightly | edc5cd771ac8bc4a | 11 / 12 | 570715 | 75 / 0 | 0 / 0 | not shipped |
| archive-custody | 806c7c31c781164c | 11 / 12 | 232699 | 126 / 0 | 0 / 0 | not shipped |
| cloud-native | d56359f0e137d710 | 51 / 52 | 4114594 | 60 / 0 | 0 / 0 | 0,0 |
| integration-case-targets | c376e8472c9a28c0 | 31 / 32 | 1547770 | 1377 / 4 | 0 / 0 | not shipped |
| integration-input-snapshots | 6131edf8f387f3ef | 20 / 21 | 2349345 | 1207 / 0 | 0 / 0 | not shipped |
| integration-input-snapshots-final | 7497e665c4ac7777 | 31 / 32 | 3201809 | 1605 / 0 | 0 / 0 | not shipped |
| integration-private-tools/host | 978532e6ef57846b | 19 / 20 | 1035243 | 637 / 0 | 0 / 0 | not shipped |
| ktest-private-inputs | 3b4f6a86682e0392 | 21 / 22 | 181101 | 161 / 0 | 0 / 0 | not shipped |
| latest-main | 35946c6e2f06dd14 | 26 / 27 | 745827 | 108 / 0 | 0 / 0 | not shipped |
| owner-ci | 94cefd6c7a7086d4 | 39 / 40 | 839557 | 0 / 0 | 0 / 0 | not shipped |
| owner-refresh | f8189352e96affdc | 171 / 172 | 7046033 | 12 / 0 | 0 / 0 | 0,0 |
| private-bios | ee73f3e7b913e35f | 15 / 16 | 465201 | 341 / 0 | 0 / 0 | not shipped |
| private-qemu-data | d67643093c672289 | 14 / 15 | 802039 | 624 / 0 | 0 / 0 | not shipped |
| private-toolchain | 638b3c5e0a1534a4 | 271 / 272 | 22799668 | 0 / 0 | 0 / 0 | 0,0 |
| repro-cargo-disambiguator | 96794ae282673468 | 9 / 10 | 3725635 | 0 / 0 | 0 / 0 | 0,0 |
| repro-compiler-flags | 7fa8188b76c2c068 | 9 / 10 | 2508995 | 0 / 0 | 0 / 0 | 0,0 |
| repro-cross-path-before | 18750895bf9c03ed | 37 / 38 | 8803051 | 194 / 0 | 0 / 0 | 0,0 |
| repro-kernel-a2 | f9d4594bba1e1c84 | 34 / 35 | 5700424 | 142 / 0 | 0 / 0 | 0,0 |
| repro-kernel-a3-before | 47d552667a3cbfac | 32 / 33 | 1764220 | 118 / 0 | 0 / 0 | 0,0 |
| repro-kernel-a4 | 84c4110dc73515af | 36 / 37 | 5746258 | 143 / 0 | 0 / 0 | 0,0 |
| repro-kernel-b2 | 2626f550815d3301 | 34 / 35 | 5698147 | 142 / 0 | 0 / 0 | 0,0 |
| repro-kernel-before | a39f591ab4abf675 | 27 / 28 | 5137416 | 137 / 0 | 0 / 0 | 0,0 |
| repro-mechanism | a59db5884010b9b3 | 19 / 20 | 6634044 | 0 / 0 | 0 / 0 | 0,0 |
| repro-producer-order | 4f6c4162af6c62b0 | 7 / 8 | 507990 | 0 / 0 | 0 / 0 | 0,0 |
| repro-kernel-b4 | f24be56fc3e9da87 | 36 / 37 | 5745980 | 143 / 0 | 0 / 0 | 0,0 |

Full manifest SHA256 values, archive counts/types and physical sizes are in inventory.json / inventory.csv. Complete exact argv, cwd, UTC start/end, exit, stdout and stderr are under executions/. audit-results.json retains every parsed verification result. plan.json fixes the explicitly authorized phase list; runtime target directories were never selected.

Owner-refresh verify-blobs.py writes derived source files, so its exact input closure and script were copied to scratch-verifier-closures/ and both mode executions ran only there. Original frozen bytes were unchanged. Other package verify.py scripts ran with no --restore/--output argument; private-toolchain additionally used trusted local gpgv for offline signatures.

The recorded storage aggregate is not a test or boot denominator. Parent packages include nested review manifests; their files are not counted twice. The file-size limit covers physical package files, while logical reassembled ELF inputs can be larger. Archive hardlinks were resolved only to validated regular archive members in memory; no extractall was used by this index audit.

Read-only suggestion: B2 report.verification.command points at the A2 verifier; the index executed the correct B2 package-local verify.py. No package was repaired.
