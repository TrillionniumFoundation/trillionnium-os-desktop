# Append batch03: before native attempts

`2026-10-17-native-cloud-before` is primarily **truefailedattempt**, retaining mixed real successes and failures at source `d895dd73a07788f6fc825fb3ca29cca22d93bb07` (tree `e0e415d6214df7311fb0c3297821659298f564a4`).

Correct-root kernel-tests command returned **0**: OSTD221 + aster-core141 = **362 reported**,0 failures,3 VMX/EPT soft skips, **359 exercised lower bound**,2 raw33 guests. The **outer session36657 returned1**, because its subsequent initial22-case matrix had **20 passed/2 failed**. That original single matrix remains failed;7 actual guests returned33, while coverage/workspace failures occurred before guests.

The wrong-root installed SDK/core failure remains separate and is not correct-root acceptance. Two coverage dependency failures remain: first missing `cc1.2.67` under offline mode, then `minicov0.3.8`. Official checksum-locked completion groups3+6 and the later coverage-only retry1/1 with actual GDB/profdata0 are separately recorded; they are not combined into an invented full22 pass.

Case14 original ELF SHA `04bd324919bd0b61991d6cbcab5382bbe1eddbc7c3ff885108f33456c76166a3` is **unavailable** after later overwrite:6/7 initial kernels retained. Before23 input mappings retain22, with12 unique artifacts; no missing bytes or original installed SDK binary were recreated. Wrong-root guest1, correct-root ktests2, initial matrix7 and separate coverage retry1 are distinct scopes; no extra N1-style full-kernel boot case is inferred.

Current refrozen SUM: `98a5b38fcb2c15dc59047056715153d466f8ebdc5bc53660f3d553eaad6387d8`. Static export metadata now names actual `capture.py`, already in92 consumed-source Git files. Old unpublished `498f…` and prior verifier receipts remain historical; no raw/artifact/consumed-source runtime bytes changed. Full metadata correction, original member hashes, source identities and failure limits are in classification-native-before.json. Parent owns current verifier execution; this classifier only read frozen bytes and ran no tools/tests/VM.
