# Append batch03: ordinary N1 build/boot

`2026-10-17-native-cloud-normal` is **actualboot**, a new independent ordinary **N1** case at `d879a9d2ffae8d0eb0df441370da54f9e3a38431` (full tree `a2baa0d707b8af80ae0e7d9f09b6e08379667bc2`, derived kernel tree `6b3cab110aa6d30d5b89f99c4389c9c3e01022da`). It adds **1 unique guest**; A2/B2/A4/B4 remain distinct earlier cases.

All11 original controller commands returned0. The absent target preceded cold `bash support/build/kernel.sh kernel` (279 compiling lines). A dedicated checked-FD copy froze its first ELF. The separate `bash support/build/kernel.sh run_kernel` reused that warm target (0 compiling lines), booted the real Rust kernel and small initramfs, and returned raw/recorder33 without timeout. Postrun live check returned0; matching pre/post source checks cover118 files and the Git status output is empty.

The complete first-built and actual loaded ELF bytes are equal:8,258,112 bytes, SHA256 `c49ad7da1c76c1f559d065ac3f8cbcbad407242dda54f1ed00028f02d5c2413d`. Exact ELF/initramfs/BIOS payloads are preserved:3 unique binaries over6 logical paths. Serial is72,247 bytes, SHA256 `3840526255cff7c53567f3e35e42739a11dba24f3feb03594719e92bec0ab5ca`.

This is ordinary direct kernel.sh/make operation: no opt-in projection launcher; known wrapper/projection/builder/timestamp variables cleared, flags/timestamp unset and jobs2. The copied controller docstring's normalized wording is historical and does not define a profile. No ordinary per-rustc argv ledger is invented.

Build and boot each have a passed `owned_removed` cleanup receipt. Both explicitly keep `continuous_public_path_occupancy_guaranteed=false`; their outcome does not identify an unknown writer or guarantee permanent path absence. The first build is cold, the boot action warm; no second cold compilation is claimed. No cross-path/cross-host/immutable environment, G1/G2 or all-blocker closure follows.

Frozen SHA256SUMS: `83d91ac582c049922a3093ede5f343ce9b156d34de94fbdee7b873b875d9f208`. classification-normal.json contains exact commands, input/source bindings, cleanup receipts, reference hashes and scope. Parent owns offline verifier execution. This classifier ran no Cargo/Rust/QEMU/GDB/test/verifier and read no active ABI phase.
