#!/usr/bin/env python3
"""Read selected frozen repository evidence; write classification only in scratch."""
from pathlib import Path
import ast
import datetime
import hashlib
import json

REPO = Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop')
ROOT = REPO / 'support/build/evidence'
OUT = Path('/workspace/scratch/ae1a8cf05419/final-round-evidence-index/classification')
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
rows = []

def add(name, primary, claim, counts, limits, scopes=None, binding=None, notes=None):
    p = ROOT / ('2026-10-17-' + name)
    assert (p / 'SHA256SUMS').is_file(), p
    docs = []
    for n in ('README.md', 'REPORT.md', 'report.json', 'result.json', 'summary.json',
              'source-bindings.json', 'source-binding.json', 'source-validation-ready.json',
              'source-validation-ready-final.json', 'verify.py', 'verify-blobs.py'):
        f = p / n
        if f.is_file():
            raw = f.read_bytes()
            docs.append(dict(path=str(f), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
    sumraw = (p / 'SHA256SUMS').read_bytes()
    row = dict(phase=str(p.relative_to(REPO)), absolute_path=str(p),
               primary_classification=primary, claim=claim, counts=counts,
               limitations=limits,
               scopes=scopes or [dict(classification=primary, claim=claim)],
               references=docs, source_binding=binding or {},
               checksum_manifest=dict(path=str(p / 'SHA256SUMS'),
                    sha256=hashlib.sha256(sumraw).hexdigest(),
                    verification_performed_by_this_classifier=False),
               freeze_observation=dict(checksum_exists=True,
                    checksum_mtime_ns=(p/'SHA256SUMS').stat().st_mtime_ns,
                    retained_draft_present=(p/'DRAFT.json').is_file(),
                    active_producer_or_process_probed=False,
                    note='Checksum presence is not by itself producer quiescence. Classification is bound to the observed manifest digest; parent owns integrity verification/freeze confirmation.'),
               notes=notes or [])
    vf=p/'verify.py'
    if vf.is_file():
        tree=ast.parse(vf.read_text())
        flags=[]
        for n in ast.walk(tree):
            if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='add_argument':
                flags += [a.value for a in n.args if isinstance(a,ast.Constant) and isinstance(a.value,str)]
        row['verifier_read_only_review']=dict(path=str(vf),docstring=ast.get_docstring(tree),cli_arguments=flags,executed=False,
            acceptance_scope='Offline retained-byte/source/status integrity, never a new historical build or guest pass.')
    else:
        row['verifier_read_only_review']=dict(path=None,executed=False,
            note='No standalone verify.py at this phase root. Parent owns generic manifest/archive integrity validation; retained producer/checker scripts are not new acceptance.')
    rows.append(row)
    return row

def load(name, filename='report.json'):
    return json.loads((ROOT/('2026-10-17-'+name)/filename).read_text())

def pick(d, *keys):
    return {k:d[k] for k in keys if k in d}

def repro_binding(name):
    p=ROOT/('2026-10-17-'+name)
    for fn in ('source-binding.json','source-bindings.json'):
        if (p/fn).is_file():
            d=json.loads((p/fn).read_text())
            return {k:v for k,v in d.items() if k!='commit_object'}
    return {}

def scope(kind, claim, **kw):
    return dict(classification=kind, claim=claim, **kw)

d=load('a02-owner-nightly','result.json')
add('a02-owner-nightly','host-only',
    'Exact exported A02 owner606 entry passed fixed-nightly host codec/contract acceptance; no native kernel or main integration.',
    dict(checks='13/13',Rust_unit_integration=69,Rust_doctests=1,Python_normal=46,Python_optimized=46,
         separately_repeated_mutation_oracle=9,golden_vectors=[12,24,1],compiled_mutants_killed='12/12',expected_mutant_assertion_failures=17),
    ['Host codec/model and no_std compile only; not native ioctl authority, HOS2 effects, scheduler enforcement, VM or main integration.',
     'The 9 canonical-oracle checks repeat a subset; do not add them as new unique tests.'],
    binding=pick(d,'source_commit','source_tree','toolchain','rustc_commit'))

d=load('archive-custody')
add('archive-custody','host-only',
    'Archive directory-FD/O_EXCL custody repair verified with actual host filesystem race fixtures and historical byte-preserving rearchive.',
    d['counts'],d['limits'],binding=pick(d,'baseline_commit','fixed_commit_binding','sources'),
    notes=['Historical attempt07/10 rearchive is not a rerun or upgrade of their guests.',
           'Expected baseline race red4 and independent FD probes are separate from final28×2.'])

d=load('cloud-native')
add('cloud-native','truefailedattempt',
    'Real source make kernel succeeded; first real QEMU failed firmware boot, later explicit-data retry failed preflight before QEMU.',
    dict(real_make_kernel_exit=0,compile_lines=279,boot_raw_exit=124,boot_recorder_exit=124,
         boot_timed_out=True,make_worker_controller_exit=2,retry_preflight_exit=1,new_successful_project_kernel_boots=0),
    ['SeaBIOS No bootable device is not Asterinas acceptance; raw serial is only217 bytes.',
     'Initial BIOS-only invocation lacked private -L auxiliary resources; retry produced no QEMU/serial/timeout status.',
     '0053 source compile cannot be relabelled as fresh31543 compile; cleanup foreign_restored does not prove public manifest absence.',
     'No clean second build, offline/immutable environment or reproducibility acceptance.'],
    scopes=[scope('truefailedattempt','Source build completed; guest attempt timed out in SeaBIOS before project kernel acceptance.',stage='actual QEMU firmware boot'),
            scope('truefailedattempt','Later retry rejected an existing OSDK.toml before make/QEMU.',stage='preflight')],
    binding=load('cloud-native','source-binding.json'))

d=load('integration-case-targets')
add('integration-case-targets','host-only',
    'Per-case generated OSDK target isolation and cache preflight passed final host suite, real SDK/Cargo metadata fault control and tiny host cache-reuse builds.',
    dict(final_host_tests_each_mode=141,final_host_executions=282,baseline_expected_red=2,
         intermediate_targeted_each=8,intermediate_full_each=139,
         initial_139_attempt_passed=138,initial_139_attempt_failures=1,
         actual_tiny_host_Cargo_builds=2,second_artifact_fresh=True,
         actual_SDK_final_calls=5,metadata_fault_red_exit=101,metadata_private_target_green_exit=0,
         deliberate_fake_Cargo_build_exit=42,SDK_outer_exit=6,
         new_native22_reruns=0,new_kernel_builds=0,new_QEMU_guests=0),
    d['limits'],
    scopes=[scope('host-only','Final141×2 host fixtures plus tiny actual host Cargo and source-built SDK metadata probes; no OS kernel build/VM.'),
            scope('candidatehistory','Retained earlier case20 native failure diagnostic; writer unknown and historical missing ELF bytes not reconstructed.',relation='selected historical receipts, not a complete current matrix'),
            scope('truefailedattempt','Initial139-suite readiness timeout and two SDK fixture-setup failures retained; later successful attempts are separately identified.',stage='host fixture/probe setup, not kernel or guest')],
    binding=pick(d,'source_files','baseline_run_matches_commit','pinned_SDK_base_crate_source_sha256'),
    notes=['Raw1381 logical payloads =1377 ordinary members +4 validated internal hardlinks; not1381 regular headers.',
           'Final code count141 is not the intermediate139, reviewer9 or targeted8 count.'])

d=load('integration-input-snapshots')
s=load('integration-input-snapshots','source-validation-ready.json')
r=add('integration-input-snapshots','candidatehistory',
    'Historical initial input-snapshot candidate passed150×2 host tests; later review found a coverage-symbol timing issue, so this source is not the final candidate.',
    dict(host_tests_each_mode=150,host_executions=300,new_snapshot_tests_each=9,old_source_red_tests=1,new_kernel_builds=0,new_VM_runs=0),
    ['Fake QEMU/capture and actual host GDB TCP leases only; no real full22 acceptance.',
     'Earlier native20/22 retains7 guest records but case14 original ELF was overwritten; only6 old input paths still matched. Host candidate does not restore missing bytes.',
     'Do not relabel recorder bc1225 as later67f576 or final9f51c0 source.'],
    scopes=[scope('candidatehistory','Historical pre-review candidate source with passing150×2 host suite.'),
            scope('host-only','Actual CLI fake-QEMU/capture fixtures and real host GDB lease lifecycle, not guest acceptance.')],
    binding=pick(s,'base_source_commit','entry_isolation_dependency_commit','source_files','normal_recorder_sha256'))
r['freeze_observation']['parent_confirmation']='Parent explicitly confirmed this untracked package frozen; expected manifest6131edf8f387f3ef854cc33df4cd05e05ad5ea1d7776a5632c2486757879e7ce.'

d=load('integration-input-snapshots-final')
s=load('integration-input-snapshots-final','source-validation-ready-final.json')
r=add('integration-input-snapshots-final','host-only',
    'Final alias-compatible, ordered input-snapshot candidate passed152×2 host tests; real published-source full22 remains separate.',
    dict(final_host_tests_each_mode=152,final_host_executions=304,new_snapshot_tests_each=11,
         historical_ordered_candidate_tests_each=151,old_candidate_tests_each=150,
         old_helpers_unchanged=14,new_kernel_builds=0,new_VM_runs=0),
    ['Host fake QEMU/capture plus real GDB TCP leases do not establish project kernel acceptance.',
     'Final9f51c0 differs from earlier150/151 source hashes; do not combine into one run.',
     'Cross-file atomic build snapshot and privileged-writer security boundary are not claimed.',
     'Missing old case14 ELF bytes are not restored. Observer draft never executed.'],
    scopes=[scope('host-only','Final152×2 actual host CLI/fake-QEMU suite on final9f51c0 source.'),
            scope('candidatehistory','Earlier ordered67f576 source151×2 suite and independent old/new timing replay retained separately.',relation='history, not additional final-source suites')],
    binding=pick(s,'base_source_commit','entry_isolation_dependency_commit','source_files','normal_recorder_sha256','historical_host_candidate_runs'))
r['freeze_observation']['parent_confirmation']='Parent explicitly confirmed final untracked package frozen; expected manifest7497e665c4ac7777f89d5f0e94cea1a8190acabbbd8721de5c68508ab07bdae4.'

d=load('integration-private-tools/host')
add('integration-private-tools/host','host-only',
    'Integration recorder shared private BIOS/data selectors validated through actual CLI with executable fake QEMU and full integration host fixtures.',
    d['counts'],d['limits'],binding=pick(d,'baseline_commit','fixed_source_binding','sources'),
    notes=['6×2 targeted preflight overlaps the131×2 full suite; do not call274 unique tests.',
           'Old baseline expected red2 is separate. Existing native GDB is host lifecycle only.'])

d=load('ktest-private-inputs','result.json')
add('ktest-private-inputs','host-only',
    'Ktest shared private input selectors retain fixed device profile and passed host CLI/checker/lifecycle suites; no actual upstream regression.',
    dict(private_CLI_each_mode=5,result_checker_each_mode=12,lifecycle_each_mode=17,host_executions=68,
         old_baseline_control_tests=2,old_baseline_control_failures=2,real_kernel_builds_or_VM_runs=0),
    ['Executable fakeQEMU raw33 is not native kernel acceptance.',
     'Ktest artifact inputs retain existing stable-FD digests but no immutable ktest snapshots are added.',
     'Real OSTD/core regression is separately owned by root.'],
    binding=pick(d,'base_commit','source_sha256','shared_selector_sha256','unchanged_checker_sha256'))

d=load('latest-main','result.json')
add('latest-main','host-only',
    'Exact main8f3bb49 sparse source passed newer A02 acceptance and A03 unmodified control validation on fixed nightly.',
    dict(ABI_checks='13/13',ABI_Rust_unit_integration=69,ABI_Rust_doctests=1,
         ABI_Python_normal=52,ABI_Python_optimized=52,separate_repeated_oracle=9,
         compiled_mutants_killed='12/12',expected_mutant_assertion_failures=17,
         control_std_passed=113,control_spin_passed=113,control_checks=6,kernel_VM_executions=0),
    ['Host codec/control models and bare-target no_std compile only; kernel_handoff filename does not mean guest execution.',
     'No native authority/enforcement, SMP or IRQ-safe locking, G1/G2 or main merge acceptance.',
     'This source differs from earlier606 owner and later40ca main; counts are not portable between them.'],
    binding=pick(d,'source_commit','source_tree','rustc_commit','source_files'))

d=load('owner-ci')
add('owner-ci','candidatehistory',
    'Read-only frozen remote owner/CI observations; source-bound historical host results and open runtime ownership, no new local execution.',
    dict(A01_historical_host_CI_executions=146,A01_groups=[23,23,30,30,20,20],
         A02_owner_supplied_checks=13,A06_owner_reported_kernel_total=374,A06_soft_skips=3,
         A06_exercised_lower_bound=371,new_local_tests=0,new_kernel_builds=0,new_VM_runs=0),
    ['Actual remote CI scope is host-only; stableA02 CI is not fixed nightly and workflow83 green was bootstrap-only.',
     'A06 historical374/371 denominator does not replace A01 historical359; final-runtime accounting remains unresolved.',
     'Owner reports and remote source findings are not fresh independent guest runs; no all-blocker closure.',
     'Per-request client times were not captured and are not reconstructed.'],
    scopes=[scope('candidatehistory','Historical remote jobs, owner records and source observations frozen; no local rerun.'),
            scope('host-only','A01 actual remote CI146 binds checkout e4677fe... and same full tree351a2d... as01a344.',relation='retained remote run, not new local execution'),
            scope('truefailedattempt','A06 remote stableG0 failed ABI-helper Clippy, control stages skipped; A04 prior preflight had no QEMU.',stage='historical remote host validation/preflight, not kernel compilation')],
    binding=dict(main=d['main'],a01=pick(d['a01'],'head','actual_checkout','head_and_checkout_tree'),
                 a02_head=d['a02']['head'],a06_head=d['a06']['head'],a05_ref=d['a05']['visible_owner_ref'],a04_head=d['a04']['head']))

d=load('owner-refresh')
add('owner-refresh','host-only',
    'Exact main40ca control host validation passed258 executions; refreshed remote owner/CI source observations remain independently bounded.',
    dict(main_std=129,main_spin=129,main_control_executions=258,
         earlier_historical_A01_CI_executions=170,latest_observed_A01_CI_status='queued',
         remote_verified_git_blobs=18,new_kernel_builds=0,new_VM_runs=0,new_Hepta_effects=0),
    ['Historical170 CI binds earlier merge154d4a62/head1e81ef45 and does not qualify queued84f49159.',
     'A04 owner11/13 and A05 old QueryAbi receipt were not reexecuted; their source/byte limits remain.',
     'No authorised available KVM/second host found in inspected repo docs is not proof that external resources do not exist.',
     'A05 effect authority/CapSpace, A06 final accounting, A04 CLOEXEC/NOFILE and A07 durable provider gaps remain owner-scoped.'],
    scopes=[scope('host-only','Actual main40ca validation129std+129spin plus fmt/strict Clippy/no_std, no guest.'),
            scope('candidatehistory','Remote old owner guest reports, historical CI170 and queued-head observation; none rerun as current kernel acceptance.')],
    binding=dict(observed_remote=d['observed_remote'],main_control=pick(d['main_control_current'],'head','tree'),
                 owners=d['owners']))
rows[-1]['verifier_read_only_review']['dangerous_retained_controller']=dict(
    path=str(ROOT/'2026-10-17-owner-refresh/verify-blobs.py'),
    note='Not a read-only verifier: writes blobs/*.source and blob-verification.json with new UTC. Do not execute in frozen phase; use scratch copy if needed.',executed=False)

for name, each in [('private-bios',25),('private-qemu-data',27)]:
    d=load(name,'result.json')
    add(name,'host-only',
        'Normal recorder explicit private '+('BIOS file' if name=='private-bios' else 'QEMU data directory')+' selection passed actual CLI/fakeQEMU regression.',
        dict(full_tests_each_mode=each,full_host_executions=2*each,new_targeted_tests=2,
             baseline_expected_control_failures=5,baseline_expected_control_errors=1,new_actual_guests=0),
        ['Executable fakeQEMU and historical serial fixture are not a fresh guest or kernel acceptance.',
         'Targeted before/after repeats are separate from the full-suite executions.',
         'Boot checker and existing artifact snapshots/guards unchanged.'],
        binding=pick(d,'base_commit','packaging_observed_git_commit','candidate_matching_git_commit_at_packaging','candidate_sources','checker_sha256'))

d=load('private-toolchain')
add('private-toolchain','host-only',
    'Fixed Rust and native tools restored in private prefix using authenticated Ubuntu snapshot metadata and eight successful Rust controller commands.',
    dict(signed_InRelease_suites=3,complete_indexes=6,selected_verified_extracted_packages=57,
         native_checks_passed=26,native_checks_total=27,Rust_commands_exit0=8,original_system_apt_exit=100,
         actual_kernel_boots=0),
    d['limitations'],
    scopes=[scope('host-only','Signed metadata/package identities, private extraction, fixed nightly/tools and paused QEMU availability checks; no Asterinas guest.'),
            scope('truefailedattempt','Original system apt exited100; paused no-L QEMU warning counts as failed resource lookup despite raw0.',stage='dependency restoration/resource availability')],
    binding=dict(toolchain='nightly-2026-07-21',rustc_commit='87e5904f5eb6398af6b22eac2802c78934260c48',
                 Ubuntu_snapshot='https://snapshot.ubuntu.com/ubuntu/20260828T000000Z/',
                 source_scope='Retained experimental restoration controller evolved during recovery; not a published production installer.'))

d=load('repro-cargo-disambiguator','source-bindings.json')
add('repro-cargo-disambiguator','host-only',
    'Schema3 canonical local Cargo metadata mechanism passed native host external-path/proc-macro fixtures and31×2 focused tests.',
    dict(focused_tests_each_mode=31,focused_executions=62,final_thin_LTO_builds=4,final_thin_LTO_native_runs=4,
         earlier_non_LTO_builds=4,earlier_non_LTO_native_runs=4,local_A2_B2_unit_keys_different=59,
         nonlocal_A2_B2_unit_keys_equal=259,new_kernel_builds=0,new_QEMU_guests=0),
    ['Equal normalized host binaries are not full-kernel equality or boot proof.',
     'Local build-script/OUT_DIR/native-link-search fixture is explicitly refused; arbitrary environment generation is not normalized.',
     'Retrospective369-argument replay forecast is synthetic, lacks historical completion receipts and must never be live ledger.',
     'Producer device/inode/size/mtime observations are not immutable content or privileged-writer security guarantees.'],
    scopes=[scope('host-only','Real Cargo/rustc tiny native builds and executions, expected refusal controls and focused31×2.'),
            scope('candidatehistory','Retained read-only A2/B2 ELF-inequality diagnosis and synthetic descriptor forecast; no new kernel run.')],
    binding=repro_binding('repro-cargo-disambiguator'))

d=load('repro-compiler-flags','summary.json')
add('repro-compiler-flags','host-only',
    'Enforced compiler remap support fix passed18×2 host tests and actual fixed-nightly native CLI, preserving originalcfg.',
    dict(focused_tests_each_mode=18,focused_executions=36,unmapped_native_compile_exit=0,unmapped_native_execution_exit=101,
         wrapped_native_compile_exit=0,wrapped_native_execution_exit=0,wrapped_version_exit=0,
         old_kernel_rustc_invocations=369,old_bare_target_invocations_without_remap=138,new_kernel_builds=0,new_VM_runs=0),
    ['Old real kernel panic at542e09 is retained failure evidence, not fixed-source boot acceptance.',
     'Native host fixture ELFs are not OS kernel artifacts; full A2/B2 builds and cross-host proof are separate.'],
    scopes=[scope('host-only','Fixed-nightly CLI remap native fixture and18×2 focused support tests.'),
            scope('candidatehistory','Retained original real-kernel component panic/argv diagnosis from542e09; no additional distinct boot.')],
    binding=repro_binding('repro-compiler-flags'))

add('repro-cross-path-before','truefailedattempt',
    'Actual same-host A2/B2 complete kernel ELF byte comparison failed, while both source-built kernels independently booted.',
    dict(original_comparator_exit=1,A2_kernel_bytes=8293608,B2_kernel_bytes=8292192,A2_minus_B2_bytes=1416,
         kernel_inputs_equal=False,initramfs_inputs_equal=True,BIOS_inputs_equal=True,
         duplicated_prior_boot_receipts=2,new_builds_or_guests_during_packaging=0),
    ['Kernel text/rodata/data/symbol/unwind content differs, not only ELF layout.',
     'Root supplied commandexit1/finalexception; no independent raw complete traceback was retained or fabricated.',
     'Same-host opt-in v2 profile only; cross-path equality failed and cross-host/immutable environment not accepted.',
     'Passing package verifier means the failed comparison evidence is intact.'],
    scopes=[scope('truefailedattempt','Original comparator failed complete ELF equality.',stage='same-host cross-path complete-input comparison'),
            scope('actualboot','Two independently successful prior A2/B2 boot receipts retained.',relation='duplicates of separate A2 and B2 packages, not two additional runs')],
    binding=repro_binding('repro-cross-path-before'))

for name,case,khash,kbytes,serialhash,duration in [
    ('repro-kernel-a2','A2','e89063b19e5895aa64695ba27c04d7d53fd5d65e23adeb0aab06983a1a33794d',8293608,'e0845a2d34a0f3d16d7a753c50c94f30b1d3eacc1d7b1649811cfdc4f574cccd',1.169),
    ('repro-kernel-b2','B2','b5fda2500d15c250d022f81bf2d30c0778244faea021a5db34aa68665d68f763',8292192,'e429eae97a05c5fe47e0fc4c09bb5cbf3911e86eea80598dbf22cbf5c5c0c123',1.319),
    ('repro-kernel-a4','A4','8c540288c6af2a1a97121031643c1af4c4db395d7e8b4082d6edc4604449849a',8286952,'82b1a0bd7f8f077b2e67a436057093c237887441f636fb802771c724a33b1a83',1.275),
    ('repro-kernel-b4','B4','8c540288c6af2a1a97121031643c1af4c4db395d7e8b4082d6edc4604449849a',8286952,'d1acbe86032800042f707c058cec3e71afbe031b9c66f2b81f4719d113572d5e',1.279)]:
    counts=dict(unique_actual_case=case,controller_commands_exit0=8,compile_lines=279,
                rustc_invocations=369,raw_QEMU_exit=33,recorder_exit=33,timed_out=False,
                duration_seconds=duration,serial_bytes=72341,successful_guest_count=1)
    if case in ('A4','B4'):counts.update(ledger_rows=738,successful_Cargo_units=332,canonical_local_units=61,
                                unchanged_metadata_Cargo_units=271,query_probe_exit0=34,query_probe_exit1=3,actual_Cargo_jobs=1)
    else:counts.update(remap_already_present_calls=130,remap_inserted_calls=239,metadata_pairs=6)
    r=add(name,'actualboot',
        case+' actual cold source run_kernel built the complete derived Asterinas Rust kernel, booted small initramfs on one CPU, emitted all markers and powered off raw33.',
        counts,
        ['Single named case only; no sibling case or cross-path equality acceptance is inferred.',
         'q35/TCG/CPUmax/1vCPU/512MiB fixed devices; no KVM, VMX, independent-host or immutable-environment qualification.',
         'Opt-in profile uses explicit synthetic embedded builder/epoch; actual host343e40cfefc1 is separately recorded.',
         'run_kernel cold action includes build and boot; no additional standalone make kernel subprocess is invented.',
         ('Schema4 completed producer stat receipts are not immutable content; three failed query probes are not failed Cargo units.' if case in ('A4','B4') else 'A2/B2 complete ELF comparison failed in its separate comparison phase.')],
        binding=repro_binding(name))
    r['loaded_input_identity']=dict(kernel_sha256=khash,kernel_bytes=kbytes,serial_sha256=serialhash,
        initramfs_sha256='86be65ab9234cd20ea6ec8d44a12b8765fd7a3e241fde920c71b3621ca0047f3',
        BIOS_sha256='1a9ea4f17bcfb27bda5728e2c21d9fa074cf7947b9b4910bb28213a735c96735')
    if case=='B2':r['notes'].append('report.verification.command erroneously repeats A2 path; README and this package verify.py correctly refer to B2. Use B2 verifier, not copied report command.')
    if case=='A4':r['freeze_observation']['parent_confirmation']='Parent confirmed published A4 package frozen; DRAFT.json is retained intermediate capture, not active-final status.'
    if case=='B4':r['freeze_observation']['parent_confirmation']='Parent explicitly confirmed B4 package frozen and authorized addition to classification:37 files, manifestf24be56fc3e9da87c8e1fdecd4227f288eb01d0e7b5e19e077d00bf7ced846a9. DRAFT.json is historical; comparison phase remains separate.'

add('repro-kernel-a3-before','truefailedattempt',
    'Actual schema3 full kernel build stopped at aster-bigtcp strict producer preflight; no QEMU, serial or final kernel ELF was produced.',
    dict(original_controller_completed_commands=3,original_action_exit=2,compile_lines=225,
         recorded_rustc_calls=304,ledger_events=608,canonical_local_calls=32,
         separate_postfailure_readonly_checks_exit0=5,QEMU_invocations=0,successful_guest_count=0),
    ['Earlier release Finished stage and304 successful recorded calls do not mean final kernel success.',
     'Rejected aster-bigtcp call is absent from recordedcalls/start ledger because preflight failed before logging.',
     'Cargo pipeline explanation is an inference here; exact rejected consumer wall-clock timing was not recorded.',
     'Prepared initramfs is unbooted; later schema4 mechanism/boot results are separate.'],
    binding=repro_binding('repro-kernel-a3-before'))

add('repro-kernel-before','truefailedattempt',
    'Actual cold Rust kernel build completed and QEMU entered OSTD, then component initialization panicked; boot acceptance failed.',
    dict(controller_completed_commands=3,compile_lines=279,rustc_invocations=369,metadata_pairs=6,
         raw_QEMU_exit=65,recorder_exit=65,timed_out=False,make_runner_controller_exit=2,
         serial_bytes=4627,successful_project_kernel_boots=0),
    ['NotIncludeAllComponent real virtio path panic is failure despite entry into Rust/OSTD.',
     'Planned live recheck/postchecks were not executed; no separate successful make kernel command receipt.',
     'Metadata projected paths while actual kernel action omitted remap; no later fix/A2/B2 success belongs here.',
     'No cross-host/immutable environment acceptance.'],
    binding=repro_binding('repro-kernel-before'))

add('repro-mechanism','host-only',
    'Native tiny component macro/path projection mechanism produced equal host ELFs and13×2 final support tests; no full kernel validation.',
    dict(final_focused_each_mode=13,final_focused_executions=26,final_tiny_cases=9,
         initial_fixture_cases_retained=9,equal_normalized_host_ELF_bytes=4512576,
         tar_regular_members=278,inner_checksum_entries=277,new_kernel_builds=0,new_VM_runs=0),
    ['Host native ELF2f42eb... is not a kernel image; cross-host/kernel/nativeHOS2/hardware acceptance not claimed.',
     'Initial relative-span fixture failed baseline and is not a passing pair; other expected mechanism failures retained.',
     'Final source hardening differs from prototype; exact published source bindings separate.',
     'Nested independent-review SHA was outside original frozen277-entry closure and preserved separately, not silently added to original archive.'],
    binding=repro_binding('repro-mechanism'))

add('repro-producer-order','host-only',
    'Schema4 single-job support mechanism passed actual fixed-nightly scheduling experiments and32×2 focused tests; strict producer gate retained.',
    dict(final_focused_each_mode=32,final_focused_executions=64,parallel_jobs2_Cargo_exit=101,
         serial_jobs1_Cargo_exit=0,serial_native_exit=0,obsolete_pipelining_false_jobs2_Cargo_exit=101,
         launcher_caller_jobs2_actual_jobs=1,launcher_Cargo_exit=0,launcher_native_exit=0,
         new_kernel_builds=0,new_QEMU_guests=0),
    ['Two expected Cargo101 controls are failed builds even though experiment aggregator exits0.',
     'Native scheduling fixtures and read-only A3 diagnosis are not A4/B4 kernel boot/equality.',
     'No native byte equality is asserted between scheduling fixture cases.',
     'No relaxed producer gate, synthetic completion receipts, arbitrary-environment or immutable-content guarantee.'],
    scopes=[scope('host-only','Actual fixed-nightly Cargo/rustc scheduling fixture and32×2 final support tests.'),
            scope('candidatehistory','Retained A3 read-only diagnosis; its failed kernel attempt is separately archived.')],
    binding=repro_binding('repro-producer-order'))

add('integration-case-targets/independent-review','host-only',
    'Independent actual-runner collaborator fixture reproduced old preflight ordering defect and confirmed repaired early rejection, plus nine tests and lock fixture.',
    dict(final_reviewed_tests=9,later_owner_tests_not_relabelled=10,real_Cargo_builds=0,new_VM_runs=0),
    ['Reviewer9 count stays9; final owner141 suite separately covers tenth test.',
     'Fake command collaborators establish order/custody only, not actual Cargo/kernel/upstream22.',
     'Read-only source-byte binding, no historical writer attribution or arbitrary-writer protection.'],
    binding=load('integration-case-targets/independent-review','source-binding.json'))

add('integration-input-snapshots-final/independent-review','host-only',
    'Independent fake-QEMU/capture mixed-input counterexample and old-candidate red/reordered green replay; final alias change statically reviewed with five production-helper checks.',
    dict(production_helper_checks=5,old_targeted_test_exit=1,reordered_targeted_test_exit=0,
         final_alias_case_rerun_by_reviewer=0,new_Rust_Cargo_GDB_VM_runs=0),
    ['Initial fake capture success does not prove real mismatched-symbol GDB would pass.',
     'Version-case replay bound ordered67f576; final9f51c0 alias-only revision bound by function comparison, not invented rerun.',
     'No atomic multi-file snapshot or arbitrary-privileged-writer sandbox. Generic archive omits binary suffixes; final inputs need explicit separate retention.'],
    binding=dict(recorder_sha256='9f51c0edb4bd919a3ab95dbee718f79a453f4f529b24c067ef831381764b9d3a',
                 shared_recorder_sha256='387845415b54f1822c55ce4198586fae8047f7d3ea94008c84e0974871954098',
                 snapshot_tests_sha256='fb3ac087283168172e7c9107db47c9f865f008cca01ded4d7ef55edddf5de5f8'))

d=load('owner-refresh/host-entry-review')
add('owner-refresh/host-entry-review','host-only',
    'Static read-only tracked-repository host-entry review found no documented authorized available KVM/second-host endpoint in its inspected scope.',
    dict(primary_docs_config_files=62,additional_tracked_handoff_JSON_files=21,
         workflows=5,jobs=6,runtime_capability_probes=0,new_Cargo_VM_runs=0),
    d['limits'],binding=pick(d,'repo_head_at_both_scans','source_bindings'),
    notes=['No credentials/cloud accounts/untracked host settings scanned; no host login/resource creation.',
           'No endpoint found in repo is not global resource absence.'])

rows.sort(key=lambda r:r['phase'])
assert len(rows)==28, len(rows)
assert len([r for r in rows if '/independent-review' not in r['phase'] and '/host-entry-review' not in r['phase']])==25
payload=dict(schema='a01-evidence-phase-classification/1',created_utc=now,
    repository=str(REPO),classifier_role='/root/closure_entry_guards/index_phase_classification',
    authorized_scope='Original24 main phases plus explicitly parent-frozen B4 =25 main phases, plus3 nested review closures; no live B4/normal/native targets or controllers.',
    new_executions=dict(Cargo=0,Rust=0,QEMU=0,verifiers=0,tests=0),
    classification_count=dict(main_phases=25,nested_review_packages=3,total=28),
    category_semantics=dict(
        **{'host-only':'Host code/model/filesystem/tools/metadata execution or static review only; expected controls/failures retain exact statuses.',
           'actualboot':'Recorded real source-built project Rust kernel completed its guest markers/raw33; only named case accepted.',
           'truefailedattempt':'Actual unaccepted compile/boot/comparison/preflight/restoration attempt; integrity verification never upgrades it.',
           'candidatehistory':'Historical/prototype/remote reported source-bound observation; do not promote or transfer its count to another source.'}),
    nonaggregation_rules=[
        'No union of phases or Python modes is called one full kernel/upstream22 run.',
        'Cross-path comparison package repeats A2/B2 boot receipts; do not count two extra boots.',
        'Historical150/151 and final152 input-snapshot suites have distinct recorder hashes.',
        'Expected mutation kills and intentionally refused controls are not unplanned production failures; each remains labeled.',
        'Source identity, host fixture pass, package checksum success and actual guest acceptance are distinct claims.',
        'Host GDB TCP lease tests are actual GDB but not project kernel execution or defaultAF_UNIX acceptance.'
    ],
    unique_successful_boot_cases_in_authorized_scope=['A2','B2','A4','B4'],
    scan_during_write_exclusions=[dict(scope='unfrozen comparison/native-before/native-final/ordinary N1 outputs',
         reason='Parent has not supplied freeze authorization for these future phases. They remain outside the explicit whitelist; no live outputs/targets/controllers are read or executed.',
         classified=False)],
    known_verifier_metadata_risks=[
        'owner-refresh/verify-blobs.py rewrites frozen .source and blob-verification.json; never run inplace.',
        'repro-kernel-b2/report.json verification command wrongly names A2; B2 README/local verify.py are correct.',
        'A4 DRAFT.json is retained intermediate receipt; final report and parent freeze confirmation are authoritative.',
        'Pending-publication/full22 wording in frozen host packets describes acceptance scope; not by itself evidence of an active writer.'
    ],
    phases=rows)

OUT.mkdir(parents=True,exist_ok=True)
(OUT/'classification.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
lines=['# 2026-10-17 evidence scope classification','',
       'Read-only classification:25 main phases +3 nested review closures. No Cargo, Rust, QEMU, test or verifier was executed by this classifier. Parent independently verifies manifests. All row claims bind the recorded source, not the current branch.',
       '',
       '| Phase | Classification | Exact scope/count |',
       '| --- | --- | --- |']
for r in rows:
    lines.append('| `'+r['phase'].replace('support/build/evidence/','')+'` | '+r['primary_classification']+' | '+r['claim'].replace('|','/')+' |')
lines += ['',
    'Unique successful kernel cases in this authorized set: **A2, B2, A4, B4**. A4/B4 are each single-case acceptance here; their comparison is separate. The cross-path-before packet duplicates A2/B2 original receipts and records **failed** complete ELF equality; it adds no unique boots. Cloud-native failed in firmware, before entered Rust/OSTD then panicked, and A3 failed before QEMU.',
    '',
    'Historical input-snapshot150×2 (`bc1225…`), intermediate151×2 (`67f576…`) and final152×2 (`9f51c0…`) remain separate source-bound runs. Case-target141×2, integration-private131×2 and normal recorder25×2/27×2 are host fixtures, not upstream22 or full-kernel regression.',
    '',
    '**Verifier cautions:** `owner-refresh/verify-blobs.py` rewrites `.source` files and `blob-verification.json`; do not execute it inplace in frozen evidence. B2 report copies the A2 verifier command; use the local B2 verifier. A4 retained DRAFT is historical, not an active-final flag.',
    '',
    'B4 was added only after explicit parent freeze authorization. Unfrozen comparison/native-before/native-final and active ordinary N1 are excluded; no live B4/normal/native output/target was read. SHA presence alone does not prove a producer is quiescent; per-phase JSON stores the observed digest and explicit freeze confirmations.',
    '',
    'Full exact source bindings, counts, separate mixed scopes, raw evidence references, limitations and verifier descriptions are in classification.json.']
(OUT/'README.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(phases=len(rows),JSON=str(OUT/'classification.json'),README=str(OUT/'README.md'))))
