# 2026-10-17 evidence scope classification

Read-only classification:25 main phases +3 nested review closures. No Cargo, Rust, QEMU, test or verifier was executed by this classifier. Parent independently verifies manifests. All row claims bind the recorded source, not the current branch.

| Phase | Classification | Exact scope/count |
| --- | --- | --- |
| `2026-10-17-a02-owner-nightly` | host-only | Exact exported A02 owner606 entry passed fixed-nightly host codec/contract acceptance; no native kernel or main integration. |
| `2026-10-17-archive-custody` | host-only | Archive directory-FD/O_EXCL custody repair verified with actual host filesystem race fixtures and historical byte-preserving rearchive. |
| `2026-10-17-cloud-native` | truefailedattempt | Real source make kernel succeeded; first real QEMU failed firmware boot, later explicit-data retry failed preflight before QEMU. |
| `2026-10-17-integration-case-targets` | host-only | Per-case generated OSDK target isolation and cache preflight passed final host suite, real SDK/Cargo metadata fault control and tiny host cache-reuse builds. |
| `2026-10-17-integration-case-targets/independent-review` | host-only | Independent actual-runner collaborator fixture reproduced old preflight ordering defect and confirmed repaired early rejection, plus nine tests and lock fixture. |
| `2026-10-17-integration-input-snapshots` | candidatehistory | Historical initial input-snapshot candidate passed150×2 host tests; later review found a coverage-symbol timing issue, so this source is not the final candidate. |
| `2026-10-17-integration-input-snapshots-final` | host-only | Final alias-compatible, ordered input-snapshot candidate passed152×2 host tests; real published-source full22 remains separate. |
| `2026-10-17-integration-input-snapshots-final/independent-review` | host-only | Independent fake-QEMU/capture mixed-input counterexample and old-candidate red/reordered green replay; final alias change statically reviewed with five production-helper checks. |
| `2026-10-17-integration-private-tools/host` | host-only | Integration recorder shared private BIOS/data selectors validated through actual CLI with executable fake QEMU and full integration host fixtures. |
| `2026-10-17-ktest-private-inputs` | host-only | Ktest shared private input selectors retain fixed device profile and passed host CLI/checker/lifecycle suites; no actual upstream regression. |
| `2026-10-17-latest-main` | host-only | Exact main8f3bb49 sparse source passed newer A02 acceptance and A03 unmodified control validation on fixed nightly. |
| `2026-10-17-owner-ci` | candidatehistory | Read-only frozen remote owner/CI observations; source-bound historical host results and open runtime ownership, no new local execution. |
| `2026-10-17-owner-refresh` | host-only | Exact main40ca control host validation passed258 executions; refreshed remote owner/CI source observations remain independently bounded. |
| `2026-10-17-owner-refresh/host-entry-review` | host-only | Static read-only tracked-repository host-entry review found no documented authorized available KVM/second-host endpoint in its inspected scope. |
| `2026-10-17-private-bios` | host-only | Normal recorder explicit private BIOS file selection passed actual CLI/fakeQEMU regression. |
| `2026-10-17-private-qemu-data` | host-only | Normal recorder explicit private QEMU data directory selection passed actual CLI/fakeQEMU regression. |
| `2026-10-17-private-toolchain` | host-only | Fixed Rust and native tools restored in private prefix using authenticated Ubuntu snapshot metadata and eight successful Rust controller commands. |
| `2026-10-17-repro-cargo-disambiguator` | host-only | Schema3 canonical local Cargo metadata mechanism passed native host external-path/proc-macro fixtures and31×2 focused tests. |
| `2026-10-17-repro-compiler-flags` | host-only | Enforced compiler remap support fix passed18×2 host tests and actual fixed-nightly native CLI, preserving originalcfg. |
| `2026-10-17-repro-cross-path-before` | truefailedattempt | Actual same-host A2/B2 complete kernel ELF byte comparison failed, while both source-built kernels independently booted. |
| `2026-10-17-repro-kernel-a2` | actualboot | A2 actual cold source run_kernel built the complete derived Asterinas Rust kernel, booted small initramfs on one CPU, emitted all markers and powered off raw33. |
| `2026-10-17-repro-kernel-a3-before` | truefailedattempt | Actual schema3 full kernel build stopped at aster-bigtcp strict producer preflight; no QEMU, serial or final kernel ELF was produced. |
| `2026-10-17-repro-kernel-a4` | actualboot | A4 actual cold source run_kernel built the complete derived Asterinas Rust kernel, booted small initramfs on one CPU, emitted all markers and powered off raw33. |
| `2026-10-17-repro-kernel-b2` | actualboot | B2 actual cold source run_kernel built the complete derived Asterinas Rust kernel, booted small initramfs on one CPU, emitted all markers and powered off raw33. |
| `2026-10-17-repro-kernel-b4` | actualboot | B4 actual cold source run_kernel built the complete derived Asterinas Rust kernel, booted small initramfs on one CPU, emitted all markers and powered off raw33. |
| `2026-10-17-repro-kernel-before` | truefailedattempt | Actual cold Rust kernel build completed and QEMU entered OSTD, then component initialization panicked; boot acceptance failed. |
| `2026-10-17-repro-mechanism` | host-only | Native tiny component macro/path projection mechanism produced equal host ELFs and13×2 final support tests; no full kernel validation. |
| `2026-10-17-repro-producer-order` | host-only | Schema4 single-job support mechanism passed actual fixed-nightly scheduling experiments and32×2 focused tests; strict producer gate retained. |

Unique successful kernel cases in this authorized set: **A2, B2, A4, B4**. A4/B4 are each single-case acceptance here; their comparison is separate. The cross-path-before packet duplicates A2/B2 original receipts and records **failed** complete ELF equality; it adds no unique boots. Cloud-native failed in firmware, before entered Rust/OSTD then panicked, and A3 failed before QEMU.

Historical input-snapshot150×2 (`bc1225…`), intermediate151×2 (`67f576…`) and final152×2 (`9f51c0…`) remain separate source-bound runs. Case-target141×2, integration-private131×2 and normal recorder25×2/27×2 are host fixtures, not upstream22 or full-kernel regression.

**Verifier cautions:** `owner-refresh/verify-blobs.py` rewrites `.source` files and `blob-verification.json`; do not execute it inplace in frozen evidence. B2 report copies the A2 verifier command; use the local B2 verifier. A4 retained DRAFT is historical, not an active-final flag.

B4 was added only after explicit parent freeze authorization. Unfrozen comparison/native-before/native-final and active ordinary N1 are excluded; no live B4/normal/native output/target was read. SHA presence alone does not prove a producer is quiescent; per-phase JSON stores the observed digest and explicit freeze confirmations.

Full exact source bindings, counts, separate mixed scopes, raw evidence references, limitations and verifier descriptions are in classification.json.
