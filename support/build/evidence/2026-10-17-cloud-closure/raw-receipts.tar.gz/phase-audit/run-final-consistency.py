#!/usr/bin/env python3
"""Run only the index's offline consistency checker and preserve exact output."""
import datetime,hashlib,json,pathlib,subprocess,sys,time
base=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
index=json.loads((base/'final-index.json').read_text())
rows=[{'phase':r['phase'],'path':'support/build/evidence/2026-10-17-'+r['phase'],'SHA256SUMS_sha256':r['manifest_sha256'],'file_count':r['outer_regular_files'],'total_bytes':r['outer_bytes']} for r in index['phase_inventory']]
(base/'phase-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
root=base/'final-consistency';root.mkdir()
records=[]
for mode,flags in [('I',['-I','-B']),('IO',['-I','-O','-B'])]:
 out=root/mode;out.mkdir();argv=[sys.executable,*flags,str(base/'verify-final-index.py')]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic();p=subprocess.run(argv,cwd=repo,capture_output=True,timeout=60)
 (out/'stdout.log').write_bytes(p.stdout);(out/'stderr.log').write_bytes(p.stderr)
 r={'kind':'index-self-consistency, separate from110 phase-verifier executions','argv':argv,'cwd':str(repo),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tick,'exit_code':p.returncode,'program_sha256':sha(base/'verify-final-index.py'),'controller_sha256':sha(pathlib.Path(__file__)),'final_index_sha256':sha(base/'final-index.json'),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'new_Cargo_kernel_VM_workloads':0}
 (out/'command.json').write_text(json.dumps(r,indent=2)+'\n');records.append(r)
 print(json.dumps({'mode':mode,'exit_code':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}))
 if p.returncode:raise SystemExit(p.returncode)
(root/'receipt.json').write_text(json.dumps({'executions':2,'all_exit_zero':True,'separate_from_phase_verifier_110_attempt_count':True,'records':records},indent=2)+'\n')
