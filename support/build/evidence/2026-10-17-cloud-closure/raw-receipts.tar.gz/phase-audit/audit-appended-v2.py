#!/usr/bin/env python3
"""Append explicit parent-authorized frozen phases; no runtime target access."""
import argparse,datetime,hashlib,json,os,pathlib,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path("/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument("phase");parser.add_argument("expected_sum");parser.add_argument("--batch",default="append-batch02");args=parser.parse_args()
phase=REPO/"support/build/evidence"/args.phase
if not phase.name.startswith("2026-10-17-") or phase.parent!=REPO/"support/build/evidence":raise SystemExit("phase outside explicitly selected evidence namespace")
if sha(phase/"SHA256SUMS")!=args.expected_sum:raise SystemExit("authorized frozen sum mismatch")
out=ROOT/args.batch/args.phase;out.mkdir(parents=True,exist_ok=False)
records=[]
def execute(kind,mode,flags,program):
 d=out/(kind+"-"+mode);d.mkdir()
 cmd=[sys.executable,*flags,str(program),*([str(phase)] if kind=="generic" else [])]
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
 p=subprocess.run(cmd,cwd=REPO,capture_output=True,timeout=300)
 (d/"stdout.log").write_bytes(p.stdout);(d/"stderr.log").write_bytes(p.stderr)
 r={"argv":cmd,"cwd":str(REPO),"started_utc":started,"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"duration_seconds":round(time.monotonic()-tick,3),"exit_code":p.returncode,"controller_sha256":sha(pathlib.Path(__file__)),"program_sha256":sha(program),"phase_manifest_before":args.expected_sum,"phase_manifest_after":sha(phase/"SHA256SUMS"),"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest(),"new_Cargo_VM_workloads":0}
 (d/"command.json").write_text(json.dumps(r,indent=2)+"\n");records.append({"kind":kind,"mode":mode,"directory":str(d.relative_to(ROOT)),**r})
 print(json.dumps({"phase":args.phase,"kind":kind,"mode":mode,"exit":p.returncode}),flush=True)
for mode,flags in (("I",["-I","-B"]),("IO",["-I","-O","-B"])):
 execute("generic",mode,flags,ROOT/"verify-phase-v2.py")
if (phase/"verify.py").is_file():
 for mode,flags in (("I",["-I","-B"]),("IO",["-I","-O","-B"])):
  execute("shipped",mode,flags,phase/"verify.py")
summary={"phase":args.phase,"frozen_SHA256SUMS":args.expected_sum,"verified_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"all_exit_zero":all(x["exit_code"]==0 for x in records),"all_manifests_unchanged":all(x["phase_manifest_after"]==args.expected_sum for x in records),"executions":records,"scope":"Offline saved package verification only; no new build, original comparator/controller, live check, actual target read, workload or VM."}
(out/"audit-results.json").write_text(json.dumps(summary,indent=2)+"\n")
if not summary["all_exit_zero"] or not summary["all_manifests_unchanged"]:raise SystemExit(1)

