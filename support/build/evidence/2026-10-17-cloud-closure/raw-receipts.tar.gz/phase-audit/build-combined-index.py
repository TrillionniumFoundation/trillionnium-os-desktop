#!/usr/bin/env python3
"""Join already executed, frozen-phase audit receipts without executing workloads."""
import collections,csv,datetime,hashlib,json,pathlib
BASE=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_text())
def ref(relative):
 p=BASE/relative
 return {'path':relative,'bytes':p.stat().st_size,'sha256':sha(p)}
def check(ok,message):
 if not ok: raise RuntimeError(message)
first=load(BASE/'inventory.json')
audit=load(BASE/'audit-results.json')
rows=[dict(x) for x in first['phase_inventory']]
accepted=[]
for phase in audit['phases']:
 for kind in ('generic','shipped'):
  for execution in phase[kind]:
   r=execution['receipt']; parsed=load(BASE/r)
   check(parsed['exit_code']==0,r+' was not successful')
   accepted.append({'kind':kind,'phase':phase['name'],'mode':execution['mode'],'receipt':ref(r)})
append_names=['2026-10-17-repro-cross-path','2026-10-17-owner-final-refresh']
append_results=[]
for name in append_names:
 relative='append-batch02/validated/'+name+'/audit-results.json'
 result=load(BASE/relative);check(result['all_exit_zero'],name+' final validation failed')
 check(result['all_manifests_unchanged'],name+' manifest changed')
 generic=load(BASE/('append-batch02/validated/'+name+'/generic-I/stdout.log'))
 optimized=load(BASE/('append-batch02/validated/'+name+'/generic-IO/stdout.log'))
 ordinary_copy=dict(generic);optimized_copy=dict(optimized)
 ordinary_copy.pop('python_optimized');optimized_copy.pop('python_optimized')
 check(ordinary_copy==optimized_copy,name+' I/IO observations differ')
 m=generic['outer_manifest'];archives=generic['archives']
 rows.append({'phase':name.removeprefix('2026-10-17-'),'manifest_sha256':m['sha256'],'outer_entries':m['entries'],'outer_regular_files':m['physical_regular_files_including_this_manifest'],'outer_bytes':m['bytes_including_this_manifest'],'largest_file_path':m['largest_content_file']['path'],'largest_file_bytes':m['largest_content_file']['size'],'archive_count':len(archives),'tar_member_count':sum(a['tar_member_count'] for a in archives),'tar_regular_members':sum(a['member_types'].get('regular',0) for a in archives),'tar_hardlink_members':sum(a['member_types'].get('hardlink',0) for a in archives),'tar_symlink_members':sum(a['member_types'].get('symlink',0) for a in archives),'nested_review_manifests':len(generic['nested_manifests']),'generic_I_exit':0,'generic_IO_exit':0,'available_verifier_exits':','.join(str(e['exit_code']) for e in result['executions'] if e['kind']=='shipped'),'manifest_unchanged':True})
 for e in result['executions']:
  accepted.append({'kind':e['kind'],'phase':name.removeprefix('2026-10-17-'),'mode':e['mode'],'receipt':ref(e['directory']+'/command.json')})
 append_results.append(ref(relative))
check(len(rows)==27,'expected exactly 27 authorized primary phases')
check(len(accepted)==86,'expected exactly 86 final accepted executions')
current=[]
for row in rows:
 folder=REPO/'support/build/evidence'/('2026-10-17-'+row['phase'])
 check(sha(folder/'SHA256SUMS')==row['manifest_sha256'],'manifest now differs '+str(folder))
 files=[p for p in folder.rglob('*') if p.is_file()]
 check(not any(p.is_symlink() for p in folder.rglob('*')),'filesystem symlink '+str(folder))
 check(len(files)==row['outer_regular_files'],'file count differs '+str(folder))
 check(sum(p.stat().st_size for p in files)==row['outer_bytes'],'size differs '+str(folder))
 check(not any(p.stat().st_size>2*1024*1024 for p in files),'file >2MiB '+str(folder))
 current.append({'phase':row['phase'],'manifest_sha256':row['manifest_sha256'],'physical_files':len(files),'physical_bytes':sum(p.stat().st_size for p in files)})
check((REPO/'README.md').stat().st_size==0,'root README not empty')
class_paths=['classification/classification.json','current/append-batch02/classification-comparison.json','append-batch02/classification-owner-final.json']
classifications=[load(BASE/x) for x in class_paths]
classification_rows=classifications[0]['phases']+[classifications[1],classifications[2]]
categories=dict(collections.Counter(x['primary_classification'] for x in classification_rows))
old_attempt=load(BASE/'append-batch02/2026-10-17-repro-cross-path/audit-results.json')
old_receipts=[]
for e in old_attempt['executions']:
 old_receipts.append({'phase':'repro-cross-path','exit_code':e['exit_code'],'kind':e['kind'],'mode':e['mode'],'receipt':ref(e['directory']+'/command.json')})
check(len(old_receipts)==4,'expected original four append attempts')
check(sum(x['exit_code']!=0 for x in old_receipts)==2,'expected exactly two retained generic scope failures')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
combined={'schema':'a01.read-only-evidence-index.v2','generated_utc':now,'scope':'Explicitly frozen 2026-10-17 phases only; scratch index, not a new runtime acceptance run.','primary_phase_count':len(rows),'complete_nested_review_packages':sum(x['nested_review_manifests'] for x in rows),'classification_rows_including_nested_reviews':len(classification_rows),'primary_classification_counts_including_nested_reviews':categories,'final_accepted_validation':{'executions':len(accepted),'generic':sum(x['kind']=='generic' for x in accepted),'shipped_or_scratch_closure':sum(x['kind']=='shipped' for x in accepted),'all_exit_zero':True,'all_manifest_bytes_unchanged':True,'I_IO_observations_identical':True,'receipts':accepted},'all_executed_verification_attempts':{'executions':len(accepted)+len(old_receipts),'exit_zero':len(accepted)+sum(x['exit_code']==0 for x in old_receipts),'exit_nonzero':sum(x['exit_code']!=0 for x in old_receipts),'retained_original_attempts':old_receipts,'explanation':'Two initial generic v1 failures treated a partial historical readable/SHA256SUMS capture as a complete independent package. Outer manifests and shipped validators were sound; scratch v2 corrected nested-manifest scope. No frozen phase bytes changed. All original failures are retained.','correction':ref('append-batch02/generic-scope-correction.json')},'physical_storage_sum_not_runtime_acceptance':{'files':sum(r['outer_regular_files'] for r in rows),'bytes':sum(r['outer_bytes'] for r in rows),'nested_reviews_counted_once':True},'root_README_bytes':(REPO/'README.md').stat().st_size,'unlisted_or_missing':[],'physical_files_over_2MiB':[],'new_Cargo_kernel_build_VM_or_workload_runs':0,'unique_successful_named_kernel_cases_in_this_scope':['A2','B2','A4','B4'],'comparison_additional_unique_guests':0,'cross_path_comparison_scope':'A4/B4 same host, different source roots and initially empty targets, schema4 opt-in profile; ELF/initrd/BIOS full bytes equal and both raw33. No general default or cross-host guarantee.','owner_final_observation_scope':'18 remote read-only requests at 2026-10-17 01:52:52.607–01:53:47.412 UTC only; pending pair/full22 states are historical observations. Later results require their own frozen phases.','known_historical_document_errata':[{'phase':'repro-kernel-b2','file':'report.json','fields':['verification.command','verification.optimized_command'],'issue':'Both frozen documentation strings point at the A2 verify.py. The actual index receipt commands execute B2/verify.py and both return0. Frozen package is unchanged.'}],'source_indexes':[ref('inventory.json'),ref('audit-results.json'),ref('first-batch-receipt.json')]+append_results,'classification_sources':[ref(x) for x in class_paths],'phase_inventory':rows,'current_frozen_manifest_count_size_recheck':current,'controller_sha256':sha(pathlib.Path(__file__)),'future_phases':'Native-before/final and normal N1 remain excluded until root explicitly freezes each phase.'}
check(combined['physical_storage_sum_not_runtime_acceptance']=={'files':1076,'bytes':104933933,'nested_reviews_counted_once':True},'unexpected physical sum')
(BASE/'combined-index.json').write_text(json.dumps(combined,ensure_ascii=False,indent=2)+'\n')
with (BASE/'combined-inventory.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
lines=['# A01 2026-10-17 evidence index — combined draft through batch02','',f'As of {now}: **27 frozen primary phases +3 complete nested review packages**. Final accepted offline validation: **54 generic +32 package/source-closure executions =86**, all exit0 in isolated ordinary/optimized Python. Every phase SHA256SUMS is unchanged; no missing/unlisted files or physical file >2 MiB. Project root README remains0 bytes.','', '**All attempted checks are retained:** 90 actual executions,88 exit0 and2 initial generic scope errors. Those two failures and the original two shipped successes remain under append-batch02/2026-10-17-repro-cross-path/. The scratch auditor v2 corrected interpretation of one partial historical readable manifest; it did not repair package bytes. Final comparison and owner-final checks are under append-batch02/validated/.','', 'This index adds **zero Cargo builds, kernel builds, VMs or workloads**. Its 1076physical files /104,933,933bytes are storage totals, never an acceptance denominator. Unique successful named kernel cases in this authorized set are A2,B2,A4,B4; the successful cross-path comparison adds no guests. Native/full22 and ordinary N1 evidence are excluded until separately frozen.','', '| Phase | SUM SHA256 | entries / physical files | Bytes | Tar regular / hardlink | Generic I/IO | Shipped exits |','| --- | --- | ---: | ---: | ---: | --- | --- |']
for r in rows:
 lines.append(f"| {r['phase']} | {r['manifest_sha256']} | {r['outer_entries']}/{r['outer_regular_files']} | {r['outer_bytes']} | {r['tar_regular_members']}/{r['tar_hardlink_members']} | {r['generic_I_exit']}/{r['generic_IO_exit']} | {r['available_verifier_exits']} |")
lines+=['','Classification and source-bound limits are retained separately for every package. Comparison is same-host full-byte equality for A4/B4 under the opt-in schema4 profile; it does not establish default-build or cross-host reproducibility. Owner-final-refresh records only the18 GitHub requests observed at01:52:52.607–01:53:47.412UTC; its pending states cannot override later independently frozen results.','', 'Complete exact argv/cwd/start/end/exit/stdout/stderr remain in the original executions/ and appended receipt directories. combined-index.json binds every accepted execution receipt and the retained original errors. inventory.json/audit-results.json remain the original first25-phase records; immutable sibling final-round-evidence-index-batch01 is unchanged.','', 'Historical B2 report.verification command strings name A2; actual execution receipts select B2/verify.py. This index records the erratum and leaves frozen evidence untouched. Archive members were inspected in memory, not extracted. Physical package limit2MiB does not restrict reconstructed logical ELF sizes.']
(BASE/'COMBINED-INDEX.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'generated_utc':now,'primary_phases':len(rows),'final_accepted_executions':len(accepted),'all_attempts':len(accepted)+len(old_receipts),'classification_counts':categories,'storage':combined['physical_storage_sum_not_runtime_acceptance'],'combined_index_sha256':sha(BASE/'combined-index.json'),'combined_inventory_sha256':sha(BASE/'combined-inventory.csv'),'combined_markdown_sha256':sha(BASE/'COMBINED-INDEX.md'),'new_Cargo_VM_workloads':0},ensure_ascii=False))
