#!/usr/bin/env python3
"""Freeze the completed scratch index into a new exclusive sibling; no cleanup."""
import datetime,hashlib,json,pathlib,shutil,stat
source=pathlib.Path(__file__).resolve().parent
out=source.parent/'final-round-evidence-index-final'
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
need(sha(source.parent/'final-round-evidence-index-batch01/SHA256SUMS')=='94e1c4f7b0c19a8b51e405ad8704fa1c2c9a88e464c29106d4c2894ad2f40b6c','firstbatch manifest changed')
for p in source.rglob('*'):
 need(not p.is_symlink(),'source index symlink')
 need(p.is_dir() or stat.S_ISREG(p.stat().st_mode),'source index special file')
shutil.copytree(source,out,symlinks=False)
files=sorted(p for p in out.rglob('*') if p.is_file());need(not (out/'SHA256SUMS').exists(),'unexpected root checksum')
lines=[sha(p)+'  '+str(p.relative_to(out)) for p in files]
(out/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
for line in lines:
 h,n=line.split('  ',1);need(sha(out/n)==h,'frozen copy mismatch '+n)
record={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'path':str(out),'root_SHA256SUMS_sha256':sha(out/'SHA256SUMS'),'checksummed_files':len(files),'physical_files_including_root_manifest':len(files)+1,'physical_bytes_including_root_manifest':sum(p.stat().st_size for p in files)+(out/'SHA256SUMS').stat().st_size,'max_physical_file_bytes':max(p.stat().st_size for p in files),'final_index_sha256':sha(out/'final-index.json'),'machine_phase_rows_sha256':sha(out/'phase-rows.json'),'primary_phase_count':30,'complete_nested_reviews':3,'final_accepted_phase_verifications':98,'all_actual_phase_verification_attempts':110,'index_self_consistency_executions_separate':2,'all_final_accepted_and_self_consistency_exit_zero':True,'new_Cargo_kernel_VM_workloads':0,'firstbatch_unchanged':True,'source_current_directory_will_not_be_used_as_stable_snapshot':True}
(source.parent/'final-round-evidence-index-final-freeze.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
