# A01 2026-10-17 final frozen evidence index

Generated2026-10-17T02:15:35.300489+00:00. **30 primary frozen packages +3 complete nested reviews**. Final accepted offline validation is **60 generic +38 package/source-closure executions =98**, all exit0 in ordinary/optimized isolated Python. All final manifests unchanged, no unlisted/missing files, no physical package file >2MiB; project root README0 bytes.

**Every original attempt is retained:**110 actual phase-verifier executions,108 exit0 and2 initial generic historical-manifest scope errors. Original comparison attempts remain under append-batch02/2026-10-17-repro-cross-path/. Eight successful old native-freeze checks remain under append-batch03/validated/ but are superseded by corrected native metadata identities under append-batch03/refrozen/. Final accepted native SUMs are98a5b38f… and1def7ab5… only. No actual payload was changed by the path-list correction.

This read-only index added **zero Cargo/kernel builds, VM boots or workloads**. The physical1247files/288,729,204bytes total describes storage, never a runtime denominator. No complete matrix is synthesized from case retries.

| Phase | Final SUM SHA256 | Entries/files | Bytes | Direct tar regular/hardlink | Generic I/IO | Shipped exits |
| --- | --- | ---: | ---: | ---: | --- | --- |
| a02-owner-nightly | edc5cd771ac8bc4a643ece6d683b53e95e6413cebc001325766eb784cb894cb3 | 11/12 | 570715 | 75/0 | 0/0 | not shipped |
| archive-custody | 806c7c31c781164caaa974e45a2081818e1cadee414e6f56a801935c037b7b56 | 11/12 | 232699 | 126/0 | 0/0 | not shipped |
| cloud-native | d56359f0e137d7100effd727d8f97b009768b5faa7b84f91a5be74055adc5942 | 51/52 | 4114594 | 60/0 | 0/0 | 0,0 |
| integration-case-targets | c376e8472c9a28c0b7c47c25e3b6827cee4760abb16722ea7a3ffc2a7748ed2b | 31/32 | 1547770 | 1377/4 | 0/0 | not shipped |
| integration-input-snapshots | 6131edf8f387f3ef854cc33df4cd05e05ad5ea1d7776a5632c2486757879e7ce | 20/21 | 2349345 | 1207/0 | 0/0 | not shipped |
| integration-input-snapshots-final | 7497e665c4ac7777f89d5f0e94cea1a8190acabbbd8721de5c68508ab07bdae4 | 31/32 | 3201809 | 1605/0 | 0/0 | not shipped |
| integration-private-tools/host | 978532e6ef57846bbd1b9732a5b817c8fa83324baeb9f282aece3bd498c4ac6e | 19/20 | 1035243 | 637/0 | 0/0 | not shipped |
| ktest-private-inputs | 3b4f6a86682e03925acc2f69bcfe579f18720d91fbf950cb06d7f9a6dcc63a62 | 21/22 | 181101 | 161/0 | 0/0 | not shipped |
| latest-main | 35946c6e2f06dd14eb56ef083fc53c8100fbeec89de94ef3bc0812d868c69f0e | 26/27 | 745827 | 108/0 | 0/0 | not shipped |
| owner-ci | 94cefd6c7a7086d415fed7e8a1ba0dd0a0f75093e87bea5e5c25f3cdf724c046 | 39/40 | 839557 | 0/0 | 0/0 | not shipped |
| owner-refresh | f8189352e96affdcc732303cb1a6aa38bb77fdfe15402ee50fc531c4278dfaf3 | 171/172 | 7046033 | 12/0 | 0/0 | 0,0 |
| private-bios | ee73f3e7b913e35fe6074cc470c13f748727b73a4cf90de4b1526115f7441807 | 15/16 | 465201 | 341/0 | 0/0 | not shipped |
| private-qemu-data | d67643093c6722890012ccff7cde4e667802974cd11d867ba41964d70ec6254c | 14/15 | 802039 | 624/0 | 0/0 | not shipped |
| private-toolchain | 638b3c5e0a1534a4c9c0656af5390374ace6f97ffd92a985cb01f2db4949da00 | 271/272 | 22799668 | 0/0 | 0/0 | 0,0 |
| repro-cargo-disambiguator | 96794ae2826734683c834b998f8b157ba03c25c925ecbdb5ecd93c856b919f10 | 9/10 | 3725635 | 0/0 | 0/0 | 0,0 |
| repro-compiler-flags | 7fa8188b76c2c068f2e94dcb8f130ff5b07f5302afe749ebc4b63a4b2fcbeaed | 9/10 | 2508995 | 0/0 | 0/0 | 0,0 |
| repro-cross-path-before | 18750895bf9c03ed247bc62f123370bdfaef6f34ceeb4a3b044308d5f9c7f1e2 | 37/38 | 8803051 | 194/0 | 0/0 | 0,0 |
| repro-kernel-a2 | f9d4594bba1e1c8451ff70c46d878491a262e7410ff83ae1863cb35273203025 | 34/35 | 5700424 | 142/0 | 0/0 | 0,0 |
| repro-kernel-a3-before | 47d552667a3cbfacd9dfa4415ac3a0bf74d9157d1a5018559dc5ad654765b4a5 | 32/33 | 1764220 | 118/0 | 0/0 | 0,0 |
| repro-kernel-a4 | 84c4110dc73515afc7a3be4f0bf27d5850b170be2a7c250af46b3b2dd9b62f6a | 36/37 | 5746258 | 143/0 | 0/0 | 0,0 |
| repro-kernel-b2 | 2626f550815d3301e0dfaf7d82302514c7764b02246e704058d43bd4654be990 | 34/35 | 5698147 | 142/0 | 0/0 | 0,0 |
| repro-kernel-before | a39f591ab4abf675ccc17b99c247b0cc55b317f264b23725697b5e06a83da726 | 27/28 | 5137416 | 137/0 | 0/0 | 0,0 |
| repro-mechanism | a59db5884010b9b3eafa4e41da0c8b91b6913ed38660f1b3c9867c6b40b059a3 | 19/20 | 6634044 | 0/0 | 0/0 | 0,0 |
| repro-producer-order | 4f6c4162af6c62b034c47c89dda93864acac5139818a940d1711ed6f4bc2f72f | 7/8 | 507990 | 0/0 | 0/0 | 0,0 |
| repro-kernel-b4 | f24be56fc3e9da87c8e1fdecd4227f288eb01d0e7b5e19e077d00bf7ced846a9 | 36/37 | 5745980 | 143/0 | 0/0 | 0,0 |
| repro-cross-path | b940afa3098a50249390419271efc9e4b21efcf012d90ccb2deef06a8966c9a2 | 29/30 | 6883299 | 86/0 | 0/0 | 0,0 |
| owner-final-refresh | 5d14476d3c577bbfe852cb50df45bf8367432785466e13783f71a254f405d3aa | 9/10 | 146873 | 39/0 | 0/0 | 0,0 |
| native-cloud-normal | 83d91ac582c049922a3093ede5f343ce9b156d34de94fbdee7b873b875d9f208 | 37/38 | 4441430 | 115/0 | 0/0 | 0,0 |
| native-cloud-before | 98a5b38fcb2c15dc59047056715153d466f8ebdc5bc53660f3d553eaad6387d8 | 59/60 | 76636687 | 92/0 | 0/0 | 0,0 |
| native-cloud-final | 1def7ab5712a1c6e5c9a68461ca4e7cc57506f51a60d482ab7fed77946dca221 | 72/73 | 102717154 | 94/0 | 0/0 | 0,0 |

Direct tar counts above describe physical tar files; package-local verifiers additionally reassemble and validate chunked raw/artifact archives in memory. Complete exact argv/cwd/time/exit/stdout/stderr are bound in final-index.json. Accepted validation is a receipt count, not a host-test or guest count. Archive hardlinks resolve only to validated internal regular members; this index never extracts archives.

A4/B4 comparison establishes complete ELF/initrd/BIOS equality for two distinct roots on this host under the opt-in schema4 profile. It adds no guest runs beyond the A4/B4 packages. N1 separately establishes the ordinary cold-build/freeze/warm-run pipeline. Final native matrix is a single22/22 OSDK example/tooling run with11 raw33 guests and23 retained privateinput mappings/13unique artifacts; those example guests are not additional complete-kernel build acceptance cases. Beforephase preserves20/22 failures, initialSDK/dependency errors, correct-root ktest and isolated coverage retry results; they are not relabeled as the final matrix. Kernelinnerexit0 and outertoolsession36657exit1 are both retained.

Owner-final-refresh remains an18-request remote observation from01:52–01:53UTC, not current-core source validation or later runtime status. Source commits and owner boundaries remain perphase. Host-only fixtures are distinguished from actual boots by the retained classification sources. B2 frozen report namesA2 verifier in two documentation fields; actual retained commands executeB2.

Original first25 inventories/receipts and immutable final-round-evidence-index-batch01 are unchanged. Root closure package is excluded from this index to avoid self-reference. All corrections and failures are additive records; frozen package bytes were never edited by the index agent.
