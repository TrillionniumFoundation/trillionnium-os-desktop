# Append batch02: actual same-host cross-path equality

`2026-10-17-repro-cross-path` is **actualboot-supported same-host, schema4 opt-in complete-input comparison**, not general reproduction acceptance. The original comparator exited **0**, with two additional successful live-artifact checks. Complete kernel ELF (8,286,952 bytes), initramfs (1,107,990) and BIOS (262,144) were byte-equal across distinct actual source roots.

Both real Rust-kernel boots returned raw QEMU **33**. They are the already-counted **A4/B4** cases: **additional unique guest count = 0**. Each original cold action logged279 compiling lines and eight successful controller commands; no extra standalone make-kernel command or VM launch is inferred.

Exact producer: `4e8c7083575cec69efabe8d2250dfdd040c8dee8`; full tree `d50cc2fd3fac4e8060ff26c324267b267767bca2`; derived kernel tree `6b3cab110aa6d30d5b89f99c4389c9c3e01022da`. Fixed Asterinas/nightly pins are unchanged. Actual host and synthetic embedded builder are separately recorded.

Accepted scope is the same cloud host under explicit path/component/Cargo-unit-metadata projection with one Cargo job. Cross-host, immutable environment, unprofiled default build, general reproducibility and G0/G1/G2 remain unaccepted. The earlier A2/B2 ELF comparison remains failed. Runtime serial bytes are not declared equal.

Frozen package SHA256SUMS: `b940afa3098a50249390419271efc9e4b21efcf012d90ccb2deef06a8966c9a2`. Exact original README/report/source/verifier, command/output/result/live-check and review hashes are referenced in classification-comparison.json. This classifier only read the frozen package and matched its manifest digest; parent owns actual verifier runs. No Cargo, Rust, QEMU, test or verifier was executed here; no initial classification or batch01 was edited.
