#!/usr/bin/env python3
"""Run bounded read-only evidence audits; write receipts only under scratch."""
import datetime,hashlib,json,os,pathlib,shutil,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path("/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop")
EVIDENCE=REPO/"support/build/evidence"
NAMES=["a02-owner-nightly","archive-custody","cloud-native","integration-case-targets","integration-input-snapshots","integration-input-snapshots-final","integration-private-tools/host","ktest-private-inputs","latest-main","owner-ci","owner-refresh","private-bios","private-qemu-data","private-toolchain","repro-cargo-disambiguator","repro-compiler-flags","repro-cross-path-before","repro-kernel-a2","repro-kernel-a3-before","repro-kernel-a4","repro-kernel-b2","repro-kernel-before","repro-mechanism","repro-producer-order","repro-kernel-b4"]
PHASES=[EVIDENCE/("2026-10-17-"+x) for x in NAMES]
EXPECTED={"integration-input-snapshots":"6131edf8f387f3ef854cc33df4cd05e05ad5ea1d7776a5632c2486757879e7ce","integration-input-snapshots-final":"7497e665c4ac7777f89d5f0e94cea1a8190acabbbd8721de5c68508ab07bdae4","repro-kernel-b4":"f24be56fc3e9da87c8e1fdecd4227f288eb01d0e7b5e19e077d00bf7ced846a9"}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(ok,msg):
 if not ok:raise ValueError(msg)
def captured(argv,label,cwd=REPO,timeout=300):
 out=ROOT/"executions"/label;out.mkdir(parents=True,exist_ok=False)
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();before=time.monotonic()
 env=os.environ.copy()
 # Python -B explicitly disables bytecode even under isolated -I.
 p=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=timeout)
 (out/"stdout.log").write_bytes(p.stdout);(out/"stderr.log").write_bytes(p.stderr)
 receipt={"argv":argv,"cwd":str(cwd),"started_utc":started,"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"duration_seconds":round(time.monotonic()-before,3),"exit_code":p.returncode,"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest(),"controller_sha256":sha(pathlib.Path(__file__)),"no_restore_or_output_flag":True}
 (out/"command.json").write_text(json.dumps(receipt,indent=2)+"\n")
 return receipt,out
plan={"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"repo_head_at_start":subprocess.check_output(["git","rev-parse","HEAD"],cwd=REPO,text=True).strip(),"phases":[],"root_README_bytes":(REPO/"README.md").stat().st_size,"excluded":"No future comparison/native/normal phase or runtime target is selected by this explicit phase list.","modes":["-I -B","-I -O -B"]}
for name,p in zip(NAMES,PHASES):
 need((p/"SHA256SUMS").is_file(),"not frozen "+str(p));digest=sha(p/"SHA256SUMS")
 if name in EXPECTED:need(digest==EXPECTED[name],"parent-authorized frozen checksum mismatch "+name)
 plan["phases"].append({"name":name,"path":str(p),"SHA256SUMS_sha256":digest,"shipped_verifier":str(p/"verify.py") if (p/"verify.py").is_file() else None})
(ROOT/"plan.json").write_text(json.dumps(plan,indent=2)+"\n")
results=[]
for name,p in zip(NAMES,PHASES):
 row={"name":name,"path":str(p),"manifest_sha256_before":sha(p/"SHA256SUMS"),"generic":[],"shipped":[]}
 safe=name.replace("/","-")
 for mode,flags in (("I",["-I","-B"]),("IO",["-I","-O","-B"])):
  argv=[sys.executable,*flags,str(ROOT/"verify-phase.py"),str(p)]
  rec,out=captured(argv,safe+"/generic-"+mode)
  row["generic"].append({"mode":mode,"receipt":str((out/"command.json").relative_to(ROOT)),"exit_code":rec["exit_code"]})
  if rec["exit_code"]==0:
   value=json.loads((out/"stdout.log").read_text())
   if mode=="I":row["inventory"]=value
  else:print(json.dumps({"phase":name,"stage":"generic-"+mode,"exit":rec["exit_code"]}),flush=True)
 if (p/"verify.py").is_file():
  for mode,flags in (("I",["-I","-B"]),("IO",["-I","-O","-B"])):
   argv=[sys.executable,*flags,str(p/"verify.py")]
   rec,out=captured(argv,safe+"/shipped-"+mode)
   row["shipped"].append({"mode":mode,"receipt":str((out/"command.json").relative_to(ROOT)),"exit_code":rec["exit_code"],"verifier_sha256":sha(p/"verify.py")})
   if rec["exit_code"]==0:
    try:row["shipped"][-1]["result"]=json.loads((out/"stdout.log").read_text())
    except json.JSONDecodeError:pass
 if name=="owner-refresh":
  # This historical verifier writes derived files. Copy only its complete input
  # closure, never execute it against frozen repository bytes.
  copy=ROOT/"scratch-verifier-closures/owner-refresh";copy.mkdir(parents=True,exist_ok=False)
  shutil.copy2(p/"verify-blobs.py",copy/"verify-blobs.py");(copy/"blobs").mkdir()
  for f in (p/"blobs").glob("*.capture.json"):shutil.copy2(f,copy/"blobs"/f.name)
  need(sha(copy/"verify-blobs.py")==sha(p/"verify-blobs.py"),"copy verifier differs")
  for mode,flags in (("I",["-I","-B"]),("IO",["-I","-O","-B"])):
   argv=[sys.executable,*flags,str(copy/"verify-blobs.py")]
   rec,out=captured(argv,safe+"/scratch-blob-verifier-"+mode)
   row["shipped"].append({"mode":mode,"receipt":str((out/"command.json").relative_to(ROOT)),"exit_code":rec["exit_code"],"verifier_sha256":sha(p/"verify-blobs.py"),"scratch_copy_only":True,"scope":"18 fetched Git source blobs only; outer generic audit checks the original frozen package."})
 row["manifest_sha256_after"]=sha(p/"SHA256SUMS")
 row["manifest_unchanged"]=row["manifest_sha256_before"]==row["manifest_sha256_after"]
 results.append(row)
 (ROOT/"audit-progress.json").write_text(json.dumps({"phases":results},indent=2)+"\n")
 print(json.dumps({"phase":name,"generic_exits":[x["exit_code"] for x in row["generic"]],"shipped_exits":[x["exit_code"] for x in row["shipped"]],"manifest_unchanged":row["manifest_unchanged"]}),flush=True)
summary={"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"controller_sha256":sha(pathlib.Path(__file__)),"phase_count":len(results),"generic_executions":sum(len(x["generic"]) for x in results),"shipped_executions":sum(len(x["shipped"]) for x in results),"all_generic_pass":all(all(r["exit_code"]==0 for r in x["generic"]) for x in results),"all_shipped_pass":all(all(r["exit_code"]==0 for r in x["shipped"]) for x in results),"all_manifests_unchanged":all(x["manifest_unchanged"] for x in results),"root_README_bytes":(REPO/"README.md").stat().st_size,"new_Cargo_VM_workloads":0,"phases":results}
(ROOT/"audit-results.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps({k:v for k,v in summary.items() if k!="phases"}),flush=True)

