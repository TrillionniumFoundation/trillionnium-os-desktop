#!/usr/bin/env python3
"""Read candidate metadata only; never read targets or in-progress raw packages."""
from pathlib import Path
import datetime,difflib,hashlib,json,re
BASE=Path('/workspace/scratch/ae1a8cf05419');REPO=BASE/'trillionnium-os-desktop';OUT=BASE/'final-metadata-review';OUT.mkdir(exist_ok=False)
paths=['support/build/README.md','support/upstream-lock.json'];raw={}
for name in paths:
 data=(REPO/name).read_bytes();raw[name]=data;p=OUT/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
d=json.loads(raw[paths[1]]);k=d['kernel'];old=json.loads((BASE/'final-owner-readback/local-source/support/upstream-lock.json').read_text())
checks=[]
def check(name,condition,scope):
 checks.append({'name':name,'passed':bool(condition),'scope':scope})
n=k['latest_native_boot'];cloud=k['cloud_validation_2026_10_17'];m=cloud['final_osdk_matrix'];p=cloud['cross_path_repeatability'];kt=k['kernel_mode_regression'];sync=k['cloud_main_sync']
check('ordinary_source_and_session',n['code_commit']=='d879a9d2ffae8d0eb0df441370da54f9e3a38431' and n['actual_tool_session']==15521 and n['actual_tool_exit']==0,'Root supplied actual N1 outer completion; not independently rerun.')
check('ordinary_cold_then_warm_scope',n['preceding_clean_kernel_build']['target_absent_before_launch'] is True and n['preceding_clean_kernel_build']['compilation_lines']==279 and n['preceding_clean_kernel_build']['public_exit']==0 and n['release_compilation_observed'] is False and n['target_cache_reused'] is True and n['empty_target_rebuild'] is False and 'boot stage reused' in n['stage_scope'],'Warm run_kernel fields are now explicitly distinguished from the preceding cold make kernel.')
check('ordinary_exact_artifact_and_serial',n['boot_sha256']=='c49ad7da1c76c1f559d065ac3f8cbcbad407242dda54f1ed00028f02d5c2413d' and n['boot_size']==8258112 and n['preceding_clean_kernel_build']['kernel_sha256']==n['boot_sha256'] and n['preceding_clean_kernel_build']['kernel_bytes']==n['boot_size'] and n['serial_sha256']=='3840526255cff7c53567f3e35e42739a11dba24f3feb03594719e92bec0ab5ca' and n['serial_size']==72247 and n['qemu_raw_exit']==33,'Matches root supplied N1 facts.')
check('ordinary_11steps_source_clean',n['controller_commands']==11 and n['all_controller_exits']==0 and n['post_source_inputs_checked']==118 and n['post_git_status_empty'] is True,'Matches supplied receipt summary, not a new source/build execution.')
check('ordinary_mirrors_equal',n==cloud['ordinary_build_and_boot'],'Latest boot and cloud pipeline objects are exactly equal.')
check('final_matrix_exact_scope',(m['source_commit'],m['selected'],m['passed'],m['failed'],m['blocked'],m['qemu_guests'],m['raw_guest_exit'],m['vmx_soft_skipped'],m['coverage_functions'],m['actual_input_mappings_retained'])==('d879a9d2ffae8d0eb0df441370da54f9e3a38431',22,22,0,0,11,33,1,5692,23) and m['coverage_profraw_sha256']=='0862a2568e4bb069835dfa6fdf2d15af727020848976bb0a2457b8eeb7fb601c','Matches root supplied real full22 facts; no fake-QEMU test promoted to VM acceptance.')
check('matrix_mirrors_equal',m==k['host_regression']['explicit_tcp_gdb_capture']['cloud_latest'],'Historical parent object is unchanged; cloud_latest duplicates the actual current matrix.')
check('optin_crosspath_samehost_only',p['source_commit']=='4e8c7083575cec69efabe8d2250dfdd040c8dee8' and p['cold_builds']==2 and p['actual_source_roots_differ'] is True and p['same_actual_host'] is True and p['complete_elf_bytes_equal'] is True and p['complete_initramfs_bytes_equal'] is True and p['complete_bios_bytes_equal'] is True and p['kernel_sha256']=='8c540288c6af2a1a97121031643c1af4c4db395d7e8b4082d6edc4604449849a' and p['raw_qemu_exits']==[33,33] and p['cross_host_verified'] is False and p['immutable_environment_verified'] is False,'Matches supplied completed A4/B4 full comparison; not equivalence to ordinary N1 artifact.')
check('ktest_denominator_and_source',kt['code_commit']=='d895dd73a07788f6fc825fb3ca29cca22d93bb07' and (kt['reported_passed'],kt['soft_skipped'],kt['exercised_passed_lower_bound'])==(362,3,359) and kt['raw_qemu_exits']==[33,33],'A01 source bound kernel tests; no import of A06 owner 374/371 denominator.')
check('ktest_tool_vs_runner_exit_fixed',kt['actual_tool_session']==36657 and kt['actual_tool_exit']==1 and kt['kernel_mode_runner_exit']==0 and 'enclosing sequential' in kt['actual_tool_exit_scope'],'Root confirmed session36657 is the outer retry controller which later failed its20/22 matrix.')
check('ktest_sdk_not_inherited',kt['osdk_code_commit']==kt['code_commit'] and kt['osdk_install_skipped'] is False and kt['source_root_bound_sdk_reinstalled'] is True and kt['osdk_binary_sha256']!=old['kernel']['kernel_mode_regression']['osdk_binary_sha256'],'Explicit d895 SDK identity; raw SDK hash/content binding remains the native-before package publisher responsibility.')
check('old_history_exact',k['cloud_main_sync_history'][-1]==old['kernel']['cloud_main_sync'] and k['native_boot_history'][-1]==old['kernel']['latest_native_boot'] and k['kernel_mode_regression_history'][-1]==old['kernel']['kernel_mode_regression'],'All displaced latest records retained byte-equivalent as parsed JSON history.')
check('host_sources_and_counts',sync['main_commit']=='40ca002fac0726b366726d3353916637b29adeae' and sync['abi_host_validation']['source_commit']=='8f3bb49ab161104063a6ebea25428c40aa884ac0' and sync['abi_host_validation']['runner_checks_passed']==13 and sync['control_host_validation']['std_passed']==129 and sync['control_host_validation']['portable_spin_passed']==129 and sync['host_results_are_not_native_control_acceptance'] is True,'Historical validation inputs are bridged; no full suite is rerun by source preflight.')
for key in ['all_project_blockers_closed','native_resource_control_accepted','default_unix_blocker_closed','vmx_ept_exercised','cross_host_reproducibility_claimed','immutable_environment_claimed']:
 check('scope_false_'+key,cloud[key] is False,'Required non-A01/environment acceptance remains open.')
check('top_ready_and_reference_scope',d['reproducible_kernel_build_ready'] is False and d['native_build_profile_ready'] is True and d['build_container_digest'] is None and d['reference_asset_downloaded'] is False,'Same-host opt-in equality does not claim immutable/cross-host readiness or a downloaded ISO.')
check('baseline_artifact_and_pin_roles',all(k[key]==old['kernel'][key] for key in ['commit','tree','toolchain','cargo_lock_sha256','osdk_cargo_lock_sha256','artifact_sha256','artifact_sha256_role']) and d['hepta']['commit']==old['hepta']['commit'],'No fixed pin/lock or original accepted baseline artifact silently relabeled.')
links=[]
for text in re.findall(r'\]\(([^)]+)\)',raw[paths[0]].decode()):
 if '://' in text or text.startswith('#'):continue
 selected=(REPO/'support/build'/text.split('#')[0]);links.append({'link':text,'exists_at_review':selected.exists()})
pending=[x['link'] for x in links if not x['exists_at_review']]
expected_pending={'evidence/2026-10-17-cloud-closure/REPORT.md','evidence/2026-10-17-cloud-closure/HANDOFF.md'}
check('only_expected_unfrozen_md_links',set(pending)<=expected_pending,'Known phase creation prerequisites, not treated as broken published links or false guest failures.')
sources=[{'path':n,'bytes':len(raw[n]),'sha256':hashlib.sha256(raw[n]).hexdigest()} for n in paths]
unchanged=all((REPO/name).read_bytes()==data for name,data in raw.items());check('reviewed_bytes_stable',unchanged,'Two reviewed files unchanged throughout this read-only analysis.')
report={'record_kind':'Independent read-only final metadata review, not an execution/guest test.', 'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,
 'source_of_runtime_facts':'Root supplied actual N1/A4-B4/full22/ktest receipts; no in-progress ABI/native raw package or target read.',
 'checks':checks,'all_passed':all(x['passed'] for x in checks),
 'resolved_finding':{'initial_lock_sha256':'6639cdee3413042ab9e3a1e1fc5898f5e3c95d0bd661ac131ee8146e8973f9e4','issue':'actual_tool_exit0 inherited for outer session36657 despite its later matrix failure1; inner ktest passed0.', 'final_fields':{'actual_tool_exit':1,'kernel_mode_runner_exit':0},'root_confirmed':True},
 'clarified_inheritance':{'N1':'stage_scope now expressly limits false compilation/empty-target flags and reused-cache true to warm run_kernel; the preceding cold build279 is separate. Both ordinary objects match.',
 'SDK':'Source d895, new explicit hash e4bdfec2..., install_skippedfalse/source-root reinstalltrue replace the old SDK fields. Source binding must be checked against the eventual frozen native-before package.',
 'history':'Old main/native/ktest latest records were copied intact to their history arrays.'},
 'links':links,'publication_prerequisites':pending+['Verify source-bridge/result.json and all four new native/cloud phase references after freeze, before publication.','Bind finalmatrix tool session78119, SDK hash and remaining raw-derived fields to their final raw package; this review deliberately did not read active package inputs.'],
 'decision':'No remaining factual blocker in the reviewed final metadata; pending phase files still need normal publication closure.'}
(OUT/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
(OUT/'REPORT.md').write_text('''# Final README / upstream-lock metadata review

独立只读复审通过，未修改仓库、Git、docs或证据，也未读取制作中的ABI/native包或target。审阅字节和SHA256见source/与report.json；runtime事实来自root给定的实际回执，不把本次JSON校验说成重跑构建。

发现并由root修复了一项真实继承误报：kernel_mode_regression 的session36657是外层顺序controller，ktest0之后matrix20/22失败，故外层actual_tool_exit应为1。终稿已记录actual_tool_exit=1、kernel_mode_runner_exit=0及明确scope。不能用inner成功改写outer失败。

N1的stage_scope也已补齐：release_compilation_observed=false、empty_target_rebuild=false、target_cache_reused=true描述暖run_kernel，而preceding_clean_kernel_build记录absent target/279 Compiling/makekernel0。两份ordinary对象逐项相等；README明确这是一条冷编译接暖启动流水线。

其余核对通过：N1 source d879、session15521/0、11steps0、118检查/clean、ELF8258112B/c49ad7da和serial72247B/38405262；opt-in4e8的A4/B4完整8c54 ELF/initrd/BIOS相等、两个raw33，仅same-host cross-path；最终矩阵source d879、22/22/0fail/0blocked、11raw33、1VMXsoft、5692functions与23inputs；d895 ktest362reported/3skip/359lower bound。矩阵两份对象一致。

旧latest main/native/ktest对象完整进入history。新SDK字段明确d895/source-root reinstalled、install_skippedfalse和新hash，不沿用旧ff040二进制。其raw identity仍由最终native-before包核验。sourcebridge只证明历史host输入继承，不是重跑13checks或129+129；README措辞明确这一点。固定pins、Cargo locks及首个artifact_sha256角色未改变，scope外false保留。

当前未出现的README链接仅cloud-closure/REPORT.md和HANDOFF.md，符合root说明的待冻结阶段，不是已发布坏链接。发布前须再次检查这两项、source-bridge/result.json和全部新phase链接，核对新包中的toolsession/SDK/raw-derived字段。除此之外未发现需要阻止metadata发布的事实问题。
''')
for name in paths:
 before=BASE/'final-owner-readback/local-source'/name
 diff=''.join(difflib.unified_diff(before.read_text().splitlines(True),raw[name].decode().splitlines(True),fromfile='before/'+name,tofile='reviewed/'+name))
 q=OUT/'diff'/Path(name).name;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(diff)
(OUT/'review-script.py').write_bytes(Path(__file__).read_bytes())
files=sorted(p for p in OUT.rglob('*') if p.is_file());(OUT/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(OUT).as_posix()+'\n' for p in files))
print(json.dumps({'all_passed':report['all_passed'],'checks':len(checks),'sources':sources,'pending_links':pending,'report_sha256':hashlib.sha256((OUT/'report.json').read_bytes()).hexdigest(),'SHA256SUMS_sha256':hashlib.sha256((OUT/'SHA256SUMS').read_bytes()).hexdigest()},indent=2))
if not report['all_passed']:raise SystemExit(1)
