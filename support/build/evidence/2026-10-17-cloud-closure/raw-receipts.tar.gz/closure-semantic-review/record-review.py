from pathlib import Path
import ast, hashlib, json, re
from datetime import datetime, timezone
repo=Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop')
phase=repo/'support/build/evidence/2026-10-17-cloud-closure'
out=Path(__file__).parent
source={}; contents={}
for name in ['REPORT.md','HANDOFF.md','report.json','blockers.json','errata.json','cloud-replay-env.sh','verify.py','coverage-counts.py','coverage-counts.json','coverage-counts-command.json']:
 p=phase/name
 before=p.stat(); blob=p.read_bytes(); after=p.stat()
 fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 if fields(before)!=fields(after): raise RuntimeError('source changed during read: '+name)
 contents[name]=blob
 source[name]={'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()}
r=json.loads(contents['report.json']); blockers=json.loads(contents['blockers.json']); cov=json.loads(contents['coverage-counts.json']); covcmd=json.loads(contents['coverage-counts-command.json'])
paths=['kernel/core/src/process/process/mod.rs','kernel/core/src/process/posix_thread/mod.rs','kernel/core/src/syscall/ioctl.rs','kernel/core/src/fs/file/file_handle.rs','kernel/core/src/process/process/init_proc.rs','kernel/core/src/process/execve.rs','kernel/core/src/sched/sched_class/mod.rs']
paths+=['kernel/core/src/sched/sched_class/'+x+'.rs' for x in ['fair','real_time','policy','time']]
paths+=['ostd/src/task/mod.rs','ostd/src/task/processor.rs','ostd/src/task/scheduler/mod.rs']
interfaces={str(Path('kernel/asterinas')/p):(repo/'kernel/asterinas'/p).is_file() for p in paths}
checks={
'ordinary_source_and_outer_exit':r['ordinary_kernel']['source']=='d879a9d2ffae8d0eb0df441370da54f9e3a38431' and r['ordinary_kernel']['tool_exit']==0,
'ordinary_cold_then_warm_scopes':r['ordinary_kernel']['target_absent_before_cold_stage'] is True and r['ordinary_kernel']['cold_make_kernel_compilation_lines']==279 and r['ordinary_kernel']['boot_stage_compilation_lines']==0 and r['ordinary_kernel']['boot_reuses_preceding_cold_target'] is True,
'ordinary_real_raw33_and_full_bytes':r['ordinary_kernel']['raw_qemu_exit']==33 and r['ordinary_kernel']['kernel_bytes']==8258112 and r['ordinary_kernel']['kernel_sha256']=='c49ad7da1c76c1f559d065ac3f8cbcbad407242dda54f1ed00028f02d5c2413d' and r['ordinary_kernel']['serial_sha256']=='3840526255cff7c53567f3e35e42739a11dba24f3feb03594719e92bec0ab5ca',
'projected_distinct_root_exact_inputs':r['projected_repeatability']['source']=='4e8c7083575cec69efabe8d2250dfdd040c8dee8' and r['projected_repeatability']['cold_distinct_actual_source_roots'] is True and all(r['projected_repeatability']['complete_input_bytes_equal'].values()) and r['projected_repeatability']['actual_comparison_exit']==0,
'correct_root_ktest_inner0_outer1':r['kernel_mode']['source']=='d895dd73a07788f6fc825fb3ca29cca22d93bb07' and r['kernel_mode']['kernel_mode_runner_exit']==0 and r['kernel_mode']['enclosing_tool_session']==36657 and r['kernel_mode']['enclosing_tool_exit']==1,
'ktest_reported_vs_exercised':r['kernel_mode']['reported_passed']==362 and r['kernel_mode']['soft_skipped']==3 and r['kernel_mode']['exercised_lower_bound']==359,
'final_matrix_complete_cached_scope':r['osdk_matrix']['selected']==22 and r['osdk_matrix']['passed']==22 and r['osdk_matrix']['failed']==0 and r['osdk_matrix']['blocked']==0 and r['osdk_matrix']['cached_compilation'] is True and r['osdk_matrix']['cold_claimed'] is False,
'final_guest_and_input_denominators':r['osdk_matrix']['actual_guests']==11 and r['osdk_matrix']['all_raw_exit']==33 and r['osdk_matrix']['vmx_soft_skip']==1 and r['osdk_matrix']['private_input_mappings']==23 and r['osdk_matrix']['unique_retained_artifacts']==13,
'fixed_nightly_and_full_kernel':r['pins']['toolchain']=='nightly-2026-07-21' and r['pins']['upstream_commit']=='c4b7ed575b7b32773475b194d2ad41fb6d03765b' and r['pins']['source_directory']=='kernel/asterinas',
'no_scope_widening':all(r['scopes'][x] is False for x in ['all_project_blockers_closed','cross_host_reproducibility_accepted','immutable_environment_accepted','native_hos2_enforcement_accepted','g1_accepted','g2_accepted','vmx_ept_exercised','default_host_af_unix_restored','unknown_writer_identified','kernel_core_modified_this_round']),
'owner_and_host_open_items_explicit':{x['id'] for x in blockers['open_items']}=={'host-af-unix','host-kvm-vmx','cross-host-reproduction','immutable-environment','unknown-workspace-writer','a05-native-control','a06-accounting','a07-persistent-owner','a04-linux-gaps','integration-and-ci'},
'host_guest_wording_corrected':"recorded main baseline's actual guest NOT_ENFORCED result" in re.sub(r'\s+',' ',contents['HANDOFF.md'].decode()) and b'NOT_ENFORCED host behavior' not in contents['HANDOFF.md'],
'handoff_all_paths_exist':all(interfaces.values()),
'source_bridge_explicitly_unfrozen':r['source_bridge']['candidate'] is None and r['source_bridge']['source_identity_is_not_test_execution'] is True,
'coverage_offline_not_new_guest':cov['scope']=='offline analysis of exact retained LLVM report; no new guest or coverage run',
'coverage_positive_denominator_and_member':cov['function_records']==5692 and cov['positive_function_entry_counts']==5692 and cov['zero_function_entry_counts']==0 and cov['maximum_function_entry_count']==383729 and cov['member_bytes']==1316142 and cov['member_sha256']=='855b402eef1decb508a55afc1b959b8cf22351cc73cc377cd24effc07287d253',
'coverage_command_result_and_source_binding':covcmd['returncode']==0 and covcmd['script_sha256']==source['coverage-counts.py']['sha256'] and covcmd['output_sha256']==source['coverage-counts.json']['sha256'],
'env_targets_selected_cwd':b'export CARGO_TARGET_DIR="$PWD/kernel/asterinas/target"' in contents['cloud-replay-env.sh'],
'env_declares_host_specific_not_installer':b'not a package installer' in contents['cloud-replay-env.sh'],
'verifier_no_python_assert':not any(isinstance(n,ast.Assert) for n in ast.walk(ast.parse(contents['verify.py']))),
'verifier_offline_scope_explicit':b'never execute archived checks, builds or VMs' in contents['verify.py'] and b'not execute' in contents['REPORT.md'],
'root_readme_zero':(repo/'README.md').stat().st_size==0,
}
if not all(checks.values()): raise RuntimeError('review consistency failure: '+repr([k for k,v in checks.items() if not v]))
report={
 'schema':'a01-independent-closure-semantic-review/1',
 'reviewed_at':datetime.now(timezone.utc).isoformat(),
 'reviewer':'/root/build_environment',
 'ready':True,'ready_scope':'Specified unfrozen prose/metadata/interfaces and scripts are semantically ready for root finalization; this receipt is not a published frozen-closure acceptance.',
 'blocking_findings_remaining':[],
 'resolved_findings':[{'file':'HANDOFF.md','old':'main NOT_ENFORCED host behavior','corrected':"recorded main baseline's actual guest NOT_ENFORCED result",'reason':'The baseline result came from the real Asterinas guest, not host-Linux behavior.'}],
 'reviewed_sources':source,
 'metadata_consistency_checks':checks,
 'metadata_consistency_count':len(checks),
 'interface_path_checks':interfaces,
 'additional_readonly_checks':[{'check':'bash -n cloud-replay-env.sh','exit':0},{'check':'ast.parse verify.py and coverage-counts.py','result':'passed'},{'check':'targeted Process/PosixThread/start_time/sys_ioctl/FileLike::ioctl/ClassScheduler source lookup','result':'paths and named interfaces present'}],
 'pending_root_finalization':['Publish/freeze native phases and final audit snapshot before generating phase-index.json.','Fill final source_bridge.candidate and retain the exact consumed-input comparison result; identity is not reexecution.','Generate final aggregate SHA256SUMS/index and run final offline verifier in -I and -I -O, preserving actual command/status.','Read back final-head CI after publication; queued/missing is not success.'],
 'limits':['No build, VM, GDB, Cargo, installer or replay environment was executed.','No target directory, active SDK, in-progress native package or ABI capture payload was read.','Runtime figures were checked against the supplied authoritative receipts and prior metadata review; this task does not independently rerun runtime checks.','The retained coverage-counts result/command/source were reviewed; the native raw archive was not re-read in this review.','The seven requested documents were unfrozen at capture; later root edits require final hash/index checks.']
}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'REPORT.md').write_text('''# Independent closure semantic review

READY for root finalization. No remaining blocking semantic finding in the reviewed unfrozen documents.

The one finding was corrected by root: HANDOFF now identifies main NOT_ENFORCED as a real guest result. All fourteen named interface paths exist. The ordinary cold build and subsequent warm boot, same-host distinct-root projected profile, inner ktest success and enclosing tool failure, cached final 22-case matrix, guest/input counts and open owner/host scopes are kept distinct.

The environment script passed bash syntax checking and explicitly targets the selected worktree while using this host's private dependencies. The offline coverage count result records 5,692 positive function-entry records, zero zero-count records, and the original report member hash; it is not a new guest execution. The aggregate verifier claims inventory/hash/pin checks only.

Root still must fill the final source bridge, index and checksums after all phases freeze, run the offline verifier in both Python modes, and read back final-head CI. These are finalization prerequisites, not results already accepted by this receipt. No VM/build/env script was executed and no repository file was modified by this review.

Exact reviewed file identities and 22 explicit metadata consistency checks are in report.json. These checks are metadata review, not newly executed upstream tests.
''')
rows=[]
for p in sorted(out.iterdir()):
 if p.is_file() and p.name!='SHA256SUMS': rows.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n')
(out/'SHA256SUMS').write_text(''.join(rows))
print(json.dumps({'output':str(out),'files':len(list(out.iterdir())),'bytes':sum(p.stat().st_size for p in out.iterdir()),'checks':len(checks),'all_checks':all(checks.values()),'report_sha256':hashlib.sha256((out/'report.json').read_bytes()).hexdigest(),'sha256sums_sha256':hashlib.sha256((out/'SHA256SUMS').read_bytes()).hexdigest(),'reviewed_hand_off_sha256':source['HANDOFF.md']['sha256']},indent=2))
