# Final closure index verifier draft

`verify.py` verifies frozen evidence inventories and hashes. It never invokes phase verifiers, archived scripts, Cargo, a compiler, a live-artifact check or a VM. A successful result means the selected preserved bytes, fixed upstream pins and explicit scope limits pass the index checks; it does not rerun the underlying validations or close project-wide blockers.

Copy only the final verifier into the future `support/build/evidence/2026-10-17-cloud-closure/verify.py`. Write `phase-index.json` and the actual final `report.json` there, then freeze that directory's own `SHA256SUMS`. This scratch directory is a draft and is not a project validation phase.

## Minimal index contract

`phase-index.example.json` contains the already frozen B4 phase's real inventory numbers as a structure example. The final index should explicitly enumerate the desired frozen phases. For each entry:

- `path`: canonical POSIX path relative to the repository, beneath `support/build/evidence/`.
- `sha256sums_sha256`: SHA256 of that phase's root `SHA256SUMS` bytes.
- `file_count`: every regular file including the root `SHA256SUMS` and any nested checksum receipts.
- `total_bytes`: sum of those exact files' byte sizes, including all checksum files.

The final phase must exclude itself and its ancestors/descendants from the index, avoiding circular checksum identities. Duplicate or overlapping indexed phase directories are rejected. No phase is discovered implicitly.

The final report must contain these exact false booleans under `scopes`:

```json
{
  "scopes": {
    "all_project_blockers_closed": false,
    "cross_host_reproducibility_accepted": false,
    "immutable_environment_accepted": false
  }
}
```

Merge that object into the real report; this example does not replace the report's actual results or owner ledger.

## Freeze and run

The final root checksum table must cover every regular file except itself. Exclude only the root path `phase / 'SHA256SUMS'`, not every filename with that basename. Nested checksum receipts must remain covered.

```sh
python3 -I support/build/evidence/2026-10-17-cloud-closure/verify.py --repo-root /absolute/repository
python3 -I -O support/build/evidence/2026-10-17-cloud-closure/verify.py --repo-root /absolute/repository
```

The default index/report names are relative to the verifier's own frozen phase. Optional `--index relative/path.json` and `--report relative/path.json` remain constrained to that directory and its own checksum table. Both files must already be checksum-covered.

## Checks and boundaries

The verifier checks every indexed root manifest's identity, every listed file hash, exact inventory coverage, counts, total bytes and the 2 MiB limit for each stored file. It rejects duplicate/self/traversal checksum entries, missing or unlisted files, symlinks and special files. `.` is explicitly rejected as an empty path. Reads use directory file descriptors, `O_NOFOLLOW`, stable pre/post file identities and directory inventory checks. Replaced phase pathnames are rejected. Index/report bytes are bound to the final phase's verified checksum table and that phase is checked again at the end.

A nested `SHA256SUMS` is an ordinary preserved receipt covered by its phase's root manifest. It is never recursively interpreted or executed. This supports readable copies of receipts whose original sibling files are retained in a raw archive rather than alongside the readable copy. Since its listed paths are never opened, a nested receipt cannot cause filesystem traversal. Actual root-manifest paths always undergo canonical-path and no-follow checks.

The repository root `README.md` must be exactly zero bytes. The kernel lock must retain Asterinas v0.19.0, the fixed upstream commit/tree, nightly-2026-07-21, full-kernel derivation and `kernel/asterinas` source location. Historical artifact/baseline fields are neither rewritten nor substituted. These are read-time checks, not an immutable-host guarantee.

`probe-fixtures.py` exercises only synthetic filesystem guards in temporary scratch repositories. `fixture-results.json` records 18 cases in both normal and optimized modes, 36 expected outcomes: a valid ordinary nested receipt, incorrect manifest/count/size, missing/unlisted/changed content, traversal/duplicate entries, symlink, oversized file, widened scope, duplicate index, nonempty root README, wrong nightly and three `.` path cases. No real build, guest, evidence phase or target was executed/read for those probes.
