"""Synthetic filesystem guards only. Never creates or claims build/guest results."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent
PINS={'repository':'asterinas/asterinas','tag':'v0.19.0','commit':'c4b7ed575b7b32773475b194d2ad41fb6d03765b','tree':'96605cf64aeae2d34f29b97e85eff9315fe10a8e','toolchain':'nightly-2026-07-21','reuse':'full_kernel_derived','source_directory':'kernel/asterinas'}
def sha(data):return hashlib.sha256(data).hexdigest()
def sums(path):
 files=[p for p in sorted(path.rglob('*')) if p.is_file() and p!=path/'SHA256SUMS'];(path/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+str(p.relative_to(path))+'\n' for p in files))
def record(path):
 files=[p for p in path.rglob('*') if p.is_file()];return {'path':'support/build/evidence/synthetic-payload','sha256sums_sha256':sha((path/'SHA256SUMS').read_bytes()),'file_count':len(files),'total_bytes':sum(p.stat().st_size for p in files)}
def initialize(root):
 repo=root/'repo';phase=repo/'support/build/evidence/synthetic-payload';final=repo/'support/build/evidence/synthetic-closure';phase.mkdir(parents=True);final.mkdir();(repo/'README.md').write_bytes(b'');(repo/'support/upstream-lock.json').write_text(json.dumps({'kernel':PINS}));(phase/'payload.bin').write_bytes(b'SYNTHETIC NON-BUILD FILESYSTEM PROBE\n');(phase/'copied-receipt').mkdir();(phase/'copied-receipt/SHA256SUMS').write_text('0'*64+'  original-context-only.txt\n');sums(phase);shutil.copyfile(HERE/'verify.py',final/'verify.py');(final/'report.json').write_text(json.dumps({'fixture':'filesystem only; no build, guest or project acceptance','scopes':{k:False for k in ['all_project_blockers_closed','cross_host_reproducibility_accepted','immutable_environment_accepted']}}));index={'schema':'a01-cloud-closure-index/1','phases':[record(phase)]};(final/'phase-index.json').write_text(json.dumps(index));sums(final);return repo,phase,final,index
names=['valid-opaque-nested-receipt','wrong-manifest-identity','wrong-file-count','wrong-total-bytes','missing-file','unlisted-file','same-size-content-change','traversal-entry','duplicate-entry','symlink-input','oversize-input','widened-scope','duplicate-index-phase','nonzero-root-readme','wrong-fixed-nightly','dot-index-path','dot-report-path','dot-checksum-path']
rows=[]
for optimized in (False,True):
 for name in names:
  with tempfile.TemporaryDirectory(prefix='fixture-',dir=HERE) as tmp:
   repo,phase,final,index=initialize(Path(tmp));expected=0 if name=='valid-opaque-nested-receipt' else 1
   if name=='wrong-manifest-identity':index['phases'][0]['sha256sums_sha256']='0'*64
   elif name=='wrong-file-count':index['phases'][0]['file_count']+=1
   elif name=='wrong-total-bytes':index['phases'][0]['total_bytes']+=1
   elif name=='missing-file':(phase/'payload.bin').unlink()
   elif name=='unlisted-file':(phase/'unlisted.bin').write_bytes(b'no')
   elif name=='same-size-content-change':(phase/'payload.bin').write_bytes(b'X'+(phase/'payload.bin').read_bytes()[1:])
   elif name=='traversal-entry':
    (phase/'SHA256SUMS').write_text('0'*64+'  ../../outside\n');index['phases'][0]=record(phase)
   elif name=='duplicate-entry':
    p=phase/'SHA256SUMS';p.write_text(p.read_text()+p.read_text().splitlines()[0]+'\n');index['phases'][0]=record(phase)
   elif name=='dot-checksum-path':
    (phase/'SHA256SUMS').write_text('0'*64+'  .\n');index['phases'][0]=record(phase)
   elif name=='symlink-input':
    (phase/'payload.bin').unlink();(phase/'payload.bin').symlink_to(repo/'README.md')
   elif name=='oversize-input':
    (phase/'payload.bin').write_bytes(b'X'*(2*1024*1024+1));sums(phase);index['phases'][0]=record(phase)
   elif name=='widened-scope':
    report=json.loads((final/'report.json').read_text());report['scopes']['all_project_blockers_closed']=True;(final/'report.json').write_text(json.dumps(report))
   elif name=='duplicate-index-phase':index['phases'].append(index['phases'][0])
   elif name=='nonzero-root-readme':(repo/'README.md').write_text('nonempty')
   elif name=='wrong-fixed-nightly':
    lock=json.loads((repo/'support/upstream-lock.json').read_text());lock['kernel']['toolchain']='fixture-wrong-toolchain';(repo/'support/upstream-lock.json').write_text(json.dumps(lock))
   (final/'phase-index.json').write_text(json.dumps(index));sums(final)
   argv=[sys.executable,'-I']+(['-O'] if optimized else [])+[str(final/'verify.py'),'--repo-root',str(repo)];argv+=['--index','.'] if name=='dot-index-path' else ['--report','.'] if name=='dot-report-path' else [];result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   rows.append({'fixture':name,'optimized':optimized,'actual_exit':result.returncode,'expected_exit':expected,'matched':result.returncode==expected and (expected==0 or result.stdout.startswith('verification failed:')),'output':result.stdout})
report={'scope':'Synthetic file/hash/path/pin/scope guard fixtures only. No Cargo, Rust compiler, guest, actual evidence phase or project acceptance was executed/read.','checks':len(rows),'all_expected':all(r['matched'] for r in rows),'cases':rows};(HERE/'fixture-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'synthetic_fixture_checks':len(rows),'all_expected':report['all_expected'],'results':str(HERE/'fixture-results.json')},indent=2));raise SystemExit(0 if report['all_expected'] else 1)
