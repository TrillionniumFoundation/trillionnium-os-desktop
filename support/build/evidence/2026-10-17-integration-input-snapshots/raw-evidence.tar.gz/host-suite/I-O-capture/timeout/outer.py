import importlib.util,json,os,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('outer_runner','/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop/support/build/osdk-integration/run.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
try:
 with runner.interruption_handlers():
  result=runner.command([sys.executable,'-I','/workspace/scratch/ae1a8cf05419/scratch/integration-input-snapshots/full-host-suite/I-O-capture/timeout/harness.py'],Path.cwd(),os.environ.copy(),Path('case.log'),float(sys.argv[1]))
except runner.RunnerInterrupted as error:
 result={'interrupted_by':error.signum}
Path('outer-result.json').write_text(json.dumps(result))
