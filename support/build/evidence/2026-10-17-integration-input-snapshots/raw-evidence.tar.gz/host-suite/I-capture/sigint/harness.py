import subprocess,sys
raise SystemExit(subprocess.call([sys.executable,'-I','/workspace/scratch/ae1a8cf05419/scratch/integration-input-snapshots/full-host-suite/I-capture/sigint/recorder-driver.py']))
