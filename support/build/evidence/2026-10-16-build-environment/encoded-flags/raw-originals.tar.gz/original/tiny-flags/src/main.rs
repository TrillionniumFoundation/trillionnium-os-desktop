#![allow(unexpected_cfgs)]
fn main() { println!("RUSTFLAGS={};ENCODED={}", cfg!(from_rustflags), cfg!(from_encoded)); }
