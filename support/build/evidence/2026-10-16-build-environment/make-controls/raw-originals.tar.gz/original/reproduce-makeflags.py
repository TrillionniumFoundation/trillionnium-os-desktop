import importlib.util,json,os,pathlib,shutil,subprocess,sys
repo=pathlib.Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop')
sp=importlib.util.spec_from_file_location('runner_tests',repo/'support/build/tests/test_kernel_runner.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
test=mod.KernelRunnerTests('test_owned_manifest_removed_after_success');test.setUp()
results=[]
try:
 root=test.root;upstream=root/'kernel/asterinas'
 shutil.copyfile(repo/'kernel/asterinas/Makefile',upstream/'Makefile')
 shutil.copyfile(repo/'support/build/minimal.mk',test.build/'minimal.mk')
 (upstream/'osdk/src').mkdir(parents=True)
 for p in ('Cargo.toml','Cargo.lock'):(upstream/'osdk'/p).write_text('# fixture\n')
 (root/'cargo-home/bin').mkdir(parents=True)
 (test.mock/'make').unlink();os.symlink('/usr/bin/make',test.mock/'make')
 test.write_tool('cargo',"#!/bin/sh\nprintf '%s\\n' \"$*\" >> \"$MOCK_PROJECT/cargo-recipe-ran.log\"\nexit 0\n")
 for i,flags in enumerate(('n','t','i','')):
  recordpath=root/'cargo-recipe-ran.log';recordpath.unlink(missing_ok=True)
  result=test.run_runner(name=f'evidence-{i}',extra={'MAKEFLAGS':flags})
  output=test.build/'out' # unused
  row={'MAKEFLAGS':flags,'argv':['bash',str(test.build/'kernel.sh'),'kernel'],'returncode':result.returncode,'cargo_calls':recordpath.read_text().splitlines() if recordpath.exists() else [],'cargo_recipe_executed':any(line.startswith('osdk build ') for line in recordpath.read_text().splitlines()) if recordpath.exists() else False,'output':result.stdout,'run_exit_code':(root/f'evidence-{i}/run-exit-code.txt').read_text()}
  results.append(row)
 pathlib.Path('/workspace/scratch/ae1a8cf05419/next9-audit/makeflags-results.json').write_text(json.dumps({'fixture':'production runner + GNU make/upstream Makefile/minimal.mk; only external inputs/tools are fixtures; no kernel compiled','gnu_make':subprocess.check_output(['/usr/bin/make','--version'],text=True).splitlines()[0],'results':results},indent=2)+'\n')
 print(json.dumps([{k:r[k] for k in ('MAKEFLAGS','returncode','cargo_recipe_executed','run_exit_code')} for r in results],indent=2))
finally:test.doCleanups()
