import hashlib,importlib.util,json,pathlib,subprocess,unittest
repo=pathlib.Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop')
out=pathlib.Path('/workspace/scratch/ae1a8cf05419/next9-audit')
sp=importlib.util.spec_from_file_location('runner_tests',repo/'support/build/tests/test_kernel_runner.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
baseline='79d7f0530f08237ab2581d70d44fe59130eced8b'
old=subprocess.check_output(['git','show',f'{baseline}:support/build/kernel.sh'],cwd=repo)
original=mod.KernelRunnerTests.setUp
def setup(self):
 original(self)
 (self.build/'kernel.sh').write_bytes(old)
mod.KernelRunnerTests.setUp=setup
names=[
 'test_inherited_dry_run_touch_and_question_flags_still_execute_real_make_recipes',
 'test_inherited_ignore_errors_does_not_mask_real_make_recipe_failure',
 'test_inherited_makefiles_are_not_read_and_normal_retry_can_build',
 'test_outer_make_state_is_recorded_and_children_establish_normal_recursion',
 'test_empty_encoded_rustflags_are_rejected_before_output_then_unset_retry',
 'test_nonempty_encoded_rustflags_are_rejected_before_output_then_unset_retry',
]
suite=unittest.TestSuite(mod.KernelRunnerTests(name) for name in names)
with (out/'baseline-red.log').open('w') as stream:
 result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
row={'baseline':baseline,'baseline_kernel_sh_sha256':hashlib.sha256(old).hexdigest(),'test_module_sha256':hashlib.sha256((repo/'support/build/tests/test_kernel_runner.py').read_bytes()).hexdigest(),'tests_run':result.testsRun,'failure_count':len(result.failures),'error_count':len(result.errors),'skipped':len(result.skipped),'expected_red':result.testsRun==6 and len(result.failures)==9 and not result.errors,'failures':[{'test':str(t),'traceback':log} for t,log in result.failures]}
(out/'baseline-red.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps({k:row[k] for k in ('tests_run','failure_count','error_count','expected_red')}))
raise SystemExit(0 if row['expected_red'] else 1)
