#!/usr/bin/env python3
"""Archive only a parent-confirmed completed next9 run; never launches tests."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import tarfile

BASE=Path(__file__).resolve().parent
WORK=BASE/'a01-next9-native'
RUN=WORK/'support/build/out/next9-ktest-01'
DEST=BASE/'trillionnium-os-desktop/support/build/evidence/2026-10-16-build-environment/kernel-tests'
HEAD='ff040c6d5afbc4e26a249022093b8090181f6176'
TREE_PREFIX='eb16c5ef'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def stable_read(path):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        before=os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise RuntimeError('not a regular file: '+str(path))
        blocks=[]
        while True:
            block=os.read(fd,1024*1024)
            if not block:
                break
            blocks.append(block)
        after=os.fstat(fd)
    finally:
        os.close(fd)
    identity=lambda value:(value.st_dev,value.st_ino,value.st_size,value.st_mtime_ns,value.st_ctime_ns)
    if identity(before)!=identity(after):
        raise RuntimeError('changed during read: '+str(path))
    return b''.join(blocks),before

def write_json(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2)+'\n')

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--parent-confirmed-outer-exit-zero',action='store_true',required=True)
    parser.add_argument('--actual-session',type=int,required=True)
    parser.add_argument('--publication-receipt',type=Path,required=True)
    args=parser.parse_args()
    invocation_path=BASE/'next9-ktest-invocation.json'
    invocation_data,_=stable_read(invocation_path)
    invocation=json.loads(invocation_data)
    if invocation.get('outer_exit_code')!=0 or invocation['source_head']!=HEAD or not invocation['source_tree'].startswith(TREE_PREFIX):
        raise RuntimeError('requires completed outer0 at fixed expected source')
    raw=[]
    for path in sorted(RUN.rglob('*')):
        if path.is_dir():
            continue
        data,_=stable_read(path)
        raw.append(('run/'+path.relative_to(RUN).as_posix(),data,str(path),'actual completed output'))
    output={name:data for name,data,*_ in raw}
    result=json.loads(output['run/result.json'])
    environment=json.loads(output['run/environment.json'])
    fixed=json.loads(output['run/source-inputs.json'])
    if not result['passed'] or environment['git_head']!=HEAD or not fixed['passed']:
        raise RuntimeError('runtime result/source checks failed')
    command_receipts=[]
    for relative in result['command_receipts']:
        record=json.loads(output['run/'+relative])
        cleanup=record['group_cleanup']
        if record['raw_exit_code']!=0 or record['exit_code']!=0 or cleanup['leader_exit_code']!=0 or not cleanup['leader_reaped'] or cleanup['external_reap_disarmed']:
            raise RuntimeError('command receipt failed: '+relative)
        command_receipts.append({'member':'run/'+relative,'sha256':sha(output['run/'+relative]),'raw_exit_code':0,'exit_code':0,'leader_reaped':True})
    actual_receipts={name for name in output if name.endswith('.command.json')}
    if len(command_receipts)!=10 or actual_receipts!={r['member'] for r in command_receipts}:
        raise RuntimeError('expected exact ten-command receipt set')
    source_hashes={**environment['build_inputs_sha256'],**{'kernel/asterinas/'+name:digest for name,digest in fixed['input_sha256'].items()}}
    input_records=[]
    for relative,expected in sorted(source_hashes.items()):
        data,_=stable_read(WORK/relative)
        if sha(data)!=expected:
            raise RuntimeError('runtime source hash changed: '+relative)
        member='inputs/'+relative
        raw.append((member,data,str(WORK/relative),'post-run source bytes matching runtime SHA'))
        input_records.append({'path':relative,'member':member,'bytes':len(data),'sha256':sha(data),'matches_runtime_hash':True})
    extra_path=WORK/'support/upstream-lock.json'
    extra_data,_=stable_read(extra_path)
    raw.append(('inputs/support/upstream-lock.json',extra_data,str(extra_path),'post-run source metadata; no separate runtime SHA'))
    console_path=BASE/'next9-ktest-console.log';console,_=stable_read(console_path)
    controller_path=BASE/'next9-real-ktest.py';controller,_=stable_read(controller_path)
    if sha(console)!=invocation['console_sha256'] or len(console)!=invocation['console_size'] or sha(controller)!=invocation['controller_sha256']:
        raise RuntimeError('observer bytes do not match invocation')
    raw.extend([('observer/invocation.json',invocation_data,str(invocation_path),'actual invocation and completion receipt'),('observer/console.log',console,str(console_path),'actual console'),('observer/controller.py',controller,str(controller_path),'actual controller')])
    publication_data,_=stable_read(args.publication_receipt)
    publication=json.loads(publication_data)
    entries=publication.get('publications',[publication])
    entry_index=next(i for i,entry in enumerate(entries) if entry['remote_commit']==HEAD)
    entry=entries[entry_index]
    if entry['tree']!=invocation['source_tree'] or not entry['remote_git_tree_parents_message_verified']:
        raise RuntimeError('publication binding failed')
    raw.append(('publication/next9-publication-receipt.json',publication_data,str(args.publication_receipt),'publisher actual Git API verification'))
    guests=[]
    capture_requests=[]
    for crate_result,crate in zip(result['crates'],['ostd','aster-core'],strict=True):
        if not crate_result['passed'] or len(crate_result['guests'])!=1:
            raise RuntimeError('expected one passed guest per crate')
        guest_result=crate_result['guests'][0]
        qemu=json.loads(output['run/'+crate+'/guests/guest-001/qemu.json'])
        serial=output['run/'+crate+'/guests/guest-001/serial.log']
        if not serial or sha(serial)!=qemu['serial_sha256'] or qemu['raw_exit_code']!=33 or qemu['timed_out']:
            raise RuntimeError('QEMU/serial failure: '+crate)
        text=re.sub(r'\x1b\[[0-9;]*m','',serial.decode(errors='replace'))
        starts=re.findall(r'test (\S+) \.\.\. ',text)
        summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) filtered out\.',text)
        declared=guest_result['declared']
        if len(starts)!=declared or len(set(starts))!=declared or summaries!=[(str(declared),'0','0')] or '[ktest runner] All crates tested.' not in text:
            raise RuntimeError('serial test count/completion mismatch: '+crate)
        skips=re.findall(r'\[skipped: ([^\]]+)\]',text)
        if len(skips)!=guest_result['soft_skipped'] or guest_result['passed']!=declared or guest_result['failed'] or guest_result['filtered']:
            raise RuntimeError('result skip/failure mismatch: '+crate)
        generated=output['run/'+crate+'/generated.Cargo.lock']
        input_lock='support/build/ktest/locks/'+crate+'.Cargo.lock'
        if sha(generated)!=source_hashes[input_lock]:
            raise RuntimeError('generated lock drift: '+crate)
        guests.append({'crate':crate,'declared_passes':declared,'failed':0,'filtered':0,'unique_test_starts':len(set(starts)),'soft_skipped':len(skips),'soft_skip_reasons':skips,'exercised_passed_lower_bound':declared-len(skips),'raw_qemu_exit':33,'timed_out':False,'serial_bytes':len(serial),'serial_sha256':sha(serial),'generated_lock_sha256':sha(generated)})
        capture_requests.append((crate,qemu['artifacts']['-kernel']))
    # Evidence directory is created only after completed-run checks pass.
    DEST.mkdir(parents=True,exist_ok=False)
    artifacts=[]
    for crate,expected in capture_requests:
        path=Path(expected['path']);data,before=stable_read(path)
        if not data.startswith(b'\x7fELF') or len(data)!=expected['size'] or sha(data)!=expected['sha256']:
            raise RuntimeError('actual recorded ELF mismatch: '+crate)
        target=DEST/'artifacts'/(crate+'.elf.gz');target.parent.mkdir(parents=True,exist_ok=True)
        temporary=target.with_name('.'+target.name+'.tmp')
        with temporary.open('xb') as stream:
            stream.write(gzip.compress(data,mtime=0));stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,target)
        if gzip.decompress(target.read_bytes())!=data:
            raise RuntimeError('gzip roundtrip failed: '+crate)
        after_data,after=stable_read(path)
        if after_data!=data or (after.st_dev,after.st_ino)!=(before.st_dev,before.st_ino):
            raise RuntimeError('ELF source changed after snapshot: '+crate)
        artifacts.append({'crate':crate,'original_path':str(path),'recorded_bytes':expected['size'],'recorded_sha256':expected['sha256'],'captured_bytes':len(data),'captured_sha256':sha(data),'retained':target.relative_to(DEST).as_posix(),'retained_bytes':target.stat().st_size,'retained_sha256':sha(target.read_bytes()),'before_identity':{'dev':before.st_dev,'ino':before.st_ino,'mtime_ns':before.st_mtime_ns,'ctime_ns':before.st_ctime_ns},'retained_fd_stable_during_read':True,'path_inode_and_bytes_match_after_read':True,'gzip_roundtrip_verified':True})
    write_json(DEST/'artifacts/manifest.json',{'classification':'Fresh snapshots from this completed invocation\u2019s actual QEMU-record kernel paths; no prior artifact substituted','artifacts':artifacts})
    print(json.dumps({'capture_confirmed':True,'artifacts':artifacts}),flush=True)
    index=[];temporary=DEST/'.raw.tar.gz.tmp'
    with temporary.open('xb') as stream:
        with gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w|') as archive:
                for name,data,origin,classification in raw:
                    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.uid=info.gid=info.mtime=0
                    archive.addfile(info,io.BytesIO(data))
                    index.append({'member':name,'bytes':len(data),'sha256':sha(data),'original_path':origin,'classification':classification})
        stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,DEST/'raw.tar.gz')
    with tarfile.open(DEST/'raw.tar.gz','r:gz') as archive:
        members=archive.getmembers()
        if len(members)!=len(index):
            raise RuntimeError('raw member count')
        for member,expected in zip(members,index,strict=True):
            data=archive.extractfile(member).read()
            if not member.isfile() or member.name!=expected['member'] or len(data)!=expected['bytes'] or sha(data)!=expected['sha256']:
                raise RuntimeError('raw member integrity: '+member.name)
    write_json(DEST/'members.json',{'archive':'raw.tar.gz','bytes':(DEST/'raw.tar.gz').stat().st_size,'sha256':sha((DEST/'raw.tar.gz').read_bytes()),'member_count':len(index),'members':index,'atomic_write_and_reopen_verified':True})
    output.update({name:data for name,data,*_ in raw})
    readable_members=['run/result.json','run/environment.json','run/source-inputs.json','run/commands.json','run/ostd/result.json','run/aster-core/result.json','run/ostd/guests/guest-001/qemu.json','run/aster-core/guests/guest-001/qemu.json','run/ostd/generated.Cargo.lock','run/aster-core/generated.Cargo.lock','observer/invocation.json']
    readable=[]
    for member in readable_members:
        path=DEST/'readable'/member;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(output[member])
        readable.append({'path':path.relative_to(DEST).as_posix(),'raw_member':member,'bytes':len(output[member]),'sha256':sha(output[member])})
    write_json(DEST/'readable-index.json',readable)
    (DEST/'publication-receipt.json').write_bytes(publication_data)
    source_binding={'runtime_commit':HEAD,'runtime_tree':invocation['source_tree'],'publication_receipt':'publication-receipt.json','publication_entry_index':entry_index,'publication_sha256':sha(publication_data),'runtime_hash_bound_inputs':input_records,'runner_sha256':result['runner_sha256'],'runner_matches_runtime_input':result['runner_sha256']==source_hashes['support/build/ktest/run.py'],'fixed_source_verification':fixed,'runtime_status':environment['git_status'],'additional_upstream_lock_snapshot':{'raw_member':'inputs/support/upstream-lock.json','sha256':sha(extra_data),'classification':'Post-run metadata only; no separate runtime SHA'},'note':'No untracked generated kernel/OSDK.toml bytes copied or read.'}
    if not source_binding['runner_matches_runtime_input']:
        raise RuntimeError('runner SHA mismatch')
    write_json(DEST/'source-binding.json',source_binding)
    counts={'passed':True,'guests':guests,'declared_passes':sum(g['declared_passes'] for g in guests),'soft_skipped':sum(g['soft_skipped'] for g in guests),'exercised_passed_lower_bound':sum(g['exercised_passed_lower_bound'] for g in guests),'outer_exit_code':0,'raw_qemu_exits':[33,33],'command_receipts':command_receipts}
    write_json(DEST/'counts.json',counts)
    write_json(DEST/'outer-completion.posthoc.json',{'classification':'Parent-observed actual tool completion supplement; actual controller invocation independently records child exit','parent_reported_actual_session':args.actual_session,'actual_exit_code':0,'actual_invocation':'readable/observer/invocation.json','packager_did_not_rerun_test':True})
    report={'passed':True,'runtime_commit':HEAD,'runtime_tree':invocation['source_tree'],'counts':counts,'fixed_toolchain':environment['toolchain'],'target_cache_reused':True,'empty_target_claim':False,'target_cache_note':'This ktest invocation reused this phase\u2019s normal build/boot target cache; it was not an empty-target build.','counts_file':'counts.json','source_binding':'source-binding.json','environment':'readable/run/environment.json','invocation':'readable/observer/invocation.json','raw_archive':'raw.tar.gz','raw_members':'members.json','artifacts':'artifacts/manifest.json','not_claimed':['A06 quota/native HOS2 control acceptance','Skipped VMX/EPT paths exercised','Clean empty-target build for this ktest run','Bit-reproducibility against earlier kernels'],'no_new_tests_or_git_or_cargo_or_vm_during_packaging':True}
    write_json(DEST/'report.json',report)
    write_json(DEST/'archive-validation.json',{'raw_member_count':len(index),'all_raw_names_types_sizes_sha256_verified':True,'atomic_raw_install_and_reopen':True,'two_actual_elf_snapshots_match_record_before_after_and_gzip_roundtrip':True,'two_serial_sha256_match_qemu_records':True,'exact_ten_receipt_set_all_raw_effective_leader_exit_zero_and_reaped':True,'generated_lock_input_equality_count':2,'runtime_hash_bound_source_inputs':len(input_records),'readable_copies':len(readable),'scope':'Packaging/integrity checks only; no new kernel/test/VM/Cargo/Git invocation.'})
    (DEST/'README.md').write_text(f'''# Full upstream kernel tests\n\nActual source [`{HEAD[:8]}`](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/commit/{HEAD}), tree `{invocation['source_tree']}`, completed the public kernel-test entry with outer exit **0**. [Source binding](source-binding.json), [publisher receipt](publication-receipt.json), [invocation](readable/observer/invocation.json), [environment](readable/run/environment.json), and [outer-completion supplement](outer-completion.posthoc.json) retain their original evidence.\n\n| Actual guest | Reported passes | Soft skips | Exercised lower bound | Raw QEMU exit |\n| --- | ---: | ---: | ---: | ---: |\n| OSTD | {guests[0]['declared_passes']} | {guests[0]['soft_skipped']} | {guests[0]['exercised_passed_lower_bound']} | 33 |\n| aster-core | {guests[1]['declared_passes']} | {guests[1]['soft_skipped']} | {guests[1]['exercised_passed_lower_bound']} | 33 |\n\nBoth guests had zero failures and filters, no timeout, unique test starts matching the upstream summary, nonempty raw serial matching its QEMU-record hash, and the final upstream completion marker. Soft skips are counted separately in [counts](counts.json); TCG cannot establish skipped VMX/EPT hardware paths. Expected-panic upstream tests remain valid. No A06 quota or native HOS2 control acceptance is claimed.\n\n**This ktest run reused the normal build/boot target cache from this phase. It was not an empty-target build.** Runtime used fixed `nightly-2026-07-21`, offline dependencies and two Cargo jobs. OSDK was installed from the fixed downstream source with `--locked`; both generated test locks match the selected fixed input locks. Source verifier output remains original, including its intentional downstream `pristine:false` status, without claiming full-tree pristine verification. Untracked generated manifest status is preserved as a fact; its contents were not read, copied, deleted or changed for packaging.\n\nReplay the project entry `python3 -I support/build/ktest/run.py --output <fresh-owned-output>` using the recorded invocation environment. [Raw archive](raw.tar.gz) retains all completed output files, exact ten subprocess command receipts, the real controller/console/entry receipt, publisher proof, runtime-hash-matching source/lock inputs and post-run upstream-lock metadata. [Member index](members.json) and [readable index](readable-index.json) provide stable relative archive locations; absolute original paths remain historical facts.\n\n[Artifact manifest](artifacts/manifest.json), [OSTD ELF gzip](artifacts/ostd.elf.gz) and [aster-core ELF gzip](artifacts/aster-core.elf.gz) retain fresh snapshots from this invocation\u2019s actual QEMU-record `-kernel` paths. Retained-FD fstat identity, recorded size/SHA, source bytes/inode after capture, and gzip decompression were checked. No earlier artifact was substituted, and no target tree or tool binary is copied.\n\nPackaging wrote only this evidence directory and started no new Cargo, VM, Git command, kernel build or test. [Archive validation](archive-validation.json) records integrity checks. [SHA256SUMS](SHA256SUMS) is generated after final review and covers every other evidence file.\n''')
    print(json.dumps({'packaged':True,'destination':str(DEST),'raw_members':len(index),'raw_sha256':sha((DEST/'raw.tar.gz').read_bytes()),'counts':counts,'pending':'independent review and final manifest freeze'}),flush=True)

if __name__=='__main__':
    main()
