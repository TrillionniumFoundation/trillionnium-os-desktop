#!/usr/bin/env python3
"""Retain initial missing-component failure and add exact nightly Clippy retry."""
import datetime,hashlib,json,os,pathlib,subprocess,time
out=pathlib.Path(__file__).resolve().parent
snap=out/'source'
def sha(data):return hashlib.sha256(data).hexdigest()
def write(name,obj):(out/name).write_text(json.dumps(obj,indent=2)+'\n')
before=json.loads((out/'environment.json').read_text())
env=os.environ.copy()
for k,v in before['selected_env'].items():
    if v=='<unset>':env.pop(k,None)
    else:env[k]=v
component=[str(pathlib.Path(env['CARGO_HOME'])/'bin/rustup'),'component','add','clippy','--toolchain','nightly-2026-07-21']
versions={}
for key,argv in [('clippy',['cargo','clippy','--version']),('installed_components',[str(pathlib.Path(env['CARGO_HOME'])/'bin/rustup'),'component','list','--toolchain','nightly-2026-07-21','--installed'])]:
    p=subprocess.run(argv,cwd=snap,env=env,capture_output=True,text=True)
    versions[key]=dict(argv=argv,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
argv=['cargo','clippy','--locked','--manifest-path','libs/os-abi/Cargo.toml','--all-targets','--','-D','warnings']
start=time.time();log=out/'cargo-clippy-after-install.log'
with log.open('wb') as f:p=subprocess.run(argv,cwd=snap,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
write('clippy-after-install.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),dependency_install=dict(argv=component,returncode=0,actual_tool_session_id=92731,actual_session_exit=0,log='clippy-install.log',log_sha256=sha((out/'clippy-install.log').read_bytes()),toolchain_replaced=False),versions=versions,clippy=dict(argv=argv,cwd=str(snap),returncode=p.returncode,elapsed_seconds=time.time()-start,log=log.name,log_sha256=sha(log.read_bytes())),initial_missing_component_failure_retained=True))
inputs=json.loads((out/'source-inputs.json').read_text())
changed=[r['path'] for r in inputs['files'] if sha((snap/r['path']).read_bytes())!=r['sha256']]
lock=(snap/'libs/os-abi/Cargo.lock').read_bytes()
write('source-after-clippy.json',dict(tracked_input_count=len(inputs['files']),changed=changed,all_original_source_inputs_unchanged=not changed,seed_lock_unchanged=lock==(out/'Cargo.lock').read_bytes(),lock_after_sha256=sha(lock)))
print(json.dumps(dict(clippy_returncode=p.returncode,changed=changed,lock_sha256=sha(lock))))
raise SystemExit(p.returncode)
