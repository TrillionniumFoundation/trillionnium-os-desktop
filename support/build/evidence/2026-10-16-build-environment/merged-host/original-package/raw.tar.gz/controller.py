#!/usr/bin/env python3
"""Actual exact-commit host checks; writes only new next9-main-host scratch."""
import datetime, gzip, hashlib, io, json, os, pathlib, platform, re, shutil, subprocess, sys, tarfile, time

BASE=pathlib.Path('/workspace/scratch/ae1a8cf05419')
REPO=BASE/'trillionnium-os-desktop'
OUT=BASE/'next9-main-host'
SOURCE='b1a15d9afc456346410af658d2164ee5fa085656'
DIRS=['libs/os-abi','tests/abi','tests/golden']
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO)
def write(name,obj):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n')

OUT.mkdir()
(OUT/'controller.py').write_bytes(pathlib.Path(__file__).read_bytes())
archive=git('archive','--format=tar',SOURCE,*DIRS)
(OUT/'source.tar.gz').write_bytes(gzip.compress(archive,mtime=0))
snap=OUT/'source';snap.mkdir()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:') as tar: tar.extractall(snap,filter='data')
files=[]
for entry in git('ls-tree','-r','-z',SOURCE,*DIRS).split(b'\0'):
    if not entry: continue
    head,path=entry.split(b'\t');mode,kind,blob=head.decode().split();path=path.decode()
    data=(snap/path).read_bytes()
    if git('hash-object','--stdin',) if False else False: pass
    blob_actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert blob_actual==blob
    files.append(dict(path=path,mode=mode,git_blob=blob,bytes=len(data),sha256=sha(data)))
manifest=git('show',SOURCE+':libs/os-abi/Cargo.toml')
historical_manifest=json.loads(git('show',SOURCE+':support/build/evidence/2026-10-16-clean-repeatability-main-sync/host/source-inputs.json'))
historical_row=next(row for row in historical_manifest['files'] if row['path']=='libs/os-abi/Cargo.toml')
assert sha(manifest)==historical_row['sha256']
lock=git('show',SOURCE+':support/build/evidence/2026-10-16-clean-repeatability-main-sync/host/Cargo.lock')
assert len(lock)==155 and sha(lock)=='95c2616d9e61cbbb848888797f71d434d59744612fbaad5fa558754488cbffbd'
(snap/'libs/os-abi/Cargo.lock').write_bytes(lock)
(OUT/'Cargo.lock').write_bytes(lock)
write('source-inputs.json',dict(source_commit=SOURCE,tree=git('rev-parse',SOURCE+'^{tree}').decode().strip(),ordered_parents=git('show','-s','--format=%P',SOURCE).decode().strip().split(),files=files,source_archive_sha256=sha((OUT/'source.tar.gz').read_bytes()),seed_lock=dict(origin='Git '+SOURCE+':support/build/evidence/2026-10-16-clean-repeatability-main-sync/host/Cargo.lock',sha256=sha(lock),bytes=len(lock),manifest_unchanged_from_recorded_source=True),no_live_working_tree_inputs=True))

env=os.environ.copy()
env.update(CARGO_HOME=str(BASE/'toolchains/cargo'),RUSTUP_HOME=str(BASE/'toolchains/rustup'),RUSTUP_TOOLCHAIN='nightly-2026-07-21',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(OUT/'target'),CARGO_TERM_COLOR='never',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(OUT/'tmp'),TZ='UTC',LC_ALL='C')
env['PATH']=str(BASE/'toolchains/cargo/bin')+os.pathsep+env['PATH']
env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
(OUT/'tmp').mkdir()
versions={}
for label,argv in [('rustc',['rustc','-Vv']),('cargo',['cargo','-V']),('clippy',['cargo','clippy','-V']),('rustfmt',['cargo','fmt','--version']),('python',['python3','-VV'])]:
    p=subprocess.run(argv,env=env,cwd=snap,capture_output=True,text=True)
    versions[label]=dict(argv=argv,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
write('environment.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),uname=platform.uname()._asdict(),uid=os.getuid(),cwd=str(snap),selected_env={k:env.get(k,'<unset>') for k in ['CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','CARGO_TARGET_DIR','CARGO_TERM_COLOR','PYTHONDONTWRITEBYTECODE','TMPDIR','TZ','LC_ALL','PATH','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']},versions=versions,target_existed_before=False))
commands=[
 ('cargo-test',['cargo','test','--locked','--manifest-path','libs/os-abi/Cargo.toml']),
 ('cargo-clippy',['cargo','clippy','--locked','--manifest-path','libs/os-abi/Cargo.toml','--all-targets','--','-D','warnings']),
 ('cargo-fmt',['cargo','fmt','--manifest-path','libs/os-abi/Cargo.toml','--','--check']),
 ('python-abi',['python3','-I','-m','unittest','discover','-s','tests/abi','-p','test_*.py','-v']),
 ('golden-hos2',['python3','-I','tests/golden/generate_hos2.py','--check']),
 ('golden-transport32',['python3','-I','tests/golden/generate_transport32.py','--check']),
]
results=[]
for label,argv in commands:
    start=time.time();log=OUT/(label+'.log')
    print('START',label,flush=True)
    with log.open('wb') as f: p=subprocess.run(argv,cwd=snap,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    data=log.read_bytes();text=data.decode(errors='replace')
    row=dict(name=label,argv=argv,cwd=str(snap),returncode=p.returncode,elapsed_seconds=time.time()-start,log=log.name,log_sha256=sha(data),log_bytes=len(data),rust_summaries=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text),python_summaries=re.findall(r'Ran (\d+) tests in [^\n]+\n\n([^\n]+)',text))
    results.append(row);write('commands.json',results)
    print('END',label,p.returncode,round(time.time()-start,3),row['rust_summaries'] or row['python_summaries'],flush=True)
changed=[]
for row in files:
    data=(snap/row['path']).read_bytes()
    if sha(data)!=row['sha256']:changed.append(row['path'])
lock_after=(snap/'libs/os-abi/Cargo.lock').read_bytes()
write('source-after.json',dict(tracked_input_count=len(files),changed=changed,all_original_source_inputs_unchanged=not changed,seed_lock_unchanged=lock==lock_after,lock_after_sha256=sha(lock_after)))
success=all(row['returncode']==0 for row in results) and not changed and lock==lock_after
write('report.json',dict(scope='Actual host Rust/Python ABI verification only; no guest kernel ioctl or authorization validation',source_commit=SOURCE,commands=results,success=success,source_inputs_unchanged=not changed,seed_lock_unchanged=lock==lock_after))
sys.exit(0 if success else 1)
