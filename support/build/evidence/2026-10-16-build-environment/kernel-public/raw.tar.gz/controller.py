#!/usr/bin/env python3
"""Actual fixed-profile source build and boot under inherited make controls."""
from datetime import datetime, timezone
import gzip, hashlib, json, os, pwd, shutil, subprocess, sys
from pathlib import Path
s=Path(__file__).resolve().parent
work=s/'a01-next9-native'; out=s/'next9-native'
source=sys.argv[1]; target=work/'kernel/asterinas/target'
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda p,o:p.write_text(json.dumps(o,indent=2)+'\n')
identity=lambda st:{k:getattr(st,k) for k in ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')}
assert not out.exists() and not target.exists() and not target.is_symlink()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==source
subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=work,check=True)
out.mkdir(mode=0o700)
shutil.copyfile(__file__,out/'controller.py')
injected=out/'inherited.mk';injected.write_text('$(error A01_NEXT9_INHERITED_MAKEFILE_WAS_READ)\n')
env=dict(os.environ)
for k in list(env):
 if k.startswith('A01_') or k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS'):
  env.pop(k,None)
selected={'CARGO_HOME':str(s/'toolchains/cargo'),'RUSTUP_HOME':str(s/'toolchains/rustup'),
 'RUSTUP_TOOLCHAIN':'nightly-2026-07-21','CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'2',
 'CARGO_TARGET_DIR':str(target),'VDSO_LIBRARY_DIR':str(s/'linux-vdso'),'A01_QEMU_TIMEOUT':'300',
 'ASTER_BUILD_TIMESTAMP':'Thu Jan  1 00:00:00 UTC 1970','SOURCE_DATE_EPOCH':'0','TZ':'UTC','LC_ALL':'C',
 'MAKEFLAGS':'nt','MFLAGS':'-n','GNUMAKEFLAGS':'--ignore-errors','MAKEFILES':str(injected),
 'MAKEOVERRIDES':'TARGET_ARCH=riscv64','MAKELEVEL':'73'}
env.update(selected);env['PATH']=selected['CARGO_HOME']+'/bin:'+env['PATH']
summary={'kind':'actual_empty_target_source_build_and_native_boot_with_inherited_make_controls',
 'source_commit':source,'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=work,text=True).strip(),
 'worktree':str(work),'environment':selected,'explicitly_unset':['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS'],
 'controller_sha256':sha(Path(__file__).read_bytes()),'started_utc':datetime.now(timezone.utc).isoformat(),
 'host':{'nodename':os.uname().nodename,'effective_uid':os.geteuid(),'username':pwd.getpwuid(os.geteuid()).pw_name},
 'guard_calls':[],'runs':[],'cross_path_or_host_reproducibility_claimed':False}
write(out/'result.json',summary)
# The same actual kernel command/output must be available after unsetting flags.
run_build=work/'support/build/out/next9-kernel'
for i,value in enumerate(('', '--cfg\x1fnot_allowed')):
 argv=['support/build/kernel.sh','kernel'];ge=dict(env,A01_RUN_DIR=str(run_build),CARGO_ENCODED_RUSTFLAGS=value)
 result=subprocess.run(argv,cwd=work,env=ge,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=out/f'guard-{i}.log';log.write_bytes(result.stdout)
 record={'argv':argv,'encoded_value':value,'exit':result.returncode,'log':log.name,
  'log_sha256':sha(result.stdout),'output_absent_after':not run_build.exists(),
  'workspace_lock_absent_after':not (work/'support/build/out-kernel.lock').exists(),
  'target_absent_after':not target.exists()}
 summary['guard_calls'].append(record);write(out/'result.json',summary)
 assert result.returncode==2 and b'unset CARGO_ENCODED_RUSTFLAGS' in result.stdout and all(record[k] for k in ('output_absent_after','workspace_lock_absent_after','target_absent_after'))
for kind in ('kernel','run_kernel'):
 run=run_build if kind=='kernel' else work/'support/build/out/next9-run'
 directory=out/kind;directory.mkdir()
 entry={'target':kind,'argv':['support/build/kernel.sh',kind],'run_output':str(run),
  'target_absent_before_launch':not target.exists(),'target_cache_reused':target.exists(),
  'started_utc':datetime.now(timezone.utc).isoformat(),'outer_exit':None}
 write(directory/'invocation.json',entry)
 print(json.dumps({'starting':kind,'source':source,'target_absent':entry['target_absent_before_launch']}),flush=True)
 with (directory/'console.log').open('wb') as log:
  p=subprocess.Popen(entry['argv'],cwd=work,env=dict(env,A01_RUN_DIR=str(run)),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  entry['entry_pid']=p.pid;write(directory/'invocation.json',entry)
  for line in p.stdout:
   log.write(line);log.flush()
   if any(x in line for x in (b'Compiling ',b'Finished ',b'PASS:',b'error:',b'A01_KERNEL_SUPERVISOR')):
    print(kind+': '+line.decode(errors='replace').rstrip(),flush=True)
  code=p.wait()
 entry.update(outer_exit=code,completed_utc=datetime.now(timezone.utc).isoformat())
 console=(directory/'console.log').read_bytes()
 entry.update(console_bytes=len(console),console_sha256=sha(console),compiling_lines=console.count(b'Compiling '))
 if run.exists():shutil.copytree(run,directory/'run')
 summary['runs'].append(entry);write(directory/'invocation.json',entry);write(out/'result.json',summary)
 if code!=0:raise SystemExit(code if code>0 else 128-code)
 metadata=(directory/'run/environment.log').read_text()
 for name in ('MAKEFLAGS','MFLAGS','GNUMAKEFLAGS','MAKEFILES','MAKEOVERRIDES','MAKELEVEL'):
  assert name+'_INHERITED=' in metadata and name+'_EFFECTIVE=<unset>' in metadata,name
 assert (directory/'run/manifest-cleanup-exit-code.txt').read_text().strip()=='0'
 assert json.loads((directory/'run/manifest-cleanup.json').read_text())['outcome']=='owned_removed'
 if kind=='run_kernel':
  q=json.loads((directory/'run/qemu.json').read_text());assert q['raw_exit_code']==33 and not q['timed_out']
  artifact=q['artifacts']['-kernel'];rawpath=Path(artifact['path'])
 else:
  assert entry['target_absent_before_launch'] and entry['compiling_lines']>0
  rawpath=target/'osdk/asterinas/asterinas-osdk-bin.elf';artifact=None
 with rawpath.open('rb') as f:
  before=identity(os.fstat(f.fileno()));raw=f.read();after=identity(os.fstat(f.fileno()))
 assert before==after and len(raw)==before['st_size']
 if artifact:assert len(raw)==artifact['size'] and sha(raw)==artifact['sha256']
 compressed=gzip.compress(raw,mtime=0);(directory/'kernel.elf.gz').write_bytes(compressed)
 assert gzip.decompress(compressed)==raw
 entry.update(kernel_sha256=sha(raw),kernel_bytes=len(raw),kernel_gzip_sha256=sha(compressed),kernel_read_identity=before)
 if kind=='run_kernel':
  serial=(directory/'run/serial.log').read_bytes();initrd=(directory/'run/initramfs.cpio.gz').read_bytes()
  assert sha(serial)==q['serial_sha256'] and sha(initrd)==q['artifacts']['-initrd']['sha256']
  entry.update(raw_qemu_exit=33,serial_sha256=sha(serial),initramfs_sha256=sha(initrd))
 entry['git_status_after']=subprocess.check_output(['git','status','--short'],cwd=work,text=True)
 write(directory/'invocation.json',entry);summary['runs'][-1]=entry;write(out/'result.json',summary)
 print(json.dumps({'completed':kind,'outer_exit':code,'kernel_sha256':sha(raw),'qemu':entry.get('raw_qemu_exit')}),flush=True)
summary.update(passed=True,completed_utc=datetime.now(timezone.utc).isoformat(),real_qemu_guests=1,
 empty_target_kernel_compilation_observed=True,make_controls_ignored_and_recorded=True,
 raw_qemu_exits=[33],normal_build_and_boot_elf_equal=summary['runs'][0]['kernel_sha256']==summary['runs'][1]['kernel_sha256'])
write(out/'result.json',summary)
print(json.dumps({'passed':True,'source':source,'real_qemu_guests':1,'raw_qemu_exit':33}),flush=True)
