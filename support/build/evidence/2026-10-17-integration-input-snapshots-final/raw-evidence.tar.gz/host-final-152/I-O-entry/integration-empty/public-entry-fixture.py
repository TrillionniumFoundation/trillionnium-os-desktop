import importlib.util,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('entry_fixture','/workspace/scratch/ae1a8cf05419/scratch/integration-input-snapshots/full-host-suite-final-alias/I-O-entry/integration-empty/fixture-project/support/build/osdk-integration/run.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def host_run(args,here,project,upstream,output):
 Path('/workspace/scratch/ae1a8cf05419/scratch/integration-input-snapshots/full-host-suite-final-alias/I-O-entry/integration-empty/work-started').write_text('host run_locked fixture, no Cargo or VM\n')
 (output/'host-fixture.json').write_text('{"host_fixture": true}\n')
 return 0
module.run_locked=host_run
sys.argv=['/workspace/scratch/ae1a8cf05419/scratch/integration-input-snapshots/full-host-suite-final-alias/I-O-entry/integration-empty/fixture-project/support/build/osdk-integration/run.py',*sys.argv[1:]]
raise SystemExit(module.main())
