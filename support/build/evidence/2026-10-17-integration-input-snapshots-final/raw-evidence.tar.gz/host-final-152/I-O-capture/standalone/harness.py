import subprocess,sys
raise SystemExit(subprocess.call([sys.executable,'-I','/workspace/scratch/ae1a8cf05419/scratch/integration-input-snapshots/full-host-suite-final-alias/I-O-capture/standalone/recorder-driver.py']))
