import hashlib,importlib.util,json,sys,types
from pathlib import Path
spec=importlib.util.spec_from_file_location('debug_fixture','/workspace/scratch/ae1a8cf05419/debug-sdk-audit/after-I/private-receipt-mismatch/project/support/build/debug/run.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
root=Path('/workspace/scratch/ae1a8cf05419/debug-sdk-audit/after-I/private-receipt-mismatch');binary=Path('/workspace/scratch/ae1a8cf05419/debug-sdk-audit/after-I/private-receipt-mismatch/debug-output/boot/osdk/bin/cargo-osdk')
# No compiler, SDK, debugger, nm or guest process executes.
class HostSession:
 def __init__(self,command,**kwargs):
  self.process=types.SimpleNamespace(pid=42);self.reaped=False;self.external_reap=False
  with (root/'invocations.jsonl').open('a') as out: out.write(json.dumps(command)+'\n')
  if any(str(value).endswith('/kernel.sh') for value in command):
   if True:
    binary.parent.mkdir(parents=True);binary.write_bytes(b'private-sdk-from-this-debug-build');binary.chmod(0o500)
    digest=chr(48)*64
    (binary.parent.parent/'cargo-osdk.sha256').write_text(digest+'  '+str(binary)+'\n')
 def wait(self,*args): self.reaped=True;return 0
 def stop(self): self.reaped=True;return 0
module.OwnedSession=HostSession
module.shutil.which=lambda name: sys.executable
module.subprocess.check_output=lambda *args,**kwargs: 'host-fixture\n'
module.wait_for_qemu=lambda *args: {'host_fixture':True}
module.entry_address=lambda *args:4096
module.bind_entry_artifacts=lambda *args:{'symbol_artifact':{'host_fixture':True},'expected_bytes':'00'*32}
module.accept_gdb=lambda *args:{'host_fixture':True}
module.accept_boot=lambda *args:{'host_fixture':True}
sys.argv=['/workspace/scratch/ae1a8cf05419/debug-sdk-audit/after-I/private-receipt-mismatch/project/support/build/debug/run.py','--output','/workspace/scratch/ae1a8cf05419/debug-sdk-audit/after-I/private-receipt-mismatch/debug-output']
raise SystemExit(module.main())
