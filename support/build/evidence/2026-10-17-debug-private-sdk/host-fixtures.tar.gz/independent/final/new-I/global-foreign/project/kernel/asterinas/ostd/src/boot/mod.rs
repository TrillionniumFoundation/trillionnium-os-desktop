explicit debug host fixture, not kernel source or ELF
