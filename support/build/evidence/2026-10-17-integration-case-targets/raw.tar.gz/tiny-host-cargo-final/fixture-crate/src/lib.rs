#![no_std]
pub fn answer() -> u8 { 42 }
