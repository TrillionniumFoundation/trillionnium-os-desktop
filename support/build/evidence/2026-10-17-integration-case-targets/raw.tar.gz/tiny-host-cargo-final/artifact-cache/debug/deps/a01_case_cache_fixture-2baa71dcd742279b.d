/workspace/scratch/ae1a8cf05419/integration-case-target/tiny-host-cargo-final/case-1/target/debug/deps/a01_case_cache_fixture-2baa71dcd742279b.d: src/lib.rs

/workspace/scratch/ae1a8cf05419/integration-case-target/tiny-host-cargo-final/case-1/target/debug/deps/liba01_case_cache_fixture-2baa71dcd742279b.rlib: src/lib.rs

/workspace/scratch/ae1a8cf05419/integration-case-target/tiny-host-cargo-final/case-1/target/debug/deps/liba01_case_cache_fixture-2baa71dcd742279b.rmeta: src/lib.rs

src/lib.rs:
