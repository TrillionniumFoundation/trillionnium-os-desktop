#![no_std]
#[ostd::main]
fn main() -> ! { loop {} }
