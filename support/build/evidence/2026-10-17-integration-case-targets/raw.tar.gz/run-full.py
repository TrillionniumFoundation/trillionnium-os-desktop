#!/usr/bin/env python3
import datetime,hashlib,json,os,pathlib,subprocess,sys
REPO=pathlib.Path("/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop")
ROOT=pathlib.Path(__file__).resolve().parent/(sys.argv[1] if len(sys.argv)>1 else "green-full");ROOT.mkdir(exist_ok=False)
HERE=REPO/"support/build/osdk-integration"
def hashes(): return {str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*sorted(HERE.glob("*.py")),HERE/"README.md",HERE.parent/"record-qemu.py"]}
before=hashes();env=os.environ.copy()
prefix="/workspace/scratch/ae1a8cf05419/native-tools/root"
env["PATH"]=prefix+"/usr/bin:"+prefix+"/usr/lib/llvm-18/bin:"+env["PATH"]
env["LD_LIBRARY_PATH"]=prefix+"/usr/lib/x86_64-linux-gnu:"+prefix+"/lib/x86_64-linux-gnu:"+prefix+"/usr/lib/llvm-18/lib"
env["A01_GDB_REAL"]=prefix+"/usr/bin/gdb"
for mode,options in (("I",["-I"]),("IO",["-I","-O"])):
 out=ROOT/mode;out.mkdir()
 for name,folder in (("A01_INTEGRATION_PRIVATE_OUT","private-fixtures"),("A01_CAPTURE_LIFECYCLE_OUT","capture-fixtures"),("A01_CASE_TARGET_OUT","case-target-fixtures")): env[name]=str(out/folder)
 cmd=[sys.executable,*options,"-m","unittest","discover","-s",str(HERE),"-p","test_*.py","-v"]
 rec={"argv":cmd,"cwd":str(REPO),"environment":{k:env.get(k) for k in ("PATH","LD_LIBRARY_PATH","A01_GDB_REAL","A01_INTEGRATION_PRIVATE_OUT","A01_CAPTURE_LIFECYCLE_OUT","A01_CASE_TARGET_OUT","CARGO_ENCODED_RUSTFLAGS")},"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"sources_before":before,"controller_sha256":hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
 with (out/"console.log").open("wb") as f:r=subprocess.run(cmd,cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec.update(exit=r.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources_after=hashes(),source_stable=hashes()==before)
 (out/"invocation.json").write_text(json.dumps(rec,indent=2)+"\n")
 print(json.dumps({"mode":mode,"exit":r.returncode,"source_stable":rec["source_stable"]}),flush=True)
 if r.returncode: raise SystemExit(r.returncode)
assert hashes()==before

