#!/usr/bin/env python3
import datetime,hashlib,importlib.util,json,os,pathlib,subprocess,sys
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent/(sys.argv[1] if len(sys.argv)>1 else "tiny-host-cargo");ROOT.mkdir(exist_ok=False)
SOURCE=pathlib.Path("/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop/support/build/osdk-integration/run.py")
spec=importlib.util.spec_from_file_location("production_case_targets",SOURCE);runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
cache=ROOT/"artifact-cache";cache.mkdir()
crate=ROOT/"fixture-crate";(crate/"src").mkdir(parents=True)
(crate/"Cargo.toml").write_text('[workspace]\n[package]\nname="a01-case-cache-fixture"\nversion="0.0.0"\nedition="2024"\n')
(crate/"src/lib.rs").write_text('#![no_std]\npub fn answer() -> u8 { 42 }\n')
tool=pathlib.Path("/workspace/scratch/ae1a8cf05419/toolchains/rustup/toolchains/nightly-2026-07-21-x86_64-unknown-linux-gnu/bin")
env=os.environ.copy();env.update(CARGO_HOME="/workspace/scratch/ae1a8cf05419/toolchains/cargo",RUSTUP_HOME="/workspace/scratch/ae1a8cf05419/toolchains/rustup",RUSTUP_TOOLCHAIN="nightly-2026-07-21",RUSTC=str(tool/"rustc"),RUSTDOC=str(tool/"rustdoc"),CARGO_BUILD_JOBS="2",CARGO_NET_OFFLINE="true")
env["PATH"]=str(tool)+os.pathsep+env["PATH"]
records=[]
def call(label,args,e):
 cmd=[str(tool/"cargo"),*args];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(cmd,cwd=crate,env=e,capture_output=True,timeout=60)
 (ROOT/(label+".stdout")).write_bytes(p.stdout);(ROOT/(label+".stderr")).write_bytes(p.stderr)
 r={"argv":cmd,"cwd":str(crate),"started":started,"ended":datetime.datetime.now(datetime.timezone.utc).isoformat(),"exit":p.returncode,"CARGO_TARGET_DIR":e.get("CARGO_TARGET_DIR")}
 (ROOT/(label+".command.json")).write_text(json.dumps(r,indent=2)+"\n");records.append(r)
 assert p.returncode==0,(label,p.stderr.decode())
 return p.stdout
call("lock",["generate-lockfile","--offline"],env)
for number in (1,2):
 case=ROOT/("case-"+str(number));case.mkdir()
 target,profile=runner.create_case_target(cache,case)
 e=env.copy();e["CARGO_TARGET_DIR"]=str(target)
 meta=json.loads(call(str(number)+"-metadata",["metadata","--offline","--no-deps","--format-version=1"],e))
 assert pathlib.Path(meta["target_directory"])==target
 raw=call(str(number)+"-build",["build","--offline","--locked","--message-format=json"],e)
 messages=[json.loads(line) for line in raw.splitlines() if line.startswith(b"{")]
 artifacts=[x for x in messages if x.get("reason")=="compiler-artifact"]
 assert len(artifacts)==1
 if number==2: assert artifacts[0]["fresh"] is True,artifacts
 (case/"verification.json").write_text(json.dumps({"profile":profile,"metadata_target":meta["target_directory"],"compiler_artifact":artifacts[0]},indent=2)+"\n")
result={"passed":True,"source_sha256":hashlib.sha256(SOURCE.read_bytes()).hexdigest(),"cargo_sha256":hashlib.sha256((tool/"cargo").read_bytes()).hexdigest(),"rustc_sha256":hashlib.sha256((tool/"rustc").read_bytes()).hexdigest(),"commands":records,"host_cargo_build_invocations":2,"second_build_fresh":True,"kernel_builds":0,"VM_runs":0,"environment":{k:env.get(k) for k in ("PATH","CARGO_HOME","RUSTUP_HOME","RUSTUP_TOOLCHAIN","RUSTC","RUSTDOC","CARGO_BUILD_JOBS","CARGO_NET_OFFLINE","RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS","RUSTC_WRAPPER")}}
(ROOT/"result.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result))

