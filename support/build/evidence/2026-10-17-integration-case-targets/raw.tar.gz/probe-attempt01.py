#!/usr/bin/env python3
import datetime,hashlib,json,os,pathlib,shutil,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parent
RUN=ROOT/"actual-sdk-probe";RUN.mkdir(exist_ok=False)
SDK=pathlib.Path("/workspace/scratch/ae1a8cf05419/native-cloud/integration-retry/target/debug/cargo-osdk")
REAL=pathlib.Path("/workspace/scratch/ae1a8cf05419/toolchains/rustup/toolchains/nightly-2026-07-21-x86_64-unknown-linux-gnu/bin/cargo")
assert hashlib.sha256(SDK.read_bytes()).hexdigest()=="9338c5166093eb8133a0f6999e82ba70fe31f71ed26d3902b46887d194e122d9"
binary=RUN/"bin";binary.mkdir();(binary/"cargo").symlink_to(ROOT/"fake-cargo.py")
def project(name):
 p=RUN/name/"myos";(p/"src").mkdir(parents=True)
 (p/"Cargo.toml").write_text('[workspace]\n[package]\nname="myos"\nversion="0.1.0"\nedition="2024"\n')
 (p/"src/lib.rs").write_text('#![no_std]\n#[ostd::main]\nfn main() -> ! { loop {} }\n')
 (p/"OSDK.toml").write_text('project_type="kernel"\n[boot]\nmethod="direct"\n')
 return p
first=project("one");second=project("two")
shared=RUN/"shared-target";shared.mkdir()
env=os.environ.copy();env.update(PROBE_REAL_CARGO=str(REAL),CARGO_HOME="/workspace/scratch/ae1a8cf05419/toolchains/cargo",RUSTUP_HOME="/workspace/scratch/ae1a8cf05419/toolchains/rustup",RUSTUP_TOOLCHAIN="nightly-2026-07-21",RUSTC=str(REAL.with_name("rustc")),RUSTDOC=str(REAL.with_name("rustdoc")),CARGO_NET_OFFLINE="true",CARGO_TARGET_DIR=str(shared))
env["PATH"]=str(binary)+os.pathsep+env["PATH"]
def call(label,p,target,restore=False):
 e=env.copy();e.update(CARGO_TARGET_DIR=str(target),PROBE_RECEIPT=str(RUN/(label+".json")),PROBE_RESTORE_STALE="1" if restore else "0",PROBE_STALE_SHARED=str(shared/"osdk/myos-run-base"),PROBE_SAVED_FIRST=str(RUN/"saved-first-Cargo.toml"))
 cmd=[str(SDK),"osdk","build","--boot-method=vmm-direct","--grub-boot-protocol=multiboot"]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 r=subprocess.run(cmd,cwd=p,env=e,capture_output=True,timeout=60)
 (RUN/(label+".stdout")).write_bytes(r.stdout);(RUN/(label+".stderr")).write_bytes(r.stderr)
 rec={"argv":cmd,"cwd":str(p),"target":str(target),"exit":r.returncode,"started_utc":start,"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (RUN/(label+".command.json")).write_text(json.dumps(rec,indent=2)+"\n")
 print(label,rec["exit"],flush=True)
call("one-shared",first,shared)
manifest=shared/"osdk/myos-run-base/Cargo.toml"
assert manifest.exists(),(RUN/"one-shared.stderr").read_text()
(RUN/"saved-first-Cargo.toml").write_bytes(manifest.read_bytes())
# Pinned SDK normally regenerates the correct changed dependency path.
call("two-normal-shared",second,shared)
assert str(second) in manifest.read_text()
# Restore the first manifest at the observed shared location immediately before Cargo.
call("red-two-stale-shared",second,shared,True)
red=json.loads((RUN/"red-two-stale-shared.json").read_text())
# Make first source unavailable, matching the runner's earlier-case cleanup.
(first/"Cargo.toml").rename(first/"Cargo.toml.no-longer-present")
call("red-two-stale-missing",second,shared,True)
redmissing=json.loads((RUN/"red-two-stale-missing.json").read_text())
assert redmissing["metadata_exit"]!=0
private=RUN/"case-two-target";private.mkdir()
for name in ("debug","release","x86_64-unknown-none"):
 (shared/name).mkdir(exist_ok=True);(private/name).symlink_to(shared/name,target_is_directory=True)
call("green-two-private-stale-shared",second,private,True)
green=json.loads((RUN/"green-two-private-stale-shared.json").read_text())
assert green["metadata_exit"]==0 and str(second) in green["manifest_after"]
assert not (private/"osdk").is_symlink()
report={"fixed_sdk":str(SDK),"sdk_sha256":hashlib.sha256(SDK.read_bytes()).hexdigest(),"cargo":str(REAL),"cargo_sha256":hashlib.sha256(REAL.read_bytes()).hexdigest(),"original_sdk_regenerates_changed_dependency":True,"fault_injection":"restore earlier manifest only to exact owned shared-target/osdk/myos-run-base immediately before real Cargo metadata","red_missing_source_metadata_exit":redmissing["metadata_exit"],"green_private_metadata_exit":green["metadata_exit"],"scope":"Actual source-built OSDK and Cargo metadata; Cargo build deliberately stops42 before rustc,0VM,0kernel compile; observed native writer cause remains unknown"}
(RUN/"result.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report))

