#!/usr/bin/env python3
import hashlib,json,os,pathlib,subprocess,sys,time
args=sys.argv[1:];real=os.environ["PROBE_REAL_CARGO"]
if "build" not in args:
 p=subprocess.run([real,*args,"--offline"] if args and args[0]=="metadata" else [real,*args])
 raise SystemExit(p.returncode)
here=pathlib.Path.cwd();out=pathlib.Path(os.environ["PROBE_RECEIPT"])
manifest=here/"Cargo.toml";before=manifest.read_bytes()
if os.environ.get("PROBE_RESTORE_STALE")=="1":
 stale=pathlib.Path(os.environ["PROBE_STALE_SHARED"])/"Cargo.toml"
 # Fault injection only into the exact private fixture-owned shared path.
 stale.write_bytes(pathlib.Path(os.environ["PROBE_SAVED_FIRST"]).read_bytes())
meta=subprocess.run([real,"metadata","--offline","--format-version=1","--no-deps"],cwd=here,capture_output=True)
(out.with_suffix(".metadata.json")).write_bytes(meta.stdout)
(out.with_suffix(".metadata.stderr")).write_bytes(meta.stderr)
out.write_text(json.dumps({"cwd":str(here),"argv":args,"CARGO_TARGET_DIR":os.environ.get("CARGO_TARGET_DIR"),"metadata_exit":meta.returncode,"manifest_before_sha256":hashlib.sha256(before).hexdigest(),"manifest_after":manifest.read_text(),"fault_restore":os.environ.get("PROBE_RESTORE_STALE")=="1","build_deliberately_not_executed":True},indent=2)+"\n")
raise SystemExit(42)

