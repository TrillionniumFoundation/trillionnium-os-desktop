#![no_std]
#![no_main]

#![feature(linkage)]

extern crate myos;

#[panic_handler]
fn panic(info: &core::panic::PanicInfo) -> ! {
    unsafe extern "Rust" {
        pub fn __ostd_panic_handler(info: &core::panic::PanicInfo) -> !;
    }
    unsafe { __ostd_panic_handler(info); }
}

mod default_frame_allocator {
    use ostd::mm::frame::GlobalFrameAllocator;

    use osdk_frame_allocator::FrameAllocator;
    static FRAME_ALLOCATOR: FrameAllocator = FrameAllocator;

    // SAFETY: The name does not collide with other symbols.
    #[unsafe(no_mangle)]
    #[linkage = "weak"]
    static __GLOBAL_FRAME_ALLOCATOR_REF: &'static dyn GlobalFrameAllocator = &FRAME_ALLOCATOR;
}

mod default_heap_allocator {
    use ostd::mm::heap::GlobalHeapAllocator;

    use osdk_heap_allocator::{HeapAllocator, type_from_layout};
    static HEAP_ALLOCATOR: HeapAllocator = HeapAllocator;

    // SAFETY: The name does not collide with other symbols.
    #[unsafe(no_mangle)]
    #[linkage = "weak"]
    static __GLOBAL_HEAP_ALLOCATOR_REF: &'static dyn GlobalHeapAllocator = &HEAP_ALLOCATOR;

    // SAFETY: The name does not collide with other symbols.
    #[unsafe(no_mangle)]
    #[linkage = "weak"]
    fn __global_heap_slot_info_from_layout(
        layout: core::alloc::Layout,
    ) -> Option<ostd::mm::heap::SlotInfo> {
        type_from_layout(layout)
    }
}
