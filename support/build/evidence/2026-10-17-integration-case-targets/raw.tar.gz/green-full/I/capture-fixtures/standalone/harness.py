import subprocess,sys
raise SystemExit(subprocess.call([sys.executable,'-I','/workspace/scratch/ae1a8cf05419/integration-case-target/green-full/I/capture-fixtures/standalone/recorder-driver.py']))
