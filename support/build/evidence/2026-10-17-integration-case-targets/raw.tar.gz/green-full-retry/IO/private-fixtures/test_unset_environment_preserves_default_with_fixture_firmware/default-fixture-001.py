import importlib.util,sys
from pathlib import Path
s=importlib.util.spec_from_file_location('recorder','/workspace/scratch/ae1a8cf05419/integration-case-target/green-full-retry/IO/private-fixtures/test_unset_environment_preserves_default_with_fixture_firmware/fixture-project/support/build/osdk-integration/record-qemu.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.FIRMWARE=Path('/workspace/scratch/ae1a8cf05419/integration-case-target/green-full-retry/IO/private-fixtures/test_unset_environment_preserves_default_with_fixture_firmware/private tools with spaces/firmware chosen.bin')
sys.argv=['/workspace/scratch/ae1a8cf05419/integration-case-target/green-full-retry/IO/private-fixtures/test_unset_environment_preserves_default_with_fixture_firmware/fixture-project/support/build/osdk-integration/record-qemu.py',*sys.argv[1:]]
raise SystemExit(m.main())
