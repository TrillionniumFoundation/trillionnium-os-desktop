#!/usr/bin/env python3
import gzip,hashlib,io,json,os,re,signal,subprocess,sys,tarfile,time
from pathlib import Path
BASE=Path(__file__).resolve().parent.parent;OUT=Path(__file__).resolve().parent;REPO=BASE/'trillionnium-os-desktop';SOURCE=OUT/'source'
COMMIT='063d7a92de77761c2358eb6faf0abb470aba49de';TREE='9ec717f096f099a3aa730db8c5f91c82c52419a7';PARENTS=['7122c9cde0b299ea1e01eb028effaf0e2ad92aa3','fb135f845dcbf9026010ebbe060c004fda7f8688']
ENV=dict(os.environ);ENV.update({'CARGO_HOME':str(BASE/'toolchains/cargo'),'RUSTUP_HOME':str(BASE/'toolchains/rustup'),'RUSTUP_TOOLCHAIN':'nightly-2026-07-21','RUSTUP_AUTO_INSTALL':'0','CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'2'});ENV['PATH']=ENV['CARGO_HOME']+'/bin:'+ENV['PATH'];ENV.pop('RUSTFLAGS',None);ENV.pop('CARGO_ENCODED_RUSTFLAGS',None)
CARGO=ENV['CARGO_HOME']+'/bin/cargo';RUSTUP=ENV['CARGO_HOME']+'/bin/rustup';RESULTS=[]
def sha(data):return hashlib.sha256(data).hexdigest()
def run(name,argv,cwd=SOURCE):
 record={'argv':list(map(str,argv)),'cwd':str(cwd),'env_overrides':{k:ENV[k] for k in ['CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTUP_AUTO_INSTALL','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','PATH']},'removed_environment_keys':['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS'],'exit_code':None,'raw_exit_code':None,'timed_out':False}
 receipt=OUT/(name+'.command.json');receipt.write_text(json.dumps(record,indent=2)+'\n');log=OUT/(name+'.log');start=time.monotonic()
 with log.open('wb') as stream:
  process=subprocess.Popen(record['argv'],cwd=cwd,env=ENV,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  deadline=time.monotonic()+120
  while os.waitid(os.P_PID,process.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT) is None:
   if time.monotonic()>deadline:record['timed_out']=True;os.killpg(process.pid,signal.SIGKILL);break
   time.sleep(.02)
  record['raw_exit_code']=process.wait();record['exit_code']=124 if record['timed_out'] else process.returncode
 record.update(duration_seconds=round(time.monotonic()-start,4),log=log.name,log_sha256=sha(log.read_bytes()),log_bytes=log.stat().st_size)
 record['test_summaries']=[dict(zip(['passed','failed','ignored','measured','filtered'],map(int,v))) for v in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log.read_text(errors='replace'))]
 receipt.write_text(json.dumps(record,indent=2)+'\n');RESULTS.append(record);print(json.dumps({'step':name,'exit':record['exit_code'],'test_summaries':record['test_summaries']}),flush=True)
 return record
SOURCE.mkdir()
paths=['libs/os-abi','tests/golden']
argv=['git','archive','--format=tar',COMMIT,*paths];p=subprocess.run(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(OUT/'extraction.json').write_text(json.dumps({'argv':argv,'cwd':str(REPO),'exit_code':p.returncode,'stderr':p.stderr.decode(),'source_commit':COMMIT},indent=2)+'\n')
if p.returncode:raise SystemExit(p.returncode)
(OUT/'source.tar.gz').write_bytes(gzip.compress(p.stdout,mtime=0))
with tarfile.open(fileobj=io.BytesIO(p.stdout)) as tar:tar.extractall(SOURCE,filter='data')
entries=subprocess.check_output(['git','ls-tree','-rz',COMMIT,'--',*paths],cwd=REPO).split(b'\0');files=[]
for entry in entries:
 if not entry:continue
 header,path=entry.split(b'\t',1);mode,kind,blob=header.decode().split();rel=path.decode();data=(SOURCE/rel).read_bytes()
 if kind!='blob' or hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()!=blob:raise RuntimeError(rel)
 files.append({'path':rel,'git_blob':blob,'mode':mode,'sha256':sha(data),'bytes':len(data)})
actual_tree=subprocess.check_output(['git','rev-parse',COMMIT+'^{tree}'],cwd=REPO,text=True).strip();actual_parents=subprocess.check_output(['git','show','-s','--format=%P',COMMIT],cwd=REPO,text=True).strip().split()
if actual_tree!=TREE or actual_parents!=PARENTS:raise RuntimeError('Git identity')
old_inputs=json.loads((BASE/'next8-merged-host/source-inputs.json').read_text());old_by_path={x['path']:x for x in old_inputs['files']}
newline=[]
for name in ['golden_vectors.rs','mutation_kill.rs','negative_vectors.rs']:
 rel='libs/os-abi/tests/'+name;old=(BASE/'next8-merged-host/source'/rel).read_bytes();new=(SOURCE/rel).read_bytes()
 if sha(old)!=old_by_path[rel]['sha256'] or old.endswith(b'\n') or new!=old+b'\n':raise RuntimeError('not newline-only '+rel)
 newline.append({'path':rel,'before_sha256':sha(old),'after_sha256':sha(new),'change':'exactly one terminal LF added'})
manifest='libs/os-abi/Cargo.toml'
if sha((SOURCE/manifest).read_bytes())!=old_by_path[manifest]['sha256']:raise RuntimeError('manifest changed')
old_lock=BASE/'next8-merged-host/locks/libs/os-abi/Cargo.lock';lockdata=old_lock.read_bytes();locksha='95c2616d9e61cbbb848888797f71d434d59744612fbaad5fa558754488cbffbd'
if sha(lockdata)!=locksha:raise RuntimeError('seed lock drift')
(SOURCE/'libs/os-abi/Cargo.lock').write_bytes(lockdata);(OUT/'Cargo.lock').write_bytes(lockdata)
(OUT/'source-inputs.json').write_text(json.dumps({'source_commit':COMMIT,'tree':TREE,'ordered_parents':PARENTS,'files':files,'source_archive_sha256':sha((OUT/'source.tar.gz').read_bytes()),'newline_only_changes':newline,'seed_lock':{'path':'Cargo.lock','sha256':locksha,'bytes':len(lockdata),'origin':str(old_lock),'origin_record':'prior exact merged-host ABI test generated lock; libs/os-abi/Cargo.toml unchanged from its recorded source'},'no_live_working_tree_inputs':True},indent=2)+'\n')
run('main-delta',['git','diff','--name-status',PARENTS[0],COMMIT],cwd=REPO)
run('abi-diff',['git','diff',PARENTS[0],COMMIT,'--','libs/os-abi'],cwd=REPO)
for role,exe in [('cargo',CARGO),('rustc',ENV['CARGO_HOME']+'/bin/rustc'),('rustfmt',ENV['CARGO_HOME']+'/bin/rustfmt')]:
 run('version-'+role,[exe,'+nightly-2026-07-21','-vV' if role!='rustfmt' else '--version'])
 run('which-'+role,[RUSTUP,'which','--toolchain','nightly-2026-07-21',role])
tools=[]
for role in ['cargo','rustc','rustfmt']:
 path=Path((OUT/('which-'+role+'.log')).read_text().strip());tools.append({'role':role,'path':str(path),'resolved_path':str(path.resolve()),'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size})
(OUT/'environment.json').write_text(json.dumps({'fixed_toolchain':'nightly-2026-07-21','offline':True,'jobs':2,'tools':tools,'cargo_proxy':{'path':CARGO,'sha256':sha(Path(CARGO).read_bytes())},'environment':{key:ENV[key] for key in ['CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTUP_AUTO_INSTALL','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','PATH']},'removed_environment_keys':['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']},indent=2)+'\n')
fmt=run('cargo-fmt',[CARGO,'+nightly-2026-07-21','fmt','--check','--manifest-path','libs/os-abi/Cargo.toml'])
target=OUT/'target';target_absent=not target.exists()
if not target_absent:raise RuntimeError('target exists')
test=run('cargo-test',[CARGO,'+nightly-2026-07-21','test','--locked','--offline','--jobs','2','--manifest-path','libs/os-abi/Cargo.toml','--target-dir',str(target)])
mutations=[entry['path'] for entry in files if sha((SOURCE/entry['path']).read_bytes())!=entry['sha256']]
lock_unchanged=sha((SOURCE/'libs/os-abi/Cargo.lock').read_bytes())==locksha
passed=all(r['exit_code']==0 for r in RESULTS) and not mutations and lock_unchanged and sum(x['passed'] for x in test['test_summaries'])==25
report={'source_commit':COMMIT,'tree':TREE,'ordered_parents':PARENTS,'passed':passed,'format_check_exit':fmt['exit_code'],'actual_rust_abi_passed':sum(x['passed'] for x in test['test_summaries']),'actual_rust_abi_failed':sum(x['failed'] for x in test['test_summaries']),'actual_rust_abi_ignored':sum(x['ignored'] for x in test['test_summaries']),'actual_rust_abi_filtered':sum(x['filtered'] for x in test['test_summaries']),'test_exit':test['exit_code'],'target_absent_before_test':target_absent,'source_input_mutations':mutations,'seed_lock_unchanged':lock_unchanged,'seed_lock_sha256':locksha,'newline_only_changes':newline,'source_inputs':'source-inputs.json','environment':'environment.json','commands':[r['log']+'.command.json' for r in RESULTS],'scope':'Final-main-sync Rust ABI host format/test only; no kernel/VM/UI execution; no live target/manifests or working-tree WIP read. Git operations were read-only archive/object/diff checks.'}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':passed,'fmt_exit':fmt['exit_code'],'rust_abi_passed':report['actual_rust_abi_passed'],'test_exit':test['exit_code'],'lock_unchanged':lock_unchanged,'source_mutations':mutations}),flush=True)
raise SystemExit(0 if passed else 1)
