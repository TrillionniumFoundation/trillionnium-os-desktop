#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

OUT=Path(__file__).resolve().parent
SOURCE=OUT/'source'
BASE=OUT.parent
ENV=dict(os.environ)
ENV.update({'CARGO_HOME':str(BASE/'toolchains/cargo'),'RUSTUP_HOME':str(BASE/'toolchains/rustup'),
 'RUSTUP_TOOLCHAIN':'nightly-2026-07-21','RUSTUP_AUTO_INSTALL':'0','CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'2'})
ENV['PATH']=str(BASE/'toolchains/cargo/bin')+os.pathsep+ENV['PATH']
CARGO=str(BASE/'toolchains/cargo/bin/cargo')
RUSTUP=str(BASE/'toolchains/cargo/bin/rustup')
RECORDS=[]

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def run(name,argv,cwd=SOURCE,timeout=180):
    log=OUT/(name+'.log')
    receipt=OUT/(name+'.command.json')
    record={'argv':list(map(str,argv)),'cwd':str(cwd),'environment_overrides':{key:ENV[key] for key in ('CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTUP_AUTO_INSTALL','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','PATH')},'exit_code':None,'raw_exit_code':None,'timed_out':False}
    receipt.write_text(json.dumps(record,indent=2)+'\n')
    started=time.monotonic()
    with log.open('wb') as output:
        process=subprocess.Popen(record['argv'],cwd=cwd,env=ENV,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            # waitid WNOWAIT keeps the leader's process-group identity anchored.
            deadline=time.monotonic()+timeout
            while os.waitid(os.P_PID,process.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT) is None:
                if time.monotonic()>=deadline:
                    record['timed_out']=True
                    os.killpg(process.pid,signal.SIGKILL)
                    break
                time.sleep(.02)
            record['raw_exit_code']=process.wait()
            record['exit_code']=124 if record['timed_out'] else process.returncode
        finally:
            if process.returncode is None:
                os.killpg(process.pid,signal.SIGKILL)
                process.wait()
    record.update(duration_seconds=round(time.monotonic()-started,4),log=log.name,log_sha256=digest(log),log_bytes=log.stat().st_size)
    data=log.read_text(errors='replace')
    record['rust_test_summaries']=[dict(zip(('passed','failed','ignored','measured','filtered_out'),map(int,match))) for match in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',data)]
    match=re.search(r'Ran (\d+) tests? in .*\n\s*\n(OK[^\n]*|FAILED[^\n]*)',data)
    if match: record['python_test_summary']={'count':int(match[1]),'result':match[2]}
    receipt.write_text(json.dumps(record,indent=2)+'\n')
    RECORDS.append(record)
    print(json.dumps({'step':name,'exit_code':record['exit_code'],'bytes':record['log_bytes'],'rust':record['rust_test_summaries'],'python':record.get('python_test_summary')}),flush=True)
    return record

versions=[]
for name,argv in [
 ('version-python',[sys.executable,'-I','--version']),
 ('version-cargo',[CARGO,'+nightly-2026-07-21','-vV']),
 ('version-rustc',[str(BASE/'toolchains/cargo/bin/rustc'),'+nightly-2026-07-21','-vV']),
 ('which-cargo',[RUSTUP,'which','--toolchain','nightly-2026-07-21','cargo']),
 ('which-rustc',[RUSTUP,'which','--toolchain','nightly-2026-07-21','rustc'])]:
    result=run(name,argv)
    if result['exit_code']!=0: raise SystemExit(result['exit_code'])
    versions.append(result)
paths=[('python',sys.executable),('cargo_proxy',CARGO),('rustup',RUSTUP)]
for name in ('cargo','rustc'):
    paths.append((name,(OUT/('which-'+name+'.log')).read_text().strip()))
tools=[]
for role,path in paths:
    resolved=str(Path(path).resolve())
    tools.append({'role':role,'invoked_path':path,'resolved_path':resolved,'sha256':digest(resolved),'bytes':Path(resolved).stat().st_size})
(OUT/'environment.json').write_text(json.dumps({'toolchain':'nightly-2026-07-21','offline':True,'jobs':2,'env':{key:ENV[key] for key in ('CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTUP_AUTO_INSTALL','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','PATH')},'tools':tools,'version_receipts':[Path(x['log']).with_suffix('.command.json').name for x in versions]},indent=2)+'\n')

initial={}
for path in SOURCE.rglob('Cargo.lock'):
    initial[str(path.relative_to(SOURCE))]={'sha256':digest(path),'bytes':path.stat().st_size}
results=[]
results.append(run('abi-python',[sys.executable,'-I','-B','-m','unittest','discover','-s','tests/abi','-p','test_*.py','-v']))
results.append(run('golden-check',[sys.executable,'-I','-B','tests/golden/generate_hos2.py','--check']))
for crate,name in [('os-abi','abi-rust'),('os-control','control-rust')]:
    target=OUT/('target-'+crate)
    if target.exists(): raise RuntimeError('target unexpectedly preexists: '+str(target))
    results.append(run(name,[CARGO,'+nightly-2026-07-21','test','--offline','--jobs','2','--manifest-path','libs/'+crate+'/Cargo.toml','--target-dir',str(target)]))
locks=[]
for path in sorted(SOURCE.rglob('Cargo.lock')):
    rel=str(path.relative_to(SOURCE))
    copy=OUT/'locks'/rel; copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(path.read_bytes())
    locks.append({'path':rel,'sha256':digest(path),'bytes':path.stat().st_size,'before':initial.get(rel),'generated_by_test':rel not in initial,'retained':str(copy.relative_to(OUT))})
inputs=json.loads((OUT/'source-inputs.json').read_text())
mutations=[]
for item in inputs['files']:
    path=SOURCE/item['path']
    if not path.is_file() or digest(path)!=item['sha256']:
        mutations.append(item['path'])
summary={'source_commit':inputs['commit'],'source_tree':inputs['tree'],'executed_tests':results,'version_receipts':versions,'locks':locks,'tracked_source_mutations':mutations,'passed':all(item['exit_code']==0 for item in results) and not mutations,'note':'Host-only ABI codec/control model tests. No QEMU, kernel build, global install, or live repository source used.'}
(OUT/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'passed':summary['passed'],'tracked_source_mutations':mutations,'locks':locks}),flush=True)
raise SystemExit(0 if summary['passed'] else 1)
