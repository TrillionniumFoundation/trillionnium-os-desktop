# Exact merged-tree host validation

Source commit `81d3080908292a0dc206f047de36b9e27bf68a73`, tree `48d1c43cb77706870cd431a7cc4cecb0f73f3254`. The 34 input files were extracted from Git, matched against Git blob IDs and SHA256 before execution, and checked unchanged after all tests. No live working-tree WIP was copied. `source.tar.gz` retains those inputs.

| Actual check | Result |
| --- | --- |
| ABI Python (`-I -B`) | 19/19, exit 0 |
| Golden generator `--check` | 12 vectors verified, exit 0 |
| Rust ABI | 25/25, exit 0 |
| Rust os-control | 21/21, exit 0 |
| Archive CI tests (`-I -B`) | 20/20, exit 0 |
| Archive CI tests (`-I -O -B`) | 20/20, exit 0 |

`overall.json`, per-command receipts, and full logs record actual commands and statuses. `environment.json` binds invoked and actual Cargo/rustc paths and executable hashes, with full versions in the adjacent logs. Rust used fixed `nightly-2026-07-21`, offline mode, jobs 2, and separate fresh targets. Both crate locks contain only the root package and no external dependencies; the newly generated ABI lock and unchanged tracked control lock are retained under `locks/`. The source archive was made before the ABI lock was generated.

The CI archive source/test pair consists of regular files and selects the branch executing the two actual archive suites. The event-base absence/bootstrap branch was inspected but not exercised by this normal merged tree. The `-B` option prevents bytecode output without changing the tests.

These are 105 host test executions plus the golden-vector check. The os-control suite is an independent host model, not a real integrated ABI/kernel consumer. No VM, kernel build, install, service change, production source mutation, or root Cargo.lock write occurred. Fresh Cargo targets and extracted working source remain only in disposable scratch and are excluded from the evidence manifest.
