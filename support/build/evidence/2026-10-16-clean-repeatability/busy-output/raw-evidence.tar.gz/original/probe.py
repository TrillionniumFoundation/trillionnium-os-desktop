import fcntl,hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop')
source='0a533b92d4a4df8e8e4643c1b7de00e83ba0fd9d'
build=root/'project/support/build';build.mkdir(parents=True)
source_hashes={}
for name in ('kernel.sh','kernel-supervisor.py'):
 data=subprocess.check_output(['git','show',source+':support/build/'+name],cwd=repo)
 (build/name).write_bytes(data);source_hashes[name]=hashlib.sha256(data).hexdigest()
output=root/'new-parent/evidence'
env=os.environ.copy();env.pop('A01_KERNEL_WORKER',None);env['A01_RUN_DIR']=str(output)
argv=['bash',str(build/'kernel.sh'),'kernel']
lockpath=build/'out-kernel.lock'
report={'source_commit':source,'source_sha256':source_hashes,'argv':argv,'explicit_environment':{'A01_RUN_DIR':str(output)},'Rust_Cargo_QEMU_invoked':False}
with lockpath.open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 identity=os.fstat(lock.fileno())
 report['lock_identity']=[identity.st_dev,identity.st_ino]
 attempt=subprocess.run(argv,env=env,capture_output=True,text=True,timeout=5)
 (root/'busy.stdout.log').write_text(attempt.stdout);(root/'busy.stderr.log').write_text(attempt.stderr)
 report['busy_exit_code']=attempt.returncode
 report['new_output_created_while_busy']=output.is_dir()
 report['output_entries_after_busy']=sorted(path.name for path in output.iterdir()) if output.exists() else None
 report['new_parent_created_while_busy']=output.parent.is_dir()
report['same_lock_inode_after_refusal']=[lockpath.stat().st_dev,lockpath.stat().st_ino]==report['lock_identity']
retry=subprocess.run(argv,env=env,capture_output=True,text=True,timeout=5)
(root/'retry.stdout.log').write_text(retry.stdout);(root/'retry.stderr.log').write_text(retry.stderr)
report['retry_after_lock_released_exit_code']=retry.returncode
report['retry_failed_because_consumed_path']='A01_RUN_DIR must be a new directory' in retry.stderr
report['finding_reproduced']=report['busy_exit_code']!=0 and report['new_output_created_while_busy'] and report['new_parent_created_while_busy'] and report['output_entries_after_busy']==[] and report['retry_failed_because_consumed_path']
(root/'observation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
if not report['finding_reproduced']:raise SystemExit(1)
