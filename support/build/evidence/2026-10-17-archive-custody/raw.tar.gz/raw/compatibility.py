#!/usr/bin/env python3
"""Rearchive exact historical evidence payloads without rerunning their tests."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop')
ARCHIVER = REPO / 'support/build/osdk-integration/archive.py'
BASE = '01a344c6a293fd73b158e9e6ca93bd9904b69bbf'
HISTORIES = [
    'support/build/evidence/2026-10-16-native-integration/osdk/attempt-07',
    'support/build/evidence/2026-10-16-native-integration/osdk/attempt-10',
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def relative(name):
    path = Path(name)
    if path.is_absolute() or not path.parts or '..' in path.parts:
        raise ValueError(name)
    return path


before = digest(ARCHIVER.read_bytes())
results = []
for historical in HISTORIES:
    archive = REPO / historical
    work = ROOT / 'compatibility' / archive.name
    work.mkdir(parents=True, exist_ok=False)
    source = work / 'restored-source'
    source.mkdir()
    old = json.loads((archive / 'archive.json').read_text())
    old_inputs = {}
    for row in (archive / 'evidence.sha256').read_text().splitlines():
        wanted, name = row.split('  ', 1)
        data = (archive / relative(name)).read_bytes()
        if digest(data) != wanted:
            raise ValueError(f'historical checksum mismatch: {historical}/{name}')
        old_inputs[name] = wanted
    for entry in old['files']:
        original, archived = relative(entry['source']), relative(entry['archived'])
        stored = (archive / archived).read_bytes()
        raw = gzip.decompress(stored) if archived.name != original.name and archived.suffix == '.gz' else stored
        if len(raw) != entry['source_size'] or digest(raw) != entry['source_sha256']:
            raise ValueError(f'historical payload mismatch: {entry}')
        target = source / original
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as output:
            output.write(raw)
    # Read-only Git comparison binds both historical input directories to the baseline.
    unchanged = subprocess.run(['git', 'diff', '--exit-code', BASE, '--', historical],
                               cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if unchanged.returncode:
        raise RuntimeError(unchanged.stdout.decode())
    for mode, flags in [('I', ['-I']), ('IO', ['-I', '-O'])]:
        destination = work / ('rebuilt-' + mode)
        command = [sys.executable, *flags, str(ARCHIVER), str(source), str(destination)]
        process = subprocess.run(command, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (work / (mode + '.log')).write_bytes(process.stdout)
        if process.returncode:
            raise RuntimeError(process.stdout.decode())
        new = json.loads((destination / 'archive.json').read_text())
        if sorted(new['files'], key=lambda item: item['source']) != sorted(old['files'], key=lambda item: item['source']):
            raise ValueError('schema1 source/archived/size/hash records changed')
        for entry in old['files']:
            name = relative(entry['archived'])
            if (destination / name).read_bytes() != (archive / name).read_bytes():
                raise ValueError(f'archived payload bytes changed: {name}')
        checker = subprocess.run(['sha256sum', '-c', 'evidence.sha256'], cwd=destination,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (work / (mode + '-sha256sum.log')).write_bytes(checker.stdout)
        if checker.returncode or (destination / '.archive-incomplete').exists():
            raise ValueError('completed archive checksum/marker verification failed')
        if any(digest((archive / name).read_bytes()) != wanted for name, wanted in old_inputs.items()):
            raise ValueError('historical inputs changed during compatibility run')
        result = {'kind': 'historical_evidence_rearchive_only_no_guest_execution',
            'historical_directory': historical, 'historical_manifest_sha256': digest((archive / 'archive.json').read_bytes()),
            'historical_checksum_file_sha256': digest((archive / 'evidence.sha256').read_bytes()),
            'argv': command, 'cwd': str(REPO), 'returncode': process.returncode,
            'mode': mode, 'archiver_sha256': before, 'archived_payload_files_equal': len(old['files']),
            'schema1_entries_equal_except_top_level_runtime_source_path': True,
            'deterministic_gzip_and_plain_payload_bytes_equal': True,
            'sha256sum_argv': ['sha256sum', '-c', 'evidence.sha256'],
            'sha256sum_cwd': str(destination), 'sha256sum_exit': checker.returncode,
            'historical_files_unchanged': True, 'complete_marker_absent': True}
        (work / (mode + '.invocation.json')).write_text(json.dumps(result, indent=2) + '\n')
        results.append(result)
if digest(ARCHIVER.read_bytes()) != before:
    raise ValueError('archiver source changed during compatibility run')
(ROOT / 'compatibility-results.json').write_text(json.dumps({'all_passed': True,
    'archiver_sha256_before_and_after': before, 'cases': results}, indent=2) + '\n')
print(json.dumps({'all_passed': True, 'archive_rebuilds': len(results),
    'historical_payloads_verified_per_mode': sum(case['archived_payload_files_equal'] for case in results) // 2,
    'new_guest_executions': 0}))
