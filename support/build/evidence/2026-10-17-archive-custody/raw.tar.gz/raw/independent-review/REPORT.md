# Archive custody 独立审阅

状态：已冻结。审阅范围为本轮 `archive.py`、`test_archive.py` 和相关 README 差异；本次落盘未新增试验。

审阅的 `archive.py` SHA256：`f5cb4da0541abe226e8f088f5d3f9469024c6018af44f671190b1ea6ce761f60`。Git blob：`a021bd0f923af160c31099da58323553b2114c2a`，与原始 review diff 显示的 `a021bd0` 前缀一致；大小 12,120 字节。完整来源绑定见 `report.json`。

在 README 明示的“目标父目录可信，非同用户 writer 沙箱”范围内，未发现必须阻止发布的缺陷。目录 FD 固定后，root/subdir 路径替换不会把后续写入重定向到替换路径；完成检查会拒绝目录身份变化。证据文件及两个索引共享 `O_EXCL|O_NOFOLLOW` 创建，摘要来自写入 payload。失败路径不执行 `rmtree`，不会递归删除被替换的目标路径。原有 source-root、硬链接和有界读取保护保留。

此前已完成的定点观测：12 次成功归档、12 次部分失败归档，打开 FD 数从 4 到 4，无增长。这是单独的资源清理探针，不是完整 suite 的替代或重跑。

必须保留的边界：在 `mkdir` 到首次 `stat/open` 之间，同用户 writer 可以把刚创建的 root 换成另一个真实目录。实际探针归档返回 1，foreign sentinel 保留，但该目录收到 `first.json`，完成时 marker 被移除。这要求破坏可信父目录前提；报告应将保护限定为“FD 固定之后”，不能声称所有 root/subdir swap 都 fail closed。子目录首次打开处存在同类代码窗口，此变体仅做源码判断，未另做试验。

本次没有再跑完整 suite、VM 或 Cargo；没有编辑仓库或创建 commit。未证明整棵 run 的原子快照、崩溃持久性或对同用户 writer 的全部 race 防御。`archive.json` 的 symlink 注入已有测试，`evidence.sha256` 共享同一 writer，但未单独注入。

原始探针脚本文件及 stdout 日志当时没有单独保留。`observed-output-transcription.txt` 逐行转录当时可见 tool-result 中的两个 JSON 输出，仅为已有观测转录，不冒充原始进程日志。没有重建或补造命令执行记录。
