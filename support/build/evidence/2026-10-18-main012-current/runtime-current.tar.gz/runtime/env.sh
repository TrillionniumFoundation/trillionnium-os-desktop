#!/usr/bin/env bash
# Source this file; all added tools and package files remain in the A01 workspace.
export A01_RUNTIME_ROOT=/workspace/scratch/d7da9e7650f0/a01-current-runtime
export CARGO_HOME="$A01_RUNTIME_ROOT/cargo"
export RUSTUP_HOME="$A01_RUNTIME_ROOT/rustup"
export RUSTUP_TOOLCHAIN=nightly-2026-07-21
export PATH="$A01_RUNTIME_ROOT/bin:$CARGO_HOME/bin:$A01_RUNTIME_ROOT/rootfs/usr/bin:$A01_RUNTIME_ROOT/rootfs/usr/sbin:$PATH"
export LD_LIBRARY_PATH="$A01_RUNTIME_ROOT/rootfs/usr/lib/x86_64-linux-gnu:$A01_RUNTIME_ROOT/rootfs/usr/lib/llvm-18/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LIBRARY_PATH="$A01_RUNTIME_ROOT/rootfs/usr/lib/x86_64-linux-gnu${LIBRARY_PATH:+:$LIBRARY_PATH}"
export PKG_CONFIG_PATH="$A01_RUNTIME_ROOT/rootfs/usr/lib/x86_64-linux-gnu/pkgconfig${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}"
export OPENSSL_INCLUDE_DIR="$A01_RUNTIME_ROOT/rootfs/usr/include"
export OPENSSL_LIB_DIR="$A01_RUNTIME_ROOT/rootfs/usr/lib/x86_64-linux-gnu"
export A01_BUSYBOX="$A01_RUNTIME_ROOT/rootfs/usr/bin/busybox"
export A01_QEMU_BIOS="$A01_RUNTIME_ROOT/rootfs/usr/share/seabios/bios-256k.bin"
export A01_QEMU_DATA_DIR="$A01_RUNTIME_ROOT/rootfs/usr/share/qemu"
export QEMU_MODULE_DIR="$A01_RUNTIME_ROOT/rootfs/usr/lib/x86_64-linux-gnu/qemu"
export VDSO_LIBRARY_DIR="$A01_RUNTIME_ROOT/linux-vdso"
export CARGO_NET_GIT_FETCH_WITH_CLI=true
