#!/usr/bin/env python3
"""Validate and record isolated A01 dependency inputs; does not boot a kernel."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import shutil
import subprocess
import tomllib

ROOT = Path('/workspace/scratch/d7da9e7650f0/a01-current-runtime')
PROJECT = Path('/workspace/scratch/d7da9e7650f0/a01-current')
SNAPSHOT = 'https://snapshot.ubuntu.com/ubuntu/20260828T000000Z/'

def fingerprint(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'resolved_path': str(path.resolve()), 'size': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}

def run(command, *, input=None):
    result = subprocess.run(command, input=input, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=30)
    record = {'argv': command, 'shell_command': shlex.join(command),
              'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
              'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    executable = shutil.which(command[0])
    if executable:
        record['executable'] = fingerprint(executable)
    return record

def parse_deb822(text):
    for block in text.split('\n\n'):
        record = {}
        for line in block.splitlines():
            if not line or line.startswith((' ', '\t')) or ': ' not in line:
                continue
            key, value = line.split(': ', 1)
            record[key] = value
        if record:
            yield record

packages = json.loads((ROOT/'native-packages.json').read_text())
apt_opts = ['-o', f'Dir::Etc::sourcelist={ROOT}/apt/sources.list', '-o', 'Dir::Etc::sourceparts=-',
            '-o', f'Dir::State={ROOT}/apt/state', '-o', 'Dir::State::status=/var/lib/dpkg/status',
            '-o', f'Dir::Cache={ROOT}/apt/cache', '-o', f'Dir::Log={ROOT}/logs']
metadata = subprocess.check_output(['apt-cache', *apt_opts, 'show',
                                   *[p['package']+'='+p['version'] for p in packages]], text=True)
(ROOT/'downloads/deb-metadata.txt').write_text(metadata)
indexed = {(p['Package'], p['Version']): p for p in parse_deb822(metadata) if 'Filename' in p}
for package in packages:
    info = indexed[(package['package'], package['version'])]
    actual = fingerprint(package['file'])
    expected = info['SHA256']
    if actual['sha256'] != expected:
        raise SystemExit('APT SHA256 mismatch for '+package['package'])
    package.update(actual)
    package.update({'expected_sha256': expected, 'sha256_verified': True,
                    'source_url': SNAPSHOT+info['Filename'],
                    'source_package': info.get('Source', package['package'])})
(ROOT/'native-inputs.json').write_text(json.dumps(packages, indent=2)+'\n')

manifest_file = ROOT/'downloads/channel-rust-nightly-2026-07-21.toml'
manifest_digest = fingerprint(manifest_file)
expected = (ROOT/'downloads/channel-rust-nightly-2026-07-21.toml.sha256.upstream').read_text().split()[0]
if manifest_digest['sha256'] != expected:
    raise SystemExit('Rust channel manifest SHA256 mismatch')
manifest = tomllib.loads(manifest_file.read_text())
rust_inputs = {'manifest': dict(manifest_digest, expected_sha256=expected, sha256_verified=True),
               'source_url': 'https://static.rust-lang.org/dist/2026-07-21/channel-rust-nightly.toml',
               'component_archive_verification': 'rustup verifies downloaded component archives against this manifest; archives are not retained after installation',
               'components': []}
for package, target in [('cargo', 'x86_64-unknown-linux-gnu'), ('rustc', 'x86_64-unknown-linux-gnu'),
                        ('rust-std', 'x86_64-unknown-linux-gnu'), ('rust-std', 'x86_64-unknown-none'),
                        ('rust-src', '*'), ('rustc-dev', 'x86_64-unknown-linux-gnu'),
                        ('llvm-tools-preview', 'x86_64-unknown-linux-gnu'),
                        ('rustfmt-preview', 'x86_64-unknown-linux-gnu'),
                        ('clippy-preview', 'x86_64-unknown-linux-gnu')]:
    entry = manifest['pkg'][package]['target'][target]
    rust_inputs['components'].append({'component': package, 'target': target,
                                     'version': manifest['pkg'][package]['version'],
                                     'source_url': entry['xz_url'], 'sha256': entry['xz_hash']})
(ROOT/'rust-inputs.json').write_text(json.dumps(rust_inputs, indent=2)+'\n')

checks = {}
for label, command in [('rustc', ['rustc', '-Vv']), ('cargo', ['cargo', '-Vv']),
                       ('components', ['rustup', 'component', 'list', '--installed']),
                       ('targets', ['rustup', 'target', 'list', '--installed']),
                       ('qemu', ['qemu-system-x86_64', '--version']), ('gcc', ['gcc', '--version']),
                       ('clang', ['clang', '--version']), ('lld', ['ld.lld', '--version']),
                       ('gdb', ['gdb', '--version']), ('gdb_batch', ['gdb', '-q', '-batch', '-ex', 'show version']),
                       ('busybox', ['busybox']), ('busybox_elf', ['readelf', '-l', os.environ['A01_BUSYBOX']]),
                       ('cpio', ['cpio', '--version']), ('pkgconfig', ['pkg-config', '--version']),
                       ('rust_strip', ['rust-strip', '--version']), ('qemu_dynamic_libraries', ['ldd', shutil.which('qemu-system-x86_64')])]:
    checks[label] = run(command)

# Machine execution and kernel acceptance are exclusively performed by the parent.
# Version and dependency loading below do not create a QEMU machine.
checks['prepare_initramfs'] = run(['python3', str(PROJECT/'support/build/minimal/prepare-initramfs.py'),
                                  '--upstream', str(PROJECT/'kernel/asterinas'),
                                  '--busybox', os.environ['A01_BUSYBOX'],
                                  '--output', str(ROOT/'initramfs.cpio.gz'),
                                  '--manifest', str(ROOT/'initramfs-manifest.json')])
record = {'recorded_at': datetime.now(timezone.utc).isoformat(), 'platform': platform.platform(),
          'installation_mode': 'rustup isolated CARGO_HOME/RUSTUP_HOME; apt-get --download-only with isolated state/cache/logs and dpkg-deb --extract to workspace prefix',
          'no_kernel_boot_claimed': True,
          'qemu_machine_created': False,
          'source_head_at_initramfs_check': subprocess.check_output(['git', '-C', str(PROJECT), 'rev-parse', 'HEAD'], text=True).strip(),
          'environment': {key: os.environ[key] for key in ['CARGO_HOME', 'RUSTUP_HOME', 'RUSTUP_TOOLCHAIN',
                        'A01_BUSYBOX', 'A01_QEMU_BIOS', 'A01_QEMU_DATA_DIR', 'QEMU_MODULE_DIR', 'VDSO_LIBRARY_DIR']},
          'unavailable': {tool: shutil.which(tool) for tool in ['docker', 'nix', 'nix-build']},
          'kvm_device_exists': Path('/dev/kvm').exists(), 'checks': checks,
          'artifacts': {name: fingerprint(path) for name, path in [('seabios', os.environ['A01_QEMU_BIOS']),
                       ('busybox', os.environ['A01_BUSYBOX']), ('vdso_x86_64', ROOT/'linux-vdso/vdso_x86_64.so'),
                       ('initramfs', ROOT/'initramfs.cpio.gz')]}}
(ROOT/'runtime-receipt.json').write_text(json.dumps(record, indent=2)+'\n')
summary = {name: value['exit_code'] for name, value in checks.items()}
print(json.dumps({'native_archives_verified': len(packages), 'rust_manifest_verified': True,
                  'checks': summary, 'artifacts': record['artifacts']}, indent=2))
if any(value != 0 for value in summary.values()):
    raise SystemExit('A runtime check failed; see runtime-receipt.json')
