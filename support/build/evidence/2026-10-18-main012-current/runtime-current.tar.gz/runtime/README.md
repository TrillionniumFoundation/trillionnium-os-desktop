# A01 fresh isolated native runtime, 2026-10-18

This evidence records a new dependency installation after workspace maintenance
removed the previous tool binaries. The parent fetched current repository source;
this agent restored only a private native tool environment. Historical bootstrap
scripts were retrieved from published commit
`7b28d9cfe9556835c4bf1ac5d1c1ec078c449b77`; the old execution logs were retained
under a separate historical directory and are not presented as this run.

## Current result

All five dependency installation/validation steps returned zero. The Rust and
native-package installation began at 08:34:02 UTC on 2026-10-18. The final runtime
validation completed at 08:36:06 UTC. There are 17 passing runtime checks, with
57 native package archives independently matched to the fixed signed APT index.
All four Ubuntu InRelease signatures also passed an explicit `gpgv` check.

The installed toolchain is `nightly-2026-07-21`, Rust commit
`87e5904f5eb6398af6b22eac2802c78934260c48`, with rust-src, rustc-dev,
llvm-tools-preview, rustfmt, clippy, and the x86_64-unknown-none target.
`cargo-binutils` 0.4.0 was installed using `--locked`; `rust-strip` reports
LLVM 22.1.8. Native dependencies include QEMU 8.2.2
(`1:8.2.2+ds-0ubuntu1.18`), SeaBIOS 1.16.3-2, static BusyBox
1:1.36.1-6ubuntu3.1, clang/lld 18.1.3, GDB 15.1, cpio, and OpenSSL development
files. APT used the fixed Ubuntu snapshot `20260828T000000Z`, isolated
state/cache/log directories, and `--download-only`; `dpkg-deb --extract` wrote
package files only into this workspace prefix.

The vDSO checkout matches commit `8af571775a3d3a1df3e84fc9709b9d6b160c771a`,
tree `8e0a300d78c2a020ccc79f1253bc27a8301416e6`, and x86_64 image SHA256
`27cd7bf576a92fa48a891c05988f52fac35b7374d5b9650d6b035e477c5d93a3`.
Private initramfs packaging passed, producing 1,107,990 bytes with SHA256
`86be65ab9234cd20ea6ec8d44a12b8765fd7a3e241fde920c71b3621ca0047f3`.

No QEMU machine was created by this agent. QEMU was invoked only for its version;
`ldd` checked dynamic dependencies. No kernel was built or booted here. The parent
owns the actual source build, QEMU execution, workspace lock, and acceptance logs.

## Entry point and replay

The live environment entry is:

```sh
source /workspace/scratch/d7da9e7650f0/a01-current-runtime/env.sh
```

`install-rust.sh`, `install-native.sh`, `install-vdso.sh`, and
`install-binutils.sh` preserve the commands actually executed. `run-step.py`
records each command, exact start/end time, exit status, script SHA256, and
complete raw log. It refuses to overwrite an existing execution record.
`record-runtime.py` verifies package/Rust metadata and runs the checks;
`finalize-runtime.py` fingerprints effective tool/library inputs.

On an equivalent Ubuntu x86_64 host, use a new private prefix, change only the
recorded prefix in the scripts and APT source public-key path, create
`downloads`, `logs`, `receipts`, `rootfs`, `bin`, `apt/state/lists/partial`, and
`apt/cache/archives/partial`, and execute:

```sh
python3 run-step.py rust-install bash ./install-rust.sh
python3 run-step.py native-install bash ./install-native.sh
python3 run-step.py vdso-install bash ./install-vdso.sh
python3 run-step.py cargo-binutils-install bash ./install-binutils.sh
source ./env.sh
python3 run-step.py runtime-checks python3 ./record-runtime.py
python3 run-step.py final-inventory python3 ./finalize-runtime.py
```

The first three steps are independent. The binutils step requires the Rust and
native steps. The validation script has an explicit project checkout path for
its read-only initramfs input; adapt that path to the current checkout.

## Evidence and practical limits

`summary.json`, `runtime-receipt.json`, `native-inputs.json`, `rust-inputs.json`,
`effective-binary-inputs.json`, and `receipts/` bind the fresh execution and
inputs. `logs/` contains unedited current logs. Public keyring, signed
InRelease files, package metadata, fixed nightly manifest, checksums, and relevant
BusyBox/QEMU/SeaBIOS/vDSO license notices are preserved. The observed initial
sandbox proxy failure is retained separately; the archive download and dependency
installation then succeeded through the ordinary authorized network mechanism.

The runtime still uses recorded host tools and shared libraries. The host package
inventory and effective binary hashes describe that dependency boundary; they are
not a complete immutable host image lock and do not establish cross-host
byte-for-byte kernel reproducibility. Docker, Nix and KVM are unavailable here.
No ISO, host package installation, production service, physical disk or firmware
write was involved.

The compact archive excludes the old historical execution files, downloaded deb
payloads, full Rust toolchain, build caches, and initramfs binary. It includes the
initramfs manifest and hashes. `archive-source-map.json` maps copied evidence to
its original path and digest; `SHA256SUMS` covers every archived file except
itself. Every copied current log and receipt is kept byte-for-byte.
