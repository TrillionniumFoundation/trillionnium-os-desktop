#!/usr/bin/env python3
"""Freeze a compact current-run dependency inventory for the parent to archive."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

root = Path(__file__).resolve().parent

def fingerprint(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return {'path': str(path), 'resolved_path': str(path.resolve()),
            'size': path.stat().st_size, 'sha256': digest.hexdigest()}

receipt = json.loads((root / 'runtime-receipt.json').read_text())
actual = {root / 'downloads/rustup-init'}
for check in receipt['checks'].values():
    if 'executable' in check:
        actual.add(Path(check['executable']['path']))
for token in re.findall(r'/(?:[^\s()]+)', receipt['checks']['qemu_dynamic_libraries']['stdout']):
    if Path(token).is_file():
        actual.add(Path(token))
for tool in ['rustc', 'cargo', 'rustfmt', 'clippy-driver']:
    actual.add(Path(subprocess.check_output(['rustup', 'which', tool], text=True).strip()))
actual.add(Path(os.environ['A01_QEMU_BIOS']))
actual.add(Path(os.environ['A01_BUSYBOX']))
actual.add(Path(os.environ['VDSO_LIBRARY_DIR']) / 'vdso_x86_64.so')
inputs = [fingerprint(path) for path in sorted(actual)]
(root / 'effective-binary-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
packages = json.loads((root / 'native-inputs.json').read_text())
steps = {name: json.loads((root / 'receipts' / (name + '.json')).read_text())
         for name in ['rust-install', 'native-install', 'vdso-install',
                      'cargo-binutils-install', 'runtime-checks']}
assert all(step['exit_code'] == 0 for step in steps.values())
assert all(check['exit_code'] == 0 for check in receipt['checks'].values())
assert all(package['sha256_verified'] for package in packages)
assert receipt['qemu_machine_created'] is False
assert receipt['no_kernel_boot_claimed'] is True
assert receipt['artifacts']['vdso_x86_64']['sha256'] == '27cd7bf576a92fa48a891c05988f52fac35b7374d5b9650d6b035e477c5d93a3'
summary = {
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Fresh isolated native dependency restoration after workspace pruning',
    'environment_entry': str(root / 'env.sh'),
    'installation_steps': {name: {'start_utc': value['start_utc'],
                                 'end_utc': value['end_utc'],
                                 'exit_code': value['exit_code'],
                                 'log_sha256': value['log_sha256']}
                           for name, value in steps.items()},
    'native_packages_verified': len(packages),
    'snapshot': 'https://snapshot.ubuntu.com/ubuntu/20260828T000000Z/',
    'runtime_checks_passed': len(receipt['checks']),
    'runtime_checks_failed': 0,
    'qemu_machine_created': False,
    'kernel_built_or_booted_by_this_agent': False,
    'fixed_toolchain': 'nightly-2026-07-21',
    'rustc_commit': '87e5904f5eb6398af6b22eac2802c78934260c48',
    'vdso_commit': '8af571775a3d3a1df3e84fc9709b9d6b160c771a',
    'vdso_tree': '8e0a300d78c2a020ccc79f1253bc27a8301416e6',
    'artifacts': receipt['artifacts'],
    'effective_binary_input_count': len(inputs),
    'unavailable': receipt['unavailable'],
    'kvm_device_exists': receipt['kvm_device_exists'],
    'host_dependencies_reused': True,
    'complete_immutable_host_dependency_lock': False,
    'cross_host_bit_reproducibility_claimed': False,
    'historical_evidence_source_commit': '7b28d9cfe9556835c4bf1ac5d1c1ec078c449b77',
    'historical_execution_logs_reused_as_current': False,
}
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'native_packages_verified': len(packages),
                  'runtime_checks_passed': len(receipt['checks']),
                  'effective_binary_input_count': len(inputs),
                  'qemu_machine_created': False,
                  'summary': str(root / 'summary.json')}))
