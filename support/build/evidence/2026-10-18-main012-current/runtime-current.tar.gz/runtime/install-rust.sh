#!/usr/bin/env bash
set -euo pipefail
runtime_dir=/workspace/scratch/d7da9e7650f0/a01-current-runtime
export CARGO_HOME="$runtime_dir/cargo"
export RUSTUP_HOME="$runtime_dir/rustup"
export PATH="$CARGO_HOME/bin:$PATH"
set -x
date -u --iso-8601=seconds
curl --fail --location --retry 3 https://static.rust-lang.org/rustup/dist/x86_64-unknown-linux-gnu/rustup-init -o "$runtime_dir/downloads/rustup-init"
curl --fail --location --retry 3 https://static.rust-lang.org/rustup/dist/x86_64-unknown-linux-gnu/rustup-init.sha256 -o "$runtime_dir/downloads/rustup-init.sha256.upstream"
python3 - "$runtime_dir" <<'PY'
import hashlib
import pathlib
import sys
root = pathlib.Path(sys.argv[1])
path = root / 'downloads/rustup-init'
expected = (root / 'downloads/rustup-init.sha256.upstream').read_text().split()[0]
actual = hashlib.sha256(path.read_bytes()).hexdigest()
if expected != actual:
    raise SystemExit(f'rustup-init mismatch: {actual} != {expected}')
print(f'rustup-init SHA256 verified: {actual}')
PY
chmod +x "$runtime_dir/downloads/rustup-init"
"$runtime_dir/downloads/rustup-init" -y --no-modify-path --default-toolchain none
rustup toolchain install nightly-2026-07-21 --no-self-update --profile minimal --component rust-src,rustc-dev,llvm-tools-preview,rustfmt,clippy --target x86_64-unknown-none
rustup --version
rustc +nightly-2026-07-21 -Vv
cargo +nightly-2026-07-21 -Vv
rustup component list --toolchain nightly-2026-07-21 --installed
rustup target list --toolchain nightly-2026-07-21 --installed
curl --fail --location --retry 3 https://static.rust-lang.org/dist/2026-07-21/channel-rust-nightly.toml -o "$runtime_dir/downloads/channel-rust-nightly-2026-07-21.toml"
curl --fail --location --retry 3 https://static.rust-lang.org/dist/2026-07-21/channel-rust-nightly.toml.sha256 -o "$runtime_dir/downloads/channel-rust-nightly-2026-07-21.toml.sha256.upstream"
date -u --iso-8601=seconds
