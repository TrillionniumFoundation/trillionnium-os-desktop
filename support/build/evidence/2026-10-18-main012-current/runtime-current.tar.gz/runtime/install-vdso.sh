#!/usr/bin/env bash
set -euo pipefail
runtime_dir=/workspace/scratch/d7da9e7650f0/a01-current-runtime
set -x
date -u --iso-8601=seconds
git clone https://github.com/asterinas/linux_vdso.git "$runtime_dir/linux-vdso"
git -C "$runtime_dir/linux-vdso" checkout --detach 8af571775a3d3a1df3e84fc9709b9d6b160c771a
git -C "$runtime_dir/linux-vdso" rev-parse HEAD HEAD^{tree}
test "$(git -C "$runtime_dir/linux-vdso" rev-parse HEAD)" = 8af571775a3d3a1df3e84fc9709b9d6b160c771a
test "$(git -C "$runtime_dir/linux-vdso" rev-parse HEAD^{tree})" = 8e0a300d78c2a020ccc79f1253bc27a8301416e6
printf '%s  %s\n' 27cd7bf576a92fa48a891c05988f52fac35b7374d5b9650d6b035e477c5d93a3 "$runtime_dir/linux-vdso/vdso_x86_64.so" | sha256sum --check
git -C "$runtime_dir/linux-vdso" show --no-patch --format=fuller HEAD
cat "$runtime_dir/linux-vdso/README.md"
date -u --iso-8601=seconds
