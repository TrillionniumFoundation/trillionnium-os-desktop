#!/usr/bin/env bash
set -euo pipefail
runtime_dir=/workspace/scratch/d7da9e7650f0/a01-current-runtime
source "$runtime_dir/env.sh"
set -x
date -u --iso-8601=seconds
cargo +nightly-2026-07-21 install cargo-binutils --version 0.4.0 --locked
cargo install --list
rust-strip --version
date -u --iso-8601=seconds
