#!/usr/bin/env python3
"""Archive fresh dependency evidence only, preserving raw bytes and source paths."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
archive = root / 'archive' / 'runtime'
archive.mkdir(parents=True, exist_ok=False)
names = [
    'README.md', 'env.sh', 'install-rust.sh', 'install-native.sh',
    'install-vdso.sh', 'install-binutils.sh', 'run-step.py', 'record-runtime.py',
    'finalize-runtime.py', 'archive-runtime.py', 'summary.json',
    'runtime-receipt.json', 'native-packages.json', 'native-inputs.json',
    'rust-inputs.json', 'effective-binary-inputs.json', 'host-installed-packages.tsv',
    'initramfs-manifest.json', 'apt/sources.list', 'apt/ubuntu-archive-keyring.gpg',
    'downloads/channel-rust-nightly-2026-07-21.toml',
    'downloads/channel-rust-nightly-2026-07-21.toml.sha256.upstream',
    'downloads/rustup-init.sha256.upstream', 'downloads/deb-SHA256SUMS',
    'downloads/deb-metadata.txt',
]
for directory in ['receipts', 'logs', 'licenses', 'apt/InRelease']:
    names.extend(str(path.relative_to(root)) for path in (root / directory).rglob('*')
                 if path.is_file())
mapping = []
for name in sorted(set(names)):
    source = root / name
    data = source.read_bytes()
    target = archive / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    mapping.append({'archived_path': name, 'original_path': str(source),
                    'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
(archive / 'archive-source-map.json').write_text(json.dumps(mapping, indent=2) + '\n')
files = sorted(path for path in archive.rglob('*') if path.is_file())
(archive / 'SHA256SUMS').write_text(''.join(
    hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + str(path.relative_to(archive)) + '\n'
    for path in files))
files.append(archive / 'SHA256SUMS')
output = root / 'runtime-current.tar.gz'
with output.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for path in sorted(files):
                info = tar.gettarinfo(str(path), arcname='runtime/' + str(path.relative_to(archive)))
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                info.mode = 0o644
                with path.open('rb') as stream:
                    tar.addfile(info, stream)
result = {'created_at_utc': datetime.now(timezone.utc).isoformat(),
          'archive': str(output), 'size': output.stat().st_size,
          'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'regular_files': len(files), 'source_files_copied_byte_exact': len(mapping),
          'source_map': str(archive / 'archive-source-map.json')}
(root / 'archive-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
