#!/usr/bin/env python3
"""Capture one fresh isolated dependency step, retaining failures as well as passes."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

root = Path(__file__).resolve().parent
name = sys.argv[1]
if not name.replace('-', '').replace('_', '').isalnum():
    raise SystemExit('invalid receipt name')
command = sys.argv[2:]
if not command:
    raise SystemExit('command is required')
log = root / 'logs' / (name + '.log')
receipt = root / 'receipts' / (name + '.json')
if log.exists() or receipt.exists():
    raise SystemExit('refusing to overwrite an existing execution record')
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
record = {'scope': 'fresh isolated dependency installation or validation; no kernel acceptance',
          'argv': command, 'shell_command': shlex.join(command), 'cwd': str(root),
          'start_utc': now(), 'log': str(log), 'scripts': {}}
for arg in command:
    path = Path(arg)
    if path.is_file() and path.suffix in ('.py', '.sh'):
        record['scripts'][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
receipt.write_text(json.dumps(record, indent=2) + '\n')
with log.open('xb') as stream:
    try:
        process = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
        record['exit_code'] = process.returncode
    except Exception as error:
        record['exception'] = repr(error)
        record['exit_code'] = 127
record.update(end_utc=now(), log_size=log.stat().st_size,
              log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
receipt.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
raise SystemExit(record['exit_code'])
