#!/usr/bin/env python3
import datetime, hashlib, json, os, pathlib, subprocess, sys, time
REPO=pathlib.Path('/workspace/scratch/d7da9e7650f0/a01-current')
ROOT=REPO/'support/build/out/2026-10-18-main012'
SOURCE='b39e154ae5a1e9853f57e23f9bee84712ee8ef7e'
CAPTURE=REPO/'support/build/evidence/2026-10-18-current-main/source/capture-source.py'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git','-C',str(REPO),*args],text=True).strip()
def save(path,value): path.write_text(json.dumps(value,indent=2)+'\n')
def capture(name,compare=None):
    dest=ROOT/'source'/name
    cmd=[sys.executable,'-B','-I',str(CAPTURE),'--repo',str(REPO)]
    if compare: cmd+=['--compare',str(compare)]
    with dest.open('wb') as stdout, dest.with_suffix('.stderr.log').open('wb') as stderr:
        p=subprocess.run(cmd,stdout=stdout,stderr=stderr)
    result=json.loads(dest.read_text())
    assert p.returncode==0 and result['matches_git'],(dest,p.returncode)
    return dest,result
stage=sys.argv[1]
assert stage in ['kernel','run_kernel']
assert git('rev-parse','HEAD')==SOURCE
ROOT.mkdir(parents=True,exist_ok=True)
(ROOT/'source').mkdir(exist_ok=True)
assert not (ROOT/stage).exists(),'stage output already exists'
if stage=='kernel':
    assert not (REPO/'kernel/asterinas/target').exists(),'expected fresh absent target'
    assert git('status','--porcelain=v1','--untracked-files=all')==''
    before,receipt=capture('before.json')
else:
    before=ROOT/'source/before.json'
    _,receipt=capture('before-run_kernel.json',before)
assert receipt['head']==SOURCE
selected=['CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','A01_SMP','A01_QEMU_TIMEOUT','A01_BUSYBOX','A01_QEMU_BIOS','A01_QEMU_DATA_DIR','QEMU_MODULE_DIR','VDSO_LIBRARY_DIR','PATH','LD_LIBRARY_PATH','LIBRARY_PATH','CARGO_NET_GIT_FETCH_WITH_CLI']
env=os.environ.copy();env['A01_RUN_DIR']=str(ROOT/stage)
cmd=[str(REPO/'support/build/kernel.sh'),stage]
start=now();clock=time.monotonic()
record={'schema':'trillionnium.a01.actual-stage.v1','stage':stage,'command':cmd,'cwd':str(REPO),'source_commit':SOURCE,'project_tree':git('rev-parse','HEAD^{tree}'),'kernel_tree':git('rev-parse','HEAD:kernel/asterinas'),'started_at_utc':start,'environment':{k:env.get(k) for k in selected},'A01_RUN_DIR':env['A01_RUN_DIR'],'source_manifest_sha256':hashlib.sha256(before.read_bytes()).hexdigest(),'target_absent_before_stage':not (REPO/'kernel/asterinas/target').exists(),'manifest_entry_present_before_stage':os.path.lexists(REPO/'kernel/asterinas/kernel/OSDK.toml'),'driver_script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'tool_sandbox_permissions':'require_escalated'}
save(ROOT/(stage+'-execution.json'),record)
print(json.dumps({'stage':stage,'started_at_utc':start,'source':SOURCE,'output':str(ROOT/stage),'target_absent':record['target_absent_before_stage']}),flush=True)
with (ROOT/(stage+'-driver.log')).open('wb') as log:
    child=subprocess.Popen(cmd,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    record['driver_pid']=child.pid;save(ROOT/(stage+'-execution.json'),record)
    rc=child.wait()
record.update(finished_at_utc=now(),elapsed_seconds=time.monotonic()-clock,driver_exit_code=rc)
save(ROOT/(stage+'-execution.json'),record)
after,check=capture('after-'+stage+'.json',before)
record.update(source_after=str(after),source_inputs_unchanged=check['comparison']['passed'],full_git_status_after=git('status','--porcelain=v1','--untracked-files=all'),manifest_entry_present_after_stage=os.path.lexists(REPO/'kernel/asterinas/kernel/OSDK.toml'))
save(ROOT/(stage+'-execution.json'),record)
print(json.dumps({k:record[k] for k in ['stage','source_commit','finished_at_utc','elapsed_seconds','driver_exit_code','source_inputs_unchanged','full_git_status_after','manifest_entry_present_after_stage']}),flush=True)
sys.exit(rc)
