#!/usr/bin/env python3
import datetime,hashlib,json,os,pathlib,stat,subprocess
repo=pathlib.Path('/workspace/scratch/d7da9e7650f0/a01-current')
root=repo/'support/build/out/2026-10-18-main012'
source=repo/'kernel/asterinas/target/osdk/asterinas/asterinas-osdk-bin.elf'
assert json.loads((root/'kernel-execution.json').read_text())['driver_exit_code']==0
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()=='b39e154ae5a1e9853f57e23f9bee84712ee8ef7e'
fields=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
before=source.lstat();assert stat.S_ISREG(before.st_mode)
with source.open('rb') as f:
    opened=os.fstat(f.fileno());raw=f.read();finished=os.fstat(f.fileno())
after=source.lstat();assert fields(before)==fields(opened)==fields(finished)==fields(after)
assert raw.startswith(b'\x7fELF')
out=root/'artifacts-first-build';out.mkdir(exist_ok=False)
dest=out/'kernel.elf'
with dest.open('xb') as f:f.write(raw)
dest.chmod(0o444)
assert dest.read_bytes()==raw
record={'schema':'trillionnium.a01.first-build-artifact.v1','captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':'b39e154ae5a1e9853f57e23f9bee84712ee8ef7e','source_path':str(source),'source_stat':dict(zip(['dev','ino','mode','size','mtime_ns','ctime_ns'],fields(before))),'frozen_path':str(dest),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stable_fd_and_path':True,'before_boot':True}
(out/'capture.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
