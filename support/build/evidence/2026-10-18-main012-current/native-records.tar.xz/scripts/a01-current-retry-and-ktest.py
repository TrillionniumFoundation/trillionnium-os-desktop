#!/usr/bin/env python3
import datetime,fcntl,hashlib,json,os,pathlib,stat,subprocess,sys,tempfile,time
REPO=pathlib.Path('/workspace/scratch/d7da9e7650f0/a01-current')
ROOT=REPO/'support/build/out/2026-10-18-main012'
SOURCE='b39e154ae5a1e9853f57e23f9bee84712ee8ef7e'
CAPTURE=REPO/'support/build/evidence/2026-10-18-current-main/source/capture-source.py'
MANIFEST=REPO/'kernel/asterinas/kernel/OSDK.toml'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args],text=True)
def describe(s):return {k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_size','st_mtime_ns','st_ctime_ns','st_nlink']}
def capture(name):
    path=ROOT/'source'/name
    assert not path.exists()
    cmd=[sys.executable,'-B','-I',str(CAPTURE),'--repo',str(REPO),'--compare',str(ROOT/'source/before.json')]
    with path.open('wb') as out,path.with_suffix('.stderr.log').open('wb') as err:
        p=subprocess.run(cmd,stdout=out,stderr=err)
    result=json.loads(path.read_text());assert p.returncode==0 and result['comparison']['passed']
    return result
assert git('rev-parse','HEAD').strip()==SOURCE
observed=json.loads((ROOT/'prelaunch-failure/observation.json').read_text())
transaction={'started_at_utc':now(),'operation':'reversible rename under native workspace lock; no unlink or overwrite','source_path':str(MANIFEST),'expected_observation':observed['stat'],'expected_sha256':observed['sha256'],'writer_identified':False}
with (REPO/'support/build/out-kernel.lock').open('a+b') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    fd=os.open(MANIFEST,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:
        before=os.fstat(fd);assert stat.S_ISREG(before.st_mode)
        raw=os.read(fd,before.st_size+1)
        assert describe(before)==describe(MANIFEST.lstat())
        assert before.st_dev==observed['stat']['st_dev'] and before.st_ino==observed['stat']['st_ino']
        assert hashlib.sha256(raw).hexdigest()==observed['sha256'] and len(raw)==before.st_size
        custody=pathlib.Path(tempfile.mkdtemp(prefix='quarantine-',dir=ROOT/'prelaunch-failure'))
        destination=custody/'OSDK.toml'
        assert not os.path.lexists(destination)
        os.rename(MANIFEST,destination)
        moved=destination.lstat()
        same=(moved.st_dev,moved.st_ino,moved.st_mode,moved.st_size)==(before.st_dev,before.st_ino,before.st_mode,before.st_size)
        transaction.update(destination=str(destination),before=describe(before),after=describe(moved),same_inode_mode_size=same,bytes_unchanged=destination.read_bytes()==raw,public_entry_absent=not os.path.lexists(MANIFEST))
        save(ROOT/'prelaunch-failure/quarantine.json',transaction)
        assert same and transaction['bytes_unchanged'] and transaction['public_entry_absent']
    finally:os.close(fd)
    fcntl.flock(lock,fcntl.LOCK_UN)
transaction['finished_at_utc']=now();save(ROOT/'prelaunch-failure/quarantine.json',transaction)
assert git('status','--porcelain=v1','--untracked-files=all')==''
print(json.dumps({'quarantined_original_inode':transaction['before']['st_ino'],'bytes_preserved':True,'time_utc':now()}),flush=True)

def execute(label,command,environment):
    assert git('rev-parse','HEAD').strip()==SOURCE
    pre=capture('before-'+label+'.json')
    assert pre['git_status_porcelain']==''
    assert not os.path.lexists(MANIFEST)
    rec={'schema':'trillionnium.a01.actual-stage.v1','stage':label,'source_commit':SOURCE,'project_tree':git('rev-parse','HEAD^{tree}').strip(),'kernel_tree':git('rev-parse','HEAD:kernel/asterinas').strip(),'command':command,'cwd':str(REPO),'started_at_utc':now(),'driver_script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'tool_sandbox_permissions':'require_escalated','environment':{k:environment.get(k) for k in ['CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','A01_RUN_DIR','A01_SMP','A01_QEMU_TIMEOUT','A01_KTEST_TIMEOUT','A01_BUSYBOX','A01_QEMU_BIOS','A01_QEMU_DATA_DIR','QEMU_MODULE_DIR','VDSO_LIBRARY_DIR']},'source_before':str(ROOT/'source'/('before-'+label+'.json'))}
    start=time.monotonic();save(ROOT/(label+'-execution.json'),rec)
    print(json.dumps({'stage':label,'started_at_utc':rec['started_at_utc'],'source':SOURCE}),flush=True)
    with (ROOT/(label+'-driver.log')).open('wb') as log:
        child=subprocess.Popen(command,cwd=REPO,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        rec['driver_pid']=child.pid;save(ROOT/(label+'-execution.json'),rec)
        rc=child.wait()
    rec.update(finished_at_utc=now(),elapsed_seconds=time.monotonic()-start,driver_exit_code=rc)
    save(ROOT/(label+'-execution.json'),rec)
    post=capture('after-'+label+'.json')
    rec.update(source_inputs_unchanged=post['comparison']['passed'],full_git_status_after=post['git_status_porcelain'],manifest_entry_present_after_stage=os.path.lexists(MANIFEST))
    save(ROOT/(label+'-execution.json'),rec)
    print(json.dumps({k:rec[k] for k in ['stage','finished_at_utc','elapsed_seconds','driver_exit_code','source_inputs_unchanged','full_git_status_after','manifest_entry_present_after_stage']}),flush=True)
    return rc

env=os.environ.copy();env['A01_RUN_DIR']=str(ROOT/'run_kernel_retry01')
assert not (ROOT/'run_kernel_retry01').exists()
rc=execute('run_kernel_retry01',[str(REPO/'support/build/kernel.sh'),'run_kernel'],env)
if rc:sys.exit(rc)
q=json.loads((ROOT/'run_kernel_retry01/qemu.json').read_text())
serial=(ROOT/'run_kernel_retry01/serial.log').read_bytes()
frozen=json.loads((ROOT/'artifacts-first-build/capture.json').read_text())
loaded=q['artifacts']['-kernel']
markers=['OSTD initialized. Preparing components.','TRILLIONNIUM_A01_INIT_BEGIN','TRILLIONNIUM_A01_CPU_COUNT=1','Successfully booted.','TRILLIONNIUM_A01_BOOT_OK']
counts={x:serial.count(x.encode()) for x in markers}
assert q['raw_exit_code']==33 and not q['timed_out']
assert len(serial)==q['serial_size'] and hashlib.sha256(serial).hexdigest()==q['serial_sha256']
assert frozen['bytes']==loaded['size'] and frozen['sha256']==loaded['sha256']
assert all(n==1 for n in counts.values())
summary={'passed':True,'source_commit':SOURCE,'raw_qemu_exit':33,'timed_out':False,'kernel_bytes':loaded['size'],'kernel_sha256':loaded['sha256'],'first_build_equals_loaded':True,'serial_bytes':len(serial),'serial_sha256':q['serial_sha256'],'duration_seconds':q['duration_seconds'],'marker_counts':counts,'prior_attempt_failed_before_qemu':True,'writer_identified':False}
save(ROOT/'boot-summary.json',summary);print(json.dumps({'boot_verified':summary}),flush=True)
assert not (ROOT/'ktest').exists()
env.pop('A01_RUN_DIR',None);env['A01_KTEST_TIMEOUT']='300'
rc=execute('ktest',[sys.executable,'-B','-I',str(REPO/'support/build/ktest/run.py'),'--output',str(ROOT/'ktest')],env)
if rc:sys.exit(rc)
result=json.loads((ROOT/'ktest/result.json').read_text())
print(json.dumps({'ktest_result':result}),flush=True)
