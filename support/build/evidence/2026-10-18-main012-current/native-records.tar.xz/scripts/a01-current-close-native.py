#!/usr/bin/env python3
"""Preserve post-ktest manifest and close source receipts; never unlink it."""
import datetime, fcntl, hashlib, json, os, pathlib, stat, subprocess, sys, tempfile
REPO = pathlib.Path('/workspace/scratch/d7da9e7650f0/a01-current')
ROOT = REPO / 'support/build/out/2026-10-18-main012'
MANIFEST = REPO / 'kernel/asterinas/kernel/OSDK.toml'
CAPTURE = REPO / 'support/build/evidence/2026-10-18-current-main/source/capture-source.py'
DEST = ROOT / 'post-ktest-manifest'
SOURCE = 'b39e154ae5a1e9853f57e23f9bee84712ee8ef7e'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git', '-C', str(REPO), *args], text=True)
def save(path, obj): path.write_text(json.dumps(obj, indent=2) + '\n')
def describe(s): return {k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_size','st_mtime_ns','st_ctime_ns','st_nlink']}
assert git('rev-parse', 'HEAD').strip() == SOURCE
DEST.mkdir(exist_ok=False)
record = {'schema':'trillionnium.a01.manifest-observation.v1', 'started_at_utc':now(),
          'source_commit':SOURCE, 'full_git_status_before':git('status','--porcelain=v1','--untracked-files=all'),
          'source_path':str(MANIFEST), 'writer_identified':False,
          'driver_script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
          'classification':'Observed after completed ktests; no writer attribution from inode, bytes or timestamps.'}
with (REPO/'support/build/out-kernel.lock').open('a+b') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fd = os.open(MANIFEST, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode)
        with os.fdopen(os.dup(fd), 'rb') as source: raw = source.read()
        assert describe(before) == describe(os.fstat(fd)) == describe(MANIFEST.lstat())
        assert len(raw) == before.st_size
        digest = hashlib.sha256(raw).hexdigest()
        assert digest == '1ff39174c39411f8b9a7fd328f762268e62d88521b43ebbde384d03d7d9a9f9f'
        record.update(observed_at_utc=now(), stat=describe(before), sha256=digest)
        (DEST/'OSDK.toml.observed').write_bytes(raw)
        save(DEST/'observation.json', record)
        custody = pathlib.Path(tempfile.mkdtemp(prefix='quarantine-',dir=DEST))
        target = custody/'OSDK.toml'
        assert not os.path.lexists(target)
        os.rename(MANIFEST,target)
        moved = target.lstat()
        same = (moved.st_dev,moved.st_ino,moved.st_mode,moved.st_size) == (before.st_dev,before.st_ino,before.st_mode,before.st_size)
        transaction = {'operation':'reversible rename under native workspace lock; no unlink or overwrite',
            'source_path':str(MANIFEST), 'destination':str(target), 'before':describe(before), 'after':describe(moved),
            'sha256':digest, 'same_inode_mode_size':same, 'bytes_unchanged':target.read_bytes()==raw,
            'public_entry_absent':not os.path.lexists(MANIFEST), 'finished_at_utc':now(), 'writer_identified':False}
        save(DEST/'quarantine.json',transaction)
        assert same and transaction['bytes_unchanged'] and transaction['public_entry_absent']
    finally:
        os.close(fd)
    fcntl.flock(lock,fcntl.LOCK_UN)
record.update(finished_at_utc=now(), full_git_status_after=git('status','--porcelain=v1','--untracked-files=all'))
save(DEST/'observation.json',record)
output = ROOT/'source/after-native-quarantine.json'
command = [sys.executable,'-B','-I',str(CAPTURE),'--repo',str(REPO),'--compare',str(ROOT/'source/before.json')]
with output.open('xb') as out, output.with_suffix('.stderr.log').open('xb') as err:
    result = subprocess.run(command,stdout=out,stderr=err)
receipt = json.loads(output.read_text())
assert result.returncode == 0 and receipt['comparison']['passed']
save(DEST/'closure.json', {'captured_at_utc':now(),'source_capture':str(output),
    'selected_inputs_unchanged':receipt['comparison']['passed'],'full_git_status_after':receipt['git_status_porcelain'],
    'public_manifest_present':os.path.lexists(MANIFEST),'writer_identified':False})
print(json.dumps({'quarantined_inode':before.st_ino,'selected_inputs_unchanged':True,
    'full_git_status_after':receipt['git_status_porcelain'],'manifest_present':os.path.lexists(MANIFEST)}))
