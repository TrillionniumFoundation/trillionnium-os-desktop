#!/usr/bin/env python3
"""Record one run of the existing A01 host-only acceptance suites."""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time


REPO = Path('/workspace/scratch/d7da9e7650f0/a01-current')
OUTPUT = Path('/tmp/a01-current-build-review/host-gate')
EXPECTED_HEAD = 'b39e154ae5a1e9853f57e23f9bee84712ee8ef7e'
UPSTREAM_TREE = '96605cf64aeae2d34f29b97e85eff9315fe10a8e'
SUITES = (
    ('source-inputs', 'support/build/tests/test_source_inputs.py', 10),
    ('boot-evidence', 'support/build/tests/test_boot_evidence.py', 29),
    ('kernel-runner', 'support/build/tests/test_kernel_runner.py', 42),
)
BUILD_INPUTS = {'Cargo.lock', 'osdk/Cargo.lock', 'rust-toolchain.toml',
                'Makefile', 'OSDK.toml', 'LICENSE-MPL'}
DIRECT_INPUTS = {
    'README.md', 'support/upstream-lock.json',
    'support/build/verify-source.py', 'support/build/check-boot.py',
    'support/build/record-qemu.py', 'support/build/kernel.sh',
    'support/build/kernel-supervisor.py', 'support/build/cleanup-manifest.py',
    'support/build/minimal.mk',
    'support/build/evidence/2026-10-16/acceptance/boot/serial.log',
    *(path for _, path, _ in SUITES),
}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def put(path, data):
    (OUTPUT / path).write_text(json.dumps(data, indent=2) + '\n')


def tree_entries(raw):
    entries = {}
    for entry in raw.split(b'\0'):
        if not entry:
            continue
        metadata, raw_name = entry.split(b'\t', 1)
        mode, kind, blob = metadata.decode().split()
        entries[os.fsdecode(raw_name)] = {'mode': mode, 'kind': kind, 'git_blob': blob}
    return entries


def capture(paths, expected):
    head = git('rev-parse', 'HEAD').decode().strip()
    result = {
        'captured_utc': now(), 'head': head,
        'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
        'git_status_full': git('status', '--porcelain=v1', '--untracked-files=normal').decode(),
        'git_status_tracked': git('status', '--porcelain=v1', '--untracked-files=no').decode(),
        'files': {},
    }
    for name in paths:
        path = REPO / name
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode):
            raw, mode = os.fsencode(os.readlink(path)), '120000'
        elif stat.S_ISREG(info.st_mode):
            raw = path.read_bytes()
            mode = '100755' if info.st_mode & 0o111 else '100644'
        else:
            raise RuntimeError('unexpected input file type: ' + name)
        blob = hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()
        item = {'size': len(raw), 'mode': mode, 'git_blob': blob,
                'sha256': hashlib.sha256(raw).hexdigest(),
                'expected_git_blob': expected[name]['git_blob'],
                'expected_mode': expected[name]['mode']}
        item['matches_git'] = blob == item['expected_git_blob'] and mode == item['expected_mode']
        result['files'][name] = item
    result['selected_inputs_match_git'] = all(item['matches_git'] for item in result['files'].values())
    result['tracked_clean'] = result['git_status_tracked'] == ''
    result['full_status_clean'] = result['git_status_full'] == ''
    result['files_digest'] = hashlib.sha256(json.dumps(result['files'], sort_keys=True).encode()).hexdigest()
    return result


def main():
    OUTPUT.mkdir(parents=True, exist_ok=False)
    (OUTPUT / 'tmp').mkdir(mode=0o700)
    (OUTPUT / 'fixture-boot').mkdir(mode=0o700)
    started = now()
    upstream_raw = git('ls-tree', '-rz', UPSTREAM_TREE)
    (OUTPUT / 'upstream-tree.ls-tree.z').write_bytes(upstream_raw)
    paths = sorted(DIRECT_INPUTS | {
        'kernel/asterinas/' + name for name in tree_entries(upstream_raw)
        if name in BUILD_INPUTS or name.endswith('Cargo.toml')
    })
    expected = tree_entries(git('ls-tree', '-rz', EXPECTED_HEAD, '--', *paths))
    if set(expected) != set(paths):
        raise RuntimeError('input paths do not all belong to the fixed source commit')
    before = capture(paths, expected)
    put('source-before.json', before)
    if before['head'] != EXPECTED_HEAD or not before['selected_inputs_match_git'] or not before['tracked_clean']:
        raise RuntimeError('tracked source does not match the authorized execution HEAD')
    environment = {key: value for key, value in os.environ.items()
                   if not key.startswith(('A01_', 'FIXTURE_', 'MOCK_', 'CARGO_', 'RUSTUP_'))
                   and key not in ('MAKEFLAGS', 'MFLAGS', 'GNUMAKEFLAGS', 'MAKEFILES',
                                   'MAKEOVERRIDES', 'MAKELEVEL', 'VDSO_LIBRARY_DIR', 'INITRAMFS')}
    environment.update(PATH='/usr/local/bin:/usr/bin:/bin',
                       TMPDIR=str(OUTPUT / 'tmp'),
                       A01_SNAPSHOT_TEST_OUT=str(OUTPUT / 'fixture-boot'))
    runner_raw = Path(__file__).read_bytes()
    (OUTPUT / 'run-host-gate.py').write_bytes(runner_raw)
    metadata = {
        'started_utc': started, 'repo': str(REPO), 'output': str(OUTPUT),
        'expected_head': EXPECTED_HEAD, 'python_executable': sys.executable,
        'python_version': sys.version, 'platform': sys.platform,
        'host_uname': list(os.uname()),
        'python_executable_sha256': hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        'runner_sha256': hashlib.sha256(runner_raw).hexdigest(),
        'selected_environment': {key: environment[key] for key in
                                 ('PATH', 'TMPDIR', 'A01_SNAPSHOT_TEST_OUT')},
        'fixture_isolation': {
            'source_inputs': 'read real fixed inputs, copy to TemporaryDirectory, patch verifier ROOT/SOURCE',
            'boot_evidence': 'private input/record directories, fake QEMU, read-only historical serial fixture',
            'kernel_runner': 'private copied runner and minimal.mk, fake Cargo/QEMU and private manifest',
            'no_real_kernel_or_qemu_execution': True,
            'no_write_to_shared_kernel_manifest': True,
            'parallel_native_builder_may_change_untracked_full_git_status': True,
        },
    }
    put('environment.json', metadata)
    cases = []
    for name, relative, expected_count in SUITES:
        suite = OUTPUT / name
        suite.mkdir()
        argv = [sys.executable, '-I', '-B', str(REPO / relative)]
        case = {'name': name, 'argv': argv, 'cwd': str(REPO),
                'source_path': relative, 'source_sha256': before['files'][relative]['sha256'],
                'expected_test_count': expected_count,
                'test_methods_in_source': [node.name for node in ast.walk(ast.parse((REPO / relative).read_bytes()))
                                           if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')],
                'started_utc': now(), 'timeout_seconds': 180}
        put(name + '/command.json', case)
        start = time.monotonic()
        with (suite / 'stdout.log').open('wb') as stdout, (suite / 'stderr.log').open('wb') as stderr:
            try:
                run = subprocess.run(argv, cwd=REPO, env=environment, stdout=stdout, stderr=stderr, timeout=180)
                case.update(exit_code=run.returncode, timed_out=False)
            except subprocess.TimeoutExpired:
                case.update(exit_code=124, timed_out=True)
        case.update(finished_utc=now(), duration_seconds=round(time.monotonic() - start, 6))
        stdout_raw, stderr_raw = (suite / 'stdout.log').read_bytes(), (suite / 'stderr.log').read_bytes()
        transcript = stdout_raw.decode(errors='replace') + stderr_raw.decode(errors='replace')
        matches = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', transcript, re.MULTILINE)
        case['reported_tests'] = int(matches[-1][0]) if len(matches) == 1 else None
        case['unittest_summary_matches'] = matches
        case['unittest_ok'] = re.search(r'^OK$', transcript, re.MULTILINE) is not None
        case['logs'] = {filename: {'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
                        for filename, raw in [('stdout.log', stdout_raw), ('stderr.log', stderr_raw)]}
        case['passed'] = (case['exit_code'] == 0 and not case['timed_out']
                          and case['reported_tests'] == expected_count and case['unittest_ok'])
        put(name + '/result.json', case)
        cases.append(case)
        print(json.dumps({'suite': name, 'exit_code': case['exit_code'],
                          'reported_tests': case['reported_tests'], 'passed': case['passed'],
                          'duration_seconds': case['duration_seconds']}), flush=True)
    after = capture(paths, expected)
    put('source-after.json', after)
    unchanged = (before['head'] == after['head'] == EXPECTED_HEAD
                 and before['tree'] == after['tree']
                 and before['files'] == after['files'] and after['tracked_clean'])
    result = {
        'kind': 'existing_A01_host_acceptance_once_per_suite',
        'execution_head': EXPECTED_HEAD, 'execution_tree': before['tree'],
        'started_utc': started, 'finished_utc': now(), 'input_count': len(paths),
        'input_files_unchanged': before['files'] == after['files'],
        'source_head_tree_and_tracked_inputs_unchanged': unchanged,
        'before_full_status_clean': before['full_status_clean'],
        'after_full_status_clean': after['full_status_clean'],
        'full_status_scope_note': 'untracked files from parallel native builder are preserved verbatim in source snapshots; selected tracked input comparison is independent',
        'reported_tests': sum(case['reported_tests'] or 0 for case in cases),
        'suites': cases, 'passed': unchanged and all(case['passed'] for case in cases),
        'actual_kernel_execution': False, 'actual_qemu_execution': False,
        'optimized_top_level_rerun': False,
        'existing_boot_suite_internal_modes': ['normal', '-O', '-I', '-I -O'],
    }
    put('result.json', result)
    print(json.dumps({key: result[key] for key in
                      ('execution_head', 'execution_tree', 'reported_tests', 'passed',
                       'source_head_tree_and_tracked_inputs_unchanged', 'before_full_status_clean',
                       'after_full_status_clean')}, indent=2), flush=True)
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
