# A01 host build-support gate on published source b39e154

This archive records one invocation of each existing host-only test suite at
`b39e154ae5a1e9853f57e23f9bee84712ee8ef7e`, tree
`80ceaa07562dd359572afdc6bfad473aa20d7271`.

Execution ran from 2026-10-18 08:50:42.445387 UTC through
08:51:03.820060 UTC. All three commands exited 0, without timeout:

| Existing suite | Actual unittest denominator | Result |
| --- | ---: | --- |
| `test_source_inputs.py` | 10 | passed |
| `test_boot_evidence.py` | 29 | passed |
| `test_kernel_runner.py` | 42 | passed |
| Total | 81 | passed |

`result.json` contains the complete argv, execution times, tool identity,
reported test counts and raw-log digests. Each suite directory retains its
unaltered complete stdout and stderr. Negative-case rejection messages in
`boot-evidence/stderr.log` are expected assertions in a passing suite.

Each suite was invoked once at the top level using Python `-I -B`. The existing
boot suite internally exercises its checker under normal, `-O`, `-I`, and
`-I -O` modes. Those internal modes and subtests are not additional top-level
test suites or additional kernel executions.

The before/after source snapshots bind 131 actual input files, including the
three test programs, their build-support dependencies, the 118 fixed upstream
build inputs, the original historical serial fixture and the project root
README/lock. All selected SHA256 values, Git blobs and file modes match the
published source commit and remain unchanged. HEAD and the full committed tree
also remain unchanged. Both snapshots have clean tracked status.

Both full Git status snapshots contain exactly:

```text
?? kernel/asterinas/kernel/OSDK.toml
```

The independently managed native builder was allowed to run concurrently.
These host tests do not write that shared manifest, take the live native
workspace lock, install a real SDK or execute a real kernel/QEMU. Their manifest
and runner mutations use private copied fixtures. This archive does not claim
full-worktree cleanliness or identify the writer of any untracked file solely
from Git status.

The fixture review is recorded in `environment.json`. The boot-recorder fixture
directories retain their child argv, fake-tool observations, raw output and
private artifact copies; the other existing suites clean their own
`TemporaryDirectory` fixtures normally. The private temporary root was empty
after all tests. No source file or test was changed to obtain these results.

`run-host-gate.py` is the exact controller used for this execution.
`upstream-tree.ls-tree.z` preserves the actual original-tree file listing used to
construct the 118 fixed input names. The separate outer archive manifest records
every retained regular file and its SHA256. No Rust build, actual QEMU boot,
debug matrix, full OSDK matrix or upstream kernel-mode regression result is
claimed by this host-only archive.
