#!/usr/bin/env python3
"""Read-only Git/worktree provenance audit; never executes Cargo or QEMU."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import tomllib

PIN = "c4b7ed575b7b32773475b194d2ad41fb6d03765b"
TREE = "96605cf64aeae2d34f29b97e85eff9315fe10a8e"
TOOLCHAIN = "nightly-2026-07-21"
PREVIOUS = "40c901c6e189058bdd6f42bb43bf46b3bbcf8ffa"
MAIN = "01225ab0a20a9f25dd8313a7fad7652dd9154e30"
DOCS = ["docs/agents/PLAN.md", "docs/PROJECT.md", "docs/ARCHITECTURE.md",
        "docs/NATIVE_ABI.md", "docs/ROADMAP.md", "docs/STATUS.md",
        "support/upstream-lock.json", "kernel/asterinas/AGENTS.md"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    repo = args.repo.resolve()

    def git(*cmd):
        return subprocess.check_output(["git", *cmd], cwd=repo)

    def value(*cmd):
        return git(*cmd).decode().strip()

    def entries(ref):
        result = {}
        for raw in git("ls-tree", "-r", "-z", ref).split(b"\0"):
            if not raw:
                continue
            meta, path = raw.split(b"\t", 1)
            mode, kind, oid = meta.decode().split()
            result[os.fsdecode(path)] = {"mode": mode, "kind": kind, "blob": oid}
        return result

    def stable_file(path, expected=None):
        p = repo / path
        info = p.lstat()
        if stat.S_ISLNK(info.st_mode):
            data, mode = os.fsencode(os.readlink(p)), "120000"
            after = p.lstat()
        else:
            if not stat.S_ISREG(info.st_mode):
                raise RuntimeError(f"unexpected type: {path}")
            fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(fd, "rb") as f:
                opened = os.fstat(f.fileno())
                if (info.st_dev, info.st_ino) != (opened.st_dev, opened.st_ino):
                    raise RuntimeError(f"path changed before open: {path}")
                data = f.read()
                after = os.fstat(f.fileno())
            mode = "100755" if info.st_mode & 0o111 else "100644"
        fingerprint = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        if fingerprint(info) != fingerprint(after):
            raise RuntimeError(f"file changed during read: {path}")
        oid = hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
        out = {"path": path, "bytes": len(data), "sha256": sha(data), "mode": mode, "blob": oid}
        if expected is not None:
            out["matches_head"] = (mode, oid) == (expected["mode"], expected["blob"])
        return out

    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    head = value("rev-parse", "HEAD")
    status_before = git("status", "--porcelain=v1", "--untracked-files=normal").decode()
    whole = entries(head)
    actual = entries(head + ":kernel/asterinas")
    original = entries(TREE)
    imported_tree = value("rev-parse", "7081fb9b34030af47b7a65d4e62a00fcf147de05:kernel/asterinas")
    commit_object = git("cat-file", "-p", PIN).decode()
    commit_tree = next(x.split()[1] for x in commit_object.splitlines() if x.startswith("tree "))
    current_tree = value("rev-parse", head + ":kernel/asterinas")
    changed = [{"path": p, "upstream": e, "derived": actual.get(p)}
               for p, e in original.items() if actual.get(p) != e]
    missing = [p for p in original if p not in actual]
    added = [p for p in actual if p not in original]
    mode_changed = [p for p in original if p in actual and
                    (original[p]["mode"], original[p]["kind"]) !=
                    (actual[p]["mode"], actual[p]["kind"])]
    attribution = [p for p in original if
                   Path(p).name.upper().startswith(("LICENSE", "COPYING", "NOTICE", "AUTHORS", "COPYRIGHT", "README", "AGENTS"))]
    attribution_changed = [p for p in attribution if original[p] != actual.get(p)]
    paths = [p for p in whole if p.startswith("kernel/asterinas/") or
             p.startswith("libs/os-abi/src/") or
             (p.startswith("support/build/") and not p.startswith((
                 "support/build/evidence/", "support/build/out/", "support/build/handoffs/"))) or
             p in {"README.md", "support/upstream-lock.json"}]
    files = [stable_file(p, whole[p]) for p in sorted(paths)]
    doc_records = [stable_file(p, whole[p]) for p in DOCS]
    lock = json.loads((repo / "support/upstream-lock.json").read_bytes())
    toolchain = tomllib.loads((repo / "kernel/asterinas/rust-toolchain.toml").read_text())["toolchain"]
    fixed_input_names = ["Cargo.lock", "rust-toolchain.toml", "Makefile", "OSDK.toml", "LICENSE-MPL"]
    fixed_inputs = [stable_file("kernel/asterinas/" + name, whole["kernel/asterinas/" + name])
                    for name in fixed_input_names]
    active_ostd_manifests = [p for p in whole if p.endswith("/ostd/Cargo.toml") and "/evidence/" not in p]
    active_core_manifests = [p for p in whole if p.endswith("/kernel/core/Cargo.toml") and "/evidence/" not in p]
    owner_diff = git("diff", "--name-status", MAIN, head, "--",
                     "kernel/asterinas/kernel", "kernel/asterinas/ostd", "libs/os-abi").decode()
    previous_diff = git("diff", "--name-status", PREVIOUS, head, "--",
                        "kernel/asterinas/kernel", "kernel/asterinas/ostd", "libs/os-abi").decode()
    status_after = git("status", "--porcelain=v1", "--untracked-files=normal").decode()
    head_after = value("rev-parse", "HEAD")
    tests = {
        "actual_upstream_commit_points_to_fixed_tree": commit_tree == TREE,
        "initial_import_tree_equals_upstream": imported_tree == TREE,
        "fixed_lock_source_identity": (lock["kernel"]["commit"], lock["kernel"]["tree"], lock["kernel"]["toolchain"]) == (PIN, TREE, TOOLCHAIN),
        "fixed_toolchain_file_channel": toolchain["channel"] == TOOLCHAIN,
        "full_kernel_single_root_lock": lock["kernel"].get("source_directory") == "kernel/asterinas" and lock["kernel"].get("reuse") == "full_kernel_derived",
        "single_active_kernel_and_ostd_roots": active_ostd_manifests == ["kernel/asterinas/ostd/Cargo.toml"] and active_core_manifests == ["kernel/asterinas/kernel/core/Cargo.toml"],
        "fixed_kernel_build_inputs_unchanged": all(actual[p] == original[p] for p in fixed_input_names),
        "all_upstream_files_retained": not missing,
        "upstream_modes_and_types_retained": not mode_changed,
        "attribution_files_retained_unchanged": not attribution_changed,
        "captured_worktree_inputs_match_head": all(x["matches_head"] for x in files),
        "root_readme_empty": (repo / "README.md").stat().st_size == 0,
        "current_main_owner_sources_preserved": not owner_diff,
        "head_unchanged_during_audit": head == head_after,
        "status_unchanged_during_audit": status_before == status_after,
    }
    report = {
        "schema": 1, "scope": "read-only source audit; no new Rust, native kernel, QEMU or regression execution",
        "started_at_utc": started, "finished_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "repo": str(repo), "head": head, "project_tree": value("rev-parse", head + "^{tree}"),
        "head_after": head_after, "main_baseline": MAIN, "previous_native_producer": PREVIOUS,
        "kernel_tree": current_tree, "upstream_commit": PIN, "upstream_tree": TREE,
        "upstream_commit_object": commit_object, "upstream_commit_object_sha256": sha(commit_object.encode()),
        "toolchain": toolchain, "original_files": len(original), "derived_files": len(actual),
        "fixed_kernel_build_inputs": fixed_inputs,
        "active_ostd_manifests": active_ostd_manifests, "active_core_manifests": active_core_manifests,
        "unchanged_upstream_files": len(original) - len(changed), "changed_upstream_files": changed,
        "missing_upstream_files": missing, "new_derived_files": added, "mode_or_type_changes": mode_changed,
        "attribution_file_count": len(attribution), "attribution_paths": attribution,
        "changed_attribution_files": attribution_changed, "main_owner_diff": owner_diff,
        "previous_native_owner_diff": previous_diff, "source_file_count": len(files),
        "source_manifest_sha256": sha(json.dumps(files, sort_keys=True, separators=(",", ":")).encode()),
        "source_files": files, "documents_read": doc_records,
        "status_before": status_before, "status_after": status_after,
        "full_worktree_clean_at_each_observation": status_before == "" and status_after == "",
        "checks": tests, "passed": all(tests.values()),
        "script_sha256": sha(Path(__file__).read_bytes()),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print(json.dumps({k: v for k, v in report.items() if k in {
        "head", "project_tree", "kernel_tree", "original_files", "derived_files", "unchanged_upstream_files",
        "source_file_count", "source_manifest_sha256", "attribution_file_count", "checks", "passed"}}, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
