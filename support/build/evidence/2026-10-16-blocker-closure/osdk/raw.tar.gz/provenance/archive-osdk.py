#!/usr/bin/env python3
"""Retain the two completed/cancelled TCP attempts; no tools or guests launched."""
from pathlib import Path
import gzip,hashlib,io,json,os,re,stat,subprocess,tarfile
BASE=Path(__file__).resolve().parent.parent
REPO=BASE/'trillionnium-os-desktop'
SCRATCH=BASE/'blocker-closure'
DEST=REPO/'support/build/evidence/2026-10-16-blocker-closure/osdk'
HEAD='071dd8edcd2a3cf9b33dbbeab713428317b9b76c';TREE='5268494bc732e2f39b319248ec4a4dc1705d8d75'
EXCLUDE={'target','.git','__pycache__'}
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  before=os.fstat(fd)
  if not stat.S_ISREG(before.st_mode) or before.st_size>30*1024*1024:raise RuntimeError('unexpected input type/size: '+str(path))
  chunks=[]
  while True:
   data=os.read(fd,1024*1024)
   if not data:break
   chunks.append(data)
  after=os.fstat(fd)
 finally:os.close(fd)
 fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 if fields(before)!=fields(after):raise RuntimeError('changed during capture: '+str(path))
 return b''.join(chunks)
def write(path,data):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2)+'\n')
raw=[];omissions=[];run_counts={}
for label in ['01','02']:
 root=REPO/'support/build/out'/('closure-tcp-full-'+label);count=0
 for current,dirs,files in os.walk(root,followlinks=False):
  current=Path(current)
  for name in list(dirs):
   path=current/name;relative=path.relative_to(root).as_posix()
   if name in EXCLUDE or path.is_symlink():
    dirs.remove(name);omissions.append({'attempt':label,'path':relative,'type':'directory-symlink' if path.is_symlink() else 'excluded-directory','reason':'external symlink not followed' if path.is_symlink() else 'cache/VCS/bytecode excluded','link_target':os.readlink(path) if path.is_symlink() else None})
  dirs.sort()
  for name in sorted(files):
   path=current/name;relative=path.relative_to(root).as_posix()
   if path.is_symlink():
    omissions.append({'attempt':label,'path':relative,'type':'file-symlink','link_target':os.readlink(path),'reason':'external tool/source link not followed'});continue
   data=read(path);raw.append(('attempt-'+label+'/'+relative,data,str(path),'actual non-cache output file'));count+=1
 run_counts[label]=count
for relative in ['integration-controller/result.json','integration-controller/console.log','integration-controller/tool-session-cancellation.json','integration2-controller/result.json','integration2-controller/console.log','run-validation.py','run-validation-attempt1.py','publication-receipt.json']:
 path=SCRATCH/relative;raw.append(('observer/'+relative,read(path),str(path),'original controller/entry source or publisher receipt'))
raw.append(('provenance/archive-osdk.py',read(Path(__file__)),str(Path(__file__)),'actual archive controller; no guest/test invocation'))
byname={name:data for name,data,*_ in raw}
latest=json.loads(byname['attempt-02/result.json']);first_controller=json.loads(byname['observer/integration-controller/result.json']);last_controller=json.loads(byname['observer/integration2-controller/result.json']);cancel=json.loads(byname['observer/integration-controller/tool-session-cancellation.json'])
if first_controller['returncode'] is not None or last_controller['returncode']!=0 or cancel['actual_write_stdin_ctrl_c_exit']!=130 or cancel['actual_unified_exec_session']!=79437:raise RuntimeError('outer attempt states')
for entry in [first_controller,last_controller]:
 if entry['git_head']!=HEAD or entry['git_tree']!=TREE:raise RuntimeError('runtime source binding')
if latest['passed']!=22 or latest['failed'] or latest['selected_cases']!=22 or latest['soft_skip_count']!=1 or len(latest['cases'])!=22 or len({c['name'] for c in latest['cases']})!=22:raise RuntimeError('case summary')
cases=[];guests=[]
for i,case in enumerate(latest['cases'],1):
 prefix='attempt-02/case-'+str(i).zfill(2)
 own=json.loads(byname[prefix+'/result.json'])
 if own!=case or case['status']!='passed' or case['raw_exit_code']!=0 or case['timed_out'] or not case['group_cleanup']['leader_reaped']:raise RuntimeError('case mismatch: '+case['name'])
 log=byname[prefix+'/harness.log'].decode(errors='replace')
 if not re.search(r'test result: ok\. 1 passed; 0 failed;',log):raise RuntimeError('harness result missing')
 actual_records=sorted(name for name in byname if name.startswith(prefix+'/guests/') and name.endswith('/qemu.json'))
 if len(actual_records)!=len(case['guests']):raise RuntimeError('guest count')
 for member in actual_records:
  qemu=json.loads(byname[member]);root=Path(member).parent
  if qemu['raw_exit_code']!=33 or qemu['wrapper_exit_code']!=33 or qemu['timed_out'] or qemu.get('error') or qemu['profile_id']!=latest['profile_id']:raise RuntimeError('guest status')
  verified=[]
  for stream in qemu['serial_logs']+list(qemu['stream_logs'].values()):
   name=(root/Path(stream['path']).name).as_posix();data=byname[name]
   if len(data)!=stream['size'] or sha(data)!=stream['sha256']:raise RuntimeError('guest stream mismatch: '+name)
   verified.append({'member':name,'bytes':len(data),'sha256':sha(data)})
  serial=byname[(root/'serial.log').as_posix()];plain=re.sub(r'\x1b\[[0-9;]*m','',serial.decode(errors='replace'))
  summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) filtered out\.',plain)
  guests.append({'case':case['name'],'qemu_record':member,'raw_exit_code':33,'wrapper_exit_code':33,'timed_out':False,'qemu_pid':qemu['qemu_pid'],'verified_streams':verified,'upstream_guest_test_summaries':summaries,'soft_skips':case['soft_skips']})
 cases.append({'case':case['name'],'status':case['status'],'raw_exit_code':0,'guests':len(case['guests']),'soft_skips':case['soft_skips'],'result_member':prefix+'/result.json','harness_log_member':prefix+'/harness.log'})
if len(guests)!=11:raise RuntimeError('expected 11 actual guests')
coverage=json.loads(byname['attempt-02/case-15/coverage/result.json']);sidecar_data=byname['attempt-02/case-15/guests/guest-001/coverage-capture.json'];sidecar=json.loads(sidecar_data);observations=json.loads(byname['attempt-02/case-15/guests/guest-001/capture-gdb-observations.json'])
rawprof=byname['attempt-02/case-15/coverage/coverage.profraw'];profdata=byname['attempt-02/case-15/coverage/coverage.profdata'];llvm=byname['attempt-02/case-15/coverage/llvm-profdata-1.log'].decode()
functions=[int(x) for x in re.findall(r'^\s*Function count: (\d+)\s*$',llvm,re.M)]
footer_total=int(re.search(r'^Total count: (\d+)$',llvm,re.M).group(1))
if not coverage['passed'] or coverage['source_osdk_exit_code']!=0 or coverage['source_preexisted'] or len(rawprof)!=coverage['size'] or sha(rawprof)!=coverage['sha256'] or sha(sidecar_data)!=coverage['guest_binding']['capture_sidecar_sha256'] or not sidecar['passed'] or not sidecar['finalized'] or sidecar['gdb_exit_code']!=0 or not observations['passed'] or observations['breakpoint']['actual_pc']!=observations['breakpoint']['resolved_address'] or not sidecar['resumed_by_detach']:raise RuntimeError('coverage binding failed')
if len(functions)!=coverage['total_functions'] or max(functions)!=coverage['maximum_function_count'] or not functions or not all(x['raw_exit_code']==0 for x in coverage['commands']):raise RuntimeError('LLVM evidence')
coverage_metrics={'profile_function_entries':len(functions),'nonzero_profile_function_entries':sum(x>0 for x in functions),'maximum_function_count':max(functions),'sum_of_function_entry_counts':sum(functions),'llvm_footer_total_count':footer_total,'coverage_percentage_claimed':False,'profraw_bytes':len(rawprof),'profraw_sha256':sha(rawprof),'profdata_bytes':len(profdata),'profdata_sha256':sha(profdata),'source_osdk_exit_code':0,'gdb_exit_code':0,'llvm_merge_and_show_exits':[x['raw_exit_code'] for x in coverage['commands']],'actual_pc':observations['breakpoint']['actual_pc'],'resolved_pc':observations['breakpoint']['resolved_address'],'capture_resumed_by_detach':True}
# Bind runtime source hashes against immutable Git objects, never live WIP.
environments=[json.loads(byname['attempt-'+label+'/environment.json']) for label in ['01','02']]
bindings={}
for env in environments:
 if env['git_head']!=HEAD:raise RuntimeError('environment source')
 for group,prefix in [('runner_inputs_sha256',''),('test_inputs_sha256','kernel/asterinas/'),('source_inputs_sha256','kernel/asterinas/'),('local_align_ext_inputs_sha256','kernel/asterinas/')]:
  for relative,digest in env[group].items():
   path=prefix+relative
   if path in bindings and bindings[path]!=digest:raise RuntimeError('attempt input hash disagreement')
   bindings[path]=digest
 bindings['kernel/asterinas/Cargo.lock']=env['seed_lock_sha256']
source_bindings=[]
for path,expected in sorted(bindings.items()):
 p=subprocess.run(['git','cat-file','blob',HEAD+':'+path],cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode or sha(p.stdout)!=expected:raise RuntimeError('committed source differs from runtime: '+path)
 source_bindings.append({'path':path,'bytes':len(p.stdout),'sha256':sha(p.stdout),'git_blob':hashlib.sha1(b'blob '+str(len(p.stdout)).encode()+b'\0'+p.stdout).hexdigest(),'matches_both_runtime_inputs':True})
publication=json.loads(byname['observer/publication-receipt.json'])
if publication['remote_commit']!=HEAD or publication['tree']!=TREE or not publication['remote_git_tree_parents_message_verified']:raise RuntimeError('publication')
DEST.mkdir(parents=True,exist_ok=False)
index=[]
with (DEST/'.raw.tar.gz.tmp').open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|') as tar:
   for name,data,origin,classification in raw:
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.uid=info.gid=info.mtime=0
    tar.addfile(info,io.BytesIO(data));index.append({'member':name,'bytes':len(data),'sha256':sha(data),'original_path':origin,'classification':classification})
 stream.flush();os.fsync(stream.fileno())
os.replace(DEST/'.raw.tar.gz.tmp',DEST/'raw.tar.gz')
with tarfile.open(DEST/'raw.tar.gz','r:gz') as tar:
 members=tar.getmembers()
 if len(members)!=len(index):raise RuntimeError('raw member count')
 for member,expected in zip(members,index,strict=True):
  data=tar.extractfile(member).read()
  if not member.isfile() or member.name!=expected['member'] or len(data)!=expected['bytes'] or sha(data)!=expected['sha256']:raise RuntimeError(member.name)
write(DEST/'members.json',{'archive':'raw.tar.gz','sha256':sha((DEST/'raw.tar.gz').read_bytes()),'bytes':(DEST/'raw.tar.gz').stat().st_size,'members':index,'member_count':len(index),'atomic_write_and_reopen_verified':True})
write(DEST/'exclusions.json',{'directory_names':sorted(EXCLUDE),'excluded_entries':omissions,'no_external_symlink_followed':True,'excluded_original_target_cache':str(REPO/'support/build/out/osdk-capture-v2-02/target'),'small_harness_and_work_inputs_retained':True})
readables=['attempt-02/result.json','attempt-02/environment.json','attempt-02/harness-lock.json','attempt-02/harness-adaptation.patch','attempt-02/case-15/coverage/result.json','attempt-02/case-15/guests/guest-001/coverage-capture.json','attempt-02/case-15/guests/guest-001/capture-gdb-observations.json','attempt-01/environment.json','attempt-01/case-01/result.json','attempt-01/case-01/guests/guest-001/qemu.json','observer/integration-controller/result.json','observer/integration-controller/tool-session-cancellation.json','observer/integration2-controller/result.json','observer/integration2-controller/console.log']
readable_index=[]
for member in readables:
 path=DEST/'readable'/member;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(byname[member]);readable_index.append({'path':path.relative_to(DEST).as_posix(),'member':member,'bytes':len(byname[member]),'sha256':sha(byname[member])})
write(DEST/'readable-index.json',readable_index)
coverage_artifacts=[]
for name,data in [('coverage.profraw',rawprof),('coverage.profdata',profdata)]:
 path=DEST/'coverage'/(name+'.gz');path.parent.mkdir(exist_ok=True);path.write_bytes(gzip.compress(data,mtime=0))
 if gzip.decompress(path.read_bytes())!=data:raise RuntimeError('coverage gzip')
 coverage_artifacts.append({'path':path.relative_to(DEST).as_posix(),'bytes':len(data),'sha256':sha(data),'gzip_bytes':path.stat().st_size,'gzip_sha256':sha(path.read_bytes()),'raw_member':'attempt-02/case-15/coverage/'+name})
write(DEST/'coverage/artifacts.json',{'metrics':coverage_metrics,'artifacts':coverage_artifacts,'no_tool_or_VM_rerun':True})
write(DEST/'cases.json',{'profile_id':latest['profile_id'],'cases':cases,'guests':guests,'passed_cases':22,'soft_skip_cases':1,'cases_without_soft_skip':21,'guest_launches':11,'raw_qemu_exits':[33]*11})
write(DEST/'source-binding.json',{'runtime_commit':HEAD,'runtime_tree':TREE,'immutable_git_blob_bindings':source_bindings,'bound_input_count':len(source_bindings),'publication_receipt_member':'observer/publication-receipt.json','publication_receipt_sha256':sha(byname['observer/publication-receipt.json']),'controller_source_members':['observer/run-validation-attempt1.py','observer/run-validation.py'],'controller_source_note':'Original controller sources preserved; no controller-source SHA was recorded inside the original outer result, so no invented execution-time SHA binding is claimed.','runtime_environment_members':['attempt-01/environment.json','attempt-02/environment.json'],'Git_readonly_check':'git cat-file blob COMMIT:path; no Git writes or live working-tree input used.'})
write(DEST/'outer-observations.posthoc.json',{'classification':'Parent-reported actual tool observations; separate from original controllers','completed_attempt':{'actual_tool_session':57340,'actual_exit_code':0,'original_controller_member':'observer/integration2-controller/result.json','original_controller_returncode':0},'cancelled_attempt':{'actual_tool_session':79437,'actual_ctrl_c_exit':130,'original_controller_member':'observer/integration-controller/result.json','original_controller_returncode':None,'cancellation_supplement_member':'observer/integration-controller/tool-session-cancellation.json','graceful_cleanup_proven':False,'last_case_status':'running','last_qemu_raw_exit_code':None,'overall_result_present':False}})
write(DEST/'report.json',{'runtime_commit':HEAD,'runtime_tree':TREE,'profile_id':latest['profile_id'],'profile_scope':latest['scope'],'completed_attempt':{'attempt':'02','selected_cases':22,'passed':22,'failed':0,'blocked':0,'soft_skip_cases':1,'guest_launches':11,'all_actual_raw_qemu_exits':33,'outer_exit':0,'case_detail':'cases.json'},'first_attempt':{'attempt':'01','status':'cancelled_by_tool_ctrl_c','tool_exit':130,'original_controller_returncode':None,'last_case_status':'running','last_qemu_raw_exit_code':None,'graceful_cleanup_claimed':False},'coverage':coverage_metrics,'source_binding':'source-binding.json','raw_archive':'raw.tar.gz','raw_member_index':'members.json','readable_index':'readable-index.json','exclusions':'exclusions.json','source_run_file_counts':run_counts,'target_cache_reused':True,'fresh_target_claim':False,'no_complete_Asterinas_kernel_acceptance_claim':True,'no_default_Unix_or_v1_result_rewritten':True,'debug_artifacts_not_read_or_archived':True})
write(DEST/'archive-validation.json',{'raw_members':len(index),'atomic_install_and_reopen_verified':True,'all_raw_member_names_types_sizes_sha256_match':True,'readable_duplicates':len(readable_index),'verified_actual_guest_records':len(guests),'all_serial_and_stdout_stderr_record_size_sha_match':True,'coverage_raw_and_profdata_gzip_roundtrip_verified':True,'immutable_source_blob_bindings':len(source_bindings),'original_controller_null_and_first_case_running_preserved':True,'no_new_Cargo_VM_or_project_tools_executed':True})
(DEST/'README.md').write_text('''# Actual opt-in TCP OSDK integration closure\n\nSource [`071dd8ed`](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/commit/071dd8edcd2a3cf9b33dbbeab713428317b9b76c), tree `5268494bc732e2f39b319248ec4a4dc1705d8d75`, ran the explicit `--local-tcp --coverage-gdb` profile `osdk-native-local-tcp-gdb-capture-v2`. The second attempt completed **22/22 exact cases**, with **11 real QEMU launches returning raw33** and no timeout. The single hypervisor-example soft skip is retained as VMX unavailable, not hardware VMX acceptance. [Case/guest bindings](cases.json), [original result](readable/attempt-02/result.json), [environment](readable/attempt-02/environment.json) and [source binding](source-binding.json) retain their actual evidence. This tests OSDK example kernels/tooling, not the complete Asterinas kernel. It does not replace old Unix/default or v1 failures. The shared Cargo target was reused; no clean-target claim is made.\n\nThe first attempt is preserved separately and remains incomplete. Its [original controller](readable/observer/integration-controller/result.json) has `returncode:null`, [last case](readable/attempt-01/case-01/result.json) remains `running`, [last QEMU record](readable/attempt-01/case-01/guests/guest-001/qemu.json) has raw exit null, and there is no overall result. The actual tool Ctrl+C returned **130** (session79437), as retained in the [cancellation supplement](readable/observer/integration-controller/tool-session-cancellation.json). No normal descendant cleanup or test pass/fail is inferred. The separate [second controller](readable/observer/integration2-controller/result.json) records0, and parent tool session57340 also actually returned0; [posthoc outer observations](outer-observations.posthoc.json) keep those layers distinct. The second attempt added the prepared GDB PATH/library environment. Original records were not rewritten.\n\nCoverage used a real GDB breakpoint at `ostd::arch::power::try_poweroff`, actual/resolved PC `0xffffffff880edfc0`, saved memory after the live announcement, then detached to let the unchanged debug-exit device produce raw33. GDB, source OSDK and both LLVM commands returned0. [Capture record](readable/attempt-02/case-15/guests/guest-001/coverage-capture.json), [GDB observations](readable/attempt-02/case-15/guests/guest-001/capture-gdb-observations.json), and [coverage validation](readable/attempt-02/case-15/coverage/result.json) bind the same kernel, symbols, serial and raw profile. [Compressed profraw/profdata and hashes](coverage/artifacts.json) preserve the actual bytes. Parsed LLVM output reports5696 function entries (all5696 nonzero), maximum function count383731, function-entry sum18573357, and separate LLVM footer total count23459710. These are profile counters, not a whole-program coverage percentage.\n\n[Raw archive](raw.tar.gz) contains both non-cache output trees, including small isolated harness/work source inputs, all original commands/logs/serial/locks/adaptation patches, the original two controller sources, and their controller/cancellation records. [Member index](members.json) binds every original byte and stable relative name; [readable index](readable-index.json) exposes core JSON and the completion console directly. Target/.git/bytecode and external symlinks are excluded explicitly in [exclusions](exclusions.json); links are recorded without following them. No compiler target or tool binary is copied. Debug outputs are outside this archive's scope and were not read. Source hashes were checked against immutable Git blobs, without reading current WIP or modifying Git.\n\nThe raw bundle was installed atomically then reopened and checked member by member. [Archive validation](archive-validation.json) records those checks; [SHA256SUMS](SHA256SUMS) is frozen after independent read-only review. All original absolute execution paths remain historical facts, with relative archive members and links supplied for retained evidence. Packaging ran no new Cargo, VM, LLVM/GDB tool or test and wrote only this evidence subdirectory.\n''')
size=sum(p.stat().st_size for p in DEST.rglob('*') if p.is_file())
if size>=30*1024*1024:raise RuntimeError('archive exceeds requested budget')
print(json.dumps({'packaged':True,'destination':str(DEST),'raw_members':len(index),'noncache_files':run_counts,'raw_bytes':(DEST/'raw.tar.gz').stat().st_size,'total_bytes_before_freeze':size,'coverage':coverage_metrics,'source_binding_count':len(source_bindings),'pending':'readonly review and final SHA256SUMS'}),flush=True)
