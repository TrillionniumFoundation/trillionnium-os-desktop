#!/usr/bin/env python3
"""Probe the unwrapped public CLI using deliberately failing host tool fixtures."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop')
records = []
for phase in ('baseline', 'fixed'):
    for entry in ('integration', 'debug'):
        for mode, flags in (('I', ['-I']), ('IO', ['-I', '-O'])):
            for label, value in (('empty', ''), ('nonempty', '-Copt-level=0\x1f--cfg=host_fixture')):
                work = ROOT / 'direct-cli' / phase / f'{entry}-{mode}-{label}'
                work.mkdir(parents=True, exist_ok=False)
                project = work / 'fixture-project'
                relative = f'support/build/{"osdk-integration" if entry == "integration" else "debug"}/run.py'
                script = project / relative
                script.parent.mkdir(parents=True)
                (project / 'kernel/asterinas').mkdir(parents=True)
                source = ROOT / 'baseline' / f'{entry}-run.py' if phase == 'baseline' else REPO / relative
                shutil.copyfile(source, script)
                marker = work / 'external-tool-started'
                fake = (project / 'host-rustup/toolchains/nightly-2026-07-21-x86_64-unknown-linux-gnu/bin/rustc'
                        if entry == 'integration' else project / 'host-tools/gdb-nm')
                fake.parent.mkdir(parents=True)
                fake.write_text('#!' + sys.executable + '\nfrom pathlib import Path\nimport sys\n'
                                f'Path({str(marker)!r}).write_text("host tool fixture executed\\n")\n'
                                'print("deliberate host tool fixture failure before any Cargo or VM")\n'
                                'raise SystemExit(19)\n')
                fake.chmod(0o755)
                output = work / 'output-parent/evidence'
                command = [sys.executable, *flags, str(script), '--output', str(output)]
                if entry == 'debug':
                    command += ['--gdb', str(fake), '--nm', str(fake)]
                env = os.environ.copy()
                env.update(CARGO_ENCODED_RUSTFLAGS=value, RUSTUP_HOME=str(project / 'host-rustup'),
                           CARGO_HOME=str(project / 'host-cargo'))
                result = subprocess.run(command, cwd=project, env=env, stdout=subprocess.PIPE,
                                        stderr=subprocess.STDOUT, timeout=15)
                (work / 'console.log').write_bytes(result.stdout)
                observation = {'phase': phase, 'entry': entry, 'mode': mode, 'encoded_label': label,
                    'kind': 'unwrapped_public_cli_with_executable_host_tool_fixture_no_Cargo_no_VM',
                    'argv': command, 'cwd': str(project), 'returncode': result.returncode,
                    'selected_environment': {key: env.get(key) for key in
                        ('CARGO_ENCODED_RUSTFLAGS', 'RUSTUP_HOME', 'CARGO_HOME')},
                    'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                    'fake_tool_sha256': hashlib.sha256(fake.read_bytes()).hexdigest(),
                    'output_exists': output.exists(), 'output_parent_exists': output.parent.exists(),
                    'integration_lock_exists': (project / 'support/build/out-osdk-integration.lock').exists(),
                    'external_tool_started': marker.exists()}
                expected = (result.returncode == 1 and output.exists() and marker.exists()
                            if phase == 'baseline' else
                            result.returncode == 2 and not output.parent.exists() and not marker.exists()
                            and not observation['integration_lock_exists'])
                observation['expected_observation_passed'] = expected
                (work / 'observation.json').write_text(json.dumps(observation, indent=2) + '\n')
                records.append(observation)
                if not expected:
                    raise RuntimeError(json.dumps(observation))
(ROOT / 'direct-cli-results.json').write_text(json.dumps({'observations': records,
    'all_expected_observations_passed': True, 'baseline_probes': 8, 'fixed_probes': 8}, indent=2) + '\n')
print('PASS: 8 baseline unwrapped CLI probes started fake tools and consumed output; '
      '8 fixed probes rejected before output/lock/tools.')
