host entry fixture, not kernel source or ELF
