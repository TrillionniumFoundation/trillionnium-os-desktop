import importlib.util,sys,types
from pathlib import Path
spec=importlib.util.spec_from_file_location('entry_fixture','/workspace/scratch/ae1a8cf05419/closure-entry-guards/green/debug-I/fixtures/debug-empty/fixture-project/support/build/debug/run.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
# This fixture tests entry ordering only; no tools, Cargo, GDB, or VM execute.
class HostSession:
 def __init__(self,*args,**kwargs):
  Path('/workspace/scratch/ae1a8cf05419/closure-entry-guards/green/debug-I/fixtures/debug-empty/work-started').write_text('host OwnedSession fixture, no child tools or VM\n')
  self.process=types.SimpleNamespace(pid=42);self.reaped=False;self.external_reap=False
 def wait(self,*args): self.reaped=True;return 0
 def stop(self): self.reaped=True;return 0
module.OwnedSession=HostSession
module.shutil.which=lambda name: sys.executable
module.subprocess.check_output=lambda *args,**kwargs: 'host-fixture\n'
module.wait_for_qemu=lambda *args: {'host_fixture':True}
module.entry_address=lambda *args: 4096
module.bind_entry_artifacts=lambda *args: {'symbol_artifact':{'host_fixture':True},'expected_bytes':'00'*32}
module.accept_gdb=lambda *args: {'host_fixture':True}
module.accept_boot=lambda *args: {'host_fixture':True}
sys.argv=['/workspace/scratch/ae1a8cf05419/closure-entry-guards/green/debug-I/fixtures/debug-empty/fixture-project/support/build/debug/run.py',*sys.argv[1:]]
raise SystemExit(module.main())
