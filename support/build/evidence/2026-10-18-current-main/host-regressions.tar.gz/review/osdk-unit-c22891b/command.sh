source /workspace/scratch/d7da9e7650f0/a01-runtime/env.sh
CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/workspace/scratch/d7da9e7650f0/a01-runtime/osdk-unit-target cargo +nightly-2026-07-21 test --manifest-path kernel/asterinas/osdk/Cargo.toml --locked --bin cargo-osdk -- --test-threads=1
