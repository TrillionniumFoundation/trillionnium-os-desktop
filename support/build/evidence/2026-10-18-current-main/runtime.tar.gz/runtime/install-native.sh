#!/usr/bin/env bash
set -euo pipefail
runtime_dir=/workspace/scratch/d7da9e7650f0/a01-runtime
exec > >(tee "$runtime_dir/logs/native-install.log") 2>&1
set -x
date -u --iso-8601=seconds
cp /etc/apt/sources.list.d/caas-snapshot.list "$runtime_dir/apt/sources.list"
apt_options=(-o "Dir::Etc::sourcelist=$runtime_dir/apt/sources.list" -o 'Dir::Etc::sourceparts=-' -o "Dir::State=$runtime_dir/apt/state" -o 'Dir::State::status=/var/lib/dpkg/status' -o "Dir::Cache=$runtime_dir/apt/cache" -o "Dir::Log=$runtime_dir/logs" -o 'APT::Sandbox::User=root')
apt-get "${apt_options[@]}" update
apt-get "${apt_options[@]}" --download-only --yes --no-install-recommends --no-remove install qemu-system-x86 seabios busybox-static cpio clang lld pkg-config libssl-dev gdb
for deb in "$runtime_dir"/apt/cache/archives/*.deb; do
    dpkg-deb --extract "$deb" "$runtime_dir/rootfs"
done
sha256sum "$runtime_dir"/apt/cache/archives/*.deb > "$runtime_dir/downloads/deb-SHA256SUMS"
python3 - "$runtime_dir" <<'PY'
import json
from pathlib import Path
import subprocess
import sys
root = Path(sys.argv[1])
records = []
for path in sorted((root / 'apt/cache/archives').glob('*.deb')):
    values = subprocess.check_output(['dpkg-deb', '--show', '--showformat=${Package}\t${Version}\t${Architecture}\n', str(path)], text=True).strip().split('\t')
    records.append(dict(zip(('package', 'version', 'architecture'), values), file=str(path)))
(root / 'native-packages.json').write_text(json.dumps(records, indent=2) + '\n')
print(f'Extracted {len(records)} native packages without installing them into the host.')
PY
date -u --iso-8601=seconds
