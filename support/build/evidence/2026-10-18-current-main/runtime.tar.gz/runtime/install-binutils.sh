#!/usr/bin/env bash
set -euo pipefail
runtime_dir=/workspace/scratch/d7da9e7650f0/a01-runtime
source "$runtime_dir/env.sh"
exec > >(tee "$runtime_dir/logs/cargo-binutils-install.log") 2>&1
set -x
date -u --iso-8601=seconds
cargo +nightly-2026-07-21 install cargo-binutils --version 0.4.0 --locked
cargo install --list
rust-strip --version
date -u --iso-8601=seconds
