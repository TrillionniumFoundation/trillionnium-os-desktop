# Independent A04 exact-input verifier review

Reviewed source SHA256: `534b5fb52b71a9b35f56a71942bf43b525f84f74c87efec0dc5c952e12374752`.

The fixed Git artifact was independently retrieved with the verifier's bounded command, validated against size/Git blob/SHA256, and decoded as the exact original 8,837,120-byte USTAR. All 17 manifest files and four ELF hashes matched. Every original member header was independently checked for USTAR magic. No payload was executed and no QEMU was run.

Nineteen positive and negative checks passed. These cover the real pinned artifact, expected size/hash mismatch, decompression length bound, manifest size/mode/hash mismatch, duplicated manifest member, unsafe/reserved ELF output name, exclusive output modes, existing output and symlink refusal, partial-write failure marker, and nonblocking metadata FIFO rejection. `review-results.json` is the raw result.

One additional adversarial case exposed a correctness gap: a same-UID writer changes a just-written output after flush/fsync but before the first recorded fstat. `write_outputs` accepted the changed same-length bytes and removed its incomplete marker, since it checked file identity and size but never compared written content to the requested payload. The deterministic injected writer temporarily sets mode 0600, writes replacement bytes, and restores 0400 inside an fsync hook. This hook represents the timing of an independent writer; it does not execute any ELF or modify repository code. `output-race-reproduction.py` and `.json` preserve the counterexample.

The input archive and manifest checks remain valid. The counterexample concerns the output acceptance claim. A content readback through the retained output descriptor, checked for equality and stable stat before/after readback, is needed before recording the baseline identity. Existing final identity and link checks should remain. Any success describes a point-in-time check; same-UID mutable storage is not an immutable artifact boundary.

This is a read-only repository review. All test fixtures and records were written outside the repository.
