import hashlib, importlib.util, json, os, pathlib, sys
sys.dont_write_bytecode=True
root=pathlib.Path('/workspace/scratch/ae1a8cf05419/a04-verifier-independent-review')
source=pathlib.Path('/workspace/scratch/ae1a8cf05419/trillionnium-os-desktop/support/build/handoffs/a04-exact-rootfs/verify.py')
spec=importlib.util.spec_from_file_location('verify_output_race',source); v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
dest=root/'concurrent-output-race'
original=b'original fixture bytes'
replacement=b'REPLACED fixture bytes'
assert len(original)==len(replacement)
actual_fsync=os.fsync
injected=False
def concurrent_writer_hook(fd):
    global injected
    actual_fsync(fd)
    p=dest/'rootfs.tar'
    if not injected and p.exists():
        os.chmod(p,0o600)
        with p.open('r+b') as stream:
            stream.write(replacement); stream.flush(); actual_fsync(stream.fileno())
        os.chmod(p,0o400)
        injected=True
v.os.fsync=concurrent_writer_hook
v.write_outputs(dest,{'rootfs.tar':original,'verification.json':b'{"expected":"original fixture bytes"}\n'})
observed=(dest/'rootfs.tar').read_bytes()
report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'hook':'same UID modification after stream.flush/os.fsync, before captured fstat','method_returned_success':True,'incomplete_marker_present':(dest/v.MARKER).exists(),'requested_sha256':hashlib.sha256(original).hexdigest(),'written_sha256':hashlib.sha256(observed).hexdigest(),'bytes_match':original==observed,'mode':oct((dest/'rootfs.tar').stat().st_mode & 0o777),'payload_executed':False,'qemu_run':False}
(root/'output-race-reproduction.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2,sort_keys=True))
assert injected and original!=observed and not (dest/v.MARKER).exists()
